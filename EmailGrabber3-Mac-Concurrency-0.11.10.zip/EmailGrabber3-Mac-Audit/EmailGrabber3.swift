import SwiftUI
import AppKit
import Foundation
import UniformTypeIdentifiers

@MainActor final class GrabberModel: ObservableObject {
    @Published var mode: SourceMode = .website { didSet { scheduleAutosave() } }
    @Published var input = "" { didSet { scheduleAutosave() } }
    @Published var excluded = "noreply@\nno-reply@" { didSet { scheduleAutosave() } }
    @Published var depth = 0 { didSet { scheduleAutosave() } }
    @Published var maxPages = 0 { didSet { scheduleAutosave() } }
    @Published var maxPagesPerDomain = 0 { didSet { scheduleAutosave() } }
    @Published var stripDuplicates = true { didSet { scheduleAutosave() } }
    @Published var excludeRole = false { didSet { scheduleAutosave() } }
    @Published var excludeFree = false { didSet { scheduleAutosave() } }
    @Published var excludeDisposable = true { didSet { scheduleAutosave() } }
    @Published var followExternalLinks = true { didSet { scheduleAutosave() } }
    @Published var concurrentSites = 5 { didSet { scheduleAutosave() } }
    @Published var topicContext = "" { didSet { scheduleAutosave() } }
    @Published var checkDNS = true { didSet { scheduleAutosave() } }
    @Published var rows: [FoundEmail] = [] { didSet { scheduleAutosave() } }
    @Published var smartRules: [SmartRule] = [] { didSet { presentationChanged() } }
    @Published var removal = RemovalState() { didSet { presentationChanged() } }
    func isHiddenByRule(_ address: String) -> Bool { smartRules.contains { $0.matches(address) } }
    func addRule(kind: String, pattern: String) {
        let token = pattern.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !token.isEmpty else { return }
        if !smartRules.contains(where: { $0.kind == kind && $0.pattern == token }) {
            smartRules.append(SmartRule(kind: kind, pattern: token))
        }
        progress = "Rule applied immediately; original results retained"
    }
    func undoRule() {
        guard !smartRules.isEmpty else { return }
        smartRules.removeLast()
        progress = "Last rule undone; matching results restored"
    }
    func countMatching(kind: String, pattern: String) -> Int {
        let rule = SmartRule(kind: kind, pattern: pattern)
        return rows.filter { rule.matches($0.address) && !isHiddenByRule($0.address) && !isRemoved($0.address) && $0.status != "Excluded" && $0.status != "Rejected" }.count
    }
    // Addresses removed from the grid are suppressed on subsequent live refreshes.
    private var projectID = UUID()
    private var restoring = true
    private var autosaveWork: DispatchWorkItem?
    func isRemoved(_ address: String) -> Bool { removal.addresses.contains(address.lowercased()) }
    func displayStatus(_ row: FoundEmail) -> String { ResultPolicy.displayedStatus(row, rules: smartRules, removed: removal.addresses) }
    private func presentationChanged() {
        guard !restoring else { return }
        CrawlDisk.updatePresentation(rules: smartRules, removal: removal, projectID: projectID)
        let checkpointError = CrawlDisk.lastError
        flushAutosave()
        if let checkpointError = checkpointError { persistenceError = "Checkpoint: " + checkpointError }
    }
    private func makeSession() -> GrabSession {
        GrabSession(mode: mode, input: input, excluded: excluded, depth: depth, maxPages: maxPages, maxPagesPerDomain: maxPagesPerDomain, stripDuplicates: stripDuplicates, excludeRole: excludeRole, excludeFree: excludeFree, excludeDisposable: excludeDisposable, checkDNS: checkDNS, rows: rows, discoveredSites: discoveredSites, directoryDiscovery: directoryDiscovery, osmStateCode: osmStateCode, smartRules: smartRules, removedAddresses: removal.addresses, removalHistory: removal.history, projectID: projectID, followExternalLinks: followExternalLinks, topicContext: topicContext, concurrentSites: concurrentSites)
    }
    private func scheduleAutosave() {
        guard !restoring else { return }
        autosaveWork?.cancel()
        let item = DispatchWorkItem { [weak self] in DispatchQueue.main.async { [weak self] in self?.flushAutosave() } }
        autosaveWork = item
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: item)
    }
    func flushAutosave() {
        guard !restoring else { return }
        autosaveWork?.cancel(); autosaveWork = nil
        if !CrawlDisk.saveProject(makeSession()) { persistenceError = "Could not autosave: " + (CrawlDisk.lastError ?? "unknown error") }
        else { persistenceError = nil }
    }
    private func apply(_ session: GrabSession) {
        currentActivity = nil; recentActivity.removeAll(); activePages.removeAll(); queuedPageURLs.removeAll(); pendingPageCount = 0
        projectID = session.projectID ?? UUID()
        concurrentSites = min(8, max(1, session.concurrentSites ?? 1))
        followExternalLinks = session.followExternalLinks ?? true; topicContext = session.topicContext ?? ""
        mode = session.mode; input = session.input; excluded = session.excluded
        depth = min(20, max(0, session.depth)); maxPages = max(0, session.maxPages); maxPagesPerDomain = max(0, session.maxPagesPerDomain ?? 0)
        stripDuplicates = session.stripDuplicates; excludeRole = session.excludeRole; excludeFree = session.excludeFree
        excludeDisposable = session.excludeDisposable; checkDNS = session.checkDNS; rows = session.rows
        smartRules = session.smartRules ?? []; removal = RemovalState(addresses: session.removedAddresses ?? [], history: session.removalHistory ?? [])
        discoveredSites = session.discoveredSites ?? []; directoryDiscovery = session.directoryDiscovery ?? true; osmStateCode = session.osmStateCode ?? ""
        discoverySignature = currentDiscoverySignature
    }
    init() {
        if let session = CrawlDisk.loadProject() {
            apply(session)
            if let checkpoint = CrawlDisk.load(), checkpoint.projectID == session.projectID, session.projectID != nil {
                rows = ResultMerge.combine(checkpoint.rows, rows)
                scanned = checkpoint.scanned; domainsScanned = checkpoint.domainPageCount.count; domainsDiscovered = checkpoint.discoveredCount
                showSavedQueue(checkpoint)
            }
            progress = "Restored autosaved project with \(rows.count) original records"
        } else if let snapshot = CrawlDisk.load() {
            applyCheckpoint(snapshot); progress = "Recovered \(rows.count) records from the crawl checkpoint"
        } else if let error = CrawlDisk.lastError { progress = "Could not restore saved data: " + error }
        restoring = false
        CrawlDisk.updatePresentation(rules: smartRules, removal: removal, projectID: projectID)
    }
    private func showSavedQueue(_ snapshot: CrawlProgress) {
        let pending = snapshot.queue.filter { !snapshot.visited.contains($0.url) }.map { $0.url }
        reportActivity(CrawlActivity(url: "", phase: "Idle", pending: pending.count, message: pending.isEmpty ? "No eligible links remain" : "Saved pages ready to resume", activeSites: [], queuedPages: pending))
    }
    private func applyCheckpoint(_ snapshot: CrawlProgress) {
        showSavedQueue(snapshot)
        projectID = snapshot.projectID ?? projectID
        let o = snapshot.settings
        concurrentSites = min(8, max(1, o.concurrentSites ?? 1))
        followExternalLinks = o.followExternalLinks ?? false; topicContext = o.topic ?? ""
        depth = min(20, max(0, o.depth)); maxPages = max(0, o.maxPages); maxPagesPerDomain = max(0, o.maxPagesPerDomain)
        excluded = o.excluded; stripDuplicates = o.stripDuplicates; excludeRole = o.excludeRole; excludeFree = o.excludeFree
        excludeDisposable = o.excludeDisposable; checkDNS = o.checkDNS
        mode = .website; input = snapshot.input; rows = snapshot.rows
        smartRules = snapshot.smartRules ?? smartRules
        removal = RemovalState(addresses: snapshot.removedAddresses ?? removal.addresses, history: snapshot.removalHistory ?? removal.history)
        scanned = snapshot.scanned; domainsScanned = snapshot.domainPageCount.count; domainsDiscovered = snapshot.discoveredCount
    }
    func restoreLastRemoval() { removal.undo(); progress = "Last removal restored; filtering rules unchanged" }
    func restoreAllRemoved() { removal.restoreAll(); progress = "Manually removed records restored; filtering rules unchanged" }

    func removeSelectedResults(_ identifiers: Set<UUID>) {
        let addresses = Set(rows.filter { identifiers.contains($0.id) }.map { $0.address.lowercased() })
        suppress(addresses)
    }

    func excludeMatchingResults(_ term: String) {
        let needle = term.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !needle.isEmpty else { progress = "Enter an address or domain filter first"; return }
        let addresses = Set(rows.filter { $0.address.lowercased().contains(needle) }.map { $0.address.lowercased() })
        suppress(addresses)
    }

    private func suppress(_ addresses: Set<String>) {
        let fresh = addresses.filter { !isRemoved($0) }
        guard !fresh.isEmpty else { progress = "No new matching addresses to remove"; return }
        removal.remove(fresh)
        progress = "Removed \(fresh.count) addresses; no filtering rule added. Use Restore last removal to undo."

    }

    @Published var discoveredSites: [DiscoveredSite] = [] { didSet { scheduleAutosave() } }
    @Published var discovering = false
    @Published var discoveryWarning: String?
    @Published var directoryDiscovery = true { didSet { scheduleAutosave() } }
    @Published var osmStateCode = "" { didSet { scheduleAutosave() } }
    @Published var running = false
    @Published var paused = false
    @Published var activePages: [String] = []
    @Published var queuedPageURLs: [String] = []
    @Published var pendingPageCount = 0
    @Published var currentActivity: CrawlActivity?
    @Published var recentActivity: [CrawlActivity] = []
    func reportActivity(_ event: CrawlActivity) {
        if let active = event.activeSites { activePages = active }
        if let waiting = event.queuedPages { queuedPageURLs = waiting }
        if event.phase == "Queue" || event.phase == "Idle" { pendingPageCount = event.pending }
        if event.phase == "Queue" { return }
        currentActivity = event
        if event.phase == "Completed" || event.phase == "Skipped" {
            recentActivity.insert(event, at: 0)
            if recentActivity.count > 100 { recentActivity.removeLast(recentActivity.count - 100) }
        }
    }
    @Published var progress = "Ready"
    @Published var persistenceError: String?
    @Published var scanned = 0
    @Published var domainsScanned = 0
    @Published var domainsDiscovered = 0
    @Published var verifierKey = ""
    @Published var verifying = false
    private var worker: Thread?
    private var crawlControl: CrawlControl?
    private var continuationEngine: GrabEngine?
    private var continuationContext: CrawlInputContext?
    @Published var canContinue = false
    private var verifierWorker: Thread?
    private var discoveryControl: CrawlControl?
    private var discoverySignature = ""
    private var startAfterDiscovery = false
    private var currentDiscoverySignature: String { "\(osmStateCode)|\(directoryDiscovery)|\(input)" }

    func discover() {
        guard !running && !verifying && !discovering && mode == .keywords else { return }
        let query = input
        let terms = query.split(whereSeparator: \.isNewline).map(String.init).filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
        guard !terms.isEmpty else { progress = "Enter search keywords first"; return }
        discovering = true; discoveryWarning = nil
        discoveredSites = []
        progress = "Discovering websites…"
        let control = CrawlControl()
        discoveryControl = control
        let settings = GrabSettings(depth: depth, maxPages: maxPages, maxPagesPerDomain: maxPagesPerDomain, exclude: excluded, duplicates: stripDuplicates, role: excludeRole, free: excludeFree, disposable: excludeDisposable, dns: checkDNS, followExternalLinks: followExternalLinks, topic: mode == .keywords ? input : topicContext, concurrentSites: concurrentSites)
        let scanDirectories = directoryDiscovery
        let stateCode = osmStateCode
        let category = OSMBusinessCategories.match(keyword: terms.joined(separator: " "))
        let location = USStates.all.first(where: { $0.code == stateCode })?.name
        let searchTerms = location.map { place in terms.map { "\($0) \(place)" } } ?? terms
        let signature = currentDiscoverySignature
        Thread { [weak self] in
            let report: (String) -> Void = { message in DispatchQueue.main.async { [weak self] in self?.progress = message } }
            let discoveryEngine = GrabEngine(settings: settings)
            var result = discoveryEngine.discoverSites(terms: searchTerms, exploreDirectories: scanDirectories, nationwide: stateCode.isEmpty, shouldStop: { control.checkpoint() }, progress: report)
            if let category = category, !stateCode.isEmpty, !control.wasCancelled {
                let regional = OpenStreetMapDiscovery.discoverBusinesses(stateCode: stateCode, category: category, shouldStop: { control.checkpoint() }, progress: report)
                var known = Set(result.map { $0.host.lowercased().replacingOccurrences(of: "www.", with: "", options: .anchored) })
                for site in regional {
                    let host = site.host.lowercased().replacingOccurrences(of: "www.", with: "", options: .anchored)
                    if known.insert(host).inserted { result.append(site) }
                }
            }
            DispatchQueue.main.async { [weak self] in
                if control.wasCancelled {
                    self?.startAfterDiscovery = false
                    self?.progress = "Discovery stopped"
                    self?.discovering = false
                    self?.discoveryControl = nil
                    return
                }
                self?.discoveryWarning = discoveryEngine.discoveryWarning
                self?.discoveredSites = result
                self?.discoverySignature = signature
                self?.discovering = false
                self?.discoveryControl = nil
                if self?.startAfterDiscovery == true {
                    self?.startAfterDiscovery = false
                    if result.isEmpty { self?.progress = "No candidate websites discovered. Try a narrower location or import a website list." }
                    else { self?.start() }
                } else {
                    self?.progress = "Discovered \(result.count) website candidates. Review selections, then Start."
                }
            }
        }.start()
    }

    func setAllSites(_ selected: Bool) {
        for i in discoveredSites.indices { discoveredSites[i].selected = selected }
    }
    func cancelDiscovery() { startAfterDiscovery = false; discoveryControl?.cancel(); progress = "Stopping discovery…" }
    func clearDiscoveredSites() { guard !running && !discovering else { return }; discoveredSites = []; discoverySignature = "" }
    func exportDiscoveredSites() {
        guard !discoveredSites.isEmpty else { return }
        let panel = NSSavePanel()
        panel.allowedContentTypes = [.commaSeparatedText]
        panel.nameFieldStringValue = "discovered-websites.csv"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        func escaped(_ value: String) -> String { EmailPolicy.csvField(value) }
        let lines = discoveredSites.map { "\(escaped($0.url)),\(escaped($0.origin)),\($0.selected)" }
        do {
            try (["website,source,selected"] + lines).joined(separator: "\r\n").appending("\r\n").write(to: url, atomically: true, encoding: .utf8)
            progress = "Exported \(discoveredSites.count) discovered website candidates"
        } catch { progress = "Could not export website list: \(error.localizedDescription)" }
    }

    func start() { beginCrawl(resume: false) }
    func continueCrawl() { beginCrawl(resume: true) }
    private func beginCrawl(resume: Bool) {
        guard !running && !verifying && !discovering else { return }
        if resume && (continuationEngine == nil || !canContinue) { progress = "No remaining pages to continue"; return }
        let terms = input.split(whereSeparator: \.isNewline).map { String($0).trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
        let useReviewedSites = mode == .keywords && discoverySignature == currentDiscoverySignature && !discoveredSites.isEmpty
        if !resume && mode == .keywords && !useReviewedSites {
            guard !terms.isEmpty else { progress = "Enter at least one keyword"; return }
            startAfterDiscovery = true
            discover()
            return
        }
        guard !terms.isEmpty || useReviewedSites else { progress = "Enter at least one input or discover websites first."; return }
        let settings = GrabSettings(depth: depth, maxPages: maxPages, maxPagesPerDomain: maxPagesPerDomain, exclude: excluded, duplicates: stripDuplicates, role: excludeRole, free: excludeFree, disposable: excludeDisposable, dns: checkDNS, followExternalLinks: followExternalLinks, topic: mode == .keywords ? input : topicContext, concurrentSites: concurrentSites)
        if resume, let engine = continuationEngine, engine.settings != settings { progress = "Settings changed; start a new crawl or restore the previous settings before continuing"; return }
        let selectedURLs = discoveredSites.filter(\.selected).map(\.url)
        if useReviewedSites && selectedURLs.isEmpty { progress = "Select at least one discovered website"; return }
        let context = CrawlInputContext(mode: mode, input: input, reviewedSites: useReviewedSites ? selectedURLs : [])
        if resume && continuationContext != context { progress = "Inputs changed; use Resume saved crawl to restore the old job, or Start a new search"; return }
        if !resume { continuationContext = context }
        let sourceMode: SourceMode = useReviewedSites ? .website : mode
        let inputs = useReviewedSites ? selectedURLs : terms
        running = true
        paused = false
        let control = CrawlControl()
        crawlControl = control
        if !resume {
            scanned = 0; domainsScanned = 0; domainsDiscovered = 0
            currentActivity = nil; recentActivity.removeAll(); activePages.removeAll(); queuedPageURLs.removeAll(); pendingPageCount = 0
            continuationEngine = GrabEngine(settings: settings)
        }
        canContinue = false
        progress = resume ? "Continuing next batch…" : "Starting…"
        let initial = rows
        guard let engine = continuationEngine else { return }
        let thread = Thread { [weak self] in
            let result = engine.run(mode: sourceMode, terms: inputs, existing: initial, liveRows: { added in
                DispatchQueue.main.async { [weak self] in self?.rows.append(contentsOf: added) }
            }, update: { count, foundDomains, visitedDomains, message in
                DispatchQueue.main.async { [weak self] in
                    self?.scanned = count
                    self?.domainsDiscovered = foundDomains
                    self?.domainsScanned = visitedDomains
                    self?.progress = message
                }
            }, shouldStop: { control.checkpoint() }, activity: { event in
                DispatchQueue.main.async { [weak self] in self?.reportActivity(event) }
            })
            let wasStopped = control.wasCancelled
            let failure = engine.lastFailure
            DispatchQueue.main.async { [weak self] in
                self?.rows = result
                self?.canContinue = engine.hasRemainingPages
                self?.running = false
                self?.paused = false
                self?.crawlControl = nil
                self?.progress = failure ?? (wasStopped ? "Stopped; remaining pages saved and available to continue" : (engine.hasRemainingPages ? "Batch complete: \(result.count) addresses. Continue to scan more pages." : "Finished: \(result.count) addresses; \(result.filter { $0.status == "Accepted" }.count) locally checked"))
                self?.flushAutosave()
            }
        }
        worker = thread
        thread.start()
    }

    func resumeSavedCrawl() {
        guard !running && !discovering && !verifying else { return }
        guard let snapshot = CrawlDisk.load() else { progress = "No readable saved crawl checkpoint"; return }
        let currentRows = rows
        restoring = true; applyCheckpoint(snapshot)
        rows = ResultMerge.combine(snapshot.rows, currentRows)
        restoring = false; CrawlDisk.updatePresentation(rules: smartRules, removal: removal, projectID: projectID); flushAutosave()
        guard !snapshot.queue.isEmpty else { progress = "Restored \(rows.count) records; no unscanned links remain"; return }
        let settings = GrabSettings(depth: depth, maxPages: maxPages, maxPagesPerDomain: maxPagesPerDomain, exclude: excluded, duplicates: stripDuplicates, role: excludeRole, free: excludeFree, disposable: excludeDisposable, dns: checkDNS, followExternalLinks: followExternalLinks, topic: mode == .keywords ? input : topicContext, concurrentSites: concurrentSites)
        let engine = GrabEngine(settings: settings); engine.restore(snapshot)
        continuationEngine = engine; continuationContext = CrawlInputContext(mode: mode, input: input, reviewedSites: []); canContinue = true
        beginCrawl(resume: true)
    }
    func pause() { guard running && !paused else { return }; crawlControl?.pause(); paused = true; progress = "Pausing after current request…" }
    func resume() { guard running && paused else { return }; paused = false; crawlControl?.resume(); progress = "Resumed" }
    func stop() { startAfterDiscovery = false; crawlControl?.cancel(); discoveryControl?.cancel(); worker?.cancel(); paused = false; progress = "Stopping after current request…" }
    func storeVerificationKey() {
        let key = verifierKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { progress = "Enter your ZeroBounce API key first"; return }
        progress = AdvancedVerifier.saveAPIKey(key) ? "Verification key stored in Mac Keychain" : "Could not store API key"
        verifierKey = ""
    }

    func verifyWithZeroBounce() {
        guard !running && !verifying && !discovering else { return }
        guard let key = AdvancedVerifier.loadAPIKey(), !key.isEmpty else {
            progress = "Store a ZeroBounce API key to enable optional checks"
            return
        }
        let targets = rows.filter { !isRemoved($0.address) && !isHiddenByRule($0.address) && ($0.status == "Accepted" || $0.status == "Uncertain") }.prefix(100).map { ($0.id, $0.address) }
        guard !targets.isEmpty else { progress = "No eligible addresses to verify"; return }
        let confirmation = NSAlert()
        confirmation.messageText = "Send \(targets.count) addresses to ZeroBounce?"
        confirmation.informativeText = "This transmits the selected addresses to ZeroBounce and may use up to \(targets.count) verification credits. It cannot guarantee delivery. No requests run automatically."
        confirmation.alertStyle = .warning
        confirmation.addButton(withTitle: "Verify \(targets.count) addresses")
        confirmation.addButton(withTitle: "Cancel")
        guard confirmation.runModal() == .alertFirstButtonReturn else { return }
        verifying = true
        progress = "Verifying 0 / \(targets.count)"
        let thread = Thread { [weak self] in
            for (position, item) in targets.enumerated() {
                if Thread.current.isCancelled { break }
                let eligible = DispatchQueue.main.sync { [weak self] in
                    guard let self = self else { return false }
                    return !self.isRemoved(item.1) && !self.isHiddenByRule(item.1) && self.rows.contains { $0.id == item.0 && $0.address == item.1 }
                }
                if !eligible { continue }
                let answer = AdvancedVerifier.validate(email: item.1, apiKey: key)
                DispatchQueue.main.sync { [weak self] in
                    guard let self = self, let index = self.rows.firstIndex(where: { $0.id == item.0 && $0.address == item.1 }), !self.isRemoved(item.1), !self.isHiddenByRule(item.1) else { return }
                    self.rows[index].status = answer.status
                    self.rows[index].reason = answer.reason
                    self.rows[index].checkedAt = Date()
                    self.progress = "Processed \(position + 1) / \(targets.count) verification checks"
                }
                if answer.stopBatch {
                    DispatchQueue.main.async { [weak self] in self?.progress = "Verification stopped: " + answer.reason }
                    break
                }
            }
            DispatchQueue.main.async { [weak self] in self?.verifying = false; self?.flushAutosave() }
        }
        verifierWorker = thread
        thread.start()
    }
    func stopVerification() { verifierWorker?.cancel(); progress = "Stopping verification after current check…" }
    func clear() { guard !running && !verifying && !discovering else { return }; rows.removeAll(); removal.restoreAll(); currentActivity = nil; recentActivity.removeAll(); activePages.removeAll(); queuedPageURLs.removeAll(); pendingPageCount = 0; projectID = UUID(); continuationEngine = nil; canContinue = false; CrawlDisk.clear(); CrawlDisk.updatePresentation(rules: smartRules, removal: removal, projectID: projectID); flushAutosave(); progress = "Results cleared; reusable rules retained" }

    func importFile() {
        guard !running && !verifying && !discovering else { return }
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.plainText, .commaSeparatedText, .html] + ["xlsx", "tsv"].compactMap { UTType(filenameExtension: $0) }
        panel.allowsMultipleSelection = true
        guard panel.runModal() == .OK else { return }
        var imports: [String] = []
        var failures: [String] = []
        for url in panel.urls {
            do { imports.append(try FileImport.text(from: url)) }
            catch { failures.append("\(url.lastPathComponent): \(error.localizedDescription)") }
        }
        let content = imports.joined(separator: "\n")
        mode = .pasted
        input = content
        progress = failures.isEmpty ? "Imported \(imports.count) file(s). Run to extract addresses." : "Imported \(imports.count); failed: \(failures.joined(separator: "; "))"
    }

    func importWebsiteList() {
        guard !running && !verifying && !discovering else { return }
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.plainText, .commaSeparatedText] + ["xlsx", "tsv"].compactMap { UTType(filenameExtension: $0) }
        panel.allowsMultipleSelection = true
        guard panel.runModal() == .OK else { return }
        var websiteURLs = Set<String>()
        var addresses: [String] = []
        for file in panel.urls {
            guard let content = try? FileImport.text(from: file) else { continue }
            for line in content.split(whereSeparator: \.isNewline) {
                let value = String(line).trimmingCharacters(in: .whitespacesAndNewlines)
                if value.isEmpty || value.contains("@") || value.contains(" ") { continue }
                guard let url = GrabEngine.normalizedURL(value), let host = url.host?.lowercased(), host.contains(".") else { continue }
                if websiteURLs.insert(url.absoluteString).inserted { addresses.append(url.absoluteString) }
            }
        }
        mode = .website
        input = addresses.joined(separator: "\n")
        progress = "Imported \(addresses.count) distinct website URLs; set page limits and Start"
    }

    func exportCSV(onlyAccepted: Bool) {
        let panel = NSSavePanel()
        panel.nameFieldStringValue = onlyAccepted ? "email-grabber-accepted.csv" : "email-grabber-all.csv"
        panel.allowedContentTypes = [.commaSeparatedText]
        guard panel.runModal() == .OK, let url = panel.url else { return }
        let eligible = rows.filter { !isHiddenByRule($0.address) && !isRemoved($0.address) }
        let target = onlyAccepted ? eligible.filter { $0.status == "Accepted" || $0.status == "Verified" } : eligible
        func q(_ s: String) -> String { EmailPolicy.csvField(s) }
        let header = "email,status,reason,source,checked_at"
        let lines = target.map { [q($0.address), q($0.status), q($0.reason), q($0.source), q(ISO8601DateFormatter().string(from: $0.checkedAt))].joined(separator: ",") }
        do { try ([header] + lines).joined(separator: "\r\n").appending("\r\n").write(to: url, atomically: true, encoding: .utf8); progress = "Exported \(target.count) rows" }
        catch { progress = "Export failed: \(error.localizedDescription)" }
    }

    func saveSession() {
        let panel = NSSavePanel()
        panel.nameFieldStringValue = "email-grabber-session.json"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        let session = makeSession()
        do { try JSONEncoder().encode(session).write(to: url, options: .atomic); progress = "Saved complete project" }
        catch { progress = "Could not save session: \(error.localizedDescription)" }
    }

    func openSession() {
        guard !running && !verifying && !discovering else { return }
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.json]
        guard panel.runModal() == .OK, let url = panel.url else { return }
        do {
            guard (try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0) <= 64_000_000 else { progress = "Project exceeds the 64 MB import limit"; return }
            let data = try Data(contentsOf: url)
            if let session = try? JSONDecoder().decode(GrabSession.self, from: data) {
                guard session.version <= 3 else { progress = "This project requires a newer application version"; return }
                restoring = true; CrawlDisk.clear(); apply(session)
                continuationEngine = nil; canContinue = false; restoring = false
                CrawlDisk.updatePresentation(rules: smartRules, removal: removal, projectID: projectID); flushAutosave()
                progress = "Opened project with \(rows.count) records"
            } else {
                let imported = try JSONDecoder().decode([FoundEmail].self, from: data)
                restoring = true; CrawlDisk.clear(); projectID = UUID(); rows = imported; removal = RemovalState(); smartRules = []
                continuationEngine = nil; canContinue = false; restoring = false; CrawlDisk.updatePresentation(rules: smartRules, removal: removal, projectID: projectID); flushAutosave()
                progress = "Opened older results file with \(rows.count) records"
            }
        }
        catch { progress = "Could not open session: \(error.localizedDescription)" }
    }
}

@MainActor struct ContentView: View {
    @ObservedObject var model: GrabberModel
    @State private var selectedStatus = "Included"
    @State private var showDiscoveredSites = true
    @State private var selectedResultIDs = Set<UUID>()
    @State private var resultSearch = ""
    @State private var resultSearchScope = "Email"
    @State private var sortOrder = [KeyPathComparator(\FoundEmail.address)]
    @State private var showingRuleSheet = false
    @State private var ruleKind = "Prefix"
    @State private var rulePattern = ""
    private var suggestedAddress: String? { model.rows.first { selectedResultIDs.contains($0.id) }?.address }
    private func makeSuggestion() {
        guard let email = suggestedAddress else {
            ruleKind = "Contains"; rulePattern = resultSearch; return
        }
        ruleKind = "Prefix"
        rulePattern = String(email.split(separator: "@").first ?? "")
    }

    private var visible: [FoundEmail] {
        ResultPolicy.filtered(model.rows, rules: model.smartRules, removed: model.removal.addresses, status: selectedStatus, search: resultSearch, scope: resultSearchScope).sorted(using: sortOrder)
    }

    private var activityPanel: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Website activity").font(.headline)
            Text("Active: \(model.activePages.count) / \(model.concurrentSites) websites").font(.caption).foregroundStyle(.secondary)
            Text("One worker per website").font(.caption2).foregroundStyle(.secondary)
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 8) {
                    ForEach(model.activePages, id: \.self) { url in
                        Text(url).font(.caption).textSelection(.enabled)
                    }
                }
            }.frame(maxHeight: 150)
            Text("Queued pages (\(model.queuedPageURLs.count))").font(.subheadline).bold()
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 6) {
                    ForEach(model.queuedPageURLs, id: \.self) { url in
                        Text(url).font(.caption).lineLimit(3).textSelection(.enabled)
                    }
                }
            }.frame(maxHeight: 180)
            if let event = model.currentActivity {
                Text(model.paused ? "Pausing / paused" : event.phase).font(.subheadline).bold()
                if !event.url.isEmpty {
                    Text(event.url).font(.caption).textSelection(.enabled).lineLimit(5)
                }
                Text(event.message).font(.caption).foregroundStyle(.secondary)
                Text("Pending pages: \(model.pendingPageCount)").font(.caption)
            } else {
                Text("Start or resume a crawl to see activity.").font(.caption).foregroundStyle(.secondary)
            }
            Divider()
            Text("Recent pages").font(.subheadline).bold()
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 12) {
                    ForEach(model.recentActivity) { event in
                        VStack(alignment: .leading, spacing: 3) {
                            HStack {
                                Text(event.phase).bold()
                                Spacer()
                                Text(event.time, style: .time).foregroundStyle(.secondary)
                            }
                            Text(event.url).lineLimit(3).textSelection(.enabled)
                            Text(event.message).foregroundStyle(.secondary)
                        }
                        .font(.caption)
                        Divider()
                    }
                }
            }
            Text("Shows the latest 100 completed or skipped pages.").font(.caption2).foregroundStyle(.secondary)
        }
        .frame(width: 260, alignment: .topLeading)
        .frame(maxHeight: .infinity, alignment: .top)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "envelope.badge.shield.half.filled").font(.title2)
                Text("Email Grabber 3").font(.title2).bold()
                Spacer()
                Text("Local Mac Edition").foregroundStyle(.secondary)
            }
            HStack(alignment: .top, spacing: 14) {
                ScrollView(.vertical) {
                VStack(alignment: .leading, spacing: 10) {
                    Picker("Input method", selection: $model.mode) { ForEach(SourceMode.allCases) { Text($0.rawValue).tag($0) } }.disabled(model.running || model.discovering || model.verifying)
                    Text(model.mode == .website ? "Enter one website or domain per line" : model.mode == .keywords ? "Enter one search phrase per line" : "Paste addresses, text or import CSV/TXT")
                        .font(.caption).foregroundStyle(.secondary)
                    TextEditor(text: $model.input).font(.system(.body, design: .monospaced)).frame(height: 135).overlay(RoundedRectangle(cornerRadius: 5).stroke(.gray.opacity(0.25))).disabled(model.running || model.discovering || model.verifying)
                    Button("Import CSV / TXT / Excel") { model.importFile() }.disabled(model.running || model.discovering || model.verifying)
                    Button("Import website list (CSV / Excel)") { model.importWebsiteList() }.disabled(model.running || model.discovering || model.verifying)
                    if model.mode == .keywords {
                        Divider()
                        Picker("Location (optional)", selection: $model.osmStateCode) {
                            Text("Any location").tag("")
                            ForEach(USStates.all) { item in Text(item.name).tag(item.code) }
                        }
                        HStack {
                            Button("Discover Websites") { model.discover() }.disabled(model.running || model.discovering)
                            Button("Cancel") { model.cancelDiscovery() }.disabled(!model.discovering)
                        }
                        if !model.discoveredSites.isEmpty {
                            DisclosureGroup(isExpanded: $showDiscoveredSites) {
                                HStack {
                                    Button("All") { model.setAllSites(true) }
                                    Button("None") { model.setAllSites(false) }
                                    Button("Export") { model.exportDiscoveredSites() }
                                    Button("Clear") { model.clearDiscoveredSites() }
                                    Spacer()
                                }
                                ScrollView {
                                    LazyVStack(alignment: .leading, spacing: 4) {
                                        ForEach($model.discoveredSites) { site in
                                            Toggle(isOn: site.selected) {
                                                VStack(alignment: .leading, spacing: 1) {
                                                    Text(site.wrappedValue.host).lineLimit(1)
                                                    Text(site.wrappedValue.origin).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                                                }
                                            }
                                            .toggleStyle(.checkbox)
                                        }
                                    }
                                }
                                .frame(height: 160)
                                Text("Review directory-derived links; some may not be relevant businesses.")
                                    .font(.caption2).foregroundStyle(.secondary)
                            } label: {
                                Text("Discovered websites (\(model.discoveredSites.filter(\.selected).count)/\(model.discoveredSites.count) selected)")
                            }
                        }
                    }
                    HStack {
                        Button("Start") { model.start() }.disabled(model.running || model.discovering || model.verifying)
                            .keyboardShortcut(.return, modifiers: .command)
                        Button(model.paused ? "Resume" : "Pause") {
                            if model.paused { model.resume() } else { model.pause() }
                        }.disabled(!model.running)
                        Button("Stop") { model.stop() }.disabled(!model.running)
                        Spacer()
                    }
                    Divider()
                    Text("Crawling").font(.headline)
                    Stepper("Simultaneous websites: \(model.concurrentSites)", value: $model.concurrentSites, in: 1...8)
                        .disabled(model.running || model.discovering || model.verifying)
                    Text("At most one worker per website. Change before starting a new crawl.").font(.caption2).foregroundStyle(.secondary)
                    Toggle("Follow relevant links to other websites", isOn: $model.followExternalLinks).disabled(model.running || model.discovering || model.verifying)
                    if model.mode == .website { TextField("Optional topic for relevant external links", text: $model.topicContext).disabled(model.running || model.discovering || model.verifying) }
                    Text("With unlimited pages, follows relevant links until stopped or no eligible links remain.").font(.caption2).foregroundStyle(.secondary)
                    Stepper("Link depth: \(model.depth == 0 ? "Adaptive" : String(model.depth))", value: $model.depth, in: 0...20).disabled(model.running || model.discovering || model.verifying)
                    Toggle("Unlimited total pages", isOn: Binding(get: { model.maxPages == 0 }, set: { model.maxPages = $0 ? 0 : 500 })).disabled(model.running || model.discovering || model.verifying)
                    if model.maxPages != 0 { Stepper("Maximum pages: \(model.maxPages)", value: $model.maxPages, in: 10...1000000, step: 100) }
                    Toggle("Adaptive pages per website (no fixed cap)", isOn: Binding(get: { model.maxPagesPerDomain == 0 }, set: { model.maxPagesPerDomain = $0 ? 0 : 10 })).disabled(model.running || model.discovering || model.verifying)
                    if model.maxPagesPerDomain != 0 { Stepper("Pages per website: \(model.maxPagesPerDomain)", value: $model.maxPagesPerDomain, in: 1...100000) }
                    Divider()
                    Text("Filtering & validation").font(.headline)
                    Toggle("Remove duplicates", isOn: $model.stripDuplicates).disabled(model.running || model.discovering || model.verifying)
                    Toggle("Exclude generic role accounts", isOn: $model.excludeRole).disabled(model.running || model.discovering || model.verifying)
                    Text("Includes info@, care@, support@, office@, and other generic addresses. Applies to new searches; rerun a search after changing filters.").font(.caption2).foregroundStyle(.secondary)
                    Toggle("Exclude free mail providers", isOn: $model.excludeFree).disabled(model.running || model.discovering || model.verifying)
                    Toggle("Exclude known disposable domains", isOn: $model.excludeDisposable).disabled(model.running || model.discovering || model.verifying)
                    Toggle("Check DNS MX records", isOn: $model.checkDNS).disabled(model.running || model.discovering || model.verifying)
                    Divider()
                    Text("Optional ZeroBounce").font(.headline)
                    SecureField("ZeroBounce API key", text: $model.verifierKey)
                    Button("Save API key in Keychain") { model.storeVerificationKey() }
                    HStack {
                        Button("Verify up to 100") { model.verifyWithZeroBounce() }.disabled(model.running || model.verifying || model.discovering)
                        Button("Stop verification") { model.stopVerification() }.disabled(!model.verifying)
                    }
                    Text("Only the explicitly confirmed batch is sent to ZeroBounce. Provider credits may be charged.")
                        .font(.caption).foregroundStyle(.secondary)
                    Text("Blocked terms / addresses (one per line)").font(.caption)
                    TextEditor(text: $model.excluded).frame(height: 75).overlay(RoundedRectangle(cornerRadius: 5).stroke(.gray.opacity(0.25)))
                    Text("MX checks do not establish mailbox existence. Provider 'catch-all' and 'unknown' remain uncertain.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                .padding(.trailing, 6)
                }
                .frame(width: 310)
                .frame(maxHeight: .infinity)
                Divider()
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text("Results (\(visible.count)) · Accepted = local checks only, mailbox not verified").font(.headline)
                        Spacer()
                        Picker("Status", selection: $selectedStatus) {
                            ForEach(["Included", "All", "Accepted", "Verified", "Uncertain", "Rejected", "Excluded", "Removed"], id: \.self) { Text($0) }
                        }.frame(width: 150)
                    }
                    HStack {
                        Picker("Filter field", selection: $resultSearchScope) {
                            ForEach(["Email", "Domain", "Source", "All fields"], id: \.self) { Text($0) }
                        }
                        .labelsHidden()
                        .frame(width: 115)
                        TextField("Filter \(resultSearchScope.lowercased())", text: $resultSearch)
                            .textFieldStyle(.roundedBorder)
                        Button("Remove / Filter…") {
                            makeSuggestion()
                            showingRuleSheet = true
                        }.disabled(selectedResultIDs.isEmpty && resultSearch.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                        Button("Undo last rule") { model.undoRule() }.disabled(model.smartRules.isEmpty)
                        Text("Rules: \(model.smartRules.count)").font(.caption).foregroundStyle(.secondary)
                        Button("Reset filter") { resultSearch = "" }.disabled(resultSearch.isEmpty)
                    }
                    .help("Preview a reusable exclusion rule. Originals are preserved and rules can be undone.")
                    HStack {
                        Button("Select visible") { selectedResultIDs = Set(visible.map(\.id)) }
                        Button("Remove selected") { model.removeSelectedResults(selectedResultIDs); selectedResultIDs.removeAll() }.disabled(selectedResultIDs.isEmpty)
                        Button("Remove all matching") { model.removeSelectedResults(Set(visible.map(\.id))); selectedResultIDs.removeAll() }.disabled(resultSearch.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || visible.isEmpty)
                        Button("Restore last removal") { model.restoreLastRemoval() }.disabled(model.removal.history.isEmpty)
                        Button("Restore all removed") { model.restoreAllRemoved() }.disabled(model.removal.addresses.isEmpty)
                    }
                    .help("Manual removal is recoverable and does not add an exclusion rule.")
                    Table(visible, selection: $selectedResultIDs, sortOrder: $sortOrder) {
                        TableColumn("Email", value: \.address).width(min: 160)
                        TableColumn("Status", value: \.status) { row in Text(model.displayStatus(row)) }.width(min: 75)
                        TableColumn("Reason", value: \.reason).width(min: 170)
                        TableColumn("Source", value: \.source).width(min: 180)
                    }
                    HStack {
                        Button("Continue next batch") { model.continueCrawl() }.disabled(!model.canContinue || model.running)
                        Button("Resume saved crawl") { model.resumeSavedCrawl() }.disabled(model.running || model.discovering)
                        Button("Export all CSV") { model.exportCSV(onlyAccepted: false) }
                        Button("Export accepted") { model.exportCSV(onlyAccepted: true) }
                        Button("Save session") { model.saveSession() }
                        Button("Open session") { model.openSession() }.disabled(model.running || model.discovering || model.verifying)
                        Spacer()
                        Button("Clear") { model.clear() }.disabled(model.running || model.verifying || model.discovering)
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                Divider()
                activityPanel
            }
            .frame(maxHeight: .infinity)
            Divider()
            if let warning = model.discoveryWarning { Text(warning).foregroundStyle(.orange).font(.caption) }
            if let error = model.persistenceError { Text(error).foregroundStyle(.red).font(.caption) }
            HStack {
                if model.running { ProgressView().controlSize(.small) }
                Text(model.progress).font(.caption)
                Spacer()
                Text("Websites discovered: \(model.domainsDiscovered) | scanned: \(model.domainsScanned) | pages: \(model.scanned)").font(.caption).foregroundStyle(.secondary)
            }
        }
        .sheet(isPresented: $showingRuleSheet) {
            VStack(alignment: .leading, spacing: 14) {
                Text("Remove / Filter results").font(.headline)
                Text("Choose what to exclude. Your original collected results remain saved.")
                    .foregroundStyle(.secondary)
                Picker("Rule", selection: $ruleKind) {
                    ForEach(["Address", "Prefix", "Domain", "Contains"], id: \.self) { Text($0) }
                }
                TextField("Address, prefix, domain, or text", text: $rulePattern)
                    .textFieldStyle(.roundedBorder)
                HStack {
                    Button("Use selected address") {
                        if let address = suggestedAddress { ruleKind = "Address"; rulePattern = address }
                    }.disabled(suggestedAddress == nil)
                    Button("Use selected domain") {
                        if let address = suggestedAddress, let domain = address.split(separator: "@").last {
                            ruleKind = "Domain"; rulePattern = String(domain)
                        }
                    }.disabled(suggestedAddress == nil)
                }
                Text("Would exclude \(model.countMatching(kind: ruleKind, pattern: rulePattern)) Included records. Applies to future results too.")
                    .font(.subheadline).bold()
                HStack {
                    Spacer()
                    Button("Cancel") { showingRuleSheet = false }
                    Button("Apply rule") {
                        model.addRule(kind: ruleKind, pattern: rulePattern)
                        selectedResultIDs.removeAll()
                        showingRuleSheet = false
                    }.disabled(rulePattern.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .padding(20)
            .frame(width: 440)
        }
        .onChange(of: resultSearch) { _ in selectedResultIDs.removeAll() }
        .onChange(of: resultSearchScope) { _ in selectedResultIDs.removeAll() }
        .onChange(of: selectedStatus) { _ in selectedResultIDs.removeAll() }
        .onReceive(NotificationCenter.default.publisher(for: NSApplication.willTerminateNotification)) { _ in model.flushAutosave() }
        .padding(16)
        .frame(minWidth: 1340, minHeight: 580)
    }
}

@main @MainActor struct EmailGrabberApp: App {
    @StateObject private var model = GrabberModel()
    var body: some Scene { WindowGroup { ContentView(model: model) } }
}
