# Directory-row person names — 0.12.34, bundle 55

## What changed

A name and email in different cells of the same directory table row can now establish an explicit source-person association. This supports plain email text and anchors that link back to a directory instead of using mailto. Generic Name/Full name/Person name/Contact name and Email/E-mail column headers identify the relevant cells, including opaque email handles. Headerless tables require a corroborating name-shaped handle in the same row. The implementation does not depend on a particular website, industry, job title, or uploaded person's name.

Rows must have one distinct email, a plausible full name, and stable cell boundaries. Multiple recipients, mismatched mailto destinations, conflicting names, mismatched column counts, merged cells, malformed or nested tables, scripts/templates and explicitly hidden rows/cells/tables/ancestors are rejected. Header context does not cross tables. Existing shared-role inbox checks, exact saved feedback and manual decisions keep their priority. Nearby text alone still cannot teach a new association, and automatic predictions do not self-train.

The previous publication/name checker silently returned no name associations for input above 1,000,000 bytes, while the crawler accepted 3,000,000 bytes. Publication checks, person-name matching and bounded browser DOM retrieval now share the crawler's 3,000,000-byte limit. Response size, extraction deadlines and cancellation checks remain bounded. No site challenges or robots rules are bypassed.

Name-check version is now 2. Earlier version-1 checks do not block a new source-name check behind the old 24-hour cooldown. Current-version checks retain the cooldown. Existing saved choices remain respected. Saved source associations record the method as same directory table row; old associations/checkpoints still decode.

The 0.12.33 continuous-crawl fix remains: interrupted pages stay unvisited and pending, other sites continue, and deferred-only frontiers use a visible cancellable retry countdown. No settings, records, learning profiles, review decisions, removal history or journals are cleared or reset.

## Verification

404 portable XCTest tests passed with zero failures, using the previously signature-verified official Swift 6.0.3 toolchain in Swift 5 language mode, four jobs. New sanitized tests cover three industries, opaque and corroborated handles, adjacent people, hidden/malformed/multi-recipient rows, conflicting evidence, Person versus shared inboxes, saved decisions, Codable round trips, version-1 rechecks, in-place upgrades of existing unresolved records with unchanged IDs and learning evidence, cancellation, pages above the old 1 MB threshold, oversized rejection and crawler attachment without extra requests. The full existing learning/removal/classification/directory/frontier/cancellation suite passes. CORE-TESTS.log and CORE-TESTS-EXTERNAL.log contain the current portable run; Swift Testing's separate zero-tests line is not the XCTest count.

A separate private local diagnostic against the supplied complete HTML confirms the reported contact receives the correct Person association and the neighboring contact keeps a separate association. That uploaded HTML, extracted rows, diagnostic tests/logs and personal data are excluded from this source distribution. Public tests use synthetic names and example.org addresses. This file-based diagnostic is not a live website crawl or a native GUI test.

Core build, Linux SwiftUI/website-checker syntax parse, and Xcode project-reference checks passed. The new test file is registered in the Xcode test target. Native Mac build/GUI remains unverified. Arbitrary contact cards, JavaScript-only pages, ambiguous tables and unsupported structures may still require further work. Organization-site scheduling improvements remain separate outstanding work.

## Mac use and existing records

Save, Stop and quit the previous app without Clear. Download the published archive and verify its release SHA256, then extract into a fresh Downloads directory. Run `bash build-mac.sh` and `open dist/EmailGrabber3.app`. Confirm version 0.12.34 and your existing records/learning/removal preference.

For already-saved unresolved records, open the relevant list and choose **Sort this list automatically**. This checks the actual source page again using the new matcher; older name-check attempts can be retried immediately. It does not require starting the entire crawl again or clearing anything. A source that cannot be retrieved, differs from the uploaded HTML, or requires unavailable browser content may still remain unresolved. Saved manual classifications remain unchanged.

Fresh crawls attach row-based associations during extraction using the page already downloaded. Existing duplicate rows can receive improved website evidence on re-encounter. No SMTP probing, paid service, or feedback threshold change was added.
