# Contact-card names — 0.12.35, bundle 56

## Change

General contact-card structure now supplies person associations when a bounded div/article/list-item/section contains exactly one plausible full-name heading and one distinct email whose handle corroborates that name. Nested markup, plain-text emails and email text linked to non-mailto pages work. Name/address corroboration is required for cards; opaque handles without supporting evidence stay unresolved. No website, employer, industry, person or CSS class is hardcoded.

Local expandable panels are recognized when a name-bearing button and its aria-hidden panel are direct children of the same card, there is one disclosure button with a relevant local panel, and aria-expanded is explicitly true or false. An aria-controls value, when present, must match the panel ID. This supports collapsed contact information intended to be revealed by the user. Hidden decorative icons do not prevent matching. Unrelated hidden content, explicit hidden/inert panels, hidden ancestors, mismatched controls and ambiguous relationships are rejected. No browser scripts are executed by this matcher.

The matcher never pairs people across neighboring cards. Multiple names, multiple recipients, conflicting names for the same email, mismatched mailto destinations, unbalanced element boundaries and oversized containers abstain. Each card is limited to 16,384 UTF-16 code units, full pages remain bounded at 3 MB, and cancellation/deadline callbacks remain active. Existing table-row, named-mailto and Schema.org matching remain. Shared inboxes and saved manual/exact decisions keep their classification priority. Automatic evidence does not teach feedback learning.

Name-check version is 3, allowing unresolved records checked by earlier versions to be rechecked immediately. Current-version checks keep the 24-hour cooldown. Records are upgraded in place through source rechecking; IDs, saved learning, review decisions and removal state are not reset. The continuous-crawl timeout/deferred-retry behavior from 0.12.33 remains intact.

## Evidence

The two uploaded pages were tested in separate private local diagnostics. The reported contact-card name is associated with its exact address, the adjacent collapsed contact remains separate, and the earlier table-row case still classifies correctly. These are actual uploaded-HTML checks, not live-site or native GUI verification. Uploaded HTML, actual identifying data and private diagnostic code/logs are excluded from this distribution. Public tests use synthetic names and example.org addresses.

413 portable XCTest tests passed with zero failures using signature-verified official Swift 6.0.3 in Swift 5 mode, four jobs. CORE-TESTS.log and CORE-TESTS-EXTERNAL.log contain the current public suite; the separate Swift Testing zero-tests line is not its XCTest count. Public regression checks cover expanded/collapsed cards, neighboring people, several generic container types, non-mailto links, name/handle corroboration, multiple names/recipients, conflicts with named links, hidden ancestors/panels, controlled-panel relationships, malformed boundaries, Codable evidence, old-record rechecking, saved choices, cancellation, size bounds and crawler checkpoint evidence. Existing table, classification, feedback/removal recovery and continuous-crawl tests remain included.

Core build, Linux SwiftUI/website-checker syntax parse and Xcode project references are checked. The new tests are registered in the Xcode test target. Native Mac build/GUI and live retrieval remain unverified. Arbitrary unstructured pages, opaque card handles, unusual layouts, access challenges and JavaScript-only content may still remain unresolved. Organization-site scheduling improvement remains separate outstanding work.

## Existing results and Mac use

Save, Stop and quit the old app without Clear. Download and verify the release ZIP, extract into a fresh directory, run `bash build-mac.sh`, then `open dist/EmailGrabber3.app`. Confirm version 0.12.35.

Open the relevant unresolved-results list and choose **Sort this list automatically**. It rechecks source pages using the new matcher; no full crawl restart, Clear, or learning reset is required. Saved manual choices remain respected. If the current source response differs from the supplied HTML, cannot be retrieved, or lacks supported evidence, that record can remain unresolved. Existing page/time limits for automatic sorting still apply; run another pass to continue unchecked sources if a pass reaches its limit. New crawls attach card evidence during extraction without a separate person-name request.
