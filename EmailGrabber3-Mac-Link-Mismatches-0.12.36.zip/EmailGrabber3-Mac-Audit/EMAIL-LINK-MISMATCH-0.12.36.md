# Email link mismatches and multi-part names — 0.12.36, bundle 57

## Mismatch behavior

A mailto link can display one email address while pointing to a different destination. The extractor now records the displayed address, conflicting destination, source URL and observation date. Both saved records show **Displayed email and link destination disagree** and retain both addresses in their evidence. The website result label is **Email link mismatch**, and the explanation does not claim that the correct contact has been verified.

The displayed address stays eligible under the existing acceptance, exclusion and removal rules. The conflicting destination remains saved with status **Link mismatch review**, but is held from ordinary CSV exports, accepted/verified exports, person/candidate exports, current-list exports and normal Copy email/Copy selected operations. Evidence and project/session saves preserve it. The CSV writer independently enforces the hold and removes only records actually written; it cannot remove a held destination as an accidental export side effect. CSV evidence columns preserve mismatch details and export decisions for exported displayed/approved records.

Right-click a held row and choose **Show verification evidence** to inspect the two addresses and source. **Approve link destination for export** explicitly releases that record's known mismatch holds; **Hold link destination from export** restores the hold. Approval does not identify the correct person or verify delivery. It does not override exclusions, removals, rejected technical addresses or the selected accepted-only export scope. A classification correction, SMTP/provider result or automatic prediction does not constitute this approval. Saved manual classifications remain respected, while an unapproved destination still cannot be exported.

Conflicting destinations cannot inherit the displayed person's source-name association. Fresh source checks, same-site profile follow-ups and browser-result processing preserve encountered mismatch evidence rather than allowing a later result to erase it. Unavailable rechecks cannot release a hold. Approvals/revocations are dated and scoped to the known source/display/destination pair; newer decisions survive older checkpoint/project snapshots. A new pair requires its own approval. Conflicts are deduplicated and merged without quadratic scans across duplicate records. Old records without the optional metadata decode normally.

Case-insensitive matching, nested link-label markup, HTML entities and percent-encoded mailto recipients are handled. Subject/body/query text is not treated as a recipient. Generic Email links without a displayed address and matching displayed/destination addresses do not create false mismatch warnings. Extra mailto recipients absent from the displayed labels are treated as conflicting destinations. Scripts/templates/comments are excluded from this matcher; parsing remains bounded by the 3 MB page limit and existing extraction/cancellation budgets.

The normal General-on-removal preference and address-level feedback learning remain. Held conflicting link evidence is not used to teach misleading published-page wording. No data, review decisions, learning profiles, removal journals or pending crawl work are cleared or reset.

## Existing results

For already-saved records, select the relevant rows and choose **Confirm selected on website**. This fetches the source again and applies mismatch evidence in place. The new version cannot retrospectively determine a mismatch from an address alone; older records are unchanged until their source is rechecked or encountered again. It does not require Clear or a full recrawl. An unmodified source with a mismatch remains held until approval even after further failed or unrelated checks; the warning/evidence stays available.

## Multi-part names

A contact-card handle may use an earlier component of its published full name instead of the final component. Corroboration now tests the given name/initial against later name components within the same unambiguous card, preserving final two-letter surnames. There is no per-person or site hardcoding. Neighboring-card, multiple-name/recipient and hidden-disclosure safeguards remain. Name-check version 4 lets unresolved records checked by older versions be rechecked immediately with **Sort this list automatically**; current-version checks retain their cooldown. Saved explicit choices remain respected.

## Verification and limits

423 portable XCTest tests passed with zero failures using the signature-verified official Swift 6.0.3 toolchain in Swift 5 language mode, four build jobs. CORE-TESTS.log and CORE-TESTS-EXTERNAL.log contain the current public suite; the separate Swift Testing zero-tests line is not its XCTest count. Public tests cover crawler extraction/checkpoint evidence, display-versus-destination export eligibility, accepted-only/current-list/person export guards, direct CSV writer and removal behavior, warnings, approval/revocation Codable round trips, stale project/checkpoint merges, saved manual classifications, exclusion priority, optional model behavior, legacy decoding, matching/query-only/encoded links, follow-up evidence retention, cancellation and multi-part/short-surname names. Existing continuous-crawl, general table/card traversal, learning and removal-recovery regressions remain included.

Private local diagnostics against the supplied HTML confirm that the displayed contact is retained and the conflicting link destination is held, and that the additional reported multi-part-name card classifies as Person. The earlier uploaded table/card cases still pass. Uploaded HTML, actual identifying data and private diagnostic code/logs are excluded from this distribution; public fixtures are synthetic and no network/SMTP probes are made for them.

Core build, Linux SwiftUI/website-checker syntax parse and Xcode project references are checked. Native Mac build/GUI and live-site retrieval remain unverified. Ambiguous structures, unsupported email formats, unavailable source pages and different live HTML can still require review. Organization-site crawl scheduling improvement remains outstanding.

Save, Stop and quit the previous app without Clear. Download/verify this source ZIP, extract into a fresh directory, run `bash build-mac.sh`, then `open dist/EmailGrabber3.app`. Confirm version 0.12.36 before source rechecking or approving held destinations.
