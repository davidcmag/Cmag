import XCTest
import Foundation
@testable import EmailGrabberCore

final class ContactCardPersonTests: DiskTests {
    func card(_ person: String = "Jane Smith", _ address: String = "jsmith@example.org", collapsed: Bool = false) -> String {
        "<div class='contact'><img src='logo.svg'><button aria-expanded='\(!collapsed)'><span><h3>\(person)</h3><p>Program Assistant</p><em>Main Campus</em></span><span aria-hidden='true'></span></button><div aria-hidden='\(collapsed)' style='display:\(collapsed ? "none" : "block")'><p>100 Main Street<br>Office 4<br>555-0100<br><span>\(address)</span></p></div></div>"
    }
    func testExpandedAndCollapsedDisclosureCardsMatchTheirOwnPeople() {
        for collapsed in [false,true] {
            let found = SourcePersonMatcher.collect("<section>" + card(collapsed: collapsed) + card("John Jones", "jjones@example.org", collapsed: collapsed) + "</section>")
            XCTAssertEqual(found["jsmith@example.org"]?.name, "Jane Smith")
            XCTAssertEqual(found["jjones@example.org"]?.name, "John Jones")
            XCTAssertEqual(found["jsmith@example.org"]?.method, .contactCard)
        }
    }
    func testDisclosureWithExplicitControlRelationshipAndCodableEvidence() throws {
        let html = card(collapsed: true).replacingOccurrences(of: "<button aria-expanded='false'>", with: "<button aria-expanded='false' aria-controls='contact-details'>").replacingOccurrences(of: "<div aria-hidden='true'", with: "<div id='contact-details' aria-hidden='true'")
        let found = try XCTUnwrap(SourcePersonMatcher.collect(html)["jsmith@example.org"])
        XCTAssertEqual(found.name, "Jane Smith")
        XCTAssertEqual(try JSONDecoder().decode(SourcePersonAssociation.self, from: JSONEncoder().encode(found)), found)
    }
    func testPlainCardsAcrossIndustriesAndMarkupDoNotNeedSiteSpecificClasses() {
        for tag in ["article","li","section","div"] {
            let html = "<\(tag)><h2><span>Jane Smith</span></h2><p>Sales Engineer</p><p><a href='/people'>jsmith@example.org</a></p></\(tag)>"
            XCTAssertEqual(SourcePersonMatcher.collect(html)["jsmith@example.org"]?.name, "Jane Smith")
        }
    }
    func testAmbiguousNamesRecipientsAndNonmatchingHandlesAreRejected() {
        for html in [
            "<div><h3>Jane Smith</h3><h3>John Jones</h3><p>jsmith@example.org</p></div>",
            "<div><h3>Jane Smith</h3><p>jsmith@example.org jjones@example.org</p></div>",
            "<div><h3>Jane Smith</h3><p>opaque391@example.org</p></div>",
            "<div><h3>Jane Smith</h3><a href='mailto:other@example.org'>jsmith@example.org</a></div>",
            "<div><h3>Jane Smith</h3></div><div>jsmith@example.org</div>",
            "<div><h3>Program Assistant</h3><p>jsmith@example.org</p></div>",
            "<div><h3>Jane Smith</h3><p>jsmith@example.org</div></p>"
        ] { XCTAssertTrue(SourcePersonMatcher.collect(html).isEmpty, html) }
    }
    func testHiddenEvidenceRequiresLocalDisclosureAndCannotLeakBetweenCards() {
        for html in [
            "<div hidden>" + card() + "</div>",
            "<div><h3>Jane Smith</h3><div aria-hidden='true'>jsmith@example.org</div></div>",
            card(collapsed: true).replacingOccurrences(of: "<button aria-expanded='false'>", with: "<button aria-expanded='false' aria-controls='other-panel'>"),
            card(collapsed: true).replacingOccurrences(of: "<div aria-hidden='true'", with: "<div hidden aria-hidden='true'"),
            "<div><h3>Jane Smith</h3><div><button aria-expanded='false'>Show</button><div aria-hidden='true'>jsmith@example.org</div></div></div>"
        ] { XCTAssertNil(SourcePersonMatcher.collect(html)["jsmith@example.org"], html) }
    }
    func testConflictingCardAndExplicitNamedEmailLinkAbstain() {
        XCTAssertNil(SourcePersonMatcher.collect(card() + card("John Jones", "jsmith@example.org"))["jsmith@example.org"])
        XCTAssertNil(SourcePersonMatcher.collect(card() + "<a href='mailto:jsmith@example.org'>John Jones</a>")["jsmith@example.org"])
    }
    func testExistingRecordRecheckAppliesCardEvidenceAndPreservesManualChoice() {
        let source = "https://example.org/staff"
        var row = FoundEmail(address: "jsmith@example.org", source: source, status: "Accepted", reason: "Local checks")
        row.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Old check", sourceURL: source, personNameCheckVersion: 2)
        let identity = row.id
        XCTAssertEqual(AutomaticPersonSort.targets([row], selected: [row.id], rules: [], removed: []).count, 1)
        let checker = WebsiteConfirmer(fetch: { request,_,_ in
            HTTPResult(data: Data(self.card(collapsed: true).utf8), status: 200, finalURL: request.url, mimeType: "text/html")
        })
        WebsiteConfirmationPolicy.apply(checker.confirmPerson(address: row.address, source: source), to: &row)
        XCTAssertEqual(row.id, identity)
        XCTAssertEqual(row.addressClassification.category, .person)
        row.classificationDecision = ClassificationDecision(category: .general, changedAt: Date())
        XCTAssertEqual(row.addressClassification.category, .general)
    }
    func testCardMatchingCancellationAndSizeBoundsRemainEnforced() {
        var checks = 0
        XCTAssertTrue(SourcePersonMatcher.collect(String(repeating: card(), count: 1500), cancelled: { checks += 1; return checks > 100 }).isEmpty)
        XCTAssertTrue(SourcePersonMatcher.collect(String(repeating: " ", count: WebsiteConfirmer.maximumBytes + 1) + card()).isEmpty)
    }
    func testCrawlerSavesCardAssociationAndSharedInboxStaysGeneral() {
        let html = card() + "<div><h3>John Jones</h3><p>info@example.org</p></div>"
        let engine = GrabEngine(settings: settings(pages: 1), fetcher: { url in
            HTTPResult(data: Data((url.path == "/robots.txt" ? "User-agent: *" : html).utf8), status: 200, finalURL: url, mimeType: "text/html")
        }, sleep: { _ in })
        let rows = engine.run(mode: .website, terms: ["https://example.org/staff"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(rows.first { $0.address == "jsmith@example.org" }?.addressClassification.category, .person)
        XCTAssertEqual(rows.first { $0.address == "info@example.org" }?.addressClassification.category, .general)
        XCTAssertEqual(CrawlDisk.load()?.rows.first { $0.address == "jsmith@example.org" }?.websiteConfirmation?.personAssociation?.method, .contactCard)
    }
}
