import XCTest
import Foundation
@testable import EmailGrabberCore

final class EmailLinkConflictTests: DiskTests {
    let source = "https://public.org/services"
    let html = "<p>Jane Smith<br>555-0100<br><a href='mailto:old@public.org'><span>jsmith@public.org</span></a></p>"
    func rows() -> [FoundEmail] {
        let engine = GrabEngine(settings: settings(pages: 1), fetcher: { url in
            HTTPResult(data: Data((url.path == "/robots.txt" ? "User-agent: *" : self.html).utf8), status: 200, finalURL: url, mimeType: "text/html")
        }, sleep: { _ in })
        return engine.run(mode: .website, terms: [source], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
    }
    func testCrawlerRetainsDisplayedContactAndHoldsConflictingDestinationWithEvidence() throws {
        let records = rows()
        let displayed = try XCTUnwrap(records.first { $0.address == "jsmith@public.org" })
        let destination = try XCTUnwrap(records.first { $0.address == "old@public.org" })
        XCTAssertFalse(EmailLinkConflictPolicy.isHeld(displayed))
        XCTAssertTrue(EmailLinkConflictPolicy.isHeld(destination))
        XCTAssertEqual(destination.websiteConfirmation?.label, "Email link mismatch")
        XCTAssertNil(destination.websiteConfirmation?.personAssociation)
        XCTAssertEqual(destination.addressClassification.category, .uncertain)
        XCTAssertTrue(ResultPolicy.displayedReason(displayed).contains("Displayed email and link destination disagree"))
        XCTAssertEqual(ResultPolicy.displayedStatus(destination, rules: [], removed: []), "Link mismatch review")
        XCTAssertEqual(ResultPolicy.exportRows(records, rules: [], removed: [], onlyAccepted: false).map(\.address), [displayed.address])
        XCTAssertEqual(ResultPolicy.exportRows(records, rules: [], removed: [], onlyAccepted: true).map(\.address), [displayed.address])
        XCTAssertEqual(ResultPolicy.exportSelection(records, currentList: [destination], rules: [], removed: [], onlyAccepted: false).count, 0)
        XCTAssertFalse(ResultPolicy.personExportRows(records, includeUncertain: true, rules: [], removed: []).contains { $0.id == destination.id })
        XCTAssertEqual(CrawlDisk.load()?.rows.first { $0.id == destination.id }?.emailLinkConflicts?.first?.displayedAddress, displayed.address)
        XCTAssertTrue(VerificationEvidence.text(destination).contains(displayed.address))
        XCTAssertTrue(VerificationEvidence.text(destination).contains(destination.address))
    }
    func testApprovalAndRevocationRoundTripAndNewestDecisionWinsStaleSnapshots() throws {
        var destination = try XCTUnwrap(rows().first { $0.address == "old@public.org" })
        let original = destination
        EmailLinkConflictPolicy.decide(&destination, approved: true, at: Date(timeIntervalSince1970: 20))
        XCTAssertFalse(EmailLinkConflictPolicy.isHeld(destination))
        XCTAssertEqual(ResultPolicy.exportRows([destination], rules: [], removed: [], onlyAccepted: false).count, 1)
        let decoded = try JSONDecoder().decode(FoundEmail.self, from: JSONEncoder().encode(destination))
        XCTAssertEqual(decoded, destination)
        XCTAssertFalse(EmailLinkConflictPolicy.isHeld(decoded))
        let inherited = ClassificationEdits.inheriting([original], from: [decoded])[0]
        XCTAssertFalse(EmailLinkConflictPolicy.isHeld(inherited))
        EmailLinkConflictPolicy.decide(&destination, approved: false, at: Date(timeIntervalSince1970: 30))
        let merged = ClassificationEdits.inheriting([decoded], from: [destination])[0]
        XCTAssertTrue(EmailLinkConflictPolicy.isHeld(merged))
        XCTAssertTrue(EmailLinkConflictPolicy.isHeld(ResultMerge.combine([decoded], [destination])[0]))
        XCTAssertFalse(EmailLinkConflictPolicy.isHeld(ResultMerge.combine([original], [decoded])[0]))
        XCTAssertEqual(merged.emailLinkConflicts, original.emailLinkConflicts)
        XCTAssertEqual(merged.id, original.id)
    }
    func testApprovalDoesNotOverrideExclusionsRemovalsAndClassificationDoesNotApprove() throws {
        var destination = try XCTUnwrap(rows().first { $0.address == "old@public.org" })
        destination.learningEvidence = LearningEvidence(category: .general, exact: true, reason: "Saved exact feedback")
        XCTAssertEqual(destination.addressClassification.category, .general)
        destination.classificationDecision = ClassificationDecision(category: .person, changedAt: Date())
        XCTAssertTrue(ResultPolicy.personExportRows([destination], includeUncertain: true, rules: [], removed: []).isEmpty)
        EmailLinkConflictPolicy.decide(&destination, approved: true)
        XCTAssertTrue(ResultPolicy.exportRows([destination], rules: [], removed: [destination.address], onlyAccepted: false).isEmpty)
        XCTAssertTrue(ResultPolicy.exportRows([destination], rules: [SmartRule(kind: "Address", pattern: destination.address)], removed: [], onlyAccepted: false).isEmpty)
    }
    func testCSVBoundaryDoesNotExportOrRemoveHeldRowsAndRetainsWarningForDisplayedRow() throws {
        let records = rows()
        let output = directory.appendingPathComponent("results.csv")
        let removal = try CSVExportTransaction.write(records, to: output, removal: RemovalState())
        let csv = try String(contentsOf: output)
        XCTAssertTrue(csv.contains("Displayed email and link destination disagree"))
        XCTAssertTrue(csv.contains("email_link_conflicts"))
        XCTAssertEqual(removal.addresses, ["jsmith@public.org"])
        XCTAssertEqual(csv.components(separatedBy: "\r\n").filter { !$0.isEmpty }.count, 2)
        XCTAssertFalse(csv.components(separatedBy: "\r\n").dropFirst().contains { $0.hasPrefix("old@public.org,") })
    }
    func testMatchingGenericAndQueryOnlyLinksDoNotCreateFalseConflicts() {
        for html in [
            "<a href='mailto:jsmith@public.org'>JSMITH@public.org</a>",
            "<a href='mailto:jsmith@public.org'>Email Jane Smith</a>",
            "<a href='https://public.org/?email=old@public.org'>jsmith@public.org</a>",
            "<a href='mailto:jsmith@public.org?subject=old@public.org'>jsmith@public.org</a>",
            "<script><a href='mailto:old@public.org'>jsmith@public.org</a></script>"
        ] { XCTAssertTrue(EmailLinkConflictMatcher.collect(html, source: source, at: Date()).isEmpty, html) }
        let encoded = "<a href='MAILTO:old%40public.org?body=ignored@public.org'>jsmith&#64;public.org</a>"
        XCTAssertEqual(EmailLinkConflictMatcher.collect(encoded, source: source, at: Date()).first?.destinationAddress, "old@public.org")
    }
    func testMismatchCannotBorrowInjectedPersonAssociationAndRecheckUpdatesExistingRow() {
        let response = HTTPResult(data: Data(html.utf8), status: 200, finalURL: URL(string: source), mimeType: "text/html")
        let fake = SourcePersonAssociation(name: "Jane Smith", address: "old@public.org", method: .namedEmailLink, sourceExcerpt: "Unrelated name")
        let proof = WebsiteConfirmer.observe(address: fake.address, source: source, response: response, checkedAt: Date(), personAssociations: [fake.address:fake])
        XCTAssertNil(proof.personAssociation)
        var existing = FoundEmail(address: fake.address, source: source, status: "Accepted", reason: "Local checks")
        let id = existing.id
        WebsiteConfirmationPolicy.apply(proof, to: &existing)
        XCTAssertEqual(existing.id, id)
        XCTAssertTrue(EmailLinkConflictPolicy.isHeld(existing))
        let failed = WebsiteConfirmation(outcome: .unavailable, reason: "Network unavailable", sourceURL: source)
        WebsiteConfirmationPolicy.apply(failed, to: &existing)
        XCTAssertTrue(EmailLinkConflictPolicy.isHeld(existing), "A failed recheck must not release a hold")
    }
    func testHoldDoesNotOverrideExclusionsOrAllowModelPredictionToReleaseIt() throws {
        var row = try XCTUnwrap(rows().first { $0.address == "old@public.org" })
        let enabled = ContextClassifierPolicy.enabled
        defer { ContextClassifierPolicy.enabled = enabled }
        ContextClassifierPolicy.enabled = true
        XCTAssertEqual(row.addressClassification.category, .uncertain)
        XCTAssertEqual(ResultPolicy.filtered([row], rules: [], removed: [], status: "Link mismatch review", search: "", scope: "Email").count, 1)
        XCTAssertTrue(ResultPolicy.filtered([row], rules: [], removed: [], status: "Accepted", search: "", scope: "Email").isEmpty)
        row.status = "Excluded"
        XCTAssertEqual(ResultPolicy.displayedStatus(row, rules: [], removed: []), "Excluded")
        XCTAssertTrue(ResultPolicy.filtered([row], rules: [], removed: [], status: "Included", search: "", scope: "Email").isEmpty)
        EmailLinkConflictPolicy.decide(&row, approved: true)
        XCTAssertTrue(ResultPolicy.exportRows([row], rules: [], removed: [], onlyAccepted: false).isEmpty)
    }
    func testNameSeekingFollowupCannotEraseOriginalMismatch() {
        var paths: [String] = []
        let checker = WebsiteConfirmer(fetch: { request,_,_ in
            paths.append(request.url!.path)
            let html = request.url!.path == "/staff/profile" ? "<a href='mailto:old@public.org'>John Jones</a>" : self.html + "<a href='/staff/profile'>Staff profile</a>"
            return HTTPResult(data: Data(html.utf8), status: 200, finalURL: request.url, mimeType: "text/html")
        })
        let proof = checker.confirmPerson(address: "old@public.org", source: source)
        XCTAssertTrue(paths.contains("/staff/profile"))
        XCTAssertFalse(proof.emailLinkConflicts?.isEmpty ?? true)
        XCTAssertNil(proof.personAssociation)
        var record = FoundEmail(address: "old@public.org", source: source, status: "Accepted", reason: "Local checks")
        WebsiteConfirmationPolicy.apply(proof, to: &record)
        XCTAssertTrue(EmailLinkConflictPolicy.isHeld(record))
        XCTAssertTrue(FeedbackContext.features(record).isEmpty)
    }
    func testLegacyRecordsDecodeAndConflictMatchingCancels() throws {
        let row = FoundEmail(address: "jsmith@public.org", source: source, status: "Accepted", reason: "Local checks")
        var object = try JSONSerialization.jsonObject(with: JSONEncoder().encode(row)) as! [String:Any]
        object.removeValue(forKey: "emailLinkConflicts"); object.removeValue(forKey: "emailLinkDecisions")
        let old = try JSONDecoder().decode(FoundEmail.self, from: JSONSerialization.data(withJSONObject: object))
        XCTAssertFalse(EmailLinkConflictPolicy.isHeld(old))
        var checks = 0
        XCTAssertTrue(EmailLinkConflictMatcher.collect(String(repeating: html, count: 2000), source: source, at: Date(), cancelled: { checks += 1; return checks > 20 }).isEmpty)
    }
    func testMultiPartPublishedNamesCanMatchAnEarlierFamilyNameComponent() {
        let html = "<article><h3>Jane Smith Brown</h3><p>Assistant Director</p><p>jsmith@public.org</p></article>"
        XCTAssertEqual(SourcePersonMatcher.collect(html)["jsmith@public.org"]?.name, "Jane Smith Brown")
        XCTAssertEqual(SourcePersonMatcher.collect("<article><h3>Jane Li</h3><p>jli@public.org</p></article>")["jli@public.org"]?.name, "Jane Li")
        XCTAssertNil(SourcePersonMatcher.collect(html.replacingOccurrences(of: "jsmith@", with: "jbrownwrong@"))["jbrownwrong@public.org"])
    }
}
