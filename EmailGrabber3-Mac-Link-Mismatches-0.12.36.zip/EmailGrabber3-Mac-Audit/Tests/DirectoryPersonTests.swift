import XCTest
import Foundation
@testable import EmailGrabberCore

final class DirectoryPersonTests: DiskTests {
    let head = "<tr><th>Name</th><th>Title</th><th>Email</th><th>Number</th></tr>"
    func entry(_ person: String, _ address: String, title: String = "Program Assistant") -> String {
        "<tr><td><div>\(person)</div></td><td>\(title)</td><td><a href='/directory'><div>\(address)</div></a></td><td>555-0100</td></tr>"
    }
    func testLabeledDirectoryRowsAssociateOpaqueAddressesWithoutMailtoAcrossIndustries() throws {
        for title in ["Program Assistant", "Sales Engineer", "Volunteer Coordinator"] {
            let html = "<table>" + head + entry("Jane Smith", "js5391@example.org", title: title) + entry("John Jones", "jj9021@example.org", title: title) + "</table>"
            let found = SourcePersonMatcher.collect(html)
            XCTAssertEqual(found["js5391@example.org"]?.name, "Jane Smith")
            XCTAssertEqual(found["jj9021@example.org"]?.name, "John Jones")
            XCTAssertEqual(found["js5391@example.org"]?.method, .directoryRow)
        }
    }
    func testHeaderlessRowsRequireAddressCorroborationAndKeepNeighborsSeparate() {
        let html = "<table>" + entry("Jane Smith", "jcsmith@example.org") + entry("John Jones", "jjones@example.org") + entry("Alice Brown", "opaque012@example.org") + "</table>"
        let found = SourcePersonMatcher.collect(html)
        XCTAssertEqual(found["jcsmith@example.org"]?.name, "Jane Smith")
        XCTAssertEqual(found["jjones@example.org"]?.name, "John Jones")
        XCTAssertNil(found["opaque012@example.org"])
    }
    func testAmbiguousRowsAndBoundaryFailuresAreRejected() {
        let address = "js5391@example.org"
        for body in [
            "<tr><td>Jane Smith</td><td>Program Assistant</td><td>\(address) other@example.org</td><td>555</td></tr>",
            "<tr><td>Jane Smith</td><td>Program Assistant</td><td><a href='mailto:other@example.org'>\(address)</a></td><td>555</td></tr>",
            "<tr><td>Jane Smith</td><td>Program Assistant</td></tr><tr><td>\(address)</td><td>555</td></tr>",
            "<tr><td colspan='2'>Jane Smith</td><td>\(address)</td><td>555</td></tr>",
            "<tr><td>Jane Smith</td><td>Program Assistant</td><td>\(address)</td></tr>",
            "<tr><td>Jane Smith</td><td>Program Assistant</td><tr><td>\(address)</td><td>555</td></tr>",
            "<tr><td>Executive Director</td><td>Program Assistant</td><td>\(address)</td><td>555</td></tr>",
            "<tr><td>Jane Smith</td><td><table><tr><td>Other Person</td></tr></table></td><td>\(address)</td><td>555</td></tr>"
        ] { XCTAssertNil(SourcePersonMatcher.collect("<table>" + head + body + "</table>")[address], body) }
        let differentTables = "<table>" + head + "</table><table>" + entry("Jane Smith", address) + "</table>"
        XCTAssertNil(SourcePersonMatcher.collect(differentTables)[address])
    }
    func testHiddenRowsCellsTablesTemplatesAndScriptsAreRejected() {
        let address = "js5391@example.org"
        let row = entry("Jane Smith", address)
        for html in [
            "<table hidden>" + head + row + "</table>",
            "<div hidden><div><table>" + head + row + "</table></div></div>",
            "<section aria-hidden='true'><table>" + head + row + "</table></section>",
            "<table>" + head + row.replacingOccurrences(of: "<tr>", with: "<tr hidden>") + "</table>",
            "<table>" + head + row.replacingOccurrences(of: "<td>", with: "<td aria-hidden='true'>") + "</table>",
            "<table>" + head + row.replacingOccurrences(of: "<div>", with: "<div style='display:none'>") + "</table>",
            "<template><table>" + head + row + "</table></template>",
            "<script><table>" + head + row + "</table></script>"
        ] { XCTAssertNil(SourcePersonMatcher.collect(html)[address], html) }
    }
    func testConflictingRowsAndExplicitAssociationsAbstain() {
        let address = "js5391@example.org"
        let table = "<table>" + head + entry("Jane Smith", address) + "</table>"
        XCTAssertNil(SourcePersonMatcher.collect(table + "<table>" + head + entry("John Jones", address) + "</table>")[address])
        XCTAssertNil(SourcePersonMatcher.collect(table + "<a href='mailto:\(address)'>John Jones</a>")[address])
    }
    func testPublicationClassifiesPersonButPreservesSharedInboxAndSavedCorrection() throws {
        let html = "<table>" + head + entry("Jane Smith", "js5391@example.org") + entry("John Jones", "info@example.org") + "</table>"
        let source = "https://example.org/directory"
        let response = HTTPResult(data: Data(html.utf8), status: 200, finalURL: URL(string: source), mimeType: "text/html")
        var row = FoundEmail(address: "js5391@example.org", source: source, status: "Accepted", reason: "Local checks")
        row.websiteConfirmation = WebsiteConfirmer.observe(address: row.address, source: source, response: response, checkedAt: Date())
        row.learningEvidence = LearningEvidence(category: .uncertain, exact: false, reason: "Your learned page-context patterns disagree; kept for review")
        XCTAssertEqual(row.addressClassification.category, .person)
        XCTAssertEqual(row.websiteConfirmation?.personAssociation?.method, .directoryRow)
        XCTAssertEqual(try JSONDecoder().decode(FoundEmail.self, from: JSONEncoder().encode(row)), row)
        row.classificationDecision = ClassificationDecision(category: .general, changedAt: Date())
        XCTAssertEqual(row.addressClassification.category, .general)
        var shared = FoundEmail(address: "info@example.org", source: source, status: "Accepted", reason: "Local checks")
        shared.websiteConfirmation = WebsiteConfirmer.observe(address: shared.address, source: source, response: response, checkedAt: Date())
        XCTAssertEqual(shared.addressClassification.category, .general)
    }
    func testLegacyNameCheckCanBeRetriedAndCurrentCheckKeepsCooldown() {
        var row = FoundEmail(address: "js5391@example.org", source: "https://example.org/directory", status: "Accepted", reason: "Local checks")
        row.websiteConfirmation = WebsiteConfirmation(outcome: .notFound, reason: "Checked", sourceURL: row.source, personNameCheckVersion: 1)
        XCTAssertEqual(AutomaticPersonSort.targets([row], selected: [row.id], rules: [], removed: []).count, 1)
        row.websiteConfirmation?.personNameCheckVersion = SourcePersonMatcher.version
        XCTAssertTrue(AutomaticPersonSort.targets([row], selected: [row.id], rules: [], removed: []).isEmpty)
    }
    func testPageAboveOldOneMegabyteLimitRetainsNameEvidenceAndOversizedInputIsRejected() {
        let table = "<table>" + head + entry("Jane Smith", "js5391@example.org") + "</table>"
        let html = "<script>" + String(repeating: " ", count: 1_030_000) + "</script>" + table
        XCTAssertEqual(SourcePersonMatcher.collect(html)["js5391@example.org"]?.name, "Jane Smith")
        let source = "https://example.org/directory"
        let response = HTTPResult(data: Data(html.utf8), status: 200, finalURL: URL(string: source), mimeType: "text/html")
        let proof = WebsiteConfirmer.observe(address: "js5391@example.org", source: source, response: response, checkedAt: Date())
        XCTAssertEqual(proof.outcome, .published)
        XCTAssertEqual(proof.personAssociation?.name, "Jane Smith")
        XCTAssertTrue(SourcePersonMatcher.collect(String(repeating: " ", count: WebsiteConfirmer.maximumBytes + 1) + table).isEmpty)
    }
    func testExistingUnresolvedListRecordUpgradesInPlaceAfterSourceRecheck() {
        let source = "https://example.org/directory"
        var saved = FoundEmail(address: "js5391@example.org", source: source, status: "Accepted", reason: "Local checks")
        saved.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Previously found without name", checkedAt: Date(timeIntervalSince1970: 1), sourceURL: source, httpStatus: 200, excerpt: "Jane Smith js5391@example.org", personNameCheckVersion: 1)
        saved.learningEvidence = LearningEvidence(category: .uncertain, exact: false, reason: "Your learned page-context patterns disagree; kept for review")
        let before = saved
        XCTAssertEqual(saved.addressClassification.category, .uncertain)
        XCTAssertEqual(AutomaticPersonSort.targets([saved], selected: [saved.id], rules: [], removed: []).count, 1)
        let html = "<table>" + head + entry("Jane Smith", saved.address) + "</table>"
        let checker = WebsiteConfirmer(fetch: { request,_,_ in
            HTTPResult(data: Data(html.utf8), status: 200, finalURL: request.url, mimeType: "text/html")
        })
        WebsiteConfirmationPolicy.apply(checker.confirmPerson(address: saved.address, source: source), to: &saved)
        XCTAssertEqual(saved.addressClassification.category, .person)
        XCTAssertEqual(saved.id, before.id)
        XCTAssertEqual(saved.address, before.address)
        XCTAssertEqual(saved.source, before.source)
        XCTAssertEqual(saved.learningEvidence, before.learningEvidence)
        XCTAssertEqual(saved.websiteConfirmation?.personNameCheckVersion, SourcePersonMatcher.version)
        XCTAssertTrue(AutomaticPersonSort.targets([saved], selected: [saved.id], rules: [], removed: []).isEmpty)
    }
    func testTableMatchingCooperativelyCancels() {
        var checks = 0
        let html = "<table>" + head + String(repeating: entry("Jane Smith", "jcsmith@example.org"), count: 2000) + "</table>"
        XCTAssertTrue(SourcePersonMatcher.collect(html, cancelled: { checks += 1; return checks > 50 }).isEmpty)
    }
    func testCrawlerAttachesDirectoryAssociationWithoutExtraRequests() throws {
        var requests = 0
        let html = "<table>" + head + entry("Jane Smith", "js5391@example.org") + entry("John Jones", "jj9021@example.org") + "</table>"
        let engine = GrabEngine(settings: settings(pages: 1), fetcher: { url in
            requests += 1
            return HTTPResult(data: Data((url.path == "/robots.txt" ? "User-agent: *" : html).utf8), status: 200, finalURL: url, mimeType: "text/html")
        }, sleep: { _ in })
        let rows = engine.run(mode: .website, terms: ["https://example.org/directory"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(requests, 2)
        XCTAssertEqual(rows.count, 2)
        XCTAssertTrue(rows.allSatisfy { $0.addressClassification.category == .person })
        XCTAssertEqual(CrawlDisk.load()?.rows.first?.websiteConfirmation?.personAssociation?.method, .directoryRow)
    }
}
