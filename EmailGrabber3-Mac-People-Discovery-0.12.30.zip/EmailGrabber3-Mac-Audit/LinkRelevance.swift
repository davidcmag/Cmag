import Foundation

struct CrawlLink {
    let url: URL
    let label: String
    let nofollow: Bool
}

enum LinkRelevance {
    static let queuePreviewLimit = 2000
    private static let peopleSearchHosts = ["addresses.com", "whitepages.com", "spokeo.com", "beenverified.com", "truepeoplesearch.com", "fastpeoplesearch.com", "peoplefinders.com", "intelius.com", "radaris.com", "mylife.com"]
    private static let gamingHosts = ["steamcommunity.com", "steampowered.com"]
    static func crawlTrapReason(_ url: URL) -> String? {
        guard let host = url.host?.lowercased() else { return nil }
        if peopleSearchHosts.contains(where: { host == $0 || host.hasSuffix("." + $0) }) { return "People-search directory is outside contact-discovery crawl scope" }
        if gamingHosts.contains(where: { host == $0 || host.hasSuffix("." + $0) }) { return "Gaming/community profile is outside contact-discovery crawl scope" }
        return nil
    }
    private static let anchors = try! NSRegularExpression(pattern: #"(?is)<a\b([^>]*?)>(.*?)</a\s*>"#)
    private static let href = try! NSRegularExpression(pattern: #"(?i)\bhref\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))"#)
    private static let rel = try! NSRegularExpression(pattern: #"(?i)\brel\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))"#)
    private static let labelTags = try! NSRegularExpression(pattern: #"<[^>]+>"#)

    private static let topicQualifiers: Set<String> = ["host","website","contact","official","best","top","find","list","directory","online"]
    private static let utilityHosts = ["facebook.com","instagram.com","twitter.com","x.com","linkedin.com","youtube.com","tiktok.com","pinterest.com","google.com","bing.com","duckduckgo.com","doubleclick.net","googlesyndication.com","paypal.com"]
    private static let stopWords: Set<String> = ["the","and","for","with","from","that","this","website","websites","www","com","org","net","http","https","official"]
    static func tokens(_ value: String) -> Set<String> {
        let text = value.folding(options: [.caseInsensitive,.diacriticInsensitive], locale: Locale(identifier: "en_US_POSIX"))
        let pieces = text.components(separatedBy: CharacterSet.alphanumerics.inverted)
        return Set(pieces.filter { $0.count >= 3 && !stopWords.contains($0) }.map { $0.count > 4 && $0.hasSuffix("s") ? String($0.dropLast()) : $0 })
    }
    static func canonical(_ url: URL) -> URL? {
        guard EmailPolicy.httpURL(url), var c = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return nil }
        c.fragment = nil
        if c.path.isEmpty { c.path = "/" }
        c.queryItems = c.queryItems?.filter { !$0.name.lowercased().hasPrefix("utm_") && !["fbclid","gclid","msclkid"].contains($0.name.lowercased()) }
        let languages: Set<String> = ["en", "en-us", "en-gb", "de", "fr", "es", "it", "hu", "nl", "pt", "pt-br", "pl", "ru", "ja", "ko", "zh", "zh-cn", "zh-tw", "ar", "english", "german", "french", "spanish", "italian", "hungarian", "dutch", "portuguese", "brazilian", "polish", "russian", "japanese", "koreana", "schinese", "tchinese", "turkish", "swedish", "finnish", "danish", "norwegian", "czech", "romanian", "ukrainian"]
        let segments = c.path.lowercased().split(separator: "/").map(String.init)
        let profileSections: Set<String> = ["people", "staff", "profile", "profiles", "faculty", "authors", "hosts"]
        let individualProfile = segments.count >= 2 && profileSections.contains(segments[segments.count - 2])
        c.queryItems = c.queryItems?.filter { item in
            let key = item.name.lowercased()
            if ["l", "lang", "language", "locale", "hl"].contains(key), languages.contains(item.value?.lowercased() ?? "") { return false }
            if individualProfile && ["page", "paged"].contains(key) { return false }
            return true
        }
        if c.queryItems?.isEmpty == true { c.queryItems = nil }
        return c.url
    }
    static func links(_ html: String, base: URL, cancelled: () -> Bool = { false }) -> [CrawlLink] {
        var result: [CrawlLink] = []
        for a in TextScan.matches(anchors, in: html, cancelled: cancelled) {
            if cancelled() { return [] }
            guard let attrs = Range(a.range(at: 1), in: html), let content = Range(a.range(at: 2), in: html) else { continue }
            let text = String(html[attrs])
            guard let h = TextScan.matches(href, in: text, cancelled: cancelled).first, let capture = (1...3).compactMap({ Range(h.range(at: $0), in: text) }).first else { continue }
            let raw = EmailPolicy.decodeHTML(String(text[capture]), cancelled: cancelled)
            guard !raw.isEmpty, let resolved = URL(string: raw, relativeTo: base)?.absoluteURL, let url = canonical(resolved) else { continue }
            let inner = String(html[content])
            let label = EmailPolicy.decodeHTML(inner.contains("<") ? TextScan.replacing(labelTags, in: inner, with: " ", cancelled: cancelled) : inner)
            var relation = ""
            if let r = TextScan.matches(rel, in: text, cancelled: cancelled).first, let capture = (1...3).compactMap({ Range(r.range(at: $0), in: text) }).first { relation = String(text[capture]).lowercased() }
            let directives = Set(relation.split(whereSeparator: \.isWhitespace).map(String.init))
            result.append(CrawlLink(url: url, label: String(label.prefix(2048)), nofollow: !directives.isDisjoint(with: ["nofollow","sponsored"])))
        }
        return result
    }
    static func priority(_ link: CrawlLink) -> Int {
        let segments = link.url.path.lowercased().split(separator: "/").map(String.init)
        // A staff/profile ancestor must not promote its article archives and
        // analysis pagination to contact pages in adaptive mode.
        if !Set(segments).isDisjoint(with: ["analysis", "article", "articles", "story", "stories", "posts", "post", "archive", "archives", "feed", "feeds", "calendar", "event", "events", "gallery", "search", "login", "signin", "checkout"]) { return -5 }
        let direct: Set<String> = ["contact","contacts","staff","team","people","directory","about","leadership","sales","profile","profiles","faculty","hosts","author","authors","contributors"]
        for segment in segments {
            let base = segment.split(separator: ".").first.map(String.init) ?? segment
            let aliases: Set<String> = ["contactus","aboutus","contact_us","about_us","ourteam","our_team","ourstaff","our_staff","staffdirectory","meettheteam"]
            if direct.contains(base) || aliases.contains(base) || ["contact-","contact_","about-","about_","staff-","staff_","team-","team_","profile-","profile_"].contains(where: base.hasPrefix) { return 10 }
        }
        let label = link.label.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let labels: Set<String> = ["contact","contact us","staff","our staff","team","our team","meet the team","people","directory","about","about us","leadership","sales","profile","faculty","hosts","our hosts","meet the hosts","authors","contributors"]
        if labels.contains(label) { return 10 }
        if !tokens(link.url.path).isDisjoint(with: ["privacy","terms","legal","blog","news","event","gallery","login","signin","checkout"]) { return -5 }
        let peopleWords: Set<String> = ["faculty", "staff", "directory", "personnel", "employee"]
        if !tokens(link.url.path + " " + label).isDisjoint(with: peopleWords) { return 10 }
        // Academic gateways are needed to reach departmental staff directories.
        if segments.contains(where: { ["academics", "academic", "departments", "schools", "colleges"].contains($0) || $0.hasPrefix("academic-") }) { return 5 }
        return 0
    }
    static func priority(_ link: CrawlLink, from source: URL) -> Int {
        let score = priority(link)
        guard score == 0,
              EmailPolicy.canonicalHost(link.url.host ?? "") == EmailPolicy.canonicalHost(source.host ?? ""),
              !tokens(source.path + " " + (source.host ?? "")).isDisjoint(with: ["staff", "faculty", "directory", "people", "personnel"]),
              AddressClassification.plausiblePublishedName(link.label) else { return score }
        return 8
    }
    static func topicWords(_ topic: String) -> Set<String> {
        let all = tokens(topic)
        let strong = all.subtracting(topicQualifiers)
        return strong.isEmpty ? all : strong
    }
    static func relevant(_ link: CrawlLink, from source: URL, topic: String) -> Bool {
        relevant(link, from: source, topicWords: topicWords(topic))
    }
    static func relevant(_ link: CrawlLink, from source: URL, topicWords: Set<String>) -> Bool {
        guard !link.nofollow, EmailPolicy.httpURL(link.url), let rawHost = link.url.host else { return false }
        let host = EmailPolicy.canonicalHost(rawHost)
        guard crawlTrapReason(link.url) == nil else { return false }
        guard !utilityHosts.contains(where: { host == $0 || host.hasSuffix("."+$0) }) else { return false }
        let label = link.label.lowercased()
        if ["website by","web design","powered by","developed by","advertis","sponsored","privacy policy","terms of","share on"].contains(where: label.contains) { return false }
        let words = tokens(link.url.path + " " + link.label)
        if !words.isDisjoint(with: ["privacy","login","signin","checkout","cookie","sharer"]) { return false }
        let directory = !tokens(source.path + " " + (source.host ?? "")).isDisjoint(with: ["directory","listing","member","partner","association","resource"])
        if !topicWords.isEmpty {
            if !words.isDisjoint(with: topicWords) { return true }
            // A relevant directory can identify people/sites by name, without
            // repeating the search topic on every "official website" link.
            let named = !tokens(link.label).isEmpty
            let directoryMatchesTopic = !tokens(source.absoluteString).isDisjoint(with: topicWords)
            return directory && directoryMatchesTopic && (named || label.contains("website"))
        }
        // Direct URL crawls have no supplied topic: require an explicit useful
        // relationship or a named directory entry, rather than every footer link.
        return !words.isDisjoint(with: ["contact","staff","team","people","sales","faculty","profile","directory","member","partner","association"]) || (directory && !tokens(link.label).isEmpty)
    }
}
