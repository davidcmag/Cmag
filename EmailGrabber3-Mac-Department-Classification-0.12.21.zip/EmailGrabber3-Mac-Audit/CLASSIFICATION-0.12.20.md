# Screenshot classification fixes — 0.12.20

0.12.19 stopped promoting bare city/name collisions to Likely person, but left
the reported office accounts Uncertain. This follow-up resolves the actual
institutional cases and distinguishes technical identifiers from real mailboxes.

- City handles can classify as General inbox when the city/state relationship
  agrees with a regional service-organization domain. For example Sandusky,
  Columbus and Cleveland agree with Ohio in ohiolegal.org. This rule combines
  location, state and domain function rather than matching a full email address.
  The city/state reference is bounded, not a complete geographic database.
- Online, student health and related campus services are shared functions.
  Mailto is a generic link/documentation-style handle, not positive name evidence.
- One/two-letter prefixes on student handles at .edu domains infer a generic
  student account when there is no explicit full-name association. They do not
  establish a deliverable shared mailbox. Published full-name evidence can still
  identify a person, as can the user's saved corrections.
- A 32-character hexadecimal key at an explicitly named bug-reporting endpoint
  is technical telemetry. It is rejected from Included results and future
  extraction, while existing saved originals remain available in All. Ordinary
  hexadecimal mailbox names and personal addresses with numeric suffixes are
  preserved. This is not a blanket numeric-address filter.

Four additional regression tests cover the full screenshot's relevant shared
accounts, matching and mismatching geographic contexts, real personal controls,
explicit student/person evidence and precise telemetry rejection. All prior
tests, including learning, manual overrides, removal, export and preservation,
remain enabled. See CORE-TESTS.log for the complete run.

No reset of learning, saved data, manual decisions or removal history. Existing
automatic rows use new classification on opening. Role-based crawl exclusions
are unchanged. No paid verification or public SMTP probes. Native Mac build and
GUI acceptance cannot be run on this Linux host; the supplied source must be
compiled on macOS as in previous versions.
