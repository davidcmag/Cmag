import Foundation

enum SMTPFailure: Error, Equatable { case invalidInput, cancelled, timeout, disconnected, protocolError, oversized, connection, tlsUnavailable, tlsFailed, certificateRejected }
struct SMTPReply: Equatable {
    var code: Int
    var lines: [String]
    var text: String { lines.joined(separator: "\n") }
    var enhanced: String? {
        for line in lines {
            if let r = line.range(of: #"(?:^|\s)[245]\.[0-9]{1,3}\.[0-9]{1,3}(?:\s|$)"#, options: .regularExpression) { return line[r].trimmingCharacters(in: .whitespacesAndNewlines) }
        }
        return nil
    }
    static func read(line: () throws -> Data) throws -> SMTPReply {
        var lines: [String] = []; var expected: Int?; var bytes = 0
        for _ in 0..<64 {
            let data = try line(); bytes += data.count
            guard bytes <= 32_768, data.count <= 2048 else { throw SMTPFailure.oversized }
            guard data.count >= 4, data.suffix(2) == Data([13,10]) else { throw SMTPFailure.protocolError }
            let raw = Array(data.dropLast(2))
            guard raw.count >= 3, raw.prefix(3).allSatisfy({ (48...57).contains($0) }), let code = Int(String(decoding: raw.prefix(3), as: UTF8.self)), (200...599).contains(code), raw.count == 3 || raw[3] == 32 || raw[3] == 45 else { throw SMTPFailure.protocolError }
            guard expected == nil || expected == code else { throw SMTPFailure.protocolError }
            expected = code
            lines.append(String(decoding: raw.dropFirst(min(4, raw.count)), as: UTF8.self))
            if raw.count == 3 || raw[3] == 32 { return SMTPReply(code: code, lines: lines) }
        }
        throw SMTPFailure.oversized
    }
}
protocol SMTPWire: AnyObject {
    func readReply() throws -> SMTPReply
    func command(_ value: String) throws -> SMTPReply
    func startTLS(host: String) throws
    func close()
}
struct SMTPOptions: Codable, Hashable {
    var ehlo = "emailgrabber.invalid"
    var sender = ""
    var requireTLS = true
    var timeout: TimeInterval = 10
    var temporaryRetries = 1
    var cooldown: TimeInterval = 30
    var valid: Bool { MailAddressSafety.hostname(ehlo) && EmailPolicy.validSyntax(sender) && !ehlo.lowercased().hasSuffix(".invalid") && !sender.lowercased().hasSuffix(".invalid") }
}
struct SMTPObservation: Codable, Hashable {
    var at = Date()
    var server: String
    var ip: String
    var stage: String
    var code: Int?
    var text: String
    var tls: Bool
}
struct SMTPVerification: Codable, Hashable {
    enum Verdict: String, Codable { case accepted = "SMTP accepted", rejected = "SMTP rejected", catchAll = "Catch-all", temporary = "Temporary", blocked = "Blocked", unknown = "Unknown", cancelled = "Cancelled", deferred = "Deferred" }
    var verdict: Verdict
    var reason: String
    var checkedAt = Date()
    var checkerVersion = "smtp-0.12.3-dev"
    var observations: [SMTPObservation] = []
    var flags: [String] = []
    var connectionFailed = false
    var options: SMTPOptions?
    var retryAfter: Date?
    var probeAttempted: Bool?
    var canRetry: Bool { [.temporary, .blocked, .unknown, .cancelled, .deferred].contains(verdict) }
    func retryIsDue(at date: Date) -> Bool { canRetry && (retryAfter == nil || retryAfter! <= date) }
}
struct ProviderVerification: Codable, Hashable {
    var status: String
    var reason: String
    var checkedAt = Date()
    var checkerVersion = "ZeroBounce-v2"
    var requestFailed = false
    var lastConclusionStatus: String?
    var lastConclusionReason: String?
    var lastConclusionAt: Date?
}

/// One instance per serial batch. There is never a message body, authentication,
/// VRFY or EXPN. RCPT acceptance is evidence, not a delivery guarantee.
final class MailboxVerifier {
    typealias Connect = (String, String, TimeInterval, @escaping () -> Bool) throws -> SMTPWire
    private let resolve: (String, () -> Bool) -> MailRoutingResult
    private let connect: Connect
    private let now: () -> Date
    private let sleep: (TimeInterval) -> Void
    private var cooldowns: [String: Date] = [:]
    init(routing: MailRouting = MailRouting(), connect: @escaping Connect = { try SMTPSocketWire(ip: $0, host: $1, timeout: $2, cancelled: $3) }, now: @escaping () -> Date = Date.init, sleep: @escaping (TimeInterval) -> Void = Thread.sleep(forTimeInterval:)) {
        self.resolve = { routing.resolve($0, cancelled: $1) }; self.connect = connect; self.now = now; self.sleep = sleep
    }
    init(resolve: @escaping (String, () -> Bool) -> MailRoutingResult, connect: @escaping Connect, now: @escaping () -> Date = Date.init, sleep: @escaping (TimeInterval) -> Void = { _ in }) {
        self.resolve = resolve; self.connect = connect; self.now = now; self.sleep = sleep
    }
    static func classify(_ reply: SMTPReply) -> SMTPVerification.Verdict {
        if [250,251].contains(reply.code) { return .accepted }
        if reply.code == 252 { return .unknown }
        if (400...499).contains(reply.code) || reply.enhanced == "5.2.2" { return .temporary }
        let lower = reply.text.lowercased()
        if reply.code >= 500 && ["relay", "authentication", "sender", "client ip", "client host", "blacklist", "blocklist", "policy", "access denied"].contains(where: lower.contains) { return .blocked }
        if reply.enhanced?.hasPrefix("5.7.") == true { return .blocked }
        if [550,553].contains(reply.code), reply.enhanced == "5.1.1" { return .rejected }
        // Some MTAs give recipient-specific English text without enhanced
        // status codes. Only narrow, explicit nonexistent-recipient phrases
        // qualify; generic 550/553, account-disabled and policy replies do not.
        let explicitMissing = ["no such user", "no such recipient", "no such mailbox", "user unknown", "unknown user", "unknown recipient", "unknown mailbox", "recipient does not exist", "mailbox does not exist", "mailbox not found", "recipient not found", "recipient address rejected: user unknown"]
        let contradictory = ["not unknown", "not found in allow", "not found in white", "not found in directory cache", "cannot verify", "unable to verify", "unverified", "disabled", "suspended", "not permitted", "not authorized", "lookup failed", "lookup failure", "directory unavailable", "temporarily", "temporary", "try again", "rate limit", "greylist", "graylist"]
        if [550,553].contains(reply.code), reply.enhanced == nil,
           explicitMissing.contains(where: lower.contains), !contradictory.contains(where: lower.contains) { return .rejected }
        return .unknown
    }
    func verify(_ address: String, options: SMTPOptions, cancelled: @escaping () -> Bool = { false }) -> SMTPVerification {
        var evidence: [SMTPObservation] = []
        var attempted = false
        let flags = DisposableDomainData.flags(address)
        func result(_ verdict: SMTPVerification.Verdict, _ reason: String, connectionFailed: Bool = false) -> SMTPVerification {
            let wait: TimeInterval? = verdict == .temporary || verdict == .unknown ? 300 : verdict == .blocked ? 1800 : nil
            var explanation = reason
            if ![.accepted, .catchAll, .deferred, .cancelled].contains(verdict), let response = evidence.last(where: { $0.code != nil && ($0.code! >= 400 || $0.code! == 252) }) {
                explanation += " [" + response.stage + " @ " + response.server + ": " + String(response.code!) + " " + response.text.prefix(300) + "]"
            } else if ![.accepted, .catchAll, .deferred, .cancelled].contains(verdict), let failure = evidence.last, failure.stage == "transport" {
                explanation += " [" + failure.server + ": " + failure.text + "]"
            }
            return SMTPVerification(verdict: verdict, reason: explanation, checkedAt: now(), observations: evidence, flags: flags, connectionFailed: connectionFailed, options: options, retryAfter: wait.map { now().addingTimeInterval($0) }, probeAttempted: attempted)
        }
        guard !cancelled() else { return result(.cancelled, "Cancelled") }
        guard EmailPolicy.validSyntax(address) else { return result(.unknown, "Unsupported address syntax; no probe sent") }
        guard options.valid else { return result(.unknown, "Supply your own valid EHLO hostname and sender identity; no probe sent") }
        let domain = String(address.split(separator: "@")[1]).lowercased()
        if let until = cooldowns[domain], until > now() {
            var answer = result(.deferred, "Not probed: domain is cooling down after an earlier inconclusive check")
            answer.retryAfter = until
            return answer
        }
        let routing = resolve(domain, cancelled)
        guard !cancelled() else { return result(.cancelled, "Cancelled") }
        switch routing.state {
        case .nxDomain, .nullMX: return result(.rejected, routing.reason)
        case .temporary: return result(.temporary, routing.reason)
        case .unknown, .noMail: return result(.unknown, routing.reason)
        case .routes: break
        }
        let deadline = now().addingTimeInterval(120)
        var connected = false; var last: SMTPVerification.Verdict = .unknown
        let preferred = routing.routes.map(\.preference).min() ?? 0
        for route in routing.routes.prefix(3) {
            for ip in route.addresses.prefix(2) {
                guard MailAddressSafety.publicIP(ip) else { continue }
                for retry in 0...min(1, max(0, options.temporaryRetries)) {
                    guard !cancelled() else { return result(.cancelled, "Cancelled") }
                    guard now() < deadline else { return result(.temporary, "Overall verification time limit reached") }
                    var tls = false
                    func record(_ stage: String, _ reply: SMTPReply) {
                        if evidence.count < 128 { evidence.append(.init(at: now(), server: route.host, ip: ip, stage: stage, code: reply.code, text: reply.text, tls: tls)) }
                    }
                    do {
                        attempted = true
                        let wire = try connect(ip, route.host, min(20, max(1, options.timeout)), { cancelled() || self.now() >= deadline })
                        connected = true
                        defer { wire.close() }
                        func cmd(_ text: String, stage: String? = nil) throws -> SMTPReply {
                            guard !cancelled() else { throw SMTPFailure.cancelled }
                            let reply = try wire.command(text); record(stage ?? text.components(separatedBy: " ")[0], reply); return reply
                        }
                        let greeting = try wire.readReply(); record("greeting", greeting)
                        guard greeting.code == 220 else { last = greeting.code / 100 == 4 ? .temporary : .blocked; throw SMTPFailure.protocolError }
                        var hello = try cmd("EHLO " + options.ehlo)
                        if [500,502,504].contains(hello.code) { hello = try cmd("HELO " + options.ehlo) }
                        guard hello.code == 250 else { last = hello.code / 100 == 4 ? .temporary : .blocked; throw SMTPFailure.protocolError }
                        let supportsTLS = hello.lines.contains { $0.uppercased().split(whereSeparator: \.isWhitespace).first == "STARTTLS" }
                        if supportsTLS {
                            guard try cmd("STARTTLS").code == 220 else { throw SMTPFailure.tlsFailed }
                            try wire.startTLS(host: route.host); tls = true
                            guard try cmd("EHLO " + options.ehlo).code == 250 else { throw SMTPFailure.protocolError }
                        } else if options.requireTLS { throw SMTPFailure.tlsUnavailable }
                        func recipient(_ value: String, stage: String) throws -> SMTPReply {
                            // Each target/control uses a new transaction, never DATA.
                            let reset = try cmd("RSET")
                            guard reset.code == 250 else { throw SMTPFailure.protocolError }
                            let mail = try cmd("MAIL FROM:<" + options.sender + ">")
                            guard mail.code == 250 else { last = mail.code / 100 == 4 ? .temporary : .blocked; throw SMTPFailure.protocolError }
                            return try cmd("RCPT TO:<" + value + ">", stage: stage)
                        }
                        let target = try recipient(address, stage: "target RCPT")
                        last = Self.classify(target)
                        if last == .accepted {
                            var a = "eg-check-" + UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased() + "@" + domain
                            while a.lowercased() == address.lowercased() { a = "eg-check-" + UUID().uuidString.lowercased() + "@" + domain }
                            var b = "eg-check-" + UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased() + "@" + domain
                            while b == a || b.lowercased() == address.lowercased() { b = "eg-check-" + UUID().uuidString.lowercased() + "@" + domain }
                            let controlA = Self.classify(try recipient(a, stage: "control 1 RCPT"))
                            let controlB = Self.classify(try recipient(b, stage: "control 2 RCPT"))
                            _ = try? cmd("RSET"); _ = try? cmd("QUIT")
                            if controlA == .rejected && controlB == .rejected { return result(.accepted, "Target accepted; two random controls rejected. Delivery is not guaranteed.") }
                            if controlA == .accepted && controlB == .accepted { return result(.catchAll, "Target and both random controls accepted. This may be a catch-all or an accepting mail gateway; individual mailbox existence remains unconfirmed") }
                            cooldowns[domain] = now().addingTimeInterval(max(5, options.cooldown))
                            return result(.unknown, "Target accepted but controls were mixed, blocked, temporary or inconclusive")
                        }
                        _ = try? cmd("RSET"); _ = try? cmd("QUIT")
                        if last == .rejected && route.preference == preferred { return result(.rejected, "Preferred mail server explicitly rejected this recipient; see recorded response") }
                        if last == .rejected { last = .unknown } // Backup rejection is not definitive.
                        if last == .blocked || last == .unknown { break }
                    } catch {
                        if cancelled() { return result(.cancelled, "Cancelled") }
                        if last == .accepted { last = .unknown }
                        if evidence.count < 128 { evidence.append(.init(at: now(), server: route.host, ip: ip, stage: "transport", code: nil, text: String(describing: error), tls: tls)) }
                        if error as? SMTPFailure == .tlsFailed || error as? SMTPFailure == .tlsUnavailable || error as? SMTPFailure == .certificateRejected { last = .unknown; break }
                    }
                    if last != .temporary || retry >= min(1, max(0, options.temporaryRetries)) { break }
                    // Short cancellable backoff; longer greylisting is left to a
                    // later user-initiated batch rather than hammering a server.
                    for _ in 0..<300 {
                        if cancelled() || now() >= deadline { break }
                        sleep(0.1)
                    }
                }
            }
        }
        let cooldown: TimeInterval = last == .temporary ? 300 : last == .blocked ? 1800 : 60
        cooldowns[domain] = now().addingTimeInterval(max(cooldown, options.cooldown))
        return result(last, connected ? "Mail server response was inconclusive; inspect SMTP evidence" : "Could not connect to recipient servers; outbound port 25 may be restricted", connectionFailed: !connected)
    }
}

enum VerificationApplication {
    static func eligible(_ row: FoundEmail, rules: [SmartRule], removed: Set<String>) -> Bool {
        !removed.contains(row.address.lowercased()) && !rules.contains { $0.matches(row.address) } && !row.status.hasPrefix("Excluded") && row.status != "Removed" && TechnicalAddressPolicy.rejectionReason(row.address) == nil && EmailPolicy.validSyntax(row.address)
    }
    static func targets(_ rows: [FoundEmail], selected: Set<UUID>? = nil, rules: [SmartRule], removed: Set<String>, uncheckedOnly: Bool = false, retryDueOnly: Bool = false, now: Date = Date()) -> [String] {
        var seen = Set<String>()
        return rows.filter { (selected == nil || selected!.contains($0.id)) && eligible($0, rules: rules, removed: removed) && (!uncheckedOnly || $0.smtpVerification == nil) && (!retryDueOnly || $0.smtpVerification?.retryIsDue(at: now) == true) }.compactMap {
            seen.insert($0.address.lowercased()).inserted ? $0.address : nil
        }.prefix(100).map { $0 }
    }
    static func smtp(_ result: SMTPVerification, to row: inout FoundEmail) {
        if let previous = row.smtpVerification {
            var history = row.smtpHistory ?? []
            history.append(previous)
            row.smtpHistory = Array(history.suffix(8))
        }
        row.smtpVerification = result
        guard !row.status.hasPrefix("Excluded") && row.status != "Removed" && TechnicalAddressPolicy.rejectionReason(row.address) == nil else { return }
        // Keep the provider conclusion separate and visible until explicitly
        // compared. A new SMTP attempt must not erase it.
        guard row.providerVerification?.requestFailed != false else { row.checkedAt = max(row.checkedAt, result.checkedAt); return }
        switch result.verdict {
        case .accepted: row.status = "Accepted"
        case .rejected: row.status = "Rejected"
        case .catchAll, .blocked, .temporary, .unknown: row.status = "Uncertain"
        case .cancelled, .deferred: return
        }
        row.reason = result.verdict.rawValue + ": " + result.reason; row.checkedAt = result.checkedAt
    }
    static func provider(_ result: ProviderVerification, to row: inout FoundEmail) {
        var record = result
        if result.requestFailed, let previous = row.providerVerification {
            record.lastConclusionStatus = previous.requestFailed ? previous.lastConclusionStatus : previous.status
            record.lastConclusionReason = previous.requestFailed ? previous.lastConclusionReason : previous.reason
            record.lastConclusionAt = previous.requestFailed ? previous.lastConclusionAt : previous.checkedAt
        }
        row.providerVerification = record
        guard !result.requestFailed, !row.status.hasPrefix("Excluded") && row.status != "Removed", TechnicalAddressPolicy.rejectionReason(row.address) == nil else { return }
        row.status = result.status; row.reason = result.reason; row.checkedAt = result.checkedAt
    }
}

enum VerificationCSV {
    static let header = "email,status,reason,source,checked_at,smtp_verdict,smtp_reason,smtp_checked_at,smtp_checker,smtp_evidence,smtp_flags,zerobounce_status,zerobounce_reason,zerobounce_checked_at,zerobounce_checker,zerobounce_request_failed,zerobounce_last_conclusion,zerobounce_last_conclusion_reason,zerobounce_last_conclusion_at,smtp_ehlo,smtp_sender,smtp_tls_required,smtp_retry_after,smtp_probe_attempted,smtp_previous_checks,website_result,website_reason,website_checked_at,website_source_url,website_final_url,website_http_status,website_match,website_excerpt,website_organization_domain,website_checker,website_previous_checks,website_pages_checked"
    static func line(_ row: FoundEmail) -> String {
        let date = ISO8601DateFormatter()
        var fields = [row.address, row.status, row.reason, row.source, date.string(from: row.checkedAt)]
        fields.append(row.smtpVerification?.verdict.rawValue ?? "")
        fields.append(row.smtpVerification?.reason ?? "")
        fields.append(row.smtpVerification.map { date.string(from: $0.checkedAt) } ?? "")
        fields.append(row.smtpVerification?.checkerVersion ?? "")
        fields.append(row.smtpVerification.flatMap { try? JSONEncoder().encode($0.observations) }.map { String(decoding: $0, as: UTF8.self) } ?? "")
        fields.append(row.smtpVerification?.flags.joined(separator: "; ") ?? "")
        fields.append(row.providerVerification?.status ?? "")
        fields.append(row.providerVerification?.reason ?? "")
        fields.append(row.providerVerification.map { date.string(from: $0.checkedAt) } ?? "")
        fields.append(row.providerVerification?.checkerVersion ?? "")
        fields.append(row.providerVerification.map { String($0.requestFailed) } ?? "")
        fields.append(row.providerVerification?.lastConclusionStatus ?? "")
        fields.append(row.providerVerification?.lastConclusionReason ?? "")
        fields.append(row.providerVerification?.lastConclusionAt.map { date.string(from: $0) } ?? "")
        fields.append(row.smtpVerification?.options?.ehlo ?? "")
        fields.append(row.smtpVerification?.options?.sender ?? "")
        fields.append(row.smtpVerification?.options.map { String($0.requireTLS) } ?? "")
        fields.append(row.smtpVerification?.retryAfter.map { date.string(from: $0) } ?? "")
        fields.append(row.smtpVerification?.probeAttempted.map(String.init) ?? "")
        fields.append(row.smtpHistory.flatMap { try? JSONEncoder().encode($0) }.map { String(decoding: $0, as: UTF8.self) } ?? "")
        fields.append(row.websiteConfirmation?.label ?? "")
        fields.append(row.websiteConfirmation?.reason ?? "")
        fields.append(row.websiteConfirmation.map { date.string(from: $0.checkedAt) } ?? "")
        fields.append(row.websiteConfirmation?.sourceURL ?? "")
        fields.append(row.websiteConfirmation?.finalURL ?? "")
        fields.append(row.websiteConfirmation?.httpStatus.map(String.init) ?? "")
        fields.append(row.websiteConfirmation?.match?.rawValue ?? "")
        fields.append(row.websiteConfirmation?.excerpt ?? "")
        fields.append(row.websiteConfirmation?.organizationDomain.map(String.init) ?? "")
        fields.append(row.websiteConfirmation?.checkerVersion ?? "")
        fields.append(row.websiteHistory.flatMap { try? JSONEncoder().encode($0) }.map { String(decoding: $0, as: UTF8.self) } ?? "")
        fields.append(row.websiteConfirmation?.pagesChecked.flatMap { try? JSONEncoder().encode($0) }.map { String(decoding: $0, as: UTF8.self) } ?? "")
        return fields.map(EmailPolicy.csvField).joined(separator: ",")
    }
}


enum VerificationEvidence {
    static func text(_ row: FoundEmail) -> String {
        let date = ISO8601DateFormatter()
        var lines = [row.address]
        if let smtp = row.smtpVerification {
            lines += ["SMTP: " + smtp.verdict.rawValue, smtp.reason,
                      "Checked: " + date.string(from: smtp.checkedAt), "Checker: " + smtp.checkerVersion]
            if let due = smtp.retryAfter { lines.append("Retry after: " + date.string(from: due)) }
            if let attempted = smtp.probeAttempted { lines.append("Recipient-server connection attempted: " + String(attempted)) }
            for item in smtp.observations {
                lines.append(date.string(from: item.at) + " | " + item.server + " [" + item.ip + "] | " + (item.tls ? "TLS" : "plain") + " | " + item.stage + " | " + (item.code.map(String.init) ?? "") + " " + item.text)
            }
        } else { lines.append("SMTP: unchecked") }
        if let history = row.smtpHistory, !history.isEmpty {
            lines.append("Previous SMTP checks (up to eight):")
            for check in history { lines.append(date.string(from: check.checkedAt) + " | " + check.verdict.rawValue + " | " + check.reason) }
        }
        if let provider = row.providerVerification {
            lines += ["ZeroBounce: " + provider.status, provider.reason, "Provider checked: " + date.string(from: provider.checkedAt)]
            if let previous = provider.lastConclusionStatus { lines.append("Earlier provider conclusion: " + previous + " | " + (provider.lastConclusionReason ?? "")) }
        }
        if let website = row.websiteConfirmation {
            lines += ["Website: " + website.label, website.reason,
                      "Website checked: " + date.string(from: website.checkedAt),
                      "Requested source: " + website.sourceURL,
                      "Final page: " + (website.finalURL ?? "Unavailable"),
                      "HTTP status: " + (website.httpStatus.map(String.init) ?? "Unavailable"),
                      "Match: " + (website.match?.rawValue ?? "None"),
                      "Excerpt: " + (website.excerpt ?? "None"),
                      "Website checker: " + website.checkerVersion,
                      "Browser-rendered: " + (website.browserRendered == true ? "true" : "false")]
            if let person = website.personAssociation {
                lines += ["Associated person: " + person.name, "Association method: " + person.method.rawValue, "Association source: " + (website.finalURL ?? website.sourceURL), "Association excerpt: " + person.sourceExcerpt]
            }
            if let pages = website.pagesChecked {
                lines.append("Pages checked:")
                for page in pages { lines.append(date.string(from: page.checkedAt) + " | " + page.requestedURL + " | " + page.outcome + " | " + (page.httpStatus.map(String.init) ?? "") + " | final: " + (page.finalURL ?? "Unavailable") + (page.browserRendered == true ? " | browser-rendered" : "")) }
            }
        }
        if let history = row.websiteHistory, !history.isEmpty {
            lines.append("Earlier website checks (historical, not fresh confirmation):")
            for website in history { lines.append(date.string(from: website.checkedAt) + " | " + website.label + " | " + (website.finalURL ?? website.sourceURL)) }
        }
        lines.append("SMTP acceptance and public/provider evidence cannot guarantee future delivery.")
        return lines.joined(separator: "\n")
    }
}
