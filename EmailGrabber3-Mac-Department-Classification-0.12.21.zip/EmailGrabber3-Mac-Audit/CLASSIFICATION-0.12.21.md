# Department and reader-service recognition — 0.12.21

The four reported addresses were Uncertain because the earlier automatic classifier
had neither a personal-name signal nor a matching shared-mailbox function. This was
incomplete department vocabulary, not extraction failure or a user's filtering rule.

This update groups shared functions into editorial/reader services, academic/student
services and business/customer services, with explanations naming the matched family.
It recognizes corrections, readers, accolades, financial aid and customer-service
abbreviations, as well as registrar, bursar, transcripts, scholarships, circulation,
reprints, permissions, syndication, obituaries, payroll, accounts payable/receivable
and related common functions. Singular/plural and spelling variants are explicit.

Composition joins dot/hyphen/underscore word boundaries and accepts bounded unit or
region qualifiers around known functions: financial-aid-office, corrections.desk,
us.customercare, reader-services-uk. Certain unambiguous customer-service abbreviation
suffixes may follow a short organization prefix, e.g. frbcustserv. Existing numeric
suffix normalization allows numbered service desks. No arbitrary substring matching:
personal names such as jane.reader and john.read are not treated as reader services.

This is broader rule-based classification, not a claim that every unfamiliar address
can be understood. Abbreviations and truly ambiguous names can still need context.
Manual corrections/exact learning keep their prior priority. An automatically detected
staff name does not override a recognized shared department. Crawl role exclusions,
storage, removal history and export policy are unchanged. Existing automatic rows
recompute when opened; no clearing or relearning is required. No public SMTP probes
or paid verification were used.

Validation: 318 portable tests passed, including four new tests covering all reported
examples, 48 function/qualifier combinations, personal-name and substring controls,
saved corrections, and unchanged crawl options. Native Mac compilation and GUI
acceptance still require a Mac. This archive contains source, not a prebuilt app.
