# Classification evidence fixes — 0.12.19

The screenshot exposed automatic classification errors, independent of extraction,
export, and result filtering. Shared departmental handles were missing from the
classifier, while ambiguous geographic handles were promoted by dictionary hits.

Changes:

- Recognize admissions/enrollment/alumni, helpdesk/service desk/newsdesk, data,
  datasets/spreadsheets, zero-waste and sustainability functions as General inbox.
  Also recognize qualified crew and discover-organization handles, preserving
  positively supported personal-name patterns such as john.crew.
- Department signals outrank an automatically detected staff association. A staff
  member named beside admissions does not make admissions a personal mailbox.
- Bare city/name collisions such as Sandusky, Columbus and Cleveland no longer
  qualify as people solely from the name dictionary. Published office wording or
  an offices/locations URL makes them General inbox. An explicit full-name
  association still supports Likely person. Otherwise they remain Uncertain.
- Explicit saved corrections and exact learning decisions retain priority. No
  learning reset, removal restoration, schema migration or data deletion.

The known place-name collision set is a conservative safeguard, not a complete
geographic database. Unknown geography may still need review. Classification is
an inference and does not verify mailbox ownership or delivery.

These are classification-only rules: role-based crawl exclusions, fetching,
deduplication, export policy, saved records, removal history and learning storage
are unchanged. Existing automatically classified rows use the new rules when
opened in this version; manually corrected rows keep their saved corrections.

Validation: full portable suite including five new regression tests; bundled
mixed-name evaluation; shared inboxes with misleading staff links; office context;
real personal names containing geographic surnames; manual overrides; persistence,
learning and export coverage. See CORE-TESTS.log for current run results.
Native macOS compilation and GUI execution cannot be performed on this Linux host.

This ZIP contains source, not a prebuilt Mac application. Build with the existing
build-mac.sh on macOS with Apple's command-line developer tools, or use the Xcode
project. Keep the previous application and your saved session until Mac acceptance
checks pass. No commands here clear your data.
