import Foundation
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

/// Pure policies shared by the application and its regression tests.
enum EmailPolicy {
    private static let numericEntity = try! NSRegularExpression(pattern: #"&#(x[0-9a-f]+|[0-9]+);"#, options: .caseInsensitive)
    static func validSyntax(_ address: String) -> Bool {
        let fields = address.split(separator: "@", omittingEmptySubsequences: false)
        guard fields.count == 2, address.utf8.count <= 254 else { return false }
        let local = String(fields[0]), domain = String(fields[1])
        guard !local.isEmpty, local.utf8.count <= 64, !local.hasPrefix("."), !local.hasSuffix("."), !address.contains("..") else { return false }
        let labels = domain.split(separator: ".", omittingEmptySubsequences: false)
        guard labels.count >= 2, labels.allSatisfy({ !$0.isEmpty && $0.utf8.count <= 63 && !$0.hasPrefix("-") && !$0.hasSuffix("-") }) else { return false }
        return address.range(of: #"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,63}$"#, options: .regularExpression) != nil
    }
    static func csvField(_ value: String) -> String {
        let safe = value.first.map { "=+-@\t\r\n".contains($0) } == true ? "'" + value : value
        return "\"" + safe.replacingOccurrences(of: "\"", with: "\"\"") + "\""
    }
    static func canonicalHost(_ host: String) -> String {
        let h = host.lowercased(); return h.hasPrefix("www.") ? String(h.dropFirst(4)) : h
    }
    static func httpURL(_ url: URL) -> Bool {
        guard ["https", "http"].contains(url.scheme?.lowercased() ?? ""), let host = url.host, !host.isEmpty, url.user == nil, url.password == nil else { return false }
        let name = host.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: "[]."))
        if name == "localhost" || name.hasSuffix(".localhost") || name.hasSuffix(".local") || name.hasSuffix(".home.arpa") || name.hasSuffix(".internal") { return false }
        var v4 = in_addr(); var v6 = in6_addr()
        if inet_pton(AF_INET, name, &v4) == 1 {
            let bytes = withUnsafeBytes(of: &v4) { Array($0) }
            let a = Int(bytes[0]), b = Int(bytes[1])
            if a == 0 || a == 10 || a == 127 || a >= 224 || (a == 169 && b == 254) || (a == 172 && (16...31).contains(b)) || (a == 192 && b == 168) || (a == 100 && (64...127).contains(b)) { return false }
        } else if inet_pton(AF_INET6, name, &v6) == 1 {
            let bytes = withUnsafeBytes(of: &v6) { Array($0) }
            guard (0x20...0x3f).contains(bytes[0]), !(bytes[0] == 0x20 && bytes[1] == 0x02) else { return false }
            if bytes[0] == 0x20 && bytes[1] == 0x01 && ((bytes[2] == 0x0d && bytes[3] == 0xb8) || bytes[2] < 2) { return false }
        } else if !name.contains(".") || name.range(of: #"^(?:0x[0-9a-f]+|[0-9]+)(?:\.(?:0x[0-9a-f]+|[0-9]+)){0,3}$"#, options: .regularExpression) != nil { return false }
        return true
    }
    static func searchURL(_ query: String) -> URL? {
        var c = URLComponents(string: "https://www.bing.com/search")!
        c.queryItems = [URLQueryItem(name: "format", value: "rss"), URLQueryItem(name: "q", value: query)]
        c.percentEncodedQuery = c.percentEncodedQuery?.replacingOccurrences(of: "+", with: "%2B")
        return c.url
    }
    static func decodeHTML(_ text: String) -> String {
        guard text.contains("&") else { return text }
        var out = text
        let entities = ["&lt;":"<", "&gt;":">", "&quot;":"\"", "&apos;":"'", "&nbsp;":" ", "&commat;":"@", "&period;":"."]
        for (key,value) in entities { out = out.replacingOccurrences(of: key, with: value, options: .caseInsensitive) }
        let regex = numericEntity
        do {
            let matches = regex.matches(in: out, range: NSRange(out.startIndex..., in: out))
            for m in matches.reversed() {
                guard let r = Range(m.range(at: 1), in: out), let full = Range(m.range, in: out) else { continue }
                let token = String(out[r]); let hex = token.lowercased().hasPrefix("x")
                if let code = UInt32(hex ? String(token.dropFirst()) : token, radix: hex ? 16 : 10), let scalar = UnicodeScalar(code) { out.replaceSubrange(full, with: String(scalar)) }
            }
        }
        return out.replacingOccurrences(of: "&amp;", with: "&", options: .caseInsensitive)
    }
}

enum DNSAssessment: Equatable {
    case mx, fallback, noMail, unknown
    var reason: String {
        switch self {
        case .mx: return "Syntax and MX passed; individual mailbox unverified"
        case .fallback: return "No MX; address-record fallback available; individual mailbox unverified"
        case .noMail: return "No usable mail-server configuration; individual mailbox unverified"
        case .unknown: return "DNS lookup failed or was inconclusive; individual mailbox unverified"
        }
    }
    static func parseMX(_ text: String) -> DNSAssessment? {
        let answers = text.split(whereSeparator: \.isNewline).map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty && !$0.hasPrefix(";") }
        guard !answers.isEmpty else { return nil }
        var hasNull = false; var hasMail = false
        for line in answers {
            let parts = line.split(whereSeparator: \.isWhitespace)
            guard parts.count == 2, UInt16(parts[0]) != nil else { return .unknown }
            if parts[1] == "." { guard parts[0] == "0" else { return .unknown }; hasNull = true }
            else if parts[1].contains(".") { hasMail = true }
            else { return .unknown }
        }
        if hasNull && hasMail { return .unknown }
        return hasNull ? .noMail : hasMail ? .mx : .unknown
    }
}

enum ProviderClassification {
    static func result(status: String, substatus: String) -> (String, String) {
        let value = status.lowercased()
        let final: String
        switch value {
        case "valid":
            let caution = substatus.lowercased().replacingOccurrences(of: "-", with: "_")
            final = caution.contains("catch_all") || caution.contains("catchall") || caution.contains("unknown") ? "Uncertain" : "Verified"
        case "invalid", "spamtrap", "abuse", "do_not_mail": final = "Rejected"
        default: final = "Uncertain"
        }
        return (final, "ZeroBounce: \(value)\(substatus.isEmpty ? "" : " (\(substatus))")")
    }
}

struct RobotsPolicy {
    struct Rule { let allow: Bool; let pattern: String }
    var rules: [Rule] = []
    var delay: TimeInterval = 0.3
    static let denyAll = RobotsPolicy(rules: [Rule(allow: false, pattern: "/")])
    init(rules: [Rule] = [], delay: TimeInterval = 0.3) { self.rules = rules; self.delay = delay }
    init(_ text: String, agent: String = "EmailGrabber3") {
        struct Group { var agents: [String] = []; var rules: [Rule] = []; var delay: TimeInterval?; var started = false }
        var groups: [Group] = []; var group = Group()
        for line in text.components(separatedBy: .newlines) {
            let raw = line.components(separatedBy: "#")[0].trimmingCharacters(in: .whitespaces)
            let pieces = raw.split(separator: ":", maxSplits: 1, omittingEmptySubsequences: false)
            guard pieces.count == 2 else { continue }
            let key = pieces[0].lowercased(), value = pieces[1].trimmingCharacters(in: .whitespaces)
            if key == "user-agent" {
                if group.started { groups.append(group); group = Group() }
                group.agents.append(value.lowercased())
            } else if !group.agents.isEmpty {
                group.started = true
                if (key == "allow" || key == "disallow") && !value.isEmpty { group.rules.append(Rule(allow: key == "allow", pattern: value)) }
                if key == "crawl-delay", let seconds = Double(value), seconds.isFinite, seconds >= 0 { group.delay = seconds }
            }
        }
        groups.append(group)
        let target = agent.lowercased()
        func specificity(_ g: Group) -> Int { g.agents.map { $0 == "*" ? 0 : (target.contains($0) ? $0.count : -1) }.max() ?? -1 }
        let best = groups.map(specificity).max() ?? -1
        let chosen = groups.filter { best >= 0 && specificity($0) == best }
        rules = chosen.flatMap(\.rules)
        delay = max(0.3, chosen.compactMap(\.delay).max() ?? 0.3)
    }
    private static func normalized(_ value: String) -> [UInt8] {
        let input = Array(value.utf8); var output: [UInt8] = []; var i = 0
        let hex = Array("0123456789ABCDEF".utf8)
        func digit(_ byte: UInt8) -> Int? {
            if (48...57).contains(byte) { return Int(byte - 48) }
            if (65...70).contains(byte) { return Int(byte - 65 + 10) }
            if (97...102).contains(byte) { return Int(byte - 97 + 10) }
            return nil
        }
        func unreserved(_ b: UInt8) -> Bool { (65...90).contains(b) || (97...122).contains(b) || (48...57).contains(b) || [45,46,95,126].contains(b) }
        while i < input.count {
            if input[i] == 37, i + 2 < input.count, let a = digit(input[i+1]), let b = digit(input[i+2]) {
                let byte = UInt8(a*16+b)
                if unreserved(byte) { output.append(byte) } else { output += [37,hex[a],hex[b]] }
                i += 3
            } else {
                let byte = input[i]
                if byte > 127 || byte < 33 { output += [37,hex[Int(byte)/16],hex[Int(byte)%16]] }
                else { output.append(byte) }
                i += 1
            }
        }
        return output
    }
    /// Greedy glob matching with a shared work budget. Website-provided patterns
    /// never become regular expressions with unbounded backtracking.
    private static func matches(_ pattern: [UInt8], _ text: [UInt8], anchored: Bool, budget: inout Int) -> Bool? {
        var i = 0; var j = 0; var star: Int?; var retry = 0
        while i < text.count {
            budget -= 1; if budget < 0 { return nil }
            if j < pattern.count && pattern[j] == 42 { star = j; j += 1; retry = i }
            else if j < pattern.count && pattern[j] == text[i] { i += 1; j += 1 }
            else if j == pattern.count && !anchored { return true }
            else if let previous = star { retry += 1; i = retry; j = previous + 1 }
            else { return false }
        }
        while j < pattern.count && pattern[j] == 42 { j += 1 }
        return j == pattern.count
    }
    func allows(_ url: URL) -> Bool {
        let c = URLComponents(url: url, resolvingAgainstBaseURL: false)
        let path = (c?.percentEncodedPath.isEmpty == false ? c!.percentEncodedPath : "/") + (c?.percentEncodedQuery.map { "?" + $0 } ?? "")
        guard rules.count <= 4096, path.utf8.count <= 16_384 else { return false }
        var best = -1; var allowed = true; var budget = 1_000_000
        let text = Self.normalized(path)
        for rule in rules {
            guard rule.pattern.utf8.count <= 4096 else { return false }
            var pattern = rule.pattern; let anchored = pattern.hasSuffix("$")
            if anchored { pattern.removeLast() }
            let bytes = Self.normalized(pattern)
            guard let match = Self.matches(bytes, text, anchored: anchored, budget: &budget) else { return false }
            if !match { continue }
            let length = bytes.filter { $0 != 42 }.count
            if length > best || (length == best && rule.allow) { best = length; allowed = rule.allow }
        }
        return allowed
    }
}


enum ResultMerge {
    /// Stable identity merge: preserves newer validation and tolerates repeated IDs
    /// in imported files without trapping or discarding newer checkpoint rows.
    static func combine(_ checkpoint: [FoundEmail], _ project: [FoundEmail]) -> [FoundEmail] {
        var values: [UUID: FoundEmail] = [:]; var order: [UUID] = []
        for row in checkpoint + project {
            if values[row.id] == nil { order.append(row.id) }
            if let previous = values[row.id] {
                var merged = row.checkedAt >= previous.checkedAt ? row : previous
                let checks = (previous.smtpHistory ?? []) + (row.smtpHistory ?? []) + [previous.smtpVerification, row.smtpVerification].compactMap { $0 }
                let unique = Array(Set(checks)).sorted { $0.checkedAt == $1.checkedAt ? $0.reason < $1.reason : $0.checkedAt < $1.checkedAt }
                merged.smtpVerification = unique.last
                merged.smtpHistory = unique.count > 1 ? Array(unique.dropLast().suffix(8)) : nil
                merged.providerVerification = [previous.providerVerification, row.providerVerification].compactMap { $0 }.max { $0.checkedAt < $1.checkedAt }
                let websiteChecks = (previous.websiteHistory ?? []) + (row.websiteHistory ?? []) + [previous.websiteConfirmation, row.websiteConfirmation].compactMap { $0 }
                let websites = Array(Set(websiteChecks)).sorted { $0.checkedAt == $1.checkedAt ? $0.reason < $1.reason : $0.checkedAt < $1.checkedAt }
                merged.websiteConfirmation = websites.last
                merged.websiteHistory = websites.count > 1 ? Array(websites.dropLast().suffix(3)) : nil
                values[row.id] = merged
            } else { values[row.id] = row }
        }
        return ClassificationEdits.inheriting(order.compactMap { values[$0] }, from: checkpoint + project)
    }
}

enum ResultPolicy {
    static func displayedStatus(_ row: FoundEmail, rules: [SmartRule], removed: Set<String>) -> String {
        if removed.contains(row.address.lowercased()) { return "Removed" }
        if TechnicalAddressPolicy.rejectionReason(row.address) != nil { return "Rejected" }
        return rules.contains { $0.matches(row.address) } ? "Excluded by rule" : row.status
    }
    static func displayedReason(_ row: FoundEmail) -> String {
        TechnicalAddressPolicy.rejectionReason(row.address) ?? row.reason
    }
    static func exportRows(_ rows: [FoundEmail], rules: [SmartRule], removed: Set<String>, onlyAccepted: Bool) -> [FoundEmail] {
        rows.compactMap { original in
            guard !removed.contains(original.address.lowercased()), !rules.contains(where: { $0.matches(original.address) }) else { return nil }
            guard !["excluded", "excluded by rule", "removed"].contains(original.status.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()) else { return nil }
            let row = TechnicalAddressPolicy.reclassified(original)
            if onlyAccepted && row.status != "Accepted" && row.status != "Verified" { return nil }
            return row
        }
    }
    static func exportSelection(_ rows: [FoundEmail], currentList: [FoundEmail]? = nil, rules: [SmartRule], removed: Set<String>, onlyAccepted: Bool) -> [FoundEmail] {
        let source = currentList ?? filtered(rows, rules: rules, removed: removed, status: "Included", search: "", scope: "Email")
        return exportRows(source, rules: rules, removed: removed, onlyAccepted: onlyAccepted)
    }
    static func personExportRows(_ rows: [FoundEmail], includeUncertain: Bool, rules: [SmartRule], removed: Set<String>) -> [FoundEmail] {
        exportSelection(rows, rules: rules, removed: removed, onlyAccepted: false).filter { row in
            let category = row.addressClassification.category
            return category == .person || (includeUncertain && category == .uncertain)
        }
    }
    static func filtered(_ rows: [FoundEmail], rules: [SmartRule], removed: Set<String>, status: String, search: String, scope: String) -> [FoundEmail] {
        let needle = search.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let wildcard = SafeWildcard.containsWildcard(needle) ? SafeWildcard(needle) : nil
        func matches(_ value: String) -> Bool {
            wildcard?.matches(value) ?? value.lowercased().contains(needle)
        }
        return rows.filter { row in
            let isRemoved = removed.contains(row.address.lowercased())
            let ruleHidden = rules.contains { $0.matches(row.address) }
            let effectiveStatus = TechnicalAddressPolicy.rejectionReason(row.address) == nil ? row.status : "Rejected"
            let eligible: Bool
            switch status {
            case "All": eligible = true
            case "Removed": eligible = isRemoved
            case "Included": eligible = !isRemoved && !ruleHidden && effectiveStatus != "Rejected" && effectiveStatus != "Excluded"
            case "Excluded": eligible = !isRemoved && (ruleHidden || effectiveStatus == "Excluded")
            default: eligible = !isRemoved && !ruleHidden && effectiveStatus == status
            }
            guard eligible, !needle.isEmpty else { return eligible }
            switch scope {
            case "Domain": return matches(row.address.split(separator: "@").last.map(String.init) ?? "")
            case "Source": return matches(row.source)
            case "All fields": return wildcard == nil ? [row.address,row.source,displayedReason(row),displayedStatus(row,rules: rules,removed: removed)].joined(separator: " ").lowercased().contains(needle) : [row.address,row.source,displayedReason(row),displayedStatus(row,rules: rules,removed: removed)].contains(where: matches)
            default: return matches(row.address)
            }
        }
    }
}

/// Whole-field, case-insensitive shell-style wildcards, without regex execution.
/// Repeated stars collapse; bounded inputs prevent pathological work in the UI.
struct SafeWildcard {
    static let maximumPatternLength = 512
    private let pattern: [Character]
    private let valid: Bool
    init(_ value: String) {
        let text = value.lowercased()
        valid = text.count <= Self.maximumPatternLength
        var result: [Character] = []
        if valid {
            for character in text {
                if character == "*" && result.last == "*" { continue }
                result.append(character)
            }
        }
        pattern = result
    }
    static func containsWildcard(_ value: String) -> Bool {
        value.contains("*") || value.contains("?")
    }
    func matches(_ value: String) -> Bool {
        guard valid, value.count <= 16_384 else { return false }
        let text = Array(value.lowercased())
        var input = 0, token = 0, retry = 0
        var star: Int?
        while input < text.count {
            if token < pattern.count && (pattern[token] == "?" || (pattern[token] != "*" && pattern[token] == text[input])) {
                token += 1; input += 1
            } else if token < pattern.count && pattern[token] == "*" {
                star = token; token += 1; retry = input
            } else if let previous = star {
                retry += 1; input = retry; token = previous + 1
            } else { return false }
        }
        while token < pattern.count && pattern[token] == "*" { token += 1 }
        return token == pattern.count
    }
}

enum ResultOrdering {
    static func label(_ order: [KeyPathComparator<FoundEmail>]) -> String {
        guard let first = order.first else { return "Found order" }
        if order.count == 1 && first.keyPath == \FoundEmail.address {
            return first.order == .forward ? "Email A–Z" : "Email Z–A"
        }
        return "Column sort"
    }
    static func comparators(_ choice: String) -> [KeyPathComparator<FoundEmail>]? {
        switch choice {
        case "Found order": return []
        case "Email A–Z": return [KeyPathComparator(\FoundEmail.address, order: .forward)]
        case "Email Z–A": return [KeyPathComparator(\FoundEmail.address, order: .reverse)]
        default: return nil
        }
    }
    static func apply(_ rows: [FoundEmail], order: [KeyPathComparator<FoundEmail>]) -> [FoundEmail] {
        order.isEmpty ? rows : rows.sorted(using: order)
    }
}

enum TechnicalAddressPolicy {
    private static let assetExtensions: Set<String> = [
        "png","jpg","jpeg","gif","webp","svg","avif","ico","bmp","tif","tiff",
        "heic","apng","jfif","woff","woff2","ttf","otf","eot","css","js","map"
    ]
    private static let wixHosts = ["sentry.wixpress.com","sentry-next.wixpress.com"]
    static func reclassified(_ original: FoundEmail) -> FoundEmail {
        guard let reason = rejectionReason(original.address) else { return original }
        var row = original; row.status = "Rejected"; row.reason = reason
        return row
    }
    static func reclassify(_ rows: [FoundEmail]) -> [FoundEmail] { rows.map(reclassified) }
    static func rejectionReason(_ address: String) -> String? {
        let fields = address.lowercased().split(separator: "@", omittingEmptySubsequences: false)
        guard fields.count == 2 else { return nil }
        let local = String(fields[0])
        let host = String(fields[1]).trimmingCharacters(in: CharacterSet(charactersIn: "."))
        let parts = host.split(separator: ".").map(String.init)
        let key = local.utf8
        let hexadecimalKey = key.count == 32 && key.allSatisfy { (48...57).contains($0) || (97...102).contains($0) }
        if hexadecimalKey && parts.contains(where: { $0 == "bug-reporting" || $0.hasPrefix("bug-reporting-") }) {
            return "Bug-reporting telemetry identifier; not a contact email address"
        }
        if let ext = parts.last, assetExtensions.contains(ext) {
            return "Technical asset filename; not a contact email address"
        }
        if parts.count == 1 && (host == "2x" || host == "3x") {
            return "Technical asset filename; not a contact email address"
        }
        if wixHosts.contains(where: { host == $0 || host.hasSuffix("." + $0) }) {
            return "Sentry telemetry endpoint; not a contact email address"
        }
        if host == "sentry.io" || host.hasSuffix(".sentry.io") {
            let key = local.utf8
            let hexadecimalKey = key.count == 32 && key.allSatisfy { (48...57).contains($0) || (97...102).contains($0) }
            if hexadecimalKey || parts.dropLast(2).contains("ingest") {
                return "Sentry telemetry identifier; not a contact email address"
            }
        }
        return nil
    }
}

enum ResultSelection {
    /// Shared by row clicks and checkbox actions. It has no native table
    /// selection binding that can replace the explicit selection on refresh.
    static func updated(_ current: Set<UUID>, id: UUID, selected: Bool? = nil) -> Set<UUID> {
        var result = current
        if selected ?? !current.contains(id) { result.insert(id) }
        else { result.remove(id) }
        return result
    }
}


/// A conservative presentation hint, independent of verification and exclusions.
enum AddressCategory: String, CaseIterable, Codable {
    case person = "Likely person", general = "General inbox", uncertain = "Uncertain"
}
/// A nil category is a dated reset, so an older checkpoint cannot resurrect an edit.
struct ClassificationDecision: Codable, Hashable {
    var category: AddressCategory?
    var changedAt: Date
    var reviewBatchID: UUID? = nil
}
enum ClassificationEdits {
    static func decisions(in rows: [FoundEmail]) -> [String: ClassificationDecision] {
        var decisions: [String: ClassificationDecision] = [:]
        for row in rows {
            guard let decision = row.classificationDecision else { continue }
            let address = row.address.lowercased()
            if decisions[address] == nil || decision.changedAt >= decisions[address]!.changedAt {
                decisions[address] = decision
            }
        }
        return decisions
    }
    static func inheriting(_ rows: [FoundEmail], from known: [FoundEmail]) -> [FoundEmail] {
        inheriting(rows, decisions: decisions(in: known))
    }
    static func inheriting(_ rows: [FoundEmail], decisions known: [String: ClassificationDecision]) -> [FoundEmail] {
        var latest = decisions(in: rows)
        for (address, decision) in known {
            if latest[address] == nil || decision.changedAt >= latest[address]!.changedAt { latest[address] = decision }
        }
        return rows.map { original in
            var row = original
            row.classificationDecision = latest[row.address.lowercased()]
            return row
        }
    }
    static func set(_ rows: [FoundEmail], selected: Set<UUID>, category: AddressCategory?, at date: Date = Date()) -> [FoundEmail] {
        let addresses = Set(rows.filter { selected.contains($0.id) }.map { $0.address.lowercased() })
        return rows.map { original in
            var row = original
            if addresses.contains(row.address.lowercased()) {
                row.classificationDecision = ClassificationDecision(category: category, changedAt: date)
            }
            return row
        }
    }
}
struct AddressClassification {
    let category: AddressCategory
    let reason: String
    var reviewPattern: ReviewPattern? = nil
    static let roleNames: Set<String> = ["info", "admin", "support", "sales", "contact", "hello", "office", "help", "webmaster", "noreply", "no-reply", "marketing", "privacy", "billing", "care", "enquiries", "inquiries", "enquiry", "inquiry", "customerservice", "customer-service", "service", "reception", "receptionist", "general", "team", "staff", "jobs", "careers", "hr", "humanresources", "media", "press", "events", "donations", "donate", "accounts", "accounting", "orders", "booking", "bookings", "reservations", "feedback", "questions", "mail", "email", "contactus", "operations", "officeadmin", "administrator"]
    static let generalNames = roleNames.union(["newsroom", "editorial", "advertising", "subscriptions", "letters", "tips", "connect", "outreach", "membership", "welcome", "bienvenidos", "volunteer", "volunteers", "registration", "registrations", "donor", "donors", "newsletter", "newsletters", "fundraising", "partnerships", "sponsorship", "community", "communications", "advocacy", "education", "programs", "programmes", "program", "project", "projects", "members", "business", "development", "policy", "publicrelations", "studentservices", "tech", "technical", "technology", "it", "security", "legal", "compliance", "procurement", "purchasing", "research", "mission", "progressive", "progressives", "campaign", "campaigns", "voters", "vote", "political", "organizing", "organising", "movement", "citizens", "people", "together", "families", "city", "county", "precinct", "district", "join", "giving", "visuals", "graphics", "dev", "contribute", "contributions", "donorrelations", "donorservices", "engagement", "supporters", "organizers", "organisers"])
    // Capitalized job titles are not name evidence. Keep this separate from
    // roleNames so presentation fixes do not change existing crawl exclusions.
    private static let titleWords: Set<String> = ["executive", "deputy", "development", "director", "assistant", "associate", "chief", "officer", "president", "vice", "chair", "chairperson", "treasurer", "secretary", "manager", "coordinator", "program", "programme", "membership", "communications", "community", "relations", "editor", "editorial", "publisher", "managing", "senior", "junior", "regional", "national", "business", "finance", "fundraising", "human", "resources", "public", "affairs", "ceo", "cfo", "coo", "cto", "staff", "contact", "email", "special", "projects", "services", "department", "division", "admissions", "alumni", "student", "school", "college", "university", "support", "help", "learn", "more", "read", "get", "involved"]
    private static let titleInboxes: Set<String> = {
        let qualifiers = ["executive", "deputy", "development", "assistant", "associate", "program", "programme", "membership", "communications", "community", "regional", "national", "business", "finance", "fundraising", "marketing", "news", "editorial", "operations"]
        return Set(qualifiers.map { $0 + "director" }).union(["director", "president", "vicepresident", "chair", "chairperson", "treasurer", "secretary", "ceo", "cfo", "coo", "cto", "editor", "publisher", "editorinchief", "managingeditor", "chiefexecutiveofficer", "chiefdevelopmentofficer", "chiefoperatingofficer", "chieffinancialofficer"])
    }()
    // Classification signals only: never add these to crawl exclusion rules.
    private static let sharedFunctions: Set<String> = ["admission", "admissions", "enrollment", "enrolment", "alumni", "helpdesk", "servicedesk", "newsdesk", "data", "dataset", "datasets", "spreadsheet", "spreadsheets", "zerowaste", "sustainability", "online", "studenthealth", "studentwellness", "studentaffairs", "studentlife", "studenthousing", "studentaccounts", "studentrecords", "mailto"]
    // Department vocabulary plus bounded composition. Whole-function matches
    // avoid classifying a person from a substring of their name (e.g. Read).
    private static let serviceFamilies: [(name: String, terms: String)] = [
        ("Civic and government services", "election elections electionoffice electionboard electioncommission voterregistration voterlist voterservices cityclerk countyclerk countyoffice clerk clerkoffice townclerk municipalclerk cityhall townhall boardoffice chairman chairwoman cochair cochairs boardchair vicechair executiveoffice exec secretaryoffice publichealth humanservices socialservices emergency emergencyservices firedepartment police nonemergency sheriff citymanager countymanager township townoffice"),
        ("Editorial, rights and broadcast services", "legals obits ads advertise editors rights rightsrepro mediarights privacyrights republish republishing unsubscribe comments newstips newscomments newsfeed viewermail viewer viewers viewerservices viewerfeedback viewernews lettersdesk readerservice caption captions closedcaption closedcaptions closedcaptioning publicfile publicinspectionfile fccpublicfile fcc captioning programming receptionissues mediarelations journalpermissions advertisingfeedback advertisinginfo classifiedinfo arts culture entertainment bizdev inbounds giftplanning plannedgiving gifts fund donationdesk services pr speakerrequests annualfinancialreport"),
        ("Editorial and reader services", "correction corrections factcheck factchecking accuracy readers readerrelations readerservices readerfeedback readernews audience audiences audiencedevelopment engagementdesk feedbackdesk accolades awards awardnominations nominations letters letterstotheeditor oped opeds opinion opinions commentary submissions submit pitches storypitches news newsdesk sports sportsdesk obituaries obituary notices announcements calendar calendars eventsdesk newsroomdesk reprints permissions licensing syndication circulation subscriptions subscriber subscribers subscriberservices subscriptionservices delivery homedelivery digitaledition backissues archives archive photos photography photo video multimedia podcasts podcast books bookreviews reviews pressreleases pressrelease mediainquiries pressinquiries presscontacts publicity"),
        ("Student and academic services", "financialaid finaid scholarships scholarship bursar bursary bursaries bursariesoffice registrar registration records transcripts transcript admissions admission admissionsoffice enrollment enrolment enrollmentservices recruitment recruiting applications application apply studentservices studentaffairs studenthealth studentwellness studentlife studenthousing studentaccounts studentrecords studentsuccess studentconduct studentemployment studentactivities studentengagement studentunion studentcenter studentsupport academicadvising advising academics academicaffairs graduation commencement accessibility disability disabilityservices accommodation accommodations counseling counselling counselingcenter counsellingcenter healthservices healthcenter wellness residence residentiallife reslife housing campuslife campussafety campuspolice campussecurity parking transportation dining catering bookstore library libraries interlibraryloan researchhelp referencelibrarian alumni alumnirelations alumniservices alumniassociation veterans veteranservices internationalstudents internationaloffice studyabroad studyaway continuingeducation distanceeducation elearning tutoring learningcenter writingcenter testing testingcenter placement careercenter careerservices internship internships workstudy tuition fees feesoffice payments payment"),
        ("Customer and business services", "customer customers customerrelations customerservice customerservices customercare customersupport custserv custservice custservices custsvc cservice cservices csupport clientservices clientservice clientcare clientrelations helpdesk servicedesk helpcenter contactcenter callcenter informationdesk reception frontdesk enquiries inquiries generalinquiries generalenquiries sales advertising adverts adsales adops classified classifieds classifiedsdesk advertisingdesk advertisingservices marketing promotions promotion partnerships partnership sponsorships sponsors sponsor businessdevelopment accounts accounting accountspayable accountsreceivable payroll finance finances financialservices benefits humanresources recruitmentoffice purchasing procurement tenders contracts vendors vendorrelations invoices invoice refunds refund returns returnservices complaints complaint resolution donations donorrelations donorservices fundraising membership memberservices membershipservices membersupport volunteercoordination volunteerservices publicaffairs publicrelations communications comms legalservices compliance ethics ombudsman ombudsperson facilities maintenance repairs repair informationtechnology technicalsupport techsupport websupport webteam webservices webmaster webadmin siteadmin administrator adminoffice administration recordsmanagement recordsrequests publicrecords mediacontact communityrelations outreachoffice grant grants grantapplications grantsadministration researchoffice developmentoffice investorrelations investors investorrelationsdesk investorservices securityoffice fraud fraudreport reportabuse abuse complaintsdesk insurance claims scheduling appointments appointment reservations bookings booking")
    ]
    private static let serviceTerms: [String: String] = {
        var terms: [String: String] = [:]
        for family in serviceFamilies { for term in family.terms.split(separator: " ") { terms[String(term)] = family.name } }
        return terms
    }()
    private static let compoundServiceEndings = serviceTerms.keys.filter { $0.count >= 8 }.sorted { $0.count > $1.count || ($0.count == $1.count && $0 < $1) }
    private static func organizationQualifiedService(_ compact: String, domain: String) -> String? {
        // A service suffix can be preceded by the organization's brand, not
        // just one of a fixed set of regional qualifiers. Avoid arbitrary
        // suffix matches on personal names.
        let labels = domain.split(separator: ".").dropLast().map { $0.replacingOccurrences(of: "-", with: "") }.filter { $0.count >= 3 && !["www", "com", "org", "net", "edu", "gov", "mail", "email"].contains($0) }
        for term in compoundServiceEndings where compact.hasSuffix(term) && compact.count > term.count {
            let prefix = String(compact.dropLast(term.count))
            if prefix.count <= 32 && !hasPersonalNameComponents(compact) {
                return (serviceTerms[term] ?? "Shared service") + " (organization-qualified " + term + ")"
            }
        }
        // Short function names (sales, press, staff) require a matching brand
        // from the actual email domain, not merely an unfamiliar prefix.
        if labels.contains(where: { compact.hasPrefix($0) }) {
            for term in ["sales", "press", "news", "comments", "viewer", "online", "staff", "info", "desk", "dtv", "webteam", "ads", "legals", "obits", "rights", "pr"] where compact.hasSuffix(term) {
                if compact.count > term.count { return "Organization-branded function (" + term + ")" }
            }
        }
        return nil
    }
    private static func serviceSignal(_ compact: String) -> String? {
        func exact(_ term: String) -> String? { serviceTerms[term].map { $0 + " (" + term + ")" } }
        if let signal = exact(compact) { return signal }
        // Accept function+unit and regional+function combinations, rather than
        // enumerating every punctuation/plural variant or full email address.
        let units = ["office", "department", "dept", "team", "desk", "unit", "center", "centre", "division", "services", "service"]
        let regions = ["us", "usa", "uk", "eu", "intl", "international", "national", "regional", "local", "north", "south", "east", "west", "central"]
        for suffix in units + regions where compact.hasSuffix(suffix) && compact.count > suffix.count {
            if let signal = exact(String(compact.dropLast(suffix.count))) { return signal }
        }
        for prefix in regions where compact.hasPrefix(prefix) && compact.count > prefix.count {
            if let signal = exact(String(compact.dropFirst(prefix.count))) { return signal }
        }
        // Publisher/service abbreviations can have an organization prefix,
        // e.g. frbcustserv. Restrict to unambiguous service abbreviations and
        // do not consume a supported personal-name pattern.
        if !hasPersonalNameComponents(compact) {
            for suffix in ["custserv", "custsvc", "customerservice", "subscriberservices"] where compact.hasSuffix(suffix) && compact.count <= suffix.count + 12 {
                return "Customer and reader service abbreviation (" + suffix + ")"
            }
        }
        return nil
    }
    private static func regionalOrganizationLocation(_ handle: String, domain: String) -> Bool {
        // Require agreement between a known location, its state, and a service
        // organization domain. A city/name dictionary hit alone is insufficient.
        let states: [String: [String]] = [
            "sandusky": ["ohio"], "columbus": ["ohio", "georgia", "indiana"], "cleveland": ["ohio", "tennessee"],
            "austin": ["texas"], "dallas": ["texas"], "houston": ["texas"], "madison": ["wisconsin"],
            "lincoln": ["nebraska"], "charlotte": ["northcarolina"], "savannah": ["georgia"], "orlando": ["florida"],
            "boston": ["massachusetts"], "denver": ["colorado"], "phoenix": ["arizona"], "salem": ["oregon", "massachusetts"],
            "berkeley": ["california"], "oakland": ["california"], "sacramento": ["california"], "richmond": ["virginia"],
            "trenton": ["newjersey"], "jacksonville": ["florida"], "chandler": ["arizona"]
        ]
        guard let regions = states[handle], ["org", "edu", "gov"].contains(domain.split(separator: ".").last.map(String.init) ?? "") else { return false }
        let labels = domain.lowercased().split(separator: ".").dropLast().map { $0.replacingOccurrences(of: "-", with: "") }
        let services: Set<String> = ["legal", "legalaid", "legalservices", "health", "healthcare", "housing", "library", "libraries", "schools", "education", "council", "hospital", "hospitals"]
        return labels.contains { label in
            regions.contains { state in label.hasPrefix(state) && services.contains(String(label.dropFirst(state.count))) }
        }
    }
    // Place names overlap the name vocabulary. A bare ambiguous handle needs
    // office context or a directly associated full name, not a dictionary hit.
    private static let placeNameCollisions: Set<String> = ["sandusky", "columbus", "cleveland", "austin", "dallas", "houston", "jackson", "madison", "lincoln", "charlotte", "savannah", "orlando", "troy", "albany", "boston", "denver", "phoenix", "salem", "berkeley", "oakland", "sacramento", "portland", "richmond", "trenton", "washington", "jacksonville", "chandler", "clinton", "hamilton", "harrison", "fremont", "franklin", "springfield"]
    private static func officeContext(_ row: FoundEmail, handle: String) -> Bool {
        guard let proof = row.websiteConfirmation, proof.outcome == .published else { return false }
        let escaped = NSRegularExpression.escapedPattern(for: handle)
        let excerpt = proof.excerpt ?? ""
        let pattern = "(?i)\\b(?:" + escaped + "\\s+(?:(?:regional|branch|legal|aid)\\s+){0,2}(?:office|branch|location)|(?:office|branch|location)\\s*(?:in|at|:|—|-)?\\s*" + escaped + ")\\b"
        if excerpt.range(of: pattern, options: .regularExpression) != nil { return true }
        guard let url = URL(string: proof.finalURL ?? proof.sourceURL) else { return false }
        let path = url.path.lowercased().split(separator: "/").map(String.init)
        return zip(path, path.dropFirst()).contains { ["office", "offices", "branch", "branches", "location", "locations"].contains($0.0) && $0.1 == handle }
    }
    private static let ambiguousSingleWords: Set<String> = ["hope", "faith", "charity", "justice", "summer", "autumn", "love", "joy", "art", "holiday", "best", "good", "true", "new", "green", "brown", "black", "white", "red", "blue", "bank", "house", "street", "road", "shop", "church", "west", "east", "north", "south", "central", "union", "first", "old", "change", "future", "choice", "working"]
    private static let nonNameWords: Set<String> = ["custom", "address", "unusual", "name", "firstname", "lastname", "test", "example", "user", "username", "account", "login", "website", "online", "download", "password", "unknown", "special", "projects", "personal", "private"]
    private static func hasPersonalNameComponents(_ stem: String) -> Bool {
        if PersonNameVocabulary.given.contains(stem) || PersonNameVocabulary.surnames.contains(stem) || PersonNameVocabulary.joinedPattern(stem) != nil { return true }
        for count in 1...2 where stem.count > count + 2 {
            if PersonNameVocabulary.surnames.contains(String(stem.dropFirst(count))) || PersonNameVocabulary.surnames.contains(String(stem.dropLast(count))) || PersonNameVocabulary.given.contains(String(stem.dropLast(count))) { return true }
        }
        return false
    }
    private static func opaqueDomainEcho(_ stem: String, domain: String) -> Bool {
        guard stem.count >= 4, !nonNameWords.contains(stem), !DisposableDomainData.freeProviders.contains(domain), domain.split(separator: ".").dropLast().contains(where: { $0.replacingOccurrences(of: "-", with: "") == stem }) else { return false }
        return !hasPersonalNameComponents(stem)
    }
    static func plausiblePublishedName(_ value: String) -> Bool {
        let words = value.lowercased().split(whereSeparator: \.isWhitespace).map(String.init)
        return (2...4).contains(words.count) && words.filter { $0.count >= 2 }.count >= 2 && words.allSatisfy { word in
            !titleWords.contains(word) && (!generalNames.contains(word) || word == "dev") && !nonNameWords.contains(word) && !["first", "last", "full", "us", "our"].contains(word) && word.unicodeScalars.allSatisfy { CharacterSet.letters.contains($0) || "'-’".unicodeScalars.contains($0) }
        }
    }
    static func classify(_ row: FoundEmail) -> AddressClassification {
        if let category = row.classificationDecision?.category {
            return .init(category: category, reason: (row.classificationDecision?.reviewBatchID == nil ? "Your saved correction: " : "Approved group decision: ") + category.rawValue + ". Use automatic classification to reset.")
        }
        return automatic(row)
    }
    static func automatic(_ row: FoundEmail) -> AddressClassification {
        if let learned = row.learningEvidence, learned.exact { return .init(category: learned.category, reason: learned.reason) }
        let parts = row.address.lowercased().split(separator: "@", omittingEmptySubsequences: false)
        guard parts.count == 2, EmailPolicy.validSyntax(row.address) else {
            return .init(category: .uncertain, reason: "Address format does not support a person inference")
        }
        let local = String(parts[0])
        let base = local.split(separator: "+").first.map(String.init) ?? local
        // Numeric suffixes are neutral, not automatic disqualification. Digits
        // inside a stem and long numeric IDs still need other evidence.
        let suffix = String(base.reversed().prefix { $0.isNumber }.reversed())
        let stem = suffix.isEmpty ? base : String(base.dropLast(suffix.count))
        let tokens = stem.components(separatedBy: CharacterSet(charactersIn: ".-_"))
        let compact = tokens.joined()
        if let service = serviceSignal(compact) {
            return .init(category: .general, reason: "Shared department/function: " + service + "; not personal-name evidence")
        }
        if let service = organizationQualifiedService(compact, domain: String(parts[1])) {
            return .init(category: .general, reason: "Shared department/function: " + service + "; organization qualifier, not person-name evidence")
        }
        if sharedFunctions.contains(compact) || tokens.contains(where: sharedFunctions.contains) {
            return .init(category: .general, reason: "Department or shared-function inbox: \(base); a nearby staff name does not make it a personal mailbox")
        }
        if ((compact.hasSuffix("crew") && compact.count > 4) || (compact.hasPrefix("discover") && compact.count > 8)) && !hasPersonalNameComponents(compact) {
            return .init(category: .general, reason: "Collective team or organization-discovery account wording: \(base)")
        }
        if titleInboxes.contains(compact) || (tokens.count >= 2 && tokens.allSatisfy { titleWords.contains($0) }) {
            return .init(category: .general, reason: "Job-title inbox in address: \(base); a published title does not identify a person")
        }
        if (tokens.contains("we") && tokens.contains("can")) || tokens.contains("of") || tokens.contains("for") || tokens.contains("our") || tokens.contains("the") {
            return .init(category: .general, reason: "Phrase-like collective or organization handle; not person-name evidence")
        }
        if generalNames.contains(stem) || tokens.contains(where: { $0 != "dev" && generalNames.contains($0) }) {
            return .init(category: .general, reason: "Recognized shared-inbox term in address: \(base)")
        }
        // Productive collective roots/plurals, not a list of particular addresses.
        let collectiveRoots = ["progressive", "advocates", "neighbors", "neighbours", "nastywomen", "votingmatters"]
        let collectivePhrases = ["forprogress", "wewillpersist", "marchfor", "occupy"]
        if let signal = collectiveRoots.first(where: { compact.contains($0) }) ?? collectivePhrases.first(where: { compact.contains($0) }) {
            return .init(category: .general, reason: "Collective/campaign account wording: " + signal + "; organization-pattern inference")
        }
        if (compact.hasPrefix("dems") || compact.hasSuffix("dems")) && compact.count > 4 {
            return .init(category: .general, reason: "Democratic group/chapter handle using dems with a location or qualifier")
        }
        if compact.hasSuffix("together") && compact.count > 8 {
            return .init(category: .general, reason: "Collective handle ending in together")
        }
        if ["beach", "island", "valley", "township"].contains(where: { compact.hasSuffix($0) && compact.count > $0.count + 3 }), !hasPersonalNameComponents(compact) {
            return .init(category: .general, reason: "Place-based account with no supporting personal-name components; geographic account inference")
        }
        if opaqueDomainEcho(compact, domain: String(parts[1])) {
            return .init(category: .general, reason: "Opaque mailbox handle repeats its own organization's domain label; not a recognized personal-name pattern")
        }
        let organizationTerms = ["coalition", "alliance", "association", "foundation", "committee", "democracy", "democrat", "republican", "community", "grassroots", "nonprofit", "organization", "organisation", "newsletter", "communications", "customerservice"]
        let organizationEndings = ["voices", "united", "chapter", "council", "network", "collective", "company", "society", "center", "centre", "southmetro", "county", "area", "district", "precinct"]
        if ["north", "south", "east", "west", "central"].contains(where: { compact == $0 + "delta" }) {
            return .init(category: .general, reason: "Regional/area account pattern; not a person's name")
        }
        if let term = organizationTerms.first(where: { compact.contains($0) }) ?? organizationEndings.first(where: { tokens.contains($0) || (compact.hasSuffix($0) && compact.count >= $0.count + 3) }) {
            return .init(category: .general, reason: "Organization term in address: \(term); classification heuristic")
        }
        if let website = row.websiteConfirmation, website.outcome == .published,
           let association = website.personAssociation, association.address.lowercased() == row.address.lowercased(), Self.plausiblePublishedName(association.name) {
            return .init(category: .person, reason: "Source page explicitly associates " + association.name + " with this exact address (" + association.method.rawValue + "). Not mailbox-delivery verification.")
        }
        if compact.contains("indivisible") {
            if let first = tokens.first, tokens.count > 1, !first.contains("indivisible"), PersonNameVocabulary.given.contains(first) {
                return .init(category: .uncertain, reason: "Personal-name prefix with organization affiliation; may be an individual contact rather than a shared chapter mailbox", reviewPattern: .unrecognized)
            }
            return .init(category: .general, reason: "Collective/chapter handle containing indivisible; full-name evidence and saved corrections retain priority")
        }
        if let learned = row.learningEvidence { return .init(category: learned.category, reason: learned.reason) }
        if String(parts[1]).hasSuffix(".edu"), compact.hasSuffix("student"), (1...2).contains(compact.count - "student".count) {
            return .init(category: .general, reason: "Generic student account pattern on an educational domain; no explicit personal-name association")
        }
        if tokens.count == 1, placeNameCollisions.contains(stem) {
            if officeContext(row, handle: stem) || regionalOrganizationLocation(stem, domain: String(parts[1])) {
                return .init(category: .general, reason: "Office/location context for \(base) from published evidence or matching regional service-organization domain; not person-name evidence")
            }
            return .init(category: .uncertain, reason: "Single handle can identify a place or a person; needs a published full-name association or office context", reviewPattern: .unrecognized)
        }
        // Spelling structure must be supported by positive name evidence.
        let honorifics: Set<String> = ["mr", "mrs", "ms", "dr", "prof"]
        let nameTokens = tokens.first.map { honorifics.contains($0) } == true ? Array(tokens.dropFirst()) : tokens
        let words = nameTokens.filter { $0.count >= 2 }
        let knownGiven = nameTokens.contains { PersonNameVocabulary.given.contains($0) }
        let knownSurnames = nameTokens.filter { PersonNameVocabulary.surnames.contains($0) }.count
        let positiveComponents = knownGiven || (knownSurnames >= 1 && !nameTokens.contains(where: ambiguousSingleWords.contains))
        let pronounceable = nameTokens.allSatisfy { token in
            token.count <= 2 || PersonNameVocabulary.given.contains(token) || PersonNameVocabulary.surnames.contains(token) || token.contains { "aeiouy".contains($0) }
        }
        let allLetters = nameTokens.allSatisfy { !$0.isEmpty && $0.unicodeScalars.allSatisfy(CharacterSet.letters.contains) }
        let blocked = tokens.contains { titleWords.contains($0) || ($0 != "dev" && generalNames.contains($0)) || nonNameWords.contains($0) }
        var score = 0
        var signals: [String] = []
        if allLetters && !blocked && suffix.count <= 4 {
            if (2...4).contains(nameTokens.count), words.count >= 2, positiveComponents, pronounceable {
                score += 4
                signals.append("Separated name pattern supported by reference name components; middle initials and either name order allowed")
            }
            if nameTokens.count == 1, let joined = PersonNameVocabulary.joinedPattern(nameTokens[0]) {
                score += 4
                signals.append(joined)
            }
            if tokens.count == 1 && suffix.isEmpty && !ambiguousSingleWords.contains(stem) && stem.count >= 4 && PersonNameVocabulary.given.contains(stem) {
                score += 3
                signals.append("Given-name handle found in reference vocabulary")
            } else if tokens.count == 1 && suffix.isEmpty && !ambiguousSingleWords.contains(stem) && stem.count >= 5 && PersonNameVocabulary.surnames.contains(stem) {
                score += 3
                signals.append("Surname handle found in reference vocabulary")
            }
        }
        if score >= 3 {
            let numeric = suffix.isEmpty ? "" : "; optional numeric suffix"
            return .init(category: .person, reason: signals.joined(separator: "; ") + numeric + ". Name-pattern inference, not verified identity.")
        }
        if tokens.contains(where: { $0.count == 1 }) {
            return .init(category: .uncertain, reason: "Initial-only or initial + surname pattern; insufficient independent person evidence. Kept for review.", reviewPattern: .initials)
        }
        if !suffix.isEmpty || stem.contains(where: { $0.isNumber }) {
            return .init(category: .uncertain, reason: "Numeric handle without a supported full-name pattern. Digits alone neither prove nor rule out a person.", reviewPattern: .numeric)
        }
        return .init(category: .uncertain, reason: "No supported person pattern or explicit organization/role signal. Kept for review; not rejected.", reviewPattern: blocked && tokens.contains(where: titleWords.contains) ? .possibleOrganization : .unrecognized)
    }
    static func review(_ rows: [FoundEmail], category: AddressCategory, removed: Set<String>) -> [FoundEmail] {
        rows.filter { !removed.contains($0.address.lowercased()) && classify($0).category == category }
    }
}
extension FoundEmail {
    var addressClassification: AddressClassification { AddressClassification.classify(self) }
    var classificationLabel: String { addressClassification.category.rawValue }
}


private final class PersonNameBundleMarker {}
/// Optional positive evidence for joined/single-name handles. Absence from this
/// US Census-derived vocabulary never rejects a name or blocks structural rules.
enum PersonNameVocabulary {
    private static let data: (Set<String>, Set<String>) = {
        #if SWIFT_PACKAGE
        let url = Bundle.module.url(forResource: "person-name-components", withExtension: "tsv", subdirectory: "Resources")
        #else
        let bundles = [Bundle.main, Bundle(for: PersonNameBundleMarker.self)] + Bundle.allBundles + Bundle.allFrameworks
        let url = bundles.compactMap { $0.url(forResource: "person-name-components", withExtension: "tsv") }.first
        #endif
        guard let url = url, let text = try? String(contentsOf: url, encoding: .utf8) else { return ([], []) }
        var given = Set<String>(), surnames = Set<String>()
        for line in text.split(whereSeparator: \.isNewline) {
            let parts = line.split(separator: "\t")
            guard parts.count == 2 else { continue }
            if parts[0] == "G" { given.insert(String(parts[1])) }
            else if parts[0] == "S" { surnames.insert(String(parts[1])) }
        }
        return (given, surnames)
    }()
    static var given: Set<String> { data.0 }
    static var surnames: Set<String> { data.1 }
    static func joinedPattern(_ stem: String) -> String? {
        guard (6...40).contains(stem.count), stem.allSatisfy({ $0.isASCII && $0.isLetter }) else { return nil }
        let text = Array(stem)
        for split in 3...(text.count - 3) {
            let first = String(text[..<split]), last = String(text[split...])
            if given.contains(first) && surnames.contains(last) {
                return "Joined given-name + surname components found in reference vocabulary"
            }
            if surnames.contains(first) && given.contains(last) {
                return "Joined surname + given-name components found in reference vocabulary"
            }
            if last.count >= 4 && given.contains(first) && surnames.contains(String(last.dropFirst())) {
                return "Joined given-name + middle initial + surname components found in reference vocabulary"
            }
        }
        return nil
    }
}


/// Structured keys, independent of user-facing explanation text.
enum ReviewPattern: String, Codable, CaseIterable, Identifiable {
    case initials, numeric, unrecognized, possibleOrganization
    var id: String { rawValue }
    var title: String {
        switch self {
        case .initials: return "Initials and abbreviated names"
        case .numeric: return "Names or handles with numbers"
        case .unrecognized: return "Unrecognized names and handles"
        case .possibleOrganization: return "Possible organization or function names"
        }
    }
}
struct ReviewGroup: Identifiable {
    var pattern: ReviewPattern
    var rows: [FoundEmail]
    var id: String { pattern.rawValue }
}
enum GroupReview {
    static func pattern(_ row: FoundEmail) -> ReviewPattern? {
        guard row.classificationDecision?.category == nil else { return nil }
        let classification = AddressClassification.automatic(row)
        guard classification.category == .uncertain else { return nil }
        return classification.reviewPattern ?? .unrecognized
    }
    static func removalAddresses(_ rows: [FoundEmail], selected: Set<UUID>, pattern: ReviewPattern, rules: [SmartRule], removed: Set<String>) -> Set<String> {
        let selectedAddresses = Set(rows.filter { selected.contains($0.id) }.map { $0.address.lowercased() })
        let eligible = groups(rows, rules: rules, removed: removed).first { $0.pattern == pattern }?.rows ?? []
        return Set(eligible.map { $0.address.lowercased() }).intersection(selectedAddresses)
    }
    static func groups(_ rows: [FoundEmail], rules: [SmartRule], removed: Set<String>) -> [ReviewGroup] {
        let included = ResultPolicy.filtered(rows, rules: rules, removed: removed, status: "Included", search: "", scope: "Email")
        var seen = Set<String>()
        var grouped: [ReviewPattern: [FoundEmail]] = [:]
        for row in included {
            guard let pattern = pattern(row), seen.insert(row.address.lowercased()).inserted else { continue }
            grouped[pattern, default: []].append(row)
        }
        return ReviewPattern.allCases.compactMap { pattern in
            guard let rows = grouped[pattern], !rows.isEmpty else { return nil }
            return ReviewGroup(pattern: pattern, rows: rows)
        }
    }
}
struct ReviewRule: Codable, Equatable, Identifiable {
    var id: UUID
    var pattern: ReviewPattern
    var category: AddressCategory
    var exceptions: Set<String>
    var createdAt: Date
}
struct PriorClassification: Codable, Equatable {
    var decision: ClassificationDecision?
}
struct ReviewUndoBatch: Codable, Equatable, Identifiable {
    var id: UUID
    var before: [String: PriorClassification]
}
struct ReviewState: Codable, Equatable {
    var rules: [ReviewRule] = []
    var history: [ReviewUndoBatch] = []
    var changedAt: Date? = nil
    static func latest(_ a: ReviewState?, _ b: ReviewState?) -> ReviewState {
        guard let a = a else { return b ?? ReviewState() }
        guard let b = b else { return a }
        return (b.changedAt ?? .distantPast) >= (a.changedAt ?? .distantPast) ? b : a
    }
    func applyingRules(to rows: [FoundEmail]) -> [FoundEmail] {
        rows.map { original in
            var row = original
            // A dated automatic reset also opts out; never override a user's choice.
            guard row.classificationDecision == nil, row.status != "Excluded", row.status != "Rejected", TechnicalAddressPolicy.rejectionReason(row.address) == nil,
                  let pattern = GroupReview.pattern(row),
                  let rule = rules.last(where: { $0.pattern == pattern }), !rule.exceptions.contains(row.address.lowercased()) else { return row }
            row.classificationDecision = ClassificationDecision(category: rule.category, changedAt: rule.createdAt, reviewBatchID: rule.id)
            return row
        }
    }
    mutating func approve(_ rows: [FoundEmail], selected: Set<UUID>, pattern: ReviewPattern, category: AddressCategory, remember: Bool, exceptions: Set<String> = [], rules exclusions: [SmartRule] = [], removed: Set<String> = [], at date: Date = Date()) -> [FoundEmail] {
        let eligible = GroupReview.groups(rows, rules: exclusions, removed: removed).first { $0.pattern == pattern }?.rows ?? []
        let wanted = Set(rows.filter { selected.contains($0.id) }.map { $0.address.lowercased() })
        let addresses = Set(eligible.map { $0.address.lowercased() }).intersection(wanted).subtracting(exceptions.map { $0.lowercased() })
        guard !addresses.isEmpty else { return rows }
        let id = UUID()
        let previous = ClassificationEdits.decisions(in: rows)
        let before = Dictionary(uniqueKeysWithValues: addresses.map { ($0, PriorClassification(decision: previous[$0])) })
        history.append(ReviewUndoBatch(id: id, before: before))
        changedAt = date
        if remember {
            let existingNotReviewed = Set(rows.filter { GroupReview.pattern($0) == pattern }.map { $0.address.lowercased() }).subtracting(addresses)
            rules.append(ReviewRule(id: id, pattern: pattern, category: category, exceptions: Set(exceptions.map { $0.lowercased() }).union(existingNotReviewed), createdAt: date))
        }
        return rows.map { original in
            var row = original
            if addresses.contains(row.address.lowercased()) { row.classificationDecision = ClassificationDecision(category: category, changedAt: date, reviewBatchID: id) }
            return row
        }
    }
    mutating func undo(_ rows: [FoundEmail], at date: Date = Date()) -> [FoundEmail] {
        guard let batch = history.popLast() else { return rows }
        rules.removeAll { $0.id == batch.id }
        changedAt = date
        let restored = rows.map { original -> FoundEmail in
            var row = original
            guard row.classificationDecision?.reviewBatchID == batch.id else { return row }
            // A reset timestamp protects the undo against later stale worker writes.
            if let previous = batch.before[row.address.lowercased()]?.decision { row.classificationDecision = ClassificationDecision(category: previous.category, changedAt: date, reviewBatchID: previous.reviewBatchID) }
            else { row.classificationDecision = ClassificationDecision(category: nil, changedAt: date) }
            return row
        }
        return restored
    }
}


enum AutomaticPersonSort {
    static func targets(_ rows: [FoundEmail], selected: Set<UUID>, rules: [SmartRule], removed: Set<String>, now: Date = Date()) -> [WebsiteTarget] {
        let candidates = rows.filter { row in
            guard selected.contains(row.id), GroupReview.pattern(row) != nil, WebsiteConfirmationPolicy.sourceURL(row.source) != nil else { return false }
            let checks = [row.websiteConfirmation].compactMap { $0 } + (row.websiteHistory ?? [])
            return !checks.contains { $0.personNameCheckVersion == 1 && $0.sourceURL == row.source && now.timeIntervalSince($0.checkedAt) < 86_400 }
        }
        return WebsiteConfirmationPolicy.targets(candidates, rules: rules, removed: removed, limit: candidates.count).sorted {
            $0.source == $1.source ? $0.address < $1.address : $0.source < $1.source
        }
    }
    static func counts(_ rows: [FoundEmail], rules: [SmartRule], removed: Set<String>) -> (people: Int, shared: Int, review: Int) {
        let included = ResultPolicy.filtered(rows, rules: rules, removed: removed, status: "Included", search: "", scope: "Email")
        var people = 0, shared = 0, review = 0
        for row in included {
            switch row.addressClassification.category {
            case .person: people += 1
            case .general: shared += 1
            case .uncertain: review += 1
            }
        }
        return (people, shared, review)
    }
}


struct LearningEvidence: Codable, Hashable {
    var category: AddressCategory
    var exact: Bool
    var reason: String
}
struct LearningSample: Codable, Equatable {
    var address: String
    var category: AddressCategory
    var at: Date
    var kind: String
    var sourceScope: String? = nil
}
struct LearningProfile: Codable, Equatable {
    var projects: [String: [LearningSample]] = [:]
    var resetAt: Date? = nil
    var exampleCount: Int { Set(projects.values.flatMap { $0 }.map(\.address)).count }
    mutating func synchronize(projectID: UUID, rows: [FoundEmail], removal: RemovalState, review: ReviewState, now: Date = Date()) {
        let floor = resetAt ?? .distantPast
        var examples: [String: LearningSample] = [:]
        let decisions = ClassificationEdits.decisions(in: rows)
        let sourceScopes = rows.reduce(into: [String: Set<String>]()) { result, row in
            if let scope = LocalLearningModel.sourceScope(row.source) { result[row.address.lowercased(), default: []].insert(scope) }
        }
        let scopes = sourceScopes.compactMapValues { $0.count == 1 ? $0.first : nil }
        let explicitGroups = Dictionary(uniqueKeysWithValues: review.history.map { ($0.id, Set($0.before.keys)) })
        for (address, decision) in decisions {
            guard let category = decision.category, category != .uncertain, decision.changedAt > floor else { continue }
            if let batch = decision.reviewBatchID, explicitGroups[batch]?.contains(address) != true { continue }
            examples[address] = LearningSample(address: address, category: category, at: decision.changedAt, kind: "correction", sourceScope: scopes[address])
        }
        for (address, date) in removal.learningDates ?? [:] where removal.addresses.contains(address) && date > floor {
            if examples[address] == nil || date >= examples[address]!.at { examples[address] = LearningSample(address: address, category: .general, at: date, kind: "removal", sourceScope: scopes[address]) }
        }
        let key = projectID.uuidString
        let values = examples.values.sorted { $0.address < $1.address }
        if values.isEmpty { projects.removeValue(forKey: key) } else { projects[key] = values }
    }
}
struct LocalLearningModel {
    private struct TransferPattern {
        var category: AddressCategory
        var count: Int
        var reason: String
    }
    private var exact: [String: LearningSample] = [:]
    private var transferPatterns: [String: TransferPattern] = [:]
    private(set) var patterns: [String: Int] = [:]
    var personPatternCount: Int { transferPatterns.values.filter { $0.category == .person }.count }
    var generalPatternCount: Int { patterns.count - personPatternCount }
    init(profile: LearningProfile) {
        for original in profile.projects.values.flatMap({ $0 }) {
            var sample = original
            sample.address = sample.address.lowercased()
            guard sample.at > (profile.resetAt ?? .distantPast) else { continue }
            if exact[sample.address] == nil || sample.at > exact[sample.address]!.at || (sample.at == exact[sample.address]!.at && sample.category == .person) { exact[sample.address] = sample }
        }
        var negatives: [String: Set<String>] = [:]
        var positives = Set<String>()
        for sample in exact.values {
            for feature in Self.features(sample.address) {
                if sample.category == .person { positives.insert(feature) }
                else if sample.category == .general { negatives[feature, default: []].insert(Self.local(sample.address)) }
            }
        }
        for (feature, locals) in negatives where locals.count >= 3 && !positives.contains(feature) { patterns[feature] = locals.count }
        // Transfer an explicitly corrected handle across independent domains.
        // Repeated addresses, projects and plus tags cannot inflate support.
        let byHandle = Dictionary(grouping: exact.values, by: { Self.local($0.address) })
        for (handle, samples) in byHandle {
            let categories = Set(samples.map(\.category))
            let domains = Set(samples.map { Self.domain($0.address) })
            guard !handle.isEmpty, categories.count == 1, let category = categories.first,
                  category != .uncertain, domains.count >= 3 else { continue }
            let key = "handle:" + handle
            transferPatterns[key] = TransferPattern(category: category, count: domains.count, reason: "Same handle ‘" + handle + "’ corrected as " + category.rawValue + " on " + String(domains.count) + " distinct domains")
        }
        // Learn person formats only from explicit Person corrections within
        // one organization's people/department context. Never from predictions.
        var shaped: [String: [LearningSample]] = [:]
        for sample in exact.values {
            guard let scope = sample.sourceScope, let shape = Self.personShape(sample.address) else { continue }
            let key = Self.shapeKey(domain: Self.domain(sample.address), scope: scope, shape: shape.format)
            shaped[key, default: []].append(sample)
        }
        for (key, samples) in shaped {
            guard !samples.contains(where: { $0.category != .person }), samples.allSatisfy({ $0.kind == "correction" }) else { continue }
            let stems = Set(samples.map { Self.unnumberedLocal($0.address) })
            let surnames = Set(samples.compactMap { Self.personShape($0.address)?.surname })
            guard stems.count >= 4, surnames.count >= 3 else { continue }
            transferPatterns[key] = TransferPattern(category: .person, count: stems.count, reason: "Organization-specific person format learned from " + String(stems.count) + " explicit corrections with " + String(surnames.count) + " distinct surnames; same domain and source-page context required")
        }
        for (key, pattern) in transferPatterns { patterns[key] = pattern.count }
    }
    private static func local(_ address: String) -> String { String(address.lowercased().split(separator: "@").first ?? "").split(separator: "+").first.map(String.init) ?? "" }
    private static func domain(_ address: String) -> String { address.lowercased().split(separator: "@").last.map(String.init) ?? "" }
    private static func unnumberedLocal(_ address: String) -> String {
        String(local(address).reversed().drop(while: { $0.isNumber }).reversed())
    }
    static func sourceScope(_ source: String) -> String? {
        guard let url = URL(string: source), EmailPolicy.httpURL(url) else { return nil }
        let segments = url.path.lowercased().split(separator: "/").map(String.init)
        if segments.contains(where: { ["department", "departments", "offices", "locations"].contains($0) }) { return "departments" }
        if segments.contains(where: { ["people", "staff", "team", "faculty", "authors", "journalists", "employees"].contains($0) }) { return "people" }
        return nil
    }
    private static func shapeKey(domain: String, scope: String, shape: String) -> String { "person-format:" + domain + ":" + scope + ":" + shape }
    private static func personShape(_ address: String) -> (format: String, surname: String)? {
        guard EmailPolicy.validSyntax(address) else { return nil }
        let local = local(address), stem = unnumberedLocal(address)
        guard local.count - stem.count <= 4, stem.allSatisfy({ $0.isASCII && ($0.isLetter || ".-_".contains($0)) }) else { return nil }
        let tokens = stem.components(separatedBy: CharacterSet(charactersIn: ".-_"))
        if tokens.count == 2, tokens[0].count == 1, tokens[1].count >= 4, PersonNameVocabulary.surnames.contains(tokens[1]) {
            return ("initial-separated-surname", tokens[1])
        }
        guard tokens.count == 1, stem.count >= 5 else { return nil }
        if PersonNameVocabulary.surnames.contains(String(stem.dropFirst())) { return ("initial-surname", String(stem.dropFirst())) }
        if PersonNameVocabulary.surnames.contains(String(stem.dropLast())) { return ("surname-initial", String(stem.dropLast())) }
        return nil
    }
    private static func features(_ address: String) -> Set<String> {
        let local = local(address)
        let stem = String(local.prefix { !$0.isNumber })
        let tokens = stem.components(separatedBy: CharacterSet(charactersIn: ".-_"))
        func usable(_ value: String) -> Bool {
            value.count >= 4 && value.allSatisfy({ $0.isASCII && $0.isLetter }) && !PersonNameVocabulary.given.contains(value) && !PersonNameVocabulary.surnames.contains(value)
        }
        var features = Set(tokens.filter(usable).map { "token:" + $0 })
        let compact = tokens.joined()
        let possibleInitialSurname = (1...2).contains { length in
            compact.count > length + 3 && PersonNameVocabulary.surnames.contains(String(compact.dropFirst(length)))
        }
        if !possibleInitialSurname && compact.count >= 9 && compact.allSatisfy({ $0.isASCII && $0.isLetter }) && PersonNameVocabulary.joinedPattern(compact) == nil {
            for length in 6...min(10,compact.count-3) {
                let prefix = String(compact.prefix(length)), suffix = String(compact.suffix(length))
                if usable(prefix) { features.insert("prefix:" + prefix) }
                if usable(suffix) { features.insert("suffix:" + suffix) }
            }
        }
        return features
    }
    func evidence(_ address: String) -> LearningEvidence? {
        evidence(address, scope: nil)
    }
    func evidence(_ row: FoundEmail) -> LearningEvidence? {
        let result = evidence(row.address, scope: Self.sourceScope(row.source))
        if result?.category == .person, result?.exact == false {
            var unlearned = row
            unlearned.learningEvidence = nil
            if AddressClassification.classify(unlearned).category == .general { return nil }
        }
        return result
    }
    private func evidence(_ address: String, scope: String?) -> LearningEvidence? {
        if let sample = exact[address.lowercased()] {
            return LearningEvidence(category: sample.category, exact: true, reason: "Learned from your " + (sample.kind == "removal" ? "not-a-person removal" : "classification correction") + " for this exact address. Local feedback, not independent identity verification.")
        }
        var candidates: [LearningEvidence] = []
        if let pattern = transferPatterns["handle:" + Self.local(address)] {
            candidates.append(LearningEvidence(category: pattern.category, exact: false, reason: "Learned handle transfer: " + pattern.reason + "; not independently verified"))
        }
        if let scope = scope, let shape = Self.personShape(address),
           let pattern = transferPatterns[Self.shapeKey(domain: Self.domain(address), scope: scope, shape: shape.format)] {
            candidates.append(LearningEvidence(category: pattern.category, exact: false, reason: "Learned person pattern: " + pattern.reason + "; not independently verified"))
        }
        let features = Self.features(address).filter { patterns[$0] != nil }.sorted { $0.count == $1.count ? $0 < $1 : $0.count > $1.count }
        if let feature = features.first, let count = patterns[feature] {
            let pieces = feature.split(separator: ":", maxSplits: 1).map(String.init)
            let wording = pieces[0] == "prefix" ? "starts with " : (pieces[0] == "suffix" ? "ends with " : "word ")
            candidates.append(LearningEvidence(category: .general, exact: false, reason: "Learned shared-inbox pattern: " + wording + "‘" + pieces[1] + "’ from " + String(count) + " distinct removed/corrected handles; no conflicting Person corrections. Reviewable inference."))
        }
        if Set(candidates.map(\.category)).count > 1 { return LearningEvidence(category: .uncertain, exact: false, reason: "Learned patterns conflict; kept for review rather than overriding contradictory feedback") }
        return candidates.first
    }
    func applying(to rows: [FoundEmail]) -> [FoundEmail] {
        rows.map { original in var row = original; row.learningEvidence = evidence(row); return row }
    }
}
enum CSVExportTransaction {
    static func write(_ rows: [FoundEmail], to url: URL, removal: RemovalState) throws -> RemovalState {
        let content = ([VerificationCSV.header] + rows.map(VerificationCSV.line)).joined(separator: "\r\n") + "\r\n"
        try content.write(to: url, atomically: true, encoding: .utf8)
        var updated = removal
        // Export is not a negative categorization example.
        updated.remove(Set(rows.map { $0.address.lowercased() }), learn: false)
        return updated
    }
}
