# Whole-session classification audit — 0.12.22

Evaluated all 8,193 records in the older uploaded session with 0.12.21, inspected
recurring Uncertain patterns and contextual excerpts, then evaluated the same
untouched records with the revised classifier. This is not an audit of the later
1,009-record screenshot; that session has not been supplied. The archive includes
no uploaded project or per-address audit output.

Changes address patterns beyond user-flagged examples:

- Civic titles and offices: chairman, elections, electionboard, voterregistration,
  cityclerk, publichealth and related roles.
- Editorial/broadcast aliases: legals, obits, ads, advertise, republish, rights,
  newstips, viewermail, captioning and public-file functions.
- Organization-qualified services: long, unambiguous function endings can follow
  an organization qualifier while retaining supported personal-name safeguards.
  Shorter functions such as sales/press/staff require a brand prefix matching a
  label from the actual email domain. This covers organization-qualified addresses
  without enumerating full mailboxes or relying on broad name substrings.
- Collective/chapter wording containing indivisible. Explicit full-name evidence
  and saved manual decisions retain priority. A separated personal-name prefix
  before the affiliation stays Uncertain, since it may identify an individual.

Aggregate audit (automatic classification plus existing saved overrides):

| Category | 0.12.21 | 0.12.22 |
| --- | ---: | ---: |
| General inbox | 1,225 | 2,675 |
| Likely person | 1,702 | 1,671 |
| Uncertain | 5,266 | 3,847 |

Transitions: 1,423 Uncertain → General; 27 Likely person → General (collective/title
signals); four Likely person → Uncertain (potentially named affiliated contacts).
These are reclassification counts, not independently measured accuracy. The audit
identified recurring patterns; it did not establish human-reviewed ground truth
for every record. Many remaining Uncertain records contain plausible personal
initials/surnames and are intentionally not forced into General.

Saved manual classifications were unchanged in the evaluation. All addresses,
statuses and removal flags were retained. The uploaded file was read only. No
learning reset, source data deletion, export-policy change, external verification,
or public SMTP probe. Existing automatically classified rows recompute on opening;
do not clear records to apply the classification changes.

Validation: 322 portable tests passed. Four new tests cover independently observed
families, organization/service composition, collective handles and individual-name
exceptions, alongside all previous personal-address, learning, persistence, export
and removal tests. Native Mac compilation and GUI acceptance remain unverified on
this Linux host. This is a source ZIP to build on macOS, not a prebuilt application.
