# Local learning improvements — 0.12.23

Earlier versions remembered exact corrections and generalized some non-name word
fragments toward General inbox. Person feedback could veto shared patterns, but
could not teach a new person-address format. These changes improve that learner;
they do not add another list of mailbox exceptions or require an online service.

## What it can now learn

1. A handle corrected consistently on at least three independent email domains
   can transfer its Person or General classification to that handle on a new
   domain. Repeated projects, addresses and plus tags do not inflate support.
   Conflicting feedback prevents this transfer.
2. At least four explicit Person corrections in one organization's source-page
   context, covering at least three surnames, can teach a supported initial/surname
   or surname/initial format. New supported handles at that email domain and page
   context can then become Likely person, including optional short numeric suffixes.
   Staff/people pages and department pages have separate contexts. Imported text,
   unknown paths and conflicting contexts do not acquire format-based predictions.
3. A conflicting General example in the same format/context vetoes person-format
   inference. Undoing that feedback rebuilds the model and can restore the pattern.
   Number variants of one handle and a set of initials for one surname do not count
   as sufficiently diverse training.

This remains conservative local inference, not a language model or ownership/mailbox
verification. It does not infer that every numeric or unfamiliar handle is a person.
Known shared functions block generalized Person evidence. Saved manual corrections
and exact learned decisions retain priority; directly published full-name evidence
still takes precedence over weaker learned patterns. Contradictory applicable learned
patterns yield Uncertain.

## Feedback and persistence

Manual Person/General classifications train the learner. Removing an address with
the learning checkbox enabled supplies not-a-person feedback. Export never trains it.
Predicted labels, automatic classification and merely viewing a row never train it.
The learning menu now reports example count and Person/shared pattern counts; its
removal-learning toggle controls new removal feedback, not remembered corrections.

An optional sourceScope field stores only the source-page kind (people/departments)
beside a feedback sample. Legacy profiles without it still decode and retain exact
memory and legacy patterns. Current-project context can be rebuilt from its retained
rows. No reset or destructive migration. Saved projects, learning, removals and earlier
archives are retained. No records leave the Mac for inference; no API key, paid service
or public SMTP operation is involved.

To teach a new organization format, select a few confirmed personal addresses in that
organization and use Classify selected → Likely person. Guessed or bulk unreviewed
labels would provide unreliable training; the app does not manufacture positive
feedback from its own predictions.

## Validation and practical limits

329 portable tests passed. Seven new learning tests include four held-out personal
handles not used in training; cross-domain transfer for both classes; wrong-domain,
wrong-context, numeric-ID and shared-function controls; conflict/undo; duplicate and
surname-diversity checks; legacy decoding; profile save/reload; and no self-training.
UI syntax and Xcode project references were checked on Linux. Native macOS compilation
and GUI acceptance remain unverified here.

Reconstructed the 178 removal lessons in the older uploaded session, in memory only.
The upgraded model still applies all 178 exact lessons and 37 generalized matches.
Five-fold evaluation grouped by normalized handle withheld each test handle from
training: 55 agreed with saved feedback, 123 abstained, zero contradictory predictions,
zero exact-address leakage. This dataset contains only General/removal feedback, so
it cannot measure Person accuracy. These are saved-feedback agreement results, not
independent classification accuracy or a comparison demonstrating overall accuracy
improvement. New Person capability is behaviorally demonstrated by held-out synthetic
tests and will need reviewed real Person feedback for a representative evaluation.

No uploaded project or per-address feedback is included in this source ZIP. Existing
earlier classification changes remain included.
