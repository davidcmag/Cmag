# Mac binding compile correction — 0.12.16

The user-supplied native build output identified one blocking error:
EmailGrabber3.swift:973: cannot find '$model' in scope. ResultsPane holds model as a
plain let reference for its existing Equatable/batched-update behavior, rather than
an ObservedObject property wrapper. The learning toggle now supplies an explicit
Binding(get:set:) for model.learnFromRemovals. Other projected-model bindings are
confined to ContentView, which declares ObservedObject. No concurrency-safety claims
or unsafe Sendable annotations were added to suppress the nonblocking warnings.

300 portable tests, SwiftUI syntax, project references and shell syntax passed. A
source audit verifies no projected $model binding remains in ResultsPane. Native
macOS compilation/launch after this correction remains unverified from Linux; the
actual reported compile blocker is corrected. Saved records and learning formats
are unchanged. No paid verification or mailbox probes were performed.

# Feedback learning, source-name sorting and export cleanup — 0.12.15

## Learning on this Mac

Learning: ON → Learn new removals as not a person is enabled by default for this
contact-cleanup workflow. Turn it off when removing an address for another reason.
Review assistant also lets you choose whether that particular removal should teach.
Explicit Person/General inbox corrections, including reviewed group choices, supply
feedback too. Old removals without a recorded learning choice are not retroactively
assumed to mean not a person. Old explicit saved corrections can supply feedback.

The local learning-profile.json stores examples in the existing private application
support directory (private directory/file permissions). It survives starting new
projects; no feedback is sent to a service. Exact-address feedback is reused directly.
Broader word/prefix/suffix patterns need three distinct local-part handles, not three
copies of the same address or the same handle on three domains. Name-vocabulary terms
and likely initial+surname endings are protected from broad fragment learning. Any
conflicting Person example vetoes a broader learned negative pattern. Email domains,
numeric shape alone, model predictions and automatically applied future group rules
are never training examples. Explicit current-project choices have priority.

A supported source-person association overrides a broad learned pattern; exact
user feedback remains a user choice. Learned reasons show the pattern and sample
count. These are feedback-based inferences, not verified identities or a guarantee
of classification accuracy. Correcting a mistake supplies counter-evidence.

Undo removal removes that removal's lesson. Undo group decision removes that group's
explicit lessons and its remembered rule, preserving later individual corrections.
Learning → Reset local learning clears examples/patterns and sets a cutoff so old
choices do not instantly train it again. It does not erase addresses, project
corrections or removal history. Starting a new project preserves prior learned
examples; the local profile is intentionally separate from portable sessions.

## Automatic source evidence

Sort this list automatically uses the current list's unresolved included records.
It never guesses addresses or invents names. A person association requires an exact
mailto recipient whose visible link label is a plausible full name, or a single
Schema.org Person object with both name and exact email, on a page that independently
passes existing exact publication and URL/content safety checks. Conflicting names,
Organization objects, unrelated headings/nearby people, titles, hidden templates,
email-query echoes, off-site redirects and failed/challenge responses are not person
proof. Evidence retains name, method, source URL and a source excerpt/field values.
Discovery also saves such evidence from pages already downloaded, without an extra
request. Name dictionaries do not gate these explicit associations.

A pass caches page text, publication matches and explicit person associations once per fetched page, batches autosaves, follows bounded same-site profile/contact links, and can use the
existing isolated native browser fallback. Limits are 100 HTTP pages, the existing
browser cap, 35 seconds per address, and five minutes per pass. Stop sorting preserves
completed results. Completed name checks are not repeated within 24 hours; unfinished
checks at page/time/cancellation limits remain eligible for another pass. A source
without supporting names may remain Uncertain. Summary counts and actual newly linked
results are shown; no claim is made that all addresses can be identified.

The old inference from arbitrary nearby capitalized word pairs is removed. It could
mistake Mississippi County for a person's name. County/area/regional accounts and
collective phrases are checked before name scoring. mission.of.zelma, progressive.yamhill,
we.can.ct and the reported county/area accounts are not routed as people. ofa.nws
stays Uncertain without real person evidence. A separated spelling pattern alone is
not positive person evidence. The mixed fixture's three uncorroborated unknown-name
patterns now correctly expect Uncertain; explicit source tests demonstrate those
same unfamiliar names can become Person from an actual named email association.
The 139-case routing matrix now has 42 Person, 63 General and 34 Uncertain examples;
these are curated routing expectations, not full-dataset identity ground truth.

## Export commits remove current results

Every successful CSV save commits one existing RemovalState batch for the exact
exported addresses. All copies and later crawl duplicates are suppressed from the
current project; originals stay saved and Undo removal restores them. The save must
complete atomically before state changes. Cancelled panels and failed writes do not
change removals. An export never records negative learning feedback, including when
Learn removals is ON. Other explicit earlier feedback remains intact. Exclusions,
CSV columns/quoting/evidence, verification status and source records are retained.

Validation: 300 portable tests passed. Coverage includes reported false positives,
explicit-name/schema association and conflict handling, source safety/cache/follow-up
limits, recent-check selection, learning thresholds/vetoes, persistence/reset/Undo,
no self/domain learning, group-rule predictions not becoming lessons, and successful
versus failed export commits with no negative export lesson. SwiftUI syntax, Xcode
references/resources and shell syntax passed. Native macOS compilation, GUI learning,
WebKit execution and live CPR confirmation remain unverified. No paid verification
or public mailbox probes were run; website tests use fixtures.

# Direct export and review removal — 0.12.14

For the fastest workflow, use Export person list in the main window. It considers
all included project results, independent of the current search/status/address-type
view. Default is Likely person only; Include Uncertain retains unresolved possible
people as well. The checkbox is remembered through a local AppStorage preference.
General inbox, excluded, removed and rejected records are omitted in both modes.
Manual classification corrections retain priority. This is a filtered export, not
a declaration of identity or mailbox existence. Originals and all unresolved records
remain saved, so review is optional rather than a prerequisite to getting a list.
Current-list export remains under Export CSV… for explicitly filtered output.

Review assistant adds Remove group beside the classification actions. It uses the
same exception checkboxes and confirms the selected unique-address count before
removing all copies of those exact addresses from included results and CSV exports.
It revalidates current inclusion, review pattern and exclusions on confirmation.
Later individual corrections are not accidentally swept into a stale review action.
Unchecked exceptions, unrelated addresses, verification and classification choices
are unchanged. No broad removal rule is created, even if Remember classifications
is checked. Existing exact-address removal suppression still covers later duplicates.
Undo removal in the assistant uses the existing persisted removal history and
restores only the last removal batch, preserving earlier removals. Main-window
Restore last removal remains available too. Undo group decision continues to handle
classification batches separately. The assistant can reopen when the current list
is empty but removal history is available.

Validation: 282 portable tests passed, including 5 new regressions for scoped group
removal, exceptions/duplicates, stale exclusions/classifications, persisted Undo,
and person-list export with optional Uncertain plus every exclusion/correction.
Existing group/CSV and 139-case classification regressions still pass. SwiftUI syntax,
Xcode project references and shell syntax passed. Native macOS build and GUI/WebKit
execution remain unverified. No paid verification or public mailbox probes were run.

# Grouped review and export correction — 0.12.13

Open Review assistant… from the results area. It captures the IDs in the current
list and queues unresolved included addresses, grouped by structured review pattern:
initials, numeric handles, unrecognized names/handles, and possible organization or
function names. Duplicate addresses are shown once per group. Classified, excluded,
rule-hidden and removed records are not queued. Existing filters limit this scope.
Already manually kept-Uncertain addresses are not repeatedly queued.

Each card shows a count and four examples. Expand Inspect all addresses / choose
exceptions to inspect every address and uncheck any exceptions. Mark group Person,
Mark group General inbox or Keep group Uncertain asks for confirmation with the
selected count. It applies to all copies of those exact selected addresses in the
project. Keep Uncertain is an explicit saved choice. Skip for now makes no changes;
Show skipped groups restores the cards during the current review session. No
classification action deletes records or changes verification, exclusions or CSV
fields. Samples are not proof that an entire group belongs to people.

Remember for future matching addresses in this project is off by default. When
selected, it saves an approved rule for that unresolved pattern, retaining unchecked
exceptions and excluding existing addresses outside the reviewed scope. New matches
inherit the decision; explicit role/person evidence, individual choices and dated
Use automatic resets are not overridden. A later remembered rule's exception is a
veto, not a fallback to an older rule. Rules are project-scoped, not global.

Undo group decision reverses the last batch and its optional remembered rule,
including later addresses classified by that rule. Later individual corrections
are preserved. Dated reset decisions prevent stale worker checkpoints from reviving
an undone choice. Group rules, original decisions and Undo history are optional
reviewState metadata in sessions/checkpoints; older saved projects remain readable.
Clear starts a new project and clears project-specific group decisions/rules.
Undo is accessible even if a classification change empties the current filter.

Export CSV… → Current list uses current address-type, search and status filters and
the displayed ordering. The menu shows the actual exportable row count. All included
results and All accepted / verified are explicitly labeled all address types.
Regardless of scope, excluded raw statuses, exclusion-rule matches and removals are
omitted. In the old Export all path, the stored full list was used even under a
filter, and crawler Excluded rows were not suppressed; this was a code defect.
Raw exclusion is now checked before technical reclassification as well. An excluded
or removed-only list has no exportable rows. CSV schema/quoting/evidence are unchanged.
Rejected records remain available only through an explicit current-list diagnostic
scope; default all-included export omits them. Classification alone is not removal:
use Current list to export only the chosen address type.

Validation: 277 portable tests passed, including 13 new group/export regressions.
They cover scope, duplicates, exceptions, optional future rules, later manual choices,
Undo, stale checkpoints, session/reopen compatibility, excluded CSV rows, current-list
filters/order, and unchanged CSV/evidence. The existing 139-case classification
matrix still passes. SwiftUI syntax, native project references/resources and shell
syntax passed. Native macOS compilation and GUI/WebKit execution remain unverified.
No paid verification or public mailbox probes were run.

# Pattern-based classification — 0.12.12

The old familiar-given-name whitelist is removed. This version evaluates independent
signals, keeping the following precedence:

1. Your saved correction wins, including an explicit Uncertain correction.
2. Explicit shared-inbox, job-title and organization signals route to General inbox.
3. A recorded exact-address excerpt with a matching name supports Likely person.
4. Name-shaped address patterns supply heuristic evidence for Likely person.
5. Insufficient or ambiguous evidence remains Uncertain, never automatically deleted.

Separated name patterns accept two to four alphabetic components with at least two
full words, allowing middle initials and either order. They are not gated by a list
of known names. This fixes sharon.dean, rebecca.dolber, debra.fyock, sheri.coln,
susanne.g.hinkle, and unfamiliar names absent from the reference vocabulary.

Joined given/surname components (either order), optionally including a middle
initial, use a bundled vocabulary derived from 1990 US Census distributions. It has
5,130 given names and 88,698 surnames, is not exhaustive or internationally complete,
and is only positive evidence. The data and package provenance, hashes, public-domain
origin and MIT package license are recorded in Resources/person-names-provenance.json
and PERSON-NAMES-LICENSE.txt. No runtime download is needed. Native app and core
resource phases include the data, and missing vocabulary fails the resource test.

Examples supported by segmentation include margueritechandler, terryewhitaker,
debiferrer and ernestinagarcia. Full-name patterns can retain up to four trailing
digits, e.g. clarkdavid01 or susanstreett24. Numeric IDs, digits inside a handle,
initial-only patterns and initial+surname forms without additional name evidence
remain cautious. Numbers alone do not establish or exclude a person. Recognized
single-name handles can contribute evidence, with ambiguous word/name terms such
as hope and faith kept for review. No inference is proof of identity.

Explicit role and organization evidence overrides address-shape evidence, including
when a role has numeric suffixes. Existing crawl role-exclusion membership is not
changed. Publication alone, SMTP results and the email's domain never prove that
the address belongs to a person. Pattern reasons state the basis and identity limit.

Evaluation: Tests/Fixtures/classification-evaluation.tsv contains 139 curated routing
examples: 45 likely-person, 63 general-inbox and 31 uncertain cases. These combine
reported examples with synthetic cases across the supported patterns, unknown names,
titles, role aliases, organizations and numeric/initial handles. All 139 passed.
They are expected routing labels, not verified real identities or a measurement of
accuracy on the user's full dataset. The full portable suite passed 264 tests,
including saved corrections/reset, recrawl/checkpoint recovery and unchanged CSV.
SwiftUI syntax, project references/resources and shell syntax passed. Native Mac
compilation, GUI/WebKit execution and live CPR confirmation remain unverified.

Existing saved rows use the new automatic rules on display; no recrawl or data
migration is required. Saved manual corrections retain priority. Use automatic
classification to reset one explicitly. No mailbox probes or paid verification
were run. Selection, filtering, removal/Undo and saved evidence remain unchanged.

# Classification tuning — 0.12.11

Select one or more rows, then Classify selected… → Mark as Likely person,
General inbox or Uncertain. The same choices appear in an address's context menu.
Corrections take priority over automatic rules for all copies of that exact address
(case insensitive, within this project). They do not change acceptance, verification,
exclusions, removal history or CSV output. Use automatic classification resets them;
a dated reset prevents older checkpoints from restoring an obsolete correction.
A correction to one address never creates a pattern rule for other addresses.

Corrections persist in the optional classificationDecision field on saved rows.
Older projects without it still load without migration. Session/autosave/checkpoint
recovery, recrawls and later duplicate discoveries preserve the latest decision.
Clear starts a new project and clears its result-bound corrections. Corrections are
not a global address book shared across unrelated projects.

The Classification reason column explains the effective choice; Show evidence also
includes it. Automated improvements recognize connect/outreach/membership and other
shared terms, coalition/alliance/democracy and organization endings such as voices
and united in the local part. These are heuristics, not proof; domains alone are not
used to infer a shared inbox. Existing crawl role-exclusion membership is unchanged.

Separated familiar-given-name / surname patterns work in either order, including
palumbo.dana. This small name list is deliberately incomplete. Initials and unusual
names remain Uncertain unless recorded exact-address publication text supplies a
matching full name. Initial+surname (including separators) and given-name+initial
forms can then be strengthened. Capitalized job titles remain barred as names.
Your saved choice always wins and can also explicitly preserve Uncertain.

261 portable tests passed, including 9 new regressions covering screenshot examples,
name patterns, manual correction/reset, duplicates, backward-compatible decoding,
CSV invariance, session/autosave reopening, recrawls and late checkpoint writes.
SwiftUI syntax, Xcode project references and shell syntax passed. Native macOS
compilation, GUI/WebKit execution and live CPR confirmation remain unverified.
No paid verification or public mailbox probes were run.

# 0.12.9 correction

Validation: 252 portable tests passed. SwiftUI syntax, Xcode project references
and shell syntax passed. Native macOS compilation and GUI/WebKit execution were
not run in this Linux environment.

0.12.8 could mistake capitalized job titles for names in publication excerpts.
0.12.9 recognizes title inboxes before interpreting name evidence, rejects job-title
and shared-inbox terms as names, and requires an exact address match in excerpts.
Existing rows are reclassified on display without changing saved data or removals.
New regressions cover the reported three director inboxes, separator/alias forms,
unknown titles, person/category filtering, genuine staff names beside titles and
false address suffix matches. This changes presentation only, not role exclusions.

# Address classification — 0.12.8

Address type is independent of acceptance, SMTP, ZeroBounce and website publication.
General inbox recognizes shared mailbox terms, including newsroom and role aliases.
Likely person requires a familiar given name and separated name-like surname, or
recorded exact-address publication text with a matching full name. These are hints,
not proof of a person's identity. Unfamiliar names, initials, numeric handles and
single-word addresses stay Uncertain without matching recorded name evidence.
No new network requests are made for classification. Existing excerpts may have
only a mailto address; those do not imply name evidence. New visible mailto text
can retain the surrounding name while preserving the Email link match type.

Choose Address type → Person addresses only to hide other rows, or select General
inbox / Uncertain for review. Click Address type's column header to sort. Hover
its cells or use Show evidence to read the classification reason.
Review category removal captures visible rows under the current status/search
filters. Confirming uses existing address-based removal: all copies of those
addresses are suppressed, including future duplicate discoveries. Restore last
removal undoes the batch. Existing removals and rules remain intact. Review and
Cancel do not remove anything. Clearing the address-type filter restores hidden
rows. CSV export behavior and saved-data schema remain unchanged.

Validation: 248 portable tests passed on Linux using signature-verified Swift
6.0.3, including 8 new classification/publication and removal regressions.
SwiftUI syntax, Xcode object/source references and shell syntax passed.
Native macOS compilation, GUI interactions, native WebKit execution and live CPR
confirmation were not run. No paid verification or public mailbox probes were run.
