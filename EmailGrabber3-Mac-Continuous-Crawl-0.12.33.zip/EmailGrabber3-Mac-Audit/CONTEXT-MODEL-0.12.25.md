# Local trained context model — experimental preview 0.12.25

This is an actual trained statistical classifier, not another address/domain exception
list. A logistic-regression model combines character fragments of the mailbox handle
with words and word pairs in the saved text around that exact address. Training fits
710 weights from labeled examples. Swift performs inference locally using the bundled
JSON weights; the app requires no Python, model server, API key or network inference.
It is a small statistical starter model, not a full language model or a proven general
semantic classifier. It does not establish mailbox ownership or deliverability.

## Trying it

Open Learning → Use trained context model (preview). This is OFF by default because
the evaluation does not establish broadly reliable accuracy. Turning it off restores
the existing automatic classifier. The table is refreshed on a toggle; current saved
records, learning and removal history remain intact. This preference is local to the
Mac, not embedded in a session file. Model-assisted Person labels can affect person
export selection, just like other automatic classifications; review before exporting.

Only previously Uncertain addresses without remembered learning evidence are eligible.
Manual corrections, remembered feedback, established rule classifications and explicit
published-name associations retain priority. The model requires an exact address in
usable saved context from a successful, Published HTTP page observation. Missing/short
context, unavailable pages, corrupt/missing model resources, technical identifiers and
scores in the uncertainty band abstain to the old classifier. No percent-confidence
claim is shown; logistic scores are not calibrated probabilities of being correct.

New link-only publication observations now retain nearby visible page text rather than
only mailto:address when meaningful surrounding text exists. Context is assembled in
one pass with a separate marked-text stream; it does not invent publication recipients
from cc/subject fields, hidden scripts or surrounding names. This is context, not proof
of a name/address association. Existing saved mailto-only evidence needs a future page
observation to gain context; the model does not silently fetch pages to fill it.

The starter weights do not automatically retrain from user corrections. Corrections
continue to override predictions and teach the existing exact/pattern/context learner
from 0.12.23. Model predictions never train either learner. Substantially improving
the bundled model requires more representative labeled context and separate evaluation,
or a more capable local language model. This preview is the first implementation step.

## Training and provenance

ModelTraining/train_context.py, requirements.txt, corpus.jsonl and evaluation.json are
included. Reproduce with Python plus numpy 2.3.5 and scikit-learn 1.8.0, then run
python3 ModelTraining/train_context.py from the extracted source directory. The Mac
application build uses the exported JSON and does not run the trainer.

Training data: 128 synthetic examples with assistant-specified Person/General labels;
validation: eight; held-out synthetic test: eight. Handles and wording templates are
split between sets. All addresses use example.org. No uploaded user record, private
context, learning profile or per-address evaluation is included or used for training.
The prototype threshold (0.8) was selected on validation, not on the private pilot.
The model and data are deliberately small; they cannot justify a broad accuracy claim.

At the selected threshold:

| Controlled set | Correct predictions | Wrong predictions | Abstentions |
| --- | ---: | ---: | ---: |
| Synthetic validation (8) | 3 | 0 | 5 |
| Held-out synthetic test (8) | 1 | 0 | 7 |

A separate 16-record convenience sample was selected from the older uploaded session
and reviewed by the assistant using stored page context. It is not blind independent
ground truth or representative production testing. The raw model made five correct
Person calls, zero wrong calls and 11 abstentions. The existing classifier correctly
labeled five General records and left 11 Uncertain. With the opt-in fallback enabled,
the combined classifier labeled ten correctly (five additional Person records), left
six Uncertain and introduced no wrong labels in that small pilot. This demonstrates a
useful capability, not a measured overall accuracy improvement on the user's current
dataset. Accordingly the preview remains off by default.

## Validation and preservation

341 portable tests passed. Seven new tests cover independent Python/Swift feature-score
parity, held-out examples, context/HTTP guards, corrupt resources, abstention, manual and
learning priority, reversible rollout, no self-training, and link-only context capture
without hidden/header-recipient leakage. The model is registered in all three Xcode
resource targets and the standalone build copies it with existing resources. UI syntax
and project references were checked. Native Mac compilation and GUI behavior still
require confirmation on a Mac.

All earlier crawl-recovery, learning, export and removal behavior is retained. No data
reset is needed. Inference sends no records to a service, and no paid verification or
public SMTP probes were used. Previous source archives remain available.
