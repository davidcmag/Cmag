"""Reproducible local starter model. Uses synthetic, explicitly labeled contexts;
never reads user projects or uses their records to train a public artifact."""
import json, re, hashlib, pathlib
import numpy as np
from sklearn.feature_extraction import DictVectorizer
from sklearn.linear_model import LogisticRegression

ROOT = pathlib.Path(__file__).resolve().parents[1]
EMAIL = re.compile(r"[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}", re.I)

def features(address, text):
    local = address.lower().split('@')[0].split('+')[0]
    result = {}
    padded = '^' + local + '$'
    for n in (3,4,5):
        for i in range(len(padded)-n+1): result['local:' + padded[i:i+n]] = 1.
    result['shape:digits'] = float(any(c.isdigit() for c in local))
    result['shape:separator'] = float(any(c in '.-_' for c in local))
    text = text.lower()
    at = text.find(address.lower())
    if at >= 0: text = text[max(0,at-160):at+len(address)+160]
    cleaned = EMAIL.sub(' email ', text)
    words = re.findall('[a-z]+', cleaned)[:100]
    for word in words: result['context:' + word] = 1.
    for a,b in zip(words,words[1:]): result['context:' + a + ' ' + b] = 1.
    return result

def corpus():
    rows = []
    people = [('Anna Moss','amoss'),('Bruno Shen','bshen'),('Cora Ibarra','cibarra'),('Dina Garza','dgarza'),('Evan Fuentes','efuentes'),('Faye Lopez','flopez'),('Gavin Kim','gkim'),('Hana Patel','hpatel'),('Iris Morgan','imorgan'),('Jules Ross','jross'),('Kira Price','kprice'),('Leon Reid','lreid')]
    roles = ['guestrelations','venuehire','ticketing','hallrentals','tourismdesk','collectionsdesk','exhibitiondesk','audioguides','lostproperty','visitorsdesk','tourbookings','groupvisits']
    person_texts = [
        '{name} is our reporter. Reach her directly at {email} for questions about her reporting.',
        'Contact {name}, our staff writer, by email at {email}. He covers local government.',
        'Our researcher {name} can be reached at {email}. She studies public policy.',
        '{name} — {email}. He is a faculty member and teaches political science.',
        'Send your questions to {name} at {email}. She will reply personally.',
        '{name} joined our editorial team last year. You can reach him at {email}.',
        'Staff biography: {name}. Her direct email address is {email}.',
        'For an interview with {name}, contact him directly at {email}.',
        '{name}, Director of Programs: {email}. She leads the team.',
        'Contact person: {name}. Personal email: {email}.',
        'Media inquiries: {name} — {email}. He handles press interviews.',
        'Finance Department: {name}, financial analyst. Her email is {email}.',
    ]
    shared_texts = [
        'For general questions, email our department at {email}. This mailbox is monitored by the team.',
        'Contact the office at {email}. Our staff will respond to your inquiry.',
        'Send requests to {email}, our shared service inbox. Any team member can answer.',
        'General contact: {email}. The department handles all visitor questions.',
        'For bookings and reservations, write to {email}. Our service team will assist you.',
        'The office mailbox {email} is used for customer requests and general enquiries.',
        'Staff directory: for this department use {email}, a shared departmental address.',
        'For questions about services, contact our team at {email}. This is not a personal mailbox.',
        '{name} manages this department. All general requests go to the team inbox {email}.',
        'Department email: {email}. Staff members take turns answering this mailbox.',
        'Our shared contact address is {email}. Requests are routed to available staff.',
        'Office inquiries should go to {email}. This is the general service address.',
    ]
    # Entire wording templates and handles are separated across train/validation/test.
    # The held-out set is a controlled starter evaluation, not real-world accuracy.
    splits = [('train',range(8),range(8)),('validation',range(8,10),range(8,10)),('test',range(10,12),range(10,12))]
    for split, handles, templates in splits:
        for i in handles:
            name, local = people[i]
            for t in templates:
                for label, handle, text in [('Person',local,person_texts[t]),('General',roles[i],shared_texts[t])]:
                    email = handle + '@example.org'
                    rows.append(dict(id=f'{split}-{label}-{i}-{t}', split=split, address=email, text=text.format(name=name,email=email), label=label))
    return rows

def score(model, vectorizer, rows, threshold):
    probs = model.predict_proba(vectorizer.transform([features(r['address'],r['text']) for r in rows]))[:,1]
    output = []
    for row,p in zip(rows,probs):
        predicted = 'Person' if p >= threshold else ('General' if p <= 1-threshold else 'Uncertain')
        output.append(dict(id=row['id'], expected=row['label'], predicted=predicted, score=float(p)))
    return output

def main():
    rows=corpus(); train=[r for r in rows if r['split']=='train']; val=[r for r in rows if r['split']=='validation']; test=[r for r in rows if r['split']=='test']
    handles=[{r['address'] for r in part} for part in (train,val,test)]
    assert not(handles[0]&handles[1] or handles[0]&handles[2] or handles[1]&handles[2])
    vectorizer=DictVectorizer(); x=vectorizer.fit_transform([features(r['address'],r['text']) for r in train])
    model=LogisticRegression(C=4,random_state=42,solver='liblinear',max_iter=1000)
    model.fit(x,np.array([r['label']=='Person' for r in train],dtype=int))
    candidates=[.75,.8,.85,.9,.95,.975]
    # Select a conservative threshold using validation only; test is untouched.
    valid=[]
    for threshold in candidates:
        results=score(model,vectorizer,val,threshold)
        wrong=sum(r['predicted'] not in (r['expected'],'Uncertain') for r in results)
        accepted=sum(r['predicted']!='Uncertain' for r in results)
        if wrong==0 and accepted: valid.append((accepted,threshold))
    threshold=max(valid,key=lambda p:(p[0],p[1]))[1] if valid else .975
    artifact=dict(version=1,algorithm='logistic-regression',training='synthetic-context-starter-v1',previewOnly=True,threshold=threshold,bias=float(model.intercept_[0]),weights={key:round(float(value),12) for key,value in zip(vectorizer.get_feature_names_out(),model.coef_[0])},trainingRows=len(train),validationRows=len(val))
    data=json.dumps(artifact,sort_keys=True,separators=(',',':'))+'\n'
    (ROOT/'Resources/context-classifier-v1.json').write_text(data)
    metrics={}
    for label,part in [('validation',val),('test',test)]:
        results=score(model,vectorizer,part,threshold)
        metrics[label]=dict(total=len(results),correct=sum(r['predicted']==r['expected'] for r in results),wrong=sum(r['predicted'] not in (r['expected'],'Uncertain') for r in results),abstained=sum(r['predicted']=='Uncertain' for r in results),results=results)
    report=dict(threshold=threshold,train=len(train),weights=len(artifact['weights']),modelSHA256=hashlib.sha256(data.encode()).hexdigest(),metrics=metrics,limitation='Synthetic starter corpus, not real-world accuracy. Training has no user records. Real-context evaluation must be separate.')
    (ROOT/'ModelTraining/evaluation.json').write_text(json.dumps(report,indent=2)+'\n')
    (ROOT/'ModelTraining/corpus.jsonl').write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in rows))
    print(json.dumps(report,indent=2))

if __name__=='__main__': main()
