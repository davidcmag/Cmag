# Removal recovery — 0.12.27

## Problem and evidence

A user reports removing an address and seeing it again without Clear. Version 0.12.26 changed classification, not removal recovery. Source inspection found that Resume saved crawl called applyCheckpoint, which replaced the current removal addresses/history/learning dates with the checkpoint's values. There was no comparison of removal recency. A stale checkpoint could therefore restore an address. Normally presentation changes also update the checkpoint, so this hazard needs stale storage or a failed write; we have not reproduced the user's exact Mac sequence or proved this was its cause. Included filtering already suppresses every duplicate of a removed address by case-insensitive address. All intentionally retains original rows, including removed ones.

## Change

- Successful Remove, Undo and Restore operations version the complete removal state with a monotonically advancing timestamp. Undo/Restore can produce an empty, newer state: recovery must not union older removals back into it.
- Sessions and checkpoints carry an optional removalChangedAt field. Older files remain decodable and untouched source archives remain available.
- An independent atomic, private (0600) removal-state-<project UUID>.json file preserves the project's newest complete removal state, including history and learning dates. The directory is private (0700). It is written before learning/project autosave from removal actions and also when presentation metadata is updated. Stale writes cannot replace a newer journal. Corrupt journals are copied to recovery files and not overwritten; errors are surfaced.
- Reopen, autosave recovery and Resume resolve the newest state among the same project's in-memory state, removal journal and saved snapshot. Ties favor current state, then journal. Another project's removal decisions are never merged. Unversioned legacy state uses the same authority order because its chronology cannot be inferred.
- Resume does not merge rows/review decisions from an unrelated currently open project.
- Manual removal buttons immediately rebuild the Included view. Originals remain accessible through All/Removed; deletion is still recoverable. CSV export continues suppressing removed copies, without negative training from exports.
- Clear still starts a separate project. Journals for previous project UUIDs remain available when reopening that project. This is not a global email ban across independent projects.

## Validation and limits

Portable regression tests cover stale checkpoint recovery, repeated/live duplicate visibility and export suppression, legacy state, session/checkpoint metadata, journal durability independently of working checkpoint, cross-project isolation, permissions, stale journal writes, clock rollback, Undo/Restore and corrupt journal preservation. The existing export undo test now checks the restored semantic fields and verifies that Undo advances the recovery version.

Full portable suite: 351 tests, 0 failures (see CORE-TESTS.log). SwiftUI source syntax and all three Xcode target/source references validated. Linux cannot compile or launch the native Mac SwiftUI app; Mac GUI acceptance remains necessary.

This protects known recovery paths. It does not prove the exact original recurrence is resolved, recover removal actions that older versions never saved, or infer whether two different address spellings belong to one mailbox.

## Mac acceptance

Save the current session, stop the crawl and quit the old app before launching the new build. Without Clear, remove one included address; let new results arrive, save/reopen and resume the same crawl. Confirm all copies stay absent from Included and CSV. Confirm Removed/All retain originals. Undo and Restore should bring them back, including after restart. Reopening an older copy of the same project should preserve newer recorded removal/restore decisions. Keep the old app and session backup until this passes.
