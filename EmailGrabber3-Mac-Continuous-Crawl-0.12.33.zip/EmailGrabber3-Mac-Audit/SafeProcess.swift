import Foundation
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

enum SafeProcess {
    enum Failure: Error { case timeout, cancelled, outputLimit, unsuccessful }
    private final class Buffer: @unchecked Sendable {
        let lock = NSLock()
        var data = Data()
        var exceeded = false
        func append(_ bytes: Data, limit: Int) {
            lock.lock(); defer { lock.unlock() }
            if data.count + bytes.count > limit { exceeded = true }
            else if !exceeded { data.append(bytes) }
        }
        func snapshot() -> (Data,Bool) { lock.lock(); defer { lock.unlock() }; return (data,exceeded) }
    }
    static func run(_ executable: String, _ arguments: [String], maxBytes: Int = 8_000_000, timeout: TimeInterval = 10, cancelled: () -> Bool = { false }) throws -> Data {
        guard !cancelled() else { throw Failure.cancelled }
        let process = Process(); process.executableURL = URL(fileURLWithPath: executable); process.arguments = arguments
        let output = Pipe(); process.standardOutput = output
        // No unread stderr pipe that can deadlock the child. Never log inputs.
        process.standardError = FileHandle.nullDevice
        let finished = DispatchSemaphore(value: 0)
        process.terminationHandler = { _ in finished.signal() }
        try process.run()
        output.fileHandleForWriting.closeFile()
        let buffer = Buffer(); let drained = DispatchSemaphore(value: 0)
        DispatchQueue.global().async {
            while true {
                let bytes = output.fileHandleForReading.readData(ofLength: 8192)
                if bytes.isEmpty { break }
                buffer.append(bytes, limit: maxBytes)
                if buffer.snapshot().1 && process.isRunning { process.terminate() }
            }
            drained.signal()
        }
        let deadline = ProcessInfo.processInfo.systemUptime + timeout
        var interrupted = false
        var timedOut = false
        while finished.wait(timeout: .now() + 0.05) != .success {
            interrupted = cancelled()
            timedOut = ProcessInfo.processInfo.systemUptime >= deadline
            if interrupted || timedOut { break }
        }
        if (timedOut || interrupted) && process.isRunning {
            process.terminate()
            if finished.wait(timeout: .now() + 0.5) != .success && process.isRunning {
                _ = kill(process.processIdentifier, SIGKILL)
                _ = finished.wait(timeout: .now() + 1)
            }
        }
        guard drained.wait(timeout: .now() + 2) == .success else { throw Failure.timeout }
        let (data, exceeded) = buffer.snapshot()
        if interrupted { throw Failure.cancelled }
        if timedOut { throw Failure.timeout }
        if exceeded { throw Failure.outputLimit }
        guard process.terminationStatus == 0 else { throw Failure.unsuccessful }
        return data
    }
}

enum DNSChecker {
    static func check(_ domain: String) -> DNSAssessment {
        check(domain, cancelled: { false })
    }
    static func check(_ domain: String, cancelled: () -> Bool) -> DNSAssessment {
        func query(_ type: String) -> String? {
            guard !cancelled(), let data = try? SafeProcess.run("/usr/bin/dig", ["+time=2", "+tries=1", "+short", type, domain], maxBytes: 256_000, timeout: 4, cancelled: cancelled) else { return nil }
            return String(data: data, encoding: .utf8)
        }
        guard let mx = query("MX"), !mx.contains(";;") else { return .unknown }
        if let answer = DNSAssessment.parseMX(mx) { return answer }
        for type in ["A", "AAAA"] {
            guard let raw = query(type), !raw.contains(";;") else { return .unknown }
            for value in raw.split(whereSeparator: \.isNewline) {
                let address = String(value).trimmingCharacters(in: .whitespaces)
                var v4 = in_addr(); var v6 = in6_addr()
                if inet_pton(AF_INET, address, &v4) == 1 || inet_pton(AF_INET6, address, &v6) == 1 { return .fallback }
            }
        }
        return .noMail
    }
}
