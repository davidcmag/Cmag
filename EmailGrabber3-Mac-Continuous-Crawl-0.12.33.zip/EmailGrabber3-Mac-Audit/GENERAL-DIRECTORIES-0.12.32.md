# 0.12.32 — general Adaptive directory traversal

The 0.12.31 directory bridge was limited to institution routes. The user's requirement is general directory → listed organization profile → official website traversal. This update replaces that industry-specific bridge with structural and semantic directory evidence.

## Behavior

- Directory/profile context is recognized through generic directory, listing, member and entry concepts, collection-to-entry route structure, or repeated sibling entry links. Repeated routes require at least three distinct URLs with three distinct labels. Opaque query-driven profiles can qualify from the same repeated-link evidence.
- Collection matching derives singular/plural route relationships rather than checking a college/industry vocabulary. Existing unrelated academic/staff scoring from prior releases is retained; the new directory bridge itself is not restricted to those sectors.
- Neutral internal entry links can become eligible in Adaptive. Existing negative priority, nofollow, trap and utility-link restrictions still apply. Footer/control routes such as privacy, subscriptions and login are not inferred as organization entries.
- Generic Website/Visit website labels and destination-hostname labels on recognized profiles can lead to the organization's external site. An arbitrary Website link on an unrecognized page does not automatically qualify. Existing social/utility hosts, advertising/designer labels and sponsored/nofollow rules remain excluded by their normal checks.
- Where a topic is provided, matching topic evidence from the listing/entry relationship is retained with the profile. A company's opaque profile URL need not repeat the topic. Blank topics remain supported. An unrelated topic does not become an unrestricted directory crawl.
- Profile context is persisted in the optional `directoryProfiles` crawl-checkpoint field and restored into a fresh engine. Stop/Resume and one-page batches therefore retain the relationship needed to leave opaque profiles for official sites. Older checkpoints without the field still decode; existing rows, removals, learning and review formats are not replaced.
- Robots handling, one worker per website, external-link opt-in, checkpoint throttling and the bounded queue preview remain unchanged. Existing saved frontiers are preserved rather than erased or broadly regenerated.

## Verification

385 portable XCTest tests passed (382 in 0.12.31). Three new test methods cover cross-industry traversal and fresh-engine resume for manufacturers, charities and association members with one/five workers; structural evidence thresholds and footer rejection; and older checkpoint compatibility. The earlier college traversal fixture still passes. One old institution-specific assertion now supplies the profile context that a real queued directory entry carries; unrelated-topic and negative cases remain asserted. Plural token normalization also handles `-ies` as `-y`, allowing listing/entry labels such as universities/university to agree.

Core build, SwiftUI syntax parse and Xcode project-reference validation passed. Native Mac compilation/GUI and live directory sites remain unverified. These are synthetic structural fixtures, not a guarantee that every directory or profile format is detectable. A single opaque entry with no directory/context evidence, unusual routes, JavaScript-only listings, forms, unavailable robots rules or site challenges can still prevent progress. No site access restrictions are bypassed.

## Mac use

Save your current session, Stop, quit the previous app, build with `bash build-mac.sh`, launch `dist/EmailGrabber3.app`, and confirm 0.12.32. Keep Adaptive and Follow relevant links to other websites enabled. Leave the topic blank or use one relevant to the selected directory; remove leftover unrelated topics.

Click Start again from the directory URL to re-examine pages previously completed with no eligible links. Resume retains the existing frontier and does not automatically reconsider completed pages. No Clear is required. Check Recent pages for considered/queued link counts and confirm that organization hosts enter the active/pending lists. Save a session before switching tasks; verify learning/removal state remains intact.

All previous source archives remain preserved. No private sessions, learned profiles, caches or compiled application are included. No paid verification or public SMTP probes were used.
