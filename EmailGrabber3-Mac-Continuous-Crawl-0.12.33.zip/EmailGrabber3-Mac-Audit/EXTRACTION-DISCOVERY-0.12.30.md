# 0.12.30 — interruptible extraction and people discovery

## What prompted this update

The user reported 0.12.29 remaining in Extracting on a UniversityGuru page, and Pause followed by Stop appearing to resume before eventually stopping. A separate direct WHED crawl showed a deferred robots check despite returning within about three seconds. Broad university/college keyword searches returned few addresses, reportedly all General. Those are distinct observations; none proves that WHED explicitly denied access or that the returned addresses were misclassified.

## Findings

The extraction code prepared publication/name evidence and complete regex-match arrays before its per-address Stop check. A slow regex search therefore could not observe cancellation until matching returned. A synthetic 72 KB malformed-anchor case using the original name-matcher regex did not finish within a three-second process limit; progress-aware matching interrupted the same pattern in approximately 0.1 seconds in a diagnostic, and regression tests use short interruption budgets. This demonstrates a failure path, not a reproduction of the exact UniversityGuru page. No captured page or native Mac stack trace was available.

Stop correctly sets cancellation and wakes a paused checkpoint, but the UI immediately cleared its paused flag without a distinct stopping state. Buffered ordinary progress could also replace the stopping message. That made ongoing cancellation look like Resume. DNS child processes used separate bounded waits, but did not poll crawl cancellation.

The robots failure path discarded the original network error and always said "Robots request timed out" for retryable results. Native networking can return an error before the caller's total deadline; the old label did not establish that the 15-second deadline elapsed. The reason for WHED's early failure remains unverified. This environment's existing domain policy does not permit live WHED/search-provider/UniversityGuru access, and network settings were not changed or bypassed.

Discovery used broad terms and geographic variants, kept the first URL per host, and did not ensure the bounded independent-search allowance reached people-focused queries for every input. University listings/rankings could occupy the frontier while a later staff-directory URL on the same host was discarded. Adaptive link scoring also missed combined Faculty and Staff labels, academic gateways and named profile links whose paths did not include staff/faculty.

## Changes

- ICU matching uses progress callbacks to poll cancellation while searching, including when no match has been returned. Publication/name matching, contact normalization and link extraction use this path and check cancellation while processing results too.
- Extraction has a ten-second cooperative budget, with a separate ten-second link-extraction budget. Activity identifies the current substage and elapsed time. An interrupted or over-budget page remains unvisited and queued; it is not counted scanned until extraction/link discovery finishes. Partial legitimate rows already saved are retained and normal duplicate handling applies on replay.
- Numeric entity and percent-encoded mailto decoding build output from the original text in one pass rather than repeatedly modifying the entire string.
- DNS child-process waits poll cancellation and terminate the process when cancelled. Existing time/output bounds remain.
- Stop stays visibly Stopping until the worker returns and checkpoint handling completes. Pause/Resume and repeat Stop are disabled during shutdown; ordinary buffered counters cannot replace the stopping summary. This is cooperative cancellation, not permission to run two crawls concurrently or discard the old worker's state. Checkpoint writes and other bounded Foundation operations still must finish.
- Robots failures retain the original error/HTTP status and measured duration, such as an early connection failure, instead of always asserting a timeout. Failed checks remain deferred and recoverable. Explicit parsed robots disallow rules are still respected; 404/410 retain the existing absent-robots behavior. There is no automatic bypass of unavailable robots rules.
- A crawl ending with deferred pages says so explicitly rather than simply claiming Batch complete. Resume retries retained pages; there is no tight automatic retry loop.
- Keyword discovery adds interleaved people-directory/contact queries before geographic expansion. University/college/school inputs include faculty-and-staff queries. It prefers later staff/profile directory URLs over a weaker first URL on the same host and orders institutional/people results ahead of ranking paths. It does not delete existing crawl queues or alter existing reviewed sites.
- Adaptive crawling follows combined faculty/staff links and academic/department gateways. Named profile links on the same host are eligible when linked from a staff/faculty/people directory. Existing negative news/event/archive scoring, nofollow handling, trap filtering and queue-preview bounds remain.
- All named people are in scope: faculty, staff and administrators. No classification or learning thresholds were changed, shared inboxes are not relabelled Person, email addresses are not guessed, and public profiles without published email may yield no address.

## Evidence and limits

379 portable XCTest tests passed (368 in 0.12.29; eleven added). New coverage includes interrupted regex and name matching, extraction-deadline queue preservation, Pause then Stop, cancellable child processes, entity decoding, truthful early robots errors, interleaved academic queries, better same-host seeds, academic link scoring and an end-to-end directory/profile fixture that yields a Person while retaining a shared inbox as General. The existing large-frontier test now explicitly requires the current interrupted page to remain queued and unvisited. Existing learning/removal recovery tests remain passing.

Core build, SwiftUI syntax parse and Xcode project-reference validation passed. Native Mac compilation/GUI, exact UniversityGuru content, actual WHED access and real-world search yield remain unverified. Synthetic discovery fixtures are regression evidence, not a promise of a contact count or comprehensive university coverage. Search providers may block requests or omit pages; JavaScript-only/search-form directories are not automatically enumerated by this static HTML crawler.

## Mac acceptance

1. Save the current session, Stop, and quit the old app. Do not Clear. Keep older apps and source archives.
2. Build with `bash build-mac.sh`, launch `dist/EmailGrabber3.app`, and confirm 0.12.30. Check saved rows, removals/history, learning and preferences remain present.
3. Resume the previous crawl. During extraction, press Pause then Stop. The UI should stay Stopping, then finish with pending pages saved. It must not begin another crawl or mark an interrupted page completed.
4. Retry the WHED page. Inspect Recent pages for the actual robots error and elapsed seconds. A site/network failure may remain; save that exact message. Test the robots URL in Safari on the same Mac to distinguish site/browser accessibility from crawler behavior. Do not interpret an error label alone as an explicit server block.
5. The screenshot's direct-URL external-link topic was government. Change it to universities/colleges, or clear it, when examining university links; this setting does not explain an initial robots failure.
6. For improved keyword discovery, run Discover websites again with universities/colleges, review the sites, then Start. Resume alone uses the saved frontier and does not rerun keyword discovery. Keep the saved session; no Clear is required to use the new discovery queries.
7. Compare actual source evidence for found Person and General rows. Missing results and incorrectly classified results are different problems; do not teach all addresses Person just to raise the count.

The ZIP contains source, synthetic fixtures and validation logs only. No private sessions, learned profiles, compiled app, caches or private diagnostic analyses are included. Prior source archives remain preserved.
