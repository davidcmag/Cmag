# Shared-function word forms — 0.12.26

The screenshot exposed three gaps: subscriptions was recognized but subscription
was not; vote was recognized but government aliases with short regional qualifiers
were not; election was recognized but election+officer was not composed as a role.
These are rule-coverage defects. The optional model can abstain when context is
missing or weak, so it is not a reliable substitute for fixing these base rules.

Changes apply to patterns rather than full-address exceptions:

- Generate bounded regular singular/plural aliases from known shared functions,
  with special handling for -ies and sibilant endings. Avoid deriving mass-noun
  nonsense such as news→new. Newly derived bare forms that collide with reference
  names do not automatically become roles. Existing recognized functions retain
  their previous priority.
- Recognize department+officer/coordinator/manager/administrator compounds and
  their plural forms. These require a known function root, not arbitrary words
  before a title. Separators normalize as before.
- Recognize government election-service handles with an optional short regional
  qualifier, including the reported votencc/votekc/votesc pattern. Require an
  actual .gov email domain; .gov lookalikes do not match. Ambiguous qualifiers
  that match known personal names stay reviewable. Explicit full-name evidence
  and saved learning decisions retain priority over the qualifier inference.

subscription and the reported Delaware office accounts now classify as General
without enabling the trained-model preview, fetching another page or adding
personal filtering rules. Ordinary initial/surname handles such as kjohnson are
not swept into General. Saved manual choices, including Uncertain, remain intact.
Role-based crawl exclusions are not expanded. No model weights were retrained.

345 portable tests passed, including four new tests for the screenshot cases,
singular/plural/title combinations, unrelated/personal controls, government-domain
boundaries, published-name overrides and unchanged crawl-exclusion behavior.
All prior model, learning, crawl repair, removal/export and persistence tests remain
enabled. UI syntax and Xcode references were checked; native Mac build and GUI
acceptance still require a Mac. No records, learning, history or old archives are
cleared. Existing automatic labels recompute after opening in this version; no new
crawl is required. No paid verification or public SMTP operations were used.
