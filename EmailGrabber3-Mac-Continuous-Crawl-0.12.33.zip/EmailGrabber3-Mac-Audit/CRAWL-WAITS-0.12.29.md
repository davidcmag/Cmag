# 0.12.29 — bounded crawl waits and retained timeouts

## Findings and limits

The reported GAO stall has **not been reproduced on the user's Mac** and its exact cause is not established. Do not treat this release as proof of a GAO-specific root cause.

Source review of 0.12.28 found:

- HTTPTransport already had a 15-second caller-side elapsed deadline, in addition to a 12-second URLRequest timeout and a 70-second session resource timeout. It did not rely solely on an inactivity timer. Continuous server bytes alone therefore do not explain an indefinite stall.
- The concurrent host gate ran before that deadline, had no wait limit, and respected arbitrary finite robots crawl delays. The activity was already labelled Fetching / Downloading page during this wait.
- The cancellation callback was the same blocking CrawlControl.checkpoint used for pause. Pausing during a request could suspend its deadline polling until Resume or Stop. This is a confirmed code path, not evidence that the user paused during the reported stall.
- Single-worker crawls slept for the entire robots delay without polling cancellation.
- A timeout was treated like a permanent failed page: its URL could be left visited and removed from pending work.
- Fetch workers do not parse addresses, perform DNS checks, or write checkpoints. Those coordinator operations have separate Extracting / Saving progress activity. The fetch pool waits in short mailbox intervals. There is no application retry/backoff loop in this request path. Redirects are limited to five; redirect policy runs off the serial session delegate queue, with nested robots requests bounded separately.
- One worker per canonical website is intentional. One visible active GAO request does not establish broken workers: remaining eligible hosts cannot be determined from the screenshot alone.
- Stop/Resume can retry an uncommitted in-flight page, consistent with the reported one-page advance, but that does not identify why either request took so long.

A live GET of https://www.gao.gov/robots.txt was attempted through this cloud environment's configured proxy. The proxy denied CONNECT with HTTP 403 under the existing destination policy. No GAO response, robots policy, page timing or server behavior was observed. Environment networking settings were not changed. Testing the two reported GAO pages remains a Mac acceptance step.

## Changes

- Host acquisition is bounded to 30 seconds, uses monotonic elapsed time, checks cancellation, and reports Waiting for website with elapsed time. It still respects the server's crawl delay; exceeding the local wait budget does not authorize an early request.
- Single-worker native requests use the same gate instead of an uncancellable post-page sleep.
- Native downloads report elapsed seconds and their 15-second total download budget. The total includes redirects and redirect checks while the transfer is active; a preceding initial robots check and host wait have their own bounds. This is not a promise that an entire page workflow, parsing, or checkpoint finishes within 15 seconds.
- Transport elapsed comparisons use system uptime. Crawl network/gate polling uses a nonblocking cancellation check. Pause remains a coordinator checkpoint; Stop interrupts the active request rather than waiting for its response.
- Transport timeouts, native URLSession timeout errors, host-wait expiration and robots timeouts retain the original page as pending. They are not marked visited or counted scanned. They are parked until the next explicit resume, avoiding a retry loop while healthy websites continue. Existing permanent-denial/HTTP-status handling is unchanged.
- Deferred pages are included in intermediate checkpoints, the final queue, and recent activity. Existing saved rows, removal recovery, learning and review-state persistence formats are unchanged.
- The Learning menu observes GrabberModel directly and binds the two preferences directly, so its checkmarks no longer depend on the Equatable results pane being refreshed. The user's existing removal-learning preference is retained.

## Validation

Original 0.12.28: 360 portable XCTest tests passed before changes. Updated 0.12.29: 368 portable XCTest tests passed. Eight added tests cover continuous slow bytes, deadline polling while paused, Stop, elapsed reporting, long host delay, cancellation before lease acquisition, preservation/resume alongside healthy work, and robots-timeout preservation. Queue/resume tests exercise both one and five configured workers. Network fixtures are synthetic; socket tests are local only. No public SMTP probes or paid verification were used.

Core build, SwiftUI syntax parse and Xcode project-reference validation passed. These Linux checks do **not** compile SwiftUI against Apple's SDK or validate native Mac URLSession behavior or the GUI. Existing synthetic classification tests remain regression checks, not an accuracy benchmark.

## Mac acceptance

1. Save the current session, Stop, and quit the old app. Do not Clear. Keep the previous app/archive.
2. Build with `bash build-mac.sh`, launch `dist/EmailGrabber3.app`, and confirm version 0.12.29.
3. Confirm saved records, removed records/history, learning examples, manual corrections and the enabled removal-learning preference remain present.
4. Resume the saved crawl. Observe both reported GAO URLs: `/about/what-gao-does/audit-role` and `/about/what-gao-does/tribal-and-indigenous-advisory-council`. Record the phase, elapsed message, recent outcome, pending count and whether another eligible website progresses.
5. A slow download should time out and show Deferred; its page must remain queued for next resume. A long site delay should show Waiting for website and defer after the local wait budget without violating robots delay. If only deferred pages remain, the batch should finish with remaining pages saved; Resume retries them.
6. Pause during a slow request, then Stop. Stop should cancel it, finish checkpointing and preserve uncommitted work. Resume should retry that work. Toggle the Learning preference and verify the checkmark refreshes immediately and survives restart.
7. If a Fetching status still exceeds its stated budget without changing, retain the session and record that exact status/elapsed display. That would demonstrate a remaining failure requiring native diagnosis; do not discard data or mark the page completed to hide it.

No private sessions, learned profiles, caches or compiled app are included in the source archive. Previous source archives remain preserved in the delivery repository.
