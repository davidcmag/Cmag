# 0.12.31 — Adaptive institution-directory bridges

The user demonstrated Email Grabber 2 processing 138 URLs with 5,049 pending while Email Grabber 3 0.12.29 completed only the BigFuture college-list starting page and queued nothing. The college website was reached through intermediate directory/profile links. The earlier recommendation to keep Adaptive without qualifying its filtering behavior was inadequate.

## Confirmed code gaps

Adaptive is a gate as well as an ordering heuristic: same-site links with nonpositive priority are rejected. 0.12.30 broadened academic routes, but singular/other intermediary institution routes could still be missed. More importantly, an external link labelled Website or Visit website was rejected even from a college profile: college-directory paths were not recognized as directory context and the link did not include contact/staff-style keywords. Increasing numbered depth alone does not override that external-link filter.

This update follows a bounded semantic bridge rather than making every Adaptive link eligible:

- On institution directory pages, same-host links to recognized college/university/school/institution routes, or links named as institutions, can receive positive priority when otherwise neutral.
- On those directory/profile pages, explicit official-website links (Website, Visit website, College website, and related labels) can cross to another host. A displayed destination hostname matching the actual link is also recognized.
- An empty topic works. University/college/school topic words are treated as related institution context. An unrelated nonempty topic still restricts these links.
- External traversal still requires Follow relevant links to other websites. Nofollow/sponsored flags, utility/social host exclusions, designer/advertising labels, negative news/event/archive scoring, download exclusions, crawl-trap filtering and robots rules remain in force.
- A successful external jump uses the normal new-host queue and worker policy; it does not skip robots or fetch multiple pages on one website concurrently.
- Recent completed-page activity now reports links considered and new pages queued. Zero queued is distinguishable from a page that actually adds frontier work; the counters are not proof that all site links were exposed in HTML.

## Verification

382 portable XCTest tests passed, three more than 0.12.30. The end-to-end synthetic fixture follows directory index → intermediate institution listing → college profile → external official website → staff page and extracts a named Person address with Adaptive selected. It runs with one and five workers and both blank and university topics. Negative fixtures cover unrelated topics, negative paths, social/trap/designer/nofollow links and external traversal disabled. Existing removal/learning/queue preservation and cancellation tests remain passing.

Core build, SwiftUI syntax parse and Xcode project-reference validation passed. Native Mac compilation/GUI and a live BigFuture crawl are unverified. The fixture reproduces the structural traversal failure; it is not captured BigFuture HTML or a claim that all BigFuture pages are crawlable. JavaScript-only controls, unavailable robots checks, access challenges and nonstandard link labels can still prevent traversal. No site restrictions are bypassed.

## Use on Mac

1. Save the current session, Stop, and quit the previous app; do not Clear. Keep older apps/archives.
2. Build with `bash build-mac.sh`, launch `dist/EmailGrabber3.app`, and confirm 0.12.31.
3. Choose Websites / domains, enter `https://bigfuture.collegeboard.org/colleges`, keep Adaptive, and enable Follow relevant links to other websites. Leave the optional topic blank or use universities/colleges, rather than the earlier government topic.
4. Click Start to re-examine the starting page. Resume uses the saved frontier and cannot reconsider links on an already completed page whose queue is exhausted. Starting preserves existing rows and learning/removal state; no Clear is required.
5. Check Recent pages for link counts and the queue for college-profile and external college-host URLs. Confirm crawling continues on the actual institution site and that Stop remains responsive. If it still ends after one page, preserve the exact recent-page status and counts; the remaining cause may be absent HTML links or a site/network response rather than this filter.

Source archives and saved-data formats are preserved. No private sessions, learned profiles, caches, compiled application, paid verification or public SMTP probes are included.
