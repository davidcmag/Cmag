# Broader feedback learning — 0.12.28

## Behavior

Person and General inbox corrections now teach recurring phrases from the published text next to an address, in addition to the existing exact-address, shared-handle and organization-specific person-format learner. The local model rebuilds when explicit feedback changes and applies to existing unresolved rows and new live batches. There is no paid service, network AI, SMTP probing or automatic training on predictions. The bundled experimental logistic model remains a separate opt-in preview; this release does not retrain its weights.

A new Learning → Teach useful examples review presents up to 20 unresolved included addresses. Conflicting feedback is prioritized, followed by wording with partial learning support, unfamiliar published wording and unresolved address patterns. Addresses are deduplicated, direct decisions and existing exact feedback are omitted, and a first pass limits each domain to two examples before filling extra slots. This is a review-priority heuristic, not a measured information-gain guarantee. Each example shows the stored source excerpt, source URL and reason for review. Person/General save explicit teaching decisions; Keep uncertain preserves an abstention without a class-training label; Skip changes nothing. The review does not remove addresses.

## Separate removal from classification

Ordinary removal now hides an address in its project without asserting that it is a General inbox. The new clearly labelled “Also teach General inbox when removing” option is off by default, using a new preference key rather than inheriting the former default-on not-a-person preference. Group review follows that choice too. Previously saved removal lessons, learning profiles, corrections, removal histories and source archives are preserved. Earlier removal-derived General lessons are not retroactively reinterpreted; Undo/Restore still removes the associated active removal lesson. Use Classify selected or the teaching review for categorical feedback. Clear remains a separate project action; 0.12.27 journal recovery is retained.

## Evidence and transfer requirements

Each corrected address can store optional contextFeatures in its local learning sample; legacy samples decode without that field. Source text is accepted only from successful HTTP 2xx Published evidence containing the exact syntactically valid non-technical address. Excerpts larger than 2,000 bytes, missing addresses and blocks containing another recipient are ignored. Features are adjacent two-word phrases within 120 characters on either side of the address, separated at sentence and email boundaries. Common function words and recognized personal names are excluded. Features contain no email addresses or source URLs. Processing of training context is limited to addresses with explicit class corrections.

A phrase needs at least three distinct corrected mailboxes across at least two email domains, all with the same explicit class. Plus aliases and duplicate addresses/projects do not inflate independent support. Any contrary explicit class blocks that phrase. At least two supported phrases must match a new contact before transfer. A conflicting learned phrase keeps the target Uncertain. Existing direct decisions and exact/address-pattern learning take priority; context transfer only fills a rule-based Uncertain result. Reasons identify the supporting phrases and distinct correction/domain counts. These are reviewable inferences, not independent identity verification.

The profile remains private on this Mac. Automatic/group-inherited labels, ordinary removal and export suppression do not train the context learner. Only captured explicitly approved members of a review group count, retaining the prior protection against self-training. Undo/reset and corrected feedback rebuild the patterns; reset's timestamp floor is respected.

## Validation

360 portable tests pass, including nine new feedback-context/review tests. They cover transfer to new handles/domains, Person and General labels, manual priority, reset-to-automatic, insufficient/dependent support, plus aliases, ordinary versus explicit removal teaching, no self-training, contradictory feedback, undo/reset, invalid/ambiguous publication evidence, profile round-trip and review prioritization/deduplication/exclusions. These are synthetic regression fixtures, not a representative accuracy benchmark.

SwiftUI source syntax and Xcode project references validated on Linux. Native Mac compilation and GUI behavior remain unverified here. No private session, address corpus or learned profile is included in the public source package.

## Mac check

Save/stop the crawl and quit the old app before building. Without Clear, launch 0.12.28 and open Learning → Teach useful examples. Check that Person/General decisions update the list and learned counts. Ordinary removal must still hide every copy without increasing training examples; enabling the explicit General lesson must teach it and Undo must retract it. Three consistent corrections with common valid published wording across two domains should teach new unresolved addresses with at least two matching phrases. Contradictory feedback should withdraw that transfer. Save/reopen and Resume should preserve corrections, learning and removals.

No claim that every ambiguous handle can be classified, that these thresholds are statistically calibrated, or that context inference replaces human feedback.
