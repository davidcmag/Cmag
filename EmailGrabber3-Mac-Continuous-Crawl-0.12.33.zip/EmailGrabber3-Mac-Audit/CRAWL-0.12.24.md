# Runaway queue and stalled-progress repair — 0.12.24

The screenshot shows 849 Included rows, 2,427 saved records, 1,697 scanned pages
and 697,513 pending URLs. Active/pending URLs include people-search directories,
Steam language variants and a staff member's article/analysis pagination. A single
screenshot does not prove a deadlock. Code inspection establishes that the old
engine let these sources expand, copied the entire queue to the UI repeatedly,
retained the original restored queue in memory, and serialized the full checkpoint
after every successful page. Those costs can dominate extraction and make it look
stalled. We did not collect a process stack from the user's Mac, so this is not a
claim that the exact historical pause had only one cause.

## Changes

- Exclude named people-search/data-broker and Steam gaming/community domains from
  contact-discovery seeds, discovery results and automatic links. Host matching
  respects domain boundaries; lookalike domains do not match. Existing saved email
  records from those sites are retained. This is a crawl-scope policy, not a claim
  that every unrelated site can now be recognized.
- Canonicalize known language-selector aliases; keep unknown parameters and profile
  identity parameters. Directory pagination remains distinct. Article pagination
  on an individual profile does not become a separate contact URL.
- In adaptive mode, a profile/about ancestor no longer gives high contact priority
  to article, analysis and archive sections. Explicitly selected article URLs can
  still be fetched; explicit non-adaptive link depths retain their broader scope.
- Clean restored queues of trap URLs, duplicate canonical URLs, already visited
  URLs and automatically reached negative-priority archive pages. Rebuild queued
  history from retained pending/visited URLs so removed trap histories do not keep
  checkpoint payloads huge. Release the pre-cleanup engine state after handing off
  its working frontier.
- Display only the first 2,000 pending URLs while reporting the full pending count.
  This caps presentation, not the saved legitimate frontier. All retained pending
  URLs remain available to resume; no hard queue-size truncation is introduced.
- Small frontiers still save per page. For queues over 5,000, serialize at completed
  page/checkpoint opportunities after ten pages or five elapsed seconds, instead
  of after every page. A long request or extraction can extend wall time. Stop and
  batch completion force a final save. During an uncommitted batch a crash can
  replay a durable ancestor and rediscover children; progress since the last save
  may be replayed. It is not an assertion of zero unsaved work after a crash.
- Emit Saving progress during checkpoint writes. Count records added in the current
  batch and duplicate occurrences skipped separately from the lifetime saved total.
  Repeated appearances of one mailbox count as duplicate occurrences, not distinct
  people. Added-to-saved counts can include excluded rows; Included visibility stays
  separate. The application header now displays the built version.

## Preserving and resuming the old run

Before repairing an older saved queue, copy its on-disk checkpoint to
`crawl-checkpoint-before-queue-repair-<UUID>.json` in the existing private
EmailGrabber3 application-support folder. If archiving fails, stop without cleaning
or overwriting that queue. A policy marker prevents repeated backup copies on
ordinary subsequent resumes. The backup includes the old URLs and original saved
checkpoint content. No saved emails, learning profile, removal history, manual
classification or prior source archive is cleared.

Stop the old crawl and save a session if the UI responds, then quit the old app.
Build/start 0.12.24; verify 0.12.24 in the header. Use Resume saved crawl to restore
and repair the on-Mac checkpoint. Do not Clear results or reset learning. Save session
stores the project, while the separate on-Mac crawl checkpoint stores the queue;
the old checkpoint must remain in place to resume it. Resuming may still take time
to decode/copy an oversized legacy file. This was not measured on the user's Mac.

## Validation

334 portable tests passed, including trap-domain/priority behavior, URL identity
preservation, byte-identical legacy checkpoint backup, retained records/removals/
learning dates/rules, bounded preview with a complete 5,999-URL stop checkpoint,
durable-ancestor replayability and independent new/duplicate counts. All previous
learning, export and persistence tests remain enabled. The activity test now expects
the added Saving progress phases.

A separate synthetic replay used exactly 697,513 pending URLs (697,512 broker URLs
plus one legitimate contact page), five workers, injected responses and isolated
temporary storage. No trap request was sent; the useful page yielded one new record;
the prior record was retained; the legacy backup was byte-identical; the repaired
queue drained. Restore plus repair/crawl took 1.15 seconds on this Linux host,
excluding initial synthetic checkpoint construction. This is not a Mac/UI timing
claim or a replay of the user's actual queue. No real websites, paid verification
or public SMTP were used in these checks.

Native Mac compilation and GUI acceptance remain unverified here. The source ZIP
retains all prior classification and learning changes. It contains no uploaded
session or personal queue data.
