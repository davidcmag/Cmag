import Foundation
import XCTest
@testable import EmailGrabberCore

final class FeedbackContextTests: XCTestCase {
    func row(_ address: String, wording: String = "Investigative reporting correspondent direct contact") -> FoundEmail {
        var value = makeEmailFixture(address)
        value.source = "https://news.example.org/contact"
        value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact address", sourceURL: value.source, httpStatus: 200, excerpt: wording + " " + address)
        return value
    }
    func profile(_ rows: [FoundEmail], category: AddressCategory = .person) -> LearningProfile {
        let corrected = ClassificationEdits.set(rows, selected: Set(rows.map(\.id)), category: category)
        var profile = LearningProfile()
        profile.synchronize(projectID: UUID(), rows: corrected, removal: RemovalState(), review: ReviewState())
        return profile
    }
    var examples: [FoundEmail] { [row("qxva1@one.example.org"), row("zpvb2@two.example.org"), row("wqvc3@one.example.org")] }
    func testExplicitCorrectionsTransferContextToDifferentHandlesAndDomains() throws {
        let learned = profile(examples)
        let model = LocalLearningModel(profile: learned)
        let target = row("vzqd9@other.example.org")
        XCTAssertEqual(AddressClassification.ruleBased(target).category, .uncertain)
        XCTAssertGreaterThanOrEqual(model.contextPatternCount, 2)
        let evidence = try XCTUnwrap(model.evidence(target))
        XCTAssertEqual(evidence.category, .person)
        XCTAssertFalse(evidence.exact)
        XCTAssertTrue(evidence.reason.contains("explicit corrections"))
        XCTAssertEqual(model.applying(to: [target])[0].addressClassification.category, .person)
        XCTAssertNil(model.evidence(row("vzqd9@other.example.org", wording: "A different page without relevant wording")))
    }
    func testGeneralContextAndPersonalCorrectionsRemainSeparate() throws {
        let model = LocalLearningModel(profile: profile(examples, category: .general))
        let target = row("vzqd9@other.example.org")
        XCTAssertEqual(model.evidence(target)?.category, .general)
        let manual = ClassificationEdits.set([target], selected: [target.id], category: .person)[0]
        XCTAssertNil(model.evidence(manual))
        XCTAssertEqual(model.applying(to: [manual])[0].addressClassification.category, .person)
        XCTAssertNil(model.evidence(row("jane.smith@other.example.org")))
        let reset = ClassificationEdits.set([manual], selected: [manual.id], category: nil)[0]
        XCTAssertEqual(model.evidence(reset)?.category, .general)
    }
    func testTooFewOrDependentExamplesAndAutomaticLabelsDoNotTrain() {
        XCTAssertEqual(LocalLearningModel(profile: profile(Array(examples.prefix(2)))).contextPatternCount, 0)
        let oneDomain = [row("qxva1@one.example.org"), row("zpvb2@one.example.org"), row("wqvc3@one.example.org")]
        XCTAssertEqual(LocalLearningModel(profile: profile(oneDomain)).contextPatternCount, 0)
        var repeats = profile([examples[0]])
        let sample = repeats.projects.values.first!
        for _ in 0..<5 { repeats.projects[UUID().uuidString] = sample }
        XCTAssertEqual(LocalLearningModel(profile: repeats).contextPatternCount, 0)
        var automatic = LearningProfile()
        let predicted = examples.map { original -> FoundEmail in
            var result = original; result.learningEvidence = LearningEvidence(category: .person, exact: false, reason: "prediction"); return result
        }
        automatic.synchronize(projectID: UUID(), rows: predicted, removal: RemovalState(), review: ReviewState())
        XCTAssertEqual(automatic.exampleCount, 0)
    }
    func testOrdinaryRemovalTeachesNoClassAndExplicitRemovalDoesNotTeachContext() {
        var removal = RemovalState(); removal.remove(Set(examples.map(\.address)))
        var ordinary = LearningProfile()
        ordinary.synchronize(projectID: UUID(), rows: examples, removal: removal, review: ReviewState())
        XCTAssertEqual(ordinary.exampleCount, 0)
        removal.restoreAll(); removal.remove(Set(examples.map(\.address)), learn: true)
        ordinary.synchronize(projectID: UUID(), rows: examples, removal: removal, review: ReviewState())
        XCTAssertEqual(ordinary.exampleCount, 3)
        XCTAssertEqual(LocalLearningModel(profile: ordinary).contextPatternCount, 0)
    }
    func testContraryFeedbackVetoesAndUndoRemovesPattern() throws {
        let id = UUID()
        let originals = examples
        let corrected = ClassificationEdits.set(originals, selected: Set(originals.map(\.id)), category: .person)
        var learned = LearningProfile()
        learned.synchronize(projectID: id, rows: corrected, removal: RemovalState(), review: ReviewState())
        XCTAssertGreaterThan(LocalLearningModel(profile: learned).contextPatternCount, 0)
        let opposing = row("zwvg8@third.example.org")
        let conflict = ClassificationEdits.set([opposing], selected: [opposing.id], category: .general)
        learned.synchronize(projectID: UUID(), rows: conflict, removal: RemovalState(), review: ReviewState())
        XCTAssertEqual(LocalLearningModel(profile: learned).contextPatternCount, 0)
        learned.synchronize(projectID: id, rows: originals, removal: RemovalState(), review: ReviewState())
        XCTAssertEqual(LocalLearningModel(profile: learned).contextPatternCount, 0)
    }
    func testEvidenceGuardsAndNoAddressLeakage() {
        let target = row("vzqd9@other.example.org")
        XCTAssertFalse(FeedbackContext.features(target).isEmpty)
        XCTAssertTrue(FeedbackContext.features(target).allSatisfy { !$0.contains("vzqd") && !$0.contains("example") && !$0.contains("@") })
        var invalid = target
        invalid.websiteConfirmation?.httpStatus = 403
        XCTAssertTrue(FeedbackContext.features(invalid).isEmpty)
        invalid = target; invalid.websiteConfirmation?.excerpt = "Investigative reporting correspondent direct contact another@elsewhere.org"
        XCTAssertTrue(FeedbackContext.features(invalid).isEmpty)
        invalid = target; invalid.websiteConfirmation?.excerpt = "Investigative reporting correspondent direct contact " + target.address + " second@elsewhere.org"
        XCTAssertTrue(FeedbackContext.features(invalid).isEmpty)
        invalid = target; invalid.websiteConfirmation?.excerpt = String(repeating: "x", count: 2001) + target.address
        XCTAssertTrue(FeedbackContext.features(invalid).isEmpty)
    }
    func testReviewListPrioritizesConflictsAndOmitsDuplicatesRemovedAndDecided() throws {
        var learned = profile(examples)
        let opposing = row("zwvg8@third.example.org")
        let conflict = ClassificationEdits.set([opposing], selected: [opposing.id], category: .general)
        learned.synchronize(projectID: UUID(), rows: conflict, removal: RemovalState(), review: ReviewState())
        let model = LocalLearningModel(profile: learned)
        let target = row("vzqd9@other.example.org")
        let other = row("anew1@elsewhere.example.org", wording: "Unfamiliar unusual text")
        let removed = row("gone1@different.example.org")
        let manual = row("saved1@different.example.org")
        let decided = ClassificationEdits.set([manual], selected: [manual.id], category: .uncertain)[0]
        let review = model.reviewCandidates([other, target, target, removed, decided], rules: [], removed: [removed.address])
        XCTAssertEqual(review.count, 2)
        XCTAssertEqual(review.first?.row.address, target.address)
        XCTAssertTrue(review.first?.reason.contains("disagrees") == true)
        XCTAssertEqual(model.reviewCandidates([target], rules: [], removed: [], limit: 0).count, 0)
        XCTAssertEqual(model.reviewCandidates([target], rules: [SmartRule(kind: "Address", pattern: target.address)], removed: []).count, 0)
    }
    func testPlusAliasesCannotInflateContextSupport() {
        let aliases = [row("qxva1@one.example.org"), row("qxva1+tag@one.example.org"), row("zpvb2@two.example.org")]
        XCTAssertEqual(LocalLearningModel(profile: profile(aliases)).contextPatternCount, 0)
    }
    func testContextSurvivesProfileRoundTripAndReset() throws {
        var learned = profile(examples)
        let restored = try JSONDecoder().decode(LearningProfile.self, from: JSONEncoder().encode(learned))
        XCTAssertEqual(restored, learned)
        XCTAssertEqual(LocalLearningModel(profile: restored).evidence(row("vzqd9@other.example.org"))?.category, .person)
        learned.resetAt = Date().addingTimeInterval(1)
        XCTAssertEqual(LocalLearningModel(profile: learned).contextPatternCount, 0)
    }
}
