import XCTest
import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
@testable import EmailGrabberCore

final class VerificationAndDiscoveryTests: DiskTests {
    func testUniversityDirectoryReachesNamedProfilesAndKeepsSharedInboxGeneral() throws {
        let pages = [
            "/robots.txt": "User-agent: *",
            "/": "info@campus.edu <a href='/academics'>Academics</a>",
            "/academics": "<a href='/faculty-staff'>Faculty and Staff</a>",
            "/faculty-staff": "<a href='/bio/123'>Jane Smith</a>",
            "/bio/123": "<a href='mailto:jkb1099@campus.edu'>Jane Smith</a>"
        ]
        var fetched: [String] = []
        let engine = GrabEngine(settings: settings(), fetcher: { url in
            fetched.append(url.path)
            return HTTPResult(data: Data((pages[url.path] ?? "").utf8), status: 200, finalURL: url, mimeType: "text/html")
        }, sleep: { _ in })
        let rows = engine.run(mode: .website, terms: ["https://campus.edu/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertTrue(fetched.contains("/bio/123"))
        XCTAssertEqual(try XCTUnwrap(rows.first { $0.address == "jkb1099@campus.edu" }).addressClassification.category, .person)
        XCTAssertEqual(try XCTUnwrap(rows.first { $0.address == "info@campus.edu" }).addressClassification.category, .general)
        XCTAssertFalse(engine.hasRemainingPages)
    }
    func testAcademicDiscoverySearchesPeopleForEveryInputBeforeGeography() {
        let queries = AdditionalSearchDiscovery.peopleQueries(["universities", "colleges", "schools"])
        XCTAssertEqual(Array(queries.prefix(3)), ["universities faculty staff directory email", "colleges faculty staff directory email", "schools faculty staff directory email"])
        XCTAssertTrue(queries.prefix(12).contains("schools staff contact"))
    }
    func testLaterStaffDirectoryReplacesHomepageAndOutranksRankingSite() {
        var request = 0
        let engine = GrabEngine(settings: settings(), fetcher: { url in response("", url, status: 429) }, sleep: { _ in }, search: { _, _ in
            request += 1
            let urls = request == 1 ? ["https://rankings.org/best-colleges", "https://campus.edu/"] : ["https://campus.edu/staff-directory"]
            return AdditionalSearchDiscovery.SearchResult(urls: urls.map { URL(string: $0)! }, status: 200)
        })
        let sites = engine.discoverSites(terms: ["colleges"], exploreDirectories: false, nationwide: false, shouldStop: { false }, progress: { _ in })
        XCTAssertEqual(sites.first?.url, "https://campus.edu/staff-directory")
        XCTAssertEqual(sites.filter { $0.host == "campus.edu" }.count, 1)
    }
    func testAcademicAndCombinedFacultyStaffLinksAreFollowable() {
        for path in ["/faculty-staff", "/academics", "/departments/chemistry", "/academic-schools"] {
            XCTAssertGreaterThan(LinkRelevance.priority(CrawlLink(url: URL(string: "https://campus.edu" + path)!, label: "", nofollow: false)), 0, path)
        }
        XCTAssertLessThan(LinkRelevance.priority(CrawlLink(url: URL(string: "https://campus.edu/faculty/events")!, label: "Faculty events", nofollow: false)), 0)
    }
    func testProviderHTTPFailureCannotLabelMailboxVerified() {
        let answer = AdvancedVerifier.validate(email: "a@public.org", apiKey: "fixture", perform: { request in
            XCTAssertEqual(request.url?.scheme, "https")
            return response("{\"status\":\"valid\"}", request.url!, status: 503)
        })
        XCTAssertEqual(answer.status, "Uncertain")
    }
    func testProviderCatchAllRemainsUncertain() {
        let answer = AdvancedVerifier.validate(email: "a@public.org", apiKey: "fixture", perform: { request in response("{\"status\":\"catch-all\"}", request.url!) })
        XCTAssertEqual(answer.status, "Uncertain")
    }
    func testProviderEncodesKeyAndPlusAddressInPOSTBodyOnly() {
        _ = AdvancedVerifier.validate(email: "name+tag@public.org", apiKey: "fixture+key", perform: { request in
            XCTAssertEqual(request.httpMethod, "POST")
            XCTAssertFalse(request.url!.absoluteString.contains("fixture"))
            let body = String(data: request.httpBody!, encoding: .utf8)!
            let fields = Dictionary(uniqueKeysWithValues: body.split(separator: "&").map { part -> (String,String) in
                let bits = part.split(separator: "=", maxSplits: 1, omittingEmptySubsequences: false)
                return (String(bits[0]), String(bits[1]).removingPercentEncoding!)
            })
            XCTAssertEqual(fields["email"], "name+tag@public.org"); XCTAssertEqual(fields["api_key"], "fixture+key")
            XCTAssertTrue(body.contains("%2B"))
            return response("{\"status\":\"valid\"}", request.url!)
        })
    }
    func testProviderMissingStatusIsUncertain() {
        XCTAssertEqual(AdvancedVerifier.validate(email: "a@public.org", apiKey: "fixture", perform: { request in response("{}", request.url!) }).status, "Uncertain")
    }
    func testRateLimitsStopEachProviderWithoutHammeringQueries() {
        var rssRequests = 0; var independentRequests = 0
        let engine = GrabEngine(settings: settings(), fetcher: { url in rssRequests += 1; return response("", url, status: 429) }, sleep: { _ in }, search: { _, _ in independentRequests += 1; return AdditionalSearchDiscovery.SearchResult(urls: [], status: 429) })
        let results = engine.discoverSites(terms: ["podcast hosts"], exploreDirectories: false, nationwide: true, shouldStop: { false }, progress: { _ in })
        XCTAssertTrue(results.isEmpty); XCTAssertEqual(rssRequests, 1); XCTAssertEqual(independentRequests, 1)
        XCTAssertTrue(engine.discoveryWarning?.contains("429") == true)
    }
    func testOneBlockedSearchProviderStillAllowsOtherResults() {
        let engine = GrabEngine(settings: settings(), fetcher: { url in response("<rss><channel><item><link>https://public.org/contact</link></item></channel></rss>", url) }, sleep: { _ in }, search: { _, _ in AdditionalSearchDiscovery.SearchResult(urls: [], status: 403) })
        let results = engine.discoverSites(terms: ["astronomy"], exploreDirectories: false, nationwide: false, shouldStop: { false }, progress: { _ in })
        XCTAssertEqual(results.map(\.url), ["https://public.org/contact"])
    }
    func testSearchPlusSignsAreFormSafe() {
        XCTAssertTrue(EmailPolicy.searchURL("C++ contacts")!.absoluteString.contains("%2B%2B"))
    }
}

final class InputSafetyTests: DiskTests {
    func testPastedInputCannotReplacePendingCrawlDuringContinuation() {
        let engine = GrabEngine(settings: settings(pages: 1), fetcher: { url in response(url.path == "/robots.txt" ? "User-agent: *" : "first@public.org <a href='/contact'>Contact</a>", url) }, sleep: { _ in })
        let first = engine.run(mode: .website, terms: ["https://public.org"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertTrue(engine.hasRemainingPages)
        let result = engine.run(mode: .pasted, terms: ["unrelated@public.org"], existing: first, liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(result.map(\.address), first.map(\.address)); XCTAssertTrue(engine.hasRemainingPages); XCTAssertNotNil(engine.lastFailure)
    }
    func testInvalidAddressIsNotTransmittedToPaidProvider() {
        var called = false
        let answer = AdvancedVerifier.validate(email: "bad..name@public.org", apiKey: "fixture", perform: { request in called = true; return response("{}", request.url!) })
        XCTAssertFalse(called); XCTAssertEqual(answer.status, "Uncertain")
    }
    func testNewerProjectFormatIsPreservedRatherThanLoadedAndDowngraded() throws {
        var value = GrabSession(mode: .website, input: "", excluded: "", depth: 0, maxPages: 0, stripDuplicates: true, excludeRole: false, excludeFree: false, excludeDisposable: false, checkDNS: false, rows: []); value.version = 99
        XCTAssertTrue(CrawlDisk.saveProject(value))
        let original = try Data(contentsOf: CrawlDisk.projectURL)
        XCTAssertNil(CrawlDisk.loadProject())
        XCTAssertEqual(try Data(contentsOf: CrawlDisk.projectURL), original)
    }
}

final class VerificationSafetyTests: XCTestCase {
    func testConflictingCatchAllSubstatusIsNotVerified() {
        XCTAssertEqual(ProviderClassification.result(status: "valid", substatus: "role_based_catch_all").0, "Uncertain")
    }
    func testRateLimitStopsRemainingPaidProviderBatch() {
        let answer = AdvancedVerifier.validate(email: "a@public.org", apiKey: "fixture", perform: { request in response("{}", request.url!, status: 429) })
        XCTAssertEqual(answer.status, "Uncertain"); XCTAssertTrue(answer.stopBatch)
    }
}
