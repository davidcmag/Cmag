import XCTest
import Foundation
@testable import EmailGrabberCore

final class ResourceAndRelevanceTests: DiskTests {
    func testGeneralDirectoryBridgePersistsOpaqueProfilesAcrossResume() throws {
        for category in ["manufacturers", "charities", "members"] {
            for workers in [1, 5] {
                var options = settings(pages: 1); options.followExternalLinks = true
                options.topic = category; options.concurrentSites = workers
                let index = "https://guide.org/" + category
                let profiles = (1...3).map { "https://guide.org/view?id=\($0)" }
                var requested = Set<String>()
                let fetch: (URL) -> HTTPResult = { url in
                    if url.path == "/robots.txt" { return response("User-agent: *", url) }
                    requested.insert(url.absoluteString)
                    let html: String
                    if url.absoluteString == index {
                        html = (1...3).map { "<a href='/view?id=\($0)'>Northstar Group \($0)</a>" }.joined()
                    } else if let number = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.first?.value {
                        html = "<a href='https://entity\(number).org/'>Website</a><a href='https://design.org/'>Website by designer</a>"
                    } else { html = "jane@\(url.host!)" }
                    return HTTPResult(data: Data(html.utf8), status: 200, finalURL: url, mimeType: "text/html")
                }
                let initial = GrabEngine(settings: options, fetcher: fetch, sleep: { _ in })
                var rows = initial.run(mode: .website, terms: [index], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
                var saved = try XCTUnwrap(CrawlDisk.load())
                XCTAssertEqual(saved.directoryProfiles, Set(profiles))
                // Fresh engine on each batch exercises persisted context, not
                // an in-memory shortcut. Topic evidence stays with entries.
                for _ in 0..<8 where !saved.queue.isEmpty {
                    let resumed = GrabEngine(settings: options, fetcher: fetch, sleep: { _ in })
                    resumed.restore(saved)
                    rows = resumed.run(mode: .website, terms: [index], existing: rows, liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
                    saved = try XCTUnwrap(CrawlDisk.load())
                }
                XCTAssertTrue(saved.queue.isEmpty)
                XCTAssertEqual(rows.count, 3, category)
                XCTAssertTrue((1...3).allSatisfy { requested.contains("https://entity\($0).org/") })
                XCTAssertFalse(requested.contains("https://design.org/"))
            }
        }
    }
    func testGeneralDirectoryInferenceRequiresCoherentLinksAndRejectsFooterControls() {
        let source = URL(string: "https://guide.org/explore")!
        let entries = (1...3).map { CrawlLink(url: URL(string: "https://guide.org/x/\($0)")!, label: "Northstar Group \($0)", nofollow: false) }
        XCTAssertEqual(LinkRelevance.directoryEntries(entries, from: source), Set(entries.map { $0.url.absoluteString }))
        XCTAssertTrue(LinkRelevance.directoryEntries(Array(entries.prefix(2)), from: source).isEmpty)
        let footer = [CrawlLink(url: URL(string: "https://guide.org/privacy/policy")!, label: "Privacy policy", nofollow: false), CrawlLink(url: URL(string: "https://guide.org/subscribe")!, label: "Subscribe", nofollow: false)]
        XCTAssertTrue(LinkRelevance.directoryEntries(footer, from: URL(string: "https://guide.org/directory")!).isEmpty)
        let unknown = CrawlLink(url: URL(string: "https://outside.org/")!, label: "Website", nofollow: false)
        XCTAssertFalse(LinkRelevance.relevant(unknown, from: source, topic: ""))
        XCTAssertTrue(LinkRelevance.relevant(unknown, from: source, topic: "", directoryProfile: true))
    }
    func testOlderCheckpointWithoutDirectoryContextStillDecodes() throws {
        let engine = GrabEngine(settings: settings(pages: 1), fetcher: { url in response(url.path == "/robots.txt" ? "User-agent: *" : "hello", url) }, sleep: { _ in })
        _ = engine.run(mode: .website, terms: ["https://guide.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        let saved = try XCTUnwrap(CrawlDisk.load())
        var object = try JSONSerialization.jsonObject(with: JSONEncoder().encode(saved)) as! [String: Any]
        object.removeValue(forKey: "directoryProfiles")
        let legacy = try JSONDecoder().decode(CrawlProgress.self, from: JSONSerialization.data(withJSONObject: object))
        XCTAssertNil(legacy.directoryProfiles)
        XCTAssertEqual(legacy.scanned, saved.scanned)
    }
    func testAdaptiveTraversesInstitutionDirectoryToOfficialWebsiteAndPerson() throws {
        for workers in [1, 5] {
            for topic in ["", "universities"] {
                var options = settings(); options.followExternalLinks = true
                options.concurrentSites = workers; options.topic = topic
                let pages = [
                    "https://guide.org/colleges": "<a href='/browse/colleges'>Browse colleges</a>",
                    "https://guide.org/browse/colleges": "<a href='/college/alpha'>Alpha University</a>",
                    "https://guide.org/college/alpha": "<a href='https://alpha.edu/'>Visit website</a><a href='https://ads.org/' rel='sponsored'>Website</a><a href='https://design.org/'>Website by Design</a>",
                    "https://alpha.edu/": "<a href='/staff'>Staff</a>",
                    "https://alpha.edu/staff": "<a href='mailto:jdoe109@alpha.edu'>Jane Smith</a>"
                ]
                var fetched: [String] = []
                var events: [CrawlActivity] = []
                let engine = GrabEngine(settings: options, fetcher: { url in
                    if url.path == "/robots.txt" { return response("User-agent: *", url) }
                    fetched.append(url.absoluteString)
                    return HTTPResult(data: Data((pages[url.absoluteString] ?? "").utf8), status: 200, finalURL: url, mimeType: "text/html")
                }, sleep: { _ in })
                let rows = engine.run(mode: .website, terms: ["https://guide.org/colleges"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false }, activity: { events.append($0) })
                XCTAssertEqual(Set(fetched), Set(pages.keys))
                XCTAssertEqual(try XCTUnwrap(rows.first { $0.address == "jdoe109@alpha.edu" }).addressClassification.category, .person)
                XCTAssertFalse(engine.hasRemainingPages)
                XCTAssertTrue(events.contains { $0.url == "https://guide.org/college/alpha" && $0.phase == "Completed" && $0.message.contains("3 links considered; 1 new pages queued") })
            }
        }
    }
    func testInstitutionWebsiteBridgeRequiresContextAndHonorsTopicAndExclusions() {
        let profile = URL(string: "https://guide.org/colleges/alpha")!
        let official = CrawlLink(url: URL(string: "https://alpha.edu/")!, label: "College website", nofollow: false)
        XCTAssertTrue(LinkRelevance.relevant(official, from: profile, topic: "colleges"))
        XCTAssertTrue(LinkRelevance.relevant(official, from: profile, topic: "universities", directoryProfile: true))
        XCTAssertFalse(LinkRelevance.relevant(official, from: profile, topic: "government"))
        XCTAssertFalse(LinkRelevance.relevant(CrawlLink(url: official.url, label: "Website", nofollow: false), from: URL(string: "https://guide.org/news")!, topic: ""))
        for (raw, label, nofollow) in [("https://alpha.edu/", "Website", true), ("https://facebook.com/alpha", "Website", false), ("https://design.org/", "Website by our designer", false), ("https://spokeo.com/", "Website", false)] {
            XCTAssertFalse(LinkRelevance.relevant(CrawlLink(url: URL(string: raw)!, label: label, nofollow: nofollow), from: profile, topic: ""))
        }
        XCTAssertLessThan(LinkRelevance.priority(CrawlLink(url: URL(string: "https://guide.org/news/colleges")!, label: "Alpha University", nofollow: false), from: profile), 0)
    }
    func testAdaptiveDoesNotLeaveDirectoryWhenExternalLinksAreDisabled() {
        var options = settings(); options.followExternalLinks = false
        var externalFetched = false
        let engine = GrabEngine(settings: options, fetcher: { url in
            if url.path == "/robots.txt" { return response("User-agent: *", url) }
            if url.host == "alpha.edu" { externalFetched = true }
            return response("<a href='https://alpha.edu/'>Visit website</a>", url)
        }, sleep: { _ in })
        _ = engine.run(mode: .website, terms: ["https://guide.org/colleges/alpha"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertFalse(externalFetched)
    }
    func testCrawlerTrapDomainsAndProfileArchivePriorities() {
        let source = URL(string: "https://public.org/directory")!
        for address in ["https://www.addresses.com/people/0-295/", "https://spokeo.com/people/B0183", "https://whitepages.com/directory/name/a/aadya", "https://steamcommunity.com/profiles/123?l=hungarian"] {
            let url = URL(string: address)!
            XCTAssertNotNil(LinkRelevance.crawlTrapReason(url))
            XCTAssertFalse(LinkRelevance.relevant(CrawlLink(url: url, label: "Podcast people directory", nofollow: false), from: source, topic: "podcast"))
        }
        XCTAssertNil(LinkRelevance.crawlTrapReason(URL(string: "https://addresses.com.example.org/people")!))
        XCTAssertLessThan(LinkRelevance.priority(CrawlLink(url: URL(string: "https://public.org/about/staff/jessica/analysis?page=3")!, label: "Analysis", nofollow: false)), 0)
        XCTAssertGreaterThan(LinkRelevance.priority(CrawlLink(url: URL(string: "https://public.org/people/ava-white")!, label: "Ava White", nofollow: false)), 0)
    }
    func testLanguageAndProfilePaginationCanonicalizationPreservesIdentity() {
        func canonical(_ raw: String) -> String { LinkRelevance.canonical(URL(string: raw)!)!.absoluteString }
        XCTAssertEqual(canonical("https://public.org/people/ava?l=hungarian&id=7&page=3"), "https://public.org/people/ava?id=7")
        XCTAssertEqual(canonical("https://public.org/people/ava?lang=en-US&id=8"), "https://public.org/people/ava?id=8")
        XCTAssertEqual(canonical("https://public.org/people?page=3&id=7"), "https://public.org/people?page=3&id=7", "Keep directory pagination")
        XCTAssertEqual(canonical("https://public.org/search?l=7&page=3"), "https://public.org/search?l=7&page=3", "Do not strip unknown identity parameters")
    }
    func testRestoredLegacyQueueIsArchivedCleanedAndKeepsRecordsAndHistory() throws {
        let existing = makeEmailFixture("saved@public.org")
        let removal = RemovalState(addresses: [existing.address], history: [[existing.address]], learningDates: [existing.address: Date()])
        let rules = [SmartRule(kind: "Address", pattern: "hidden@public.org")]
        CrawlDisk.updatePresentation(rules: rules, removal: removal)
        var snapshot = CrawlProgress(queue: [
            .init(url: "https://www.addresses.com/people/0-295/", level: 1, host: "addresses.com"),
            .init(url: "https://steamcommunity.com/profiles/123?l=italian", level: 1, host: "steamcommunity.com"),
            .init(url: "https://public.org/about/staff/jessica/analysis?page=3", level: 1, host: "public.org"),
            .init(url: "https://public.org/people/ava?lang=de", level: 1, host: "public.org"),
            .init(url: "https://public.org/people/ava?lang=en", level: 1, host: "public.org")
        ], visited: [], queued: [], robotRules: [:], domainPageCount: [:], discoveredCount: 3, scanned: 0, rows: [existing], selectedSites: ["https://public.org"], settings: CrawlOptions(depth: 0, maxPages: 1, maxPagesPerDomain: 0, excluded: "", stripDuplicates: true, excludeRole: false, excludeFree: false, excludeDisposable: false, checkDNS: false), input: "https://public.org")
        snapshot.queued = Set(snapshot.queue.map(\.url)); snapshot.frontierPolicyVersion = nil
        XCTAssertTrue(CrawlDisk.save(snapshot))
        let originalData = try Data(contentsOf: CrawlDisk.fileURL)
        var requested = [String]()
        let engine = GrabEngine(settings: settings(pages: 1), fetcher: { url in
            requested.append(url.absoluteString)
            return response(url.path == "/robots.txt" ? "User-agent: *" : "new@public.org", url)
        }, sleep: { _ in })
        engine.restore(try XCTUnwrap(CrawlDisk.load()))
        let rows = engine.run(mode: .website, terms: ["https://public.org"], existing: [existing], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(Set(rows.map(\.address)), [existing.address, "new@public.org"])
        XCTAssertTrue(requested.allSatisfy { $0.hasPrefix("https://public.org/") })
        let repaired = try XCTUnwrap(CrawlDisk.load())
        XCTAssertTrue(repaired.queue.isEmpty)
        XCTAssertEqual(repaired.frontierPolicyVersion, 1)
        XCTAssertEqual(repaired.removedAddresses, removal.addresses)
        XCTAssertEqual(repaired.removalHistory, removal.history)
        XCTAssertEqual(repaired.removalLearningDates, removal.learningDates)
        XCTAssertEqual(repaired.smartRules, rules)
        let backups = try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil).filter { $0.lastPathComponent.hasPrefix("crawl-checkpoint-before-queue-repair-") }
        XCTAssertEqual(backups.count, 1)
        XCTAssertEqual(try Data(contentsOf: XCTUnwrap(backups.first)), originalData)
    }
    func testLargeQueuePreviewIsBoundedWhileStopSavesEntireFrontier() throws {
        var options = settings(); options.followExternalLinks = true
        var stop = false, durableAncestorSeen = false
        let count = 6000
        let html = (0..<count).map { "<a href='/contact/\($0)'>Contact</a>" }.joined()
        let initialWrites = CrawlDisk.checkpointWriteCount
        var activities = [CrawlActivity]()
        let engine = GrabEngine(settings: options, fetcher: { url in
            if url.path == "/robots.txt" { return response("User-agent: *", url) }
            if url.path == "/" { return response(html, url) }
            durableAncestorSeen = CrawlDisk.load()?.queue.contains { $0.url == "https://public.org/" } == true
            return response("person@public.org", url)
        }, sleep: { _ in }, checkpointClock: { Date(timeIntervalSince1970: 100) })
        let rows = engine.run(mode: .website, terms: ["https://public.org/"], existing: [], liveRows: { _ in stop = true }, update: { _,_,_,_ in }, shouldStop: { stop }, activity: { activities.append($0) })
        XCTAssertTrue(durableAncestorSeen, "Uncommitted new links must have a durable replayable ancestor")
        XCTAssertEqual(rows.map(\.address), ["person@public.org"])
        XCTAssertEqual(CrawlDisk.checkpointWriteCount - initialWrites, 2, "Initial recovery point and forced stop commit; no per-page full-queue save")
        let saved = try XCTUnwrap(CrawlDisk.load())
        XCTAssertEqual(saved.queue.count, count, "Stop during extraction preserves the current uncommitted page too")
        XCTAssertFalse(saved.visited.contains("https://public.org/contact/0"))
        XCTAssertEqual(saved.scanned, 1)
        XCTAssertEqual(saved.rows.map(\.address), rows.map(\.address))
        XCTAssertEqual(activities.last?.pending, count)
        XCTAssertEqual(activities.last?.queuedPages?.count, LinkRelevance.queuePreviewLimit)
        XCTAssertTrue(activities.allSatisfy { ($0.queuedPages?.count ?? 0) <= LinkRelevance.queuePreviewLimit })
        XCTAssertTrue(activities.contains { $0.phase == "Saving progress" })
    }
    func testNewAndDuplicateCountsAreSeparateFromSavedTotal() {
        let old = makeEmailFixture("old@public.org")
        let engine = GrabEngine(settings: settings())
        let rows = engine.run(mode: .pasted, terms: ["old@public.org old@public.org new@public.org"], existing: [old], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(rows.count, 2)
        XCTAssertEqual(engine.newAddressCount, 1)
        XCTAssertEqual(engine.duplicateSkippedCount, 2)
    }
    func testUnchangedProgressDoesNotRefilter3572ResultsAgainst12Rules() {
        let rows = (0..<3572).map { makeEmailFixture("person\($0)@public.org") }
        let rules = (0..<12).map { SmartRule(kind: "Prefix", pattern: "excluded\($0)@") }
        let cache = ResultsFilterCache()
        func refresh(_ input: [FoundEmail]) -> [FoundEmail] {
            cache.update(input, rules: rules, removed: [], status: "Included", search: "", scope: "Email", sort: [])
        }
        XCTAssertEqual(refresh(rows).count, 3572)
        for _ in 0..<100 { XCTAssertEqual(refresh(rows).count, 3572) }
        XCTAssertEqual(cache.evaluatedRows, 3572)
        let appended = rows + [makeEmailFixture("new@public.org")]
        XCTAssertEqual(refresh(appended).map(\.id), appended.map(\.id))
        XCTAssertEqual(cache.evaluatedRows, 3573)
    }
    func testCacheInvalidatesForRulesRemovalFieldScopeAndEditedRecords() {
        let rows = ["info@public.org","jane@public.org","person@other.org"].map(makeEmailFixture)
        let cache = ResultsFilterCache()
        let changes: [([SmartRule], Set<String>, String, String, String)] = [
            ([], [], "Included", "", "Email"),
            ([SmartRule(kind: "Wildcard", pattern: "info@*")], [], "Included", "", "Email"),
            ([], ["jane@public.org"], "Included", "", "Email"),
            ([], [], "Included", "fixture", "Source"),
            ([], [], "Included", "fixture", "Email"),
            ([], [], "All", "*@public.org", "Email")
        ]
        for (rules,removed,status,search,scope) in changes {
            let actual = cache.update(rows, rules: rules, removed: removed, status: status, search: search, scope: scope, sort: [])
            let expected = ResultPolicy.filtered(rows, rules: rules, removed: removed, status: status, search: search, scope: scope)
            XCTAssertEqual(actual, expected)
        }
        var edited = rows; edited[0].status = "Rejected"
        XCTAssertEqual(cache.update(edited, rules: [], removed: [], status: "Included", search: "", scope: "Email", sort: []).count, 2)
        XCTAssertEqual(cache.update([], rules: [], removed: [], status: "Included", search: "", scope: "Email", sort: []).count, 0)
    }
    func testChangingSortDoesNotRepeatFilteringOrLoseFoundSequence() {
        let rows = ["z@public.org","a@public.org"].map(makeEmailFixture)
        let cache = ResultsFilterCache()
        func refresh(_ order: [KeyPathComparator<FoundEmail>]) -> [FoundEmail] {
            cache.update(rows, rules: [], removed: [], status: "Included", search: "", scope: "Email", sort: order)
        }
        XCTAssertEqual(refresh([]).map(\.id), rows.map(\.id))
        XCTAssertEqual(refresh(ResultOrdering.comparators("Email A–Z")!).first?.address, "a@public.org")
        XCTAssertEqual(cache.evaluatedRows, 2)
        XCTAssertEqual(refresh([]).map(\.id), rows.map(\.id))
    }
    func testDisplayBatchRetainsRowsAndOnlyLatestQueueAndCounters() {
        let buffer = CrawlDisplayBuffer()
        let rows = (0..<70).map { makeEmailFixture("person\($0)@public.org") }
        buffer.append(Array(rows.prefix(25))); buffer.append(Array(rows.dropFirst(25)))
        for n in 0..<20 {
            buffer.report(CrawlCounters(pages: n, discovered: n, scannedSites: n, message: "\(n)"))
            buffer.report(CrawlActivity(url: "", phase: "Queue", pending: n, message: "", queuedPages: ["https://public.org/\(n)"]))
        }
        let batch = buffer.drain()
        XCTAssertEqual(batch.rows.map(\.id), rows.map(\.id))
        XCTAssertEqual(batch.counters?.pages, 19)
        XCTAssertEqual(batch.queue?.queuedPages, ["https://public.org/19"])
        XCTAssertTrue(buffer.drain().isEmpty)
    }
    func testDisplayHistoryIsBoundedButPendingPageListIsNotCapped() {
        let buffer = CrawlDisplayBuffer()
        for n in 0..<150 { buffer.report(CrawlActivity(url: "https://public.org/\(n)", phase: "Completed", pending: 0, message: "")) }
        let pending = (0..<1922).map { "https://public.org/contact/\($0)" }
        buffer.report(CrawlActivity(url: "", phase: "Queue", pending: pending.count, message: "", queuedPages: pending))
        buffer.report(CrawlActivity(url: "", phase: "Idle", pending: pending.count, message: "Saved", activeSites: [], queuedPages: pending))
        let batch = buffer.drain()
        XCTAssertEqual(batch.recent.count, 100)
        XCTAssertEqual(batch.recent.first?.url, "https://public.org/50")
        XCTAssertEqual(batch.queue?.queuedPages?.count, 1922)
        XCTAssertEqual(batch.current?.phase, "Idle")
    }
    func testConcurrentDisplayProducersDoNotLoseRows() {
        let buffer = CrawlDisplayBuffer(), group = DispatchGroup()
        for n in 0..<50 {
            group.enter()
            DispatchQueue.global().async { buffer.append([makeEmailFixture("person\(n)@public.org")]); group.leave() }
        }
        group.wait()
        let batch = buffer.drain()
        XCTAssertEqual(Set(batch.rows.map(\.address)).count, 50)
        XCTAssertTrue(buffer.drain().isEmpty)
    }
    func testEveryPageRemainsCheckpointedWithoutDuplicateSuccessWrites() {
        let initialWrites = CrawlDisk.checkpointWriteCount
        let engine = GrabEngine(settings: settings(), fetcher: { url in
            if url.path == "/robots.txt" { return response("User-agent: *", url) }
            if url.path == "/contact" {
                XCTAssertEqual(CrawlDisk.load()?.scanned, 1)
                XCTAssertTrue(CrawlDisk.load()?.queue.contains { $0.url == url.absoluteString } ?? false)
            }
            return response(url.path == "/" ? "<a href='/contact'>Contact</a>" : "person@public.org", url)
        }, sleep: { _ in })
        _ = engine.run(mode: .website, terms: ["https://public.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(CrawlDisk.checkpointWriteCount - initialWrites, 3)
        XCTAssertEqual(CrawlDisk.load()?.scanned, 2)
        XCTAssertTrue(CrawlDisk.load()?.queue.isEmpty ?? false)
    }
    func testRemovingOverBudgetPagesPersistsTheEmptyFrontier() {
        var options = settings(perSite: 1); options.concurrentSites = 5
        let engine = GrabEngine(settings: options, fetcher: { url in
            response(url.path == "/robots.txt" ? "User-agent: *" : "<a href='/contact'>Contact</a>", url)
        }, sleep: { _ in })
        _ = engine.run(mode: .website, terms: ["https://public.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertTrue(CrawlDisk.load()?.queue.isEmpty ?? false)
    }
    func testGenericHostWordCannotCarryPodcastCrawlToUnrelatedSites() {
        let source = URL(string: "https://podcasts.public.org/")!
        let sports = CrawlLink(url: URL(string: "https://sports.org/college-football/arizona-preseason-poll")!, label: "Arizona hosts preseason event", nofollow: false)
        let hosting = CrawlLink(url: URL(string: "https://hosting.org/")!, label: "Website hosts", nofollow: false)
        XCTAssertFalse(LinkRelevance.relevant(sports, from: source, topic: "podcast hosts"))
        XCTAssertFalse(LinkRelevance.relevant(hosting, from: source, topic: "podcast hosts"))
        XCTAssertTrue(LinkRelevance.relevant(CrawlLink(url: URL(string: "https://other.org/")!, label: "Podcast hosts", nofollow: false), from: source, topic: "podcast hosts"))
        XCTAssertFalse(LinkRelevance.topicWords("hosts").isEmpty)
    }
    func testAdaptiveContactScoringDoesNotTreatArticleProseAsAStaffPage() {
        for (path,label) in [("/college-football/arizona-preseason-poll","Arizona hosts preseason event"),("/news/all-about-shoes","All about shoes"),("/news/stafford-interview","Stafford interview")] {
            XCTAssertLessThanOrEqual(LinkRelevance.priority(CrawlLink(url: URL(string: "https://public.org" + path)!, label: label, nofollow: false)), 0)
        }
        for (path,label) in [("/contact-us","Contact us"),("/people/renee-parks","Renee Parks"),("/hosts/jane","Jane"),("/page?id=6","Meet the hosts"),("/ContactUs.jsp","Contact"),("/staff_directory.html","Directory")] {
            XCTAssertGreaterThan(LinkRelevance.priority(CrawlLink(url: URL(string: "https://public.org" + path)!, label: label, nofollow: false)), 0)
        }
    }
    func testDecodedLabelsAndResponsibleLinkHandlingArePreserved() {
        let links = LinkRelevance.links("<a href='/contact'><b>Contact</b> &amp; sales</a><a href='/staff' rel='nofollow'>Staff</a>", base: URL(string: "https://public.org/")!)
        XCTAssertTrue(links.first?.label.contains("Contact") ?? false)
        XCTAssertTrue(links.first?.label.contains("& sales") ?? false)
        XCTAssertEqual(links.last?.nofollow, true)
        XCTAssertEqual(CrawlMemoryScope.perform { 42 }, 42)
    }
}
