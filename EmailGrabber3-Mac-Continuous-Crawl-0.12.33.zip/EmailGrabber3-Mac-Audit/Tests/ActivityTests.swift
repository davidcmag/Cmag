import XCTest
import Foundation
@testable import EmailGrabberCore

final class ActivityTests: DiskTests {
    func testActivityPrecedesFetchAndReportsCompletedAndBlockedPages() {
        var events: [CrawlActivity] = []
        let engine = GrabEngine(settings: settings(), fetcher: { url in
            if url.path == "/robots.txt" { return response("User-agent: *", url) }
            XCTAssertEqual(events.last?.phase, "Fetching")
            XCTAssertEqual(events.last?.url, url.absoluteString)
            return response("person@public.org", url, status: url.host == "blocked.org" ? 403 : 200)
        }, sleep: { _ in })
        let rows = engine.run(mode: .website, terms: ["https://blocked.org/","https://public.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false }, activity: { events.append($0) })
        XCTAssertEqual(rows.count, 1)
        XCTAssertEqual(events.filter { $0.phase == "Completed" }.map(\.url), ["https://public.org/"])
        XCTAssertEqual(events.first { $0.phase == "Skipped" }?.message, "HTTP 403")
        XCTAssertEqual(events.last?.phase, "Idle")
        XCTAssertEqual(events.last?.pending, 0)
        XCTAssertEqual(events.first { $0.phase == "Checking robots" }?.pending, 1)
    }
    func testActivityReportsRobotsRestrictedPageWithoutFetchingIt() {
        var events: [CrawlActivity] = []
        let engine = GrabEngine(settings: settings(), fetcher: { url in
            XCTAssertEqual(url.path, "/robots.txt")
            return response("User-agent: *\nDisallow: /", url)
        }, sleep: { _ in })
        _ = engine.run(mode: .website, terms: ["https://public.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false }, activity: { events.append($0) })
        XCTAssertEqual(events.filter { $0.phase != "Queue" }.map(\.phase), ["Saving progress", "Checking robots", "Skipped", "Saving progress", "Idle"])
    }
}
