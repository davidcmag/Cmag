import XCTest
import Foundation
@testable import EmailGrabberCore

final class RemovalRecoveryTests: DiskTests {
    func testStaleCheckpointCannotRestoreRemovedAddressOrLiveDuplicate() throws {
        let id = UUID()
        let stale = RemovalState()
        var current = stale
        current.remove(["JANE@public.org"], learn: true)
        let recovered = CrawlDisk.recoverRemovals(projectID: id, saved: stale, currentProjectID: id, current: current)
        XCTAssertEqual(recovered, current)
        let rows = [makeEmailFixture("jane@public.org"), makeEmailFixture("jane@public.org"), makeEmailFixture("other@public.org")]
        XCTAssertEqual(ResultPolicy.filtered(rows, rules: [], removed: recovered.addresses, status: "Included", search: "", scope: "Email").map(\.address), ["other@public.org"])
        XCTAssertEqual(ResultPolicy.filtered(rows, rules: [], removed: recovered.addresses, status: "All", search: "", scope: "Email").count, 3)
        XCTAssertEqual(ResultPolicy.exportRows(rows, rules: [], removed: recovered.addresses, onlyAccepted: false).map(\.address), ["other@public.org"])
    }
    func testJournalRecoversRemovalAfterClearOfCheckpointAndStaleProject() throws {
        let id = UUID()
        var state = RemovalState()
        state.remove(["jane@public.org"], learn: true)
        XCTAssertTrue(CrawlDisk.saveRemovals(state, projectID: id))
        CrawlDisk.clear()
        let recovered = CrawlDisk.recoverRemovals(projectID: id, saved: RemovalState())
        XCTAssertEqual(recovered, state)
        XCTAssertEqual(CrawlDisk.recoverRemovals(projectID: UUID(), saved: RemovalState()).addresses, [])
        XCTAssertEqual(CrawlDisk.recoverRemovals(projectID: UUID(), saved: RemovalState(), currentProjectID: id, current: state).addresses, [])
        let attributes = try FileManager.default.attributesOfItem(atPath: CrawlDisk.removalURL(id).path)
        XCTAssertEqual((attributes[.posixPermissions] as? NSNumber)?.intValue, 0o600)
    }
    func testUndoTombstoneWinsOlderRemovedSnapshotAndCannotBeOverwritten() throws {
        let id = UUID()
        var state = RemovalState()
        state.remove(["jane@public.org"], learn: true)
        let stale = state
        XCTAssertTrue(CrawlDisk.saveRemovals(stale, projectID: id))
        state.undo()
        XCTAssertTrue(state.addresses.isEmpty)
        XCTAssertTrue(state.history.isEmpty)
        XCTAssertNil(state.learningDates)
        XCTAssertGreaterThan(try XCTUnwrap(state.changedAt), try XCTUnwrap(stale.changedAt))
        XCTAssertTrue(CrawlDisk.saveRemovals(state, projectID: id))
        XCTAssertTrue(CrawlDisk.saveRemovals(stale, projectID: id))
        XCTAssertEqual(CrawlDisk.recoverRemovals(projectID: id, saved: stale), state)
        state.remove(["other@public.org"])
        state.restoreAll()
        XCTAssertTrue(CrawlDisk.saveRemovals(state, projectID: id))
        XCTAssertEqual(CrawlDisk.recoverRemovals(projectID: id, saved: stale), state)
    }
    func testLegacyStateRoundTripAndMonotonicEdits() throws {
        let legacy = try JSONDecoder().decode(RemovalState.self, from: Data(#"{"addresses":["old@public.org"],"history":[["old@public.org"]]}"#.utf8))
        XCTAssertNil(legacy.changedAt)
        var newer = legacy
        newer.remove(["new@public.org"], at: Date(timeIntervalSince1970: 100))
        newer.remove(["third@public.org"], at: Date(timeIntervalSince1970: 10))
        XCTAssertGreaterThan(try XCTUnwrap(newer.changedAt), Date(timeIntervalSince1970: 100))
        let before = newer
        newer.remove(["NEW@public.org"])
        XCTAssertEqual(before, newer)
        XCTAssertEqual(try JSONDecoder().decode(RemovalState.self, from: JSONEncoder().encode(newer)), newer)
    }
    func testLateWorkerSnapshotAndSessionRoundTripKeepRemovalVersion() throws {
        let id = UUID()
        var state = RemovalState(); state.remove(["jane@public.org"], learn: true)
        let stale = CrawlProgress(queue: [], visited: [], queued: [], robotRules: [:], domainPageCount: [:], discoveredCount: 0, scanned: 0, rows: [makeEmailFixture("jane@public.org")], selectedSites: [], settings: CrawlOptions(depth: 0, maxPages: 0, maxPagesPerDomain: 0, excluded: "", stripDuplicates: true, excludeRole: false, excludeFree: false, excludeDisposable: false, checkDNS: false), input: "")
        CrawlDisk.updatePresentation(rules: [], removal: state, projectID: id)
        XCTAssertTrue(CrawlDisk.save(stale))
        let loaded = try XCTUnwrap(CrawlDisk.load())
        XCTAssertEqual(loaded.removedAddresses, state.addresses)
        XCTAssertEqual(loaded.removalHistory, state.history)
        XCTAssertEqual(loaded.removalChangedAt, state.changedAt)
        XCTAssertEqual(CrawlDisk.loadRemovals(projectID: id), state)
        var session = GrabSession(mode: .website, input: "", excluded: "", depth: 0, maxPages: 0, stripDuplicates: true, excludeRole: false, excludeFree: false, excludeDisposable: false, checkDNS: false, rows: [], removedAddresses: state.addresses, removalHistory: state.history, removalLearningDates: state.learningDates, projectID: id, removalChangedAt: state.changedAt)
        XCTAssertTrue(CrawlDisk.saveProject(session))
        XCTAssertEqual(CrawlDisk.loadProject()?.removalChangedAt, state.changedAt)
        session.removalChangedAt = nil // older files decode as an unversioned candidate
        XCTAssertTrue(CrawlDisk.saveProject(session))
        XCTAssertNil(CrawlDisk.loadProject()?.removalChangedAt)
    }
    func testCorruptJournalPreservedWithoutOverwrite() throws {
        let id = UUID(), bad = Data("invalid-json".utf8)
        try bad.write(to: CrawlDisk.removalURL(id))
        var state = RemovalState(); state.remove(["jane@public.org"])
        XCTAssertFalse(CrawlDisk.saveRemovals(state, projectID: id))
        XCTAssertNotNil(CrawlDisk.lastError)
        XCTAssertEqual(try Data(contentsOf: CrawlDisk.removalURL(id)), bad)
        let copies = try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil).filter { $0.lastPathComponent.hasPrefix("recovery-") }
        XCTAssertEqual(copies.count, 1)
        XCTAssertEqual(try Data(contentsOf: copies[0]), bad)
    }
}
