# Continuous crawling 0.12.33 (bundle 54)

Based on delivered 0.12.32, commit a9145015ea62bc8b651affbdaf5bf08bf33974e6; original ZIP SHA256 0c5eca2d2dd70cf20cb84dd02d09710289bb7875b2da612578d6f09e3f3eca52 was verified before extraction into a new working directory.

## Behavior

A page exceeding its address-extraction or separate link-extraction budget no longer ends the crawl. It remains pending and unvisited while other eligible pages continue. Partial legitimate rows and links already queued survive. A replay does not duplicate saved same-source rows, including when ordinary duplicate stripping is disabled. Interrupted DNS work cannot prematurely mark an address as already processed. Cancelling a partially processed page also retains replay context.

Temporary network timeouts, connection/DNS failures, robots lookup failures, and website-wait timeouts use the same deferred retry workflow. A failed robots lookup is rechecked on retry, including failures encountered at redirect destinations. Robots denials, TLS failures, unsupported responses, and HTTP errors remain truthful; this release does not bypass access rules or site challenges.

Each failed page retries after 30 seconds, then 60, 120, 240, and at most 300 seconds per subsequent attempt. Due retries join the end of the ordinary queue, so they do not immediately displace healthy pending pages. If only deferred work remains, the app displays Waiting to retry with a countdown and pending count. It keeps waiting/retrying until Stop, a selected limit, a checkpoint failure, or actual frontier exhaustion. Unlimited pages stays unlimited; no settings are rewritten. This does not promise success on a permanently unavailable or excessively expensive page.

Live cooldowns use monotonic time and check pause/cancellation at coordinator boundaries, with sleep slices at most 100ms. Optional checkpoint metadata stores attempts and the next eligible retry time; a fresh engine restores the remaining delay, capped at five minutes to avoid clock shifts creating an unbounded delay. Old checkpoints decode without this field. Network, regex, DNS-process and shutdown cancellation safeguards remain. Directory-entry inference and priority scoring loops now check the link budget/cancellation too.

Checkpoint failures end the run with an explicit save failure, rather than claiming persistence succeeded. Saved records, manual corrections, feedback learning, review decisions, removal journals and recovery rules are unchanged. Directory profile context remains durable. No private sessions, profiles or address analyses are included.

## Validation

393 portable XCTest tests passed (0 failures) using signature-verified official Swift 6.0.3, Swift 5 language mode, four build jobs, Linux. CORE-TESTS.log and CORE-TESTS-EXTERNAL.log contain the current complete run; the separate Swift Testing runner's zero-tests line is not the XCTest count.

Coverage includes slow extraction with one/five workers and a healthy queued site; link timeout followed by successful automatic retry; partial-row replay with duplicate stripping disabled; interrupted DNS plus fresh-engine restart; saved directory context and retry cooldown; exponential backoff capped at 300 seconds; Pause then Stop in retry waiting and extraction; partial-row Stop/restart; temporary robots recovery; transport connection-loss versus TLS failure; selected page limits; and prior learning, removal, classification, general-directory and large-frontier regressions. Timing fixtures are synthetic, not captures of the reported UniversityGuru page.

Core build, Linux SwiftUI syntax parse, and Xcode project references passed. Native Mac build/GUI and live directory behavior were not verified. The related improvement to prioritize discovered organization websites over further directory browsing remains outstanding. Existing general structural directory inference was preserved; no industry keyword bridge was added.

## Mac acceptance

Save, Stop and quit the previous app first, without Clear. Download the new archive, verify its published SHA256 and extract into a fresh directory. Run `bash build-mac.sh`, then `open dist/EmailGrabber3.app` on the Mac. Confirm version 0.12.33, existing records/learning/removal preference, and Resume of saved pending work. With unlimited pages, confirm other queued sites continue after a slow page; deferred-only work shows its countdown; Stop works during the wait; Pause then Stop never resumes normal crawling. Save failures must be treated as failures. Source ZIP root remains EmailGrabber3-Mac-Audit/.
