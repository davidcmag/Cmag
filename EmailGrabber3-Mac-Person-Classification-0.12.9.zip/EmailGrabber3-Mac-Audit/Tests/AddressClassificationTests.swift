import XCTest
import Foundation
@testable import EmailGrabberCore

final class AddressClassificationTests: XCTestCase {
    func row(_ address: String) -> FoundEmail {
        FoundEmail(address: address, source: "https://example.org/staff", status: "Accepted", reason: "Local checks")
    }
    func testPublishedJobTitlesAreGeneralInboxesNotPeople() {
        for (local, title) in [("executivedirector", "Executive Director"), ("deputydirector", "Deputy Director"), ("developmentdirector", "Development Director"), ("program.director", "Program Director"), ("executive-director+contact", "Executive Director"), ("chiefdevelopmentofficer", "Chief Development Officer")] {
            var value = row(local + "@example.org")
            XCTAssertEqual(value.addressClassification.category, .general, local)
            value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact text", sourceURL: value.source, excerpt: title + " — " + value.address)
            XCTAssertEqual(value.addressClassification.category, .general, local)
            XCTAssertFalse(value.addressClassification.reason.contains("excerpt names"))
            XCTAssertFalse(AddressClassification.roleNames.contains(local), "Do not change crawl exclusions")
        }
    }
    func testCapitalizedTitleCannotBecomeNameEvidenceForUnknownMailbox() {
        for (local, title) in [("eofficer", "Executive Officer"), ("specialprojects", "Special Projects"), ("developmentmanager", "Development Manager"), ("jdirector", "Junior Director"), ("salesoffice", "Sales Office")] {
            var value = row(local + "@example.org")
            value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact text", sourceURL: value.source, excerpt: title + " — " + value.address)
            // Unknown titles may remain uncertain; capitalization alone is insufficient.
            XCTAssertNotEqual(value.addressClassification.category, .person, local)
        }
    }
    func testPersonFilterAndCategoryReviewExcludePublishedDirectors() {
        var director = row("executivedirector@example.org")
        director.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact text", sourceURL: director.source, excerpt: "Executive Director — executivedirector@example.org")
        let rows = [director, row("dan.boyce@example.org")]
        XCTAssertEqual(AddressClassification.review(rows, category: .person, removed: []).map(\.address), ["dan.boyce@example.org"])
        XCTAssertEqual(AddressClassification.review(rows, category: .general, removed: []).map(\.address), [director.address])
    }
    func testActualStaffNameBesideTitleStillSupportsPerson() {
        var value = row("mbrown@example.org")
        value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact text", sourceURL: value.source, excerpt: "Executive Director: Michael Brown — mbrown@example.org")
        XCTAssertEqual(value.addressClassification.category, .person)
        XCTAssertTrue(value.addressClassification.reason.contains("Michael Brown"))
        value.websiteConfirmation?.excerpt = "Michael Brown — mbrown@example.org.evil"
        XCTAssertEqual(value.addressClassification.category, .uncertain)
    }
    func testGeneralInboxAndAliases() {
        for address in ["INFO@example.org", "sales+press@example.org", "support@example.org", "newsroom@example.org", "press.office@example.org"] {
            XCTAssertEqual(row(address).addressClassification.category, .general, address)
            XCTAssertFalse(row(address).addressClassification.reason.isEmpty)
        }
        XCTAssertFalse(AddressClassification.roleNames.contains("newsroom"), "Existing crawl exclusions must not expand")
    }
    func testConservativeNamesAndInitials() {
        XCTAssertEqual(row("dan.boyce@example.org").addressClassification.category, .person)
        for local in ["db", "dboyce", "d.boyce", "x", "cher", "maria99", "a_b", "weird-name-xyz", "unusual.name", "custom.address"] {
            XCTAssertEqual(row(local + "@example.org").addressClassification.category, .uncertain, local)
        }
    }
    func testRecordedExactPublicationNameStrengthensInitial() {
        var value = row("dboyce@example.org")
        value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact text", sourceURL: value.source, match: .pageText, excerpt: "Dan Boyce — dboyce@example.org")
        XCTAssertEqual(value.addressClassification.category, .person)
        XCTAssertTrue(value.addressClassification.reason.contains("Dan Boyce"))
        value.websiteConfirmation?.outcome = .notFound
        XCTAssertEqual(value.addressClassification.category, .uncertain)
        value.websiteConfirmation?.outcome = .published
        value.websiteConfirmation?.excerpt = "Dan Boyce — another@example.org"
        XCTAssertEqual(value.addressClassification.category, .uncertain)
        value.websiteConfirmation?.excerpt = "Jane Smith — dboyce@example.org"
        XCTAssertEqual(value.addressClassification.category, .uncertain)
    }
    func testDuplicateAddressBulkRemovalUsesExistingAddressHistory() {
        let rows = [row("info@example.org"), row("INFO@example.org"), row("db@example.org")]
        var state = RemovalState()
        state.remove(Set(AddressClassification.review(rows, category: .general, removed: []).map(\.address)))
        XCTAssertEqual(state.addresses.count, 1)
        XCTAssertEqual(state.history.count, 1)
        XCTAssertEqual(ResultPolicy.filtered(rows, rules: [], removed: state.addresses, status: "Included", search: "", scope: "Email").map(\.address), ["db@example.org"])
        state.undo()
        XCTAssertEqual(ResultPolicy.filtered(rows, rules: [], removed: state.addresses, status: "Included", search: "", scope: "Email"), rows)
    }
    func testRoleEvidenceNeverOverridesSharedInbox() {
        var value = row("info@example.org")
        value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact text", sourceURL: value.source, excerpt: "Dan Boyce info@example.org")
        XCTAssertEqual(value.addressClassification.category, .general)
    }
    func testBulkRemovalUndoPersistenceAndExport() throws {
        let rows = [row("info@example.org"), row("newsroom@example.org"), row("dan.boyce@example.org"), row("db@example.org")]
        var state = RemovalState(addresses: ["old@example.org"], history: [["old@example.org"]])
        let original = rows
        let reviewed = AddressClassification.review(rows, category: .general, removed: state.addresses)
        XCTAssertEqual(reviewed.count, 2)
        state.remove(Set(reviewed.map(\.address)))
        XCTAssertEqual(state.history.count, 2)
        XCTAssertEqual(ResultPolicy.exportRows(rows, rules: [], removed: state.addresses, onlyAccepted: false).map(\.address), ["dan.boyce@example.org", "db@example.org"])
        XCTAssertEqual(rows, original)
        var restored = try JSONDecoder().decode(RemovalState.self, from: JSONEncoder().encode(state))
        restored.undo()
        XCTAssertEqual(restored.addresses, ["old@example.org"])
        XCTAssertEqual(ResultPolicy.exportRows(rows, rules: [], removed: restored.addresses, onlyAccepted: false), original)
    }
    func testSortAndFilterPreserveOriginalRecordsAndRules() {
        let rows = [row("info@example.org"), row("dan.boyce@example.org"), row("db@example.org")]
        let sorted = ResultOrdering.apply(rows, order: [KeyPathComparator(\FoundEmail.classificationLabel)])
        XCTAssertEqual(sorted.map(\.classificationLabel), ["General inbox", "Likely person", "Uncertain"])
        let filtered = rows.filter { $0.addressClassification.category == .person }
        XCTAssertEqual(filtered.map(\.address), ["dan.boyce@example.org"])
        XCTAssertEqual(rows.count, 3)
        let rule = SmartRule(kind: "Address", pattern: "dan.boyce@example.org")
        XCTAssertEqual(ResultPolicy.filtered(rows, rules: [rule], removed: [], status: "Included", search: "", scope: "Email").count, 2)
    }
}
