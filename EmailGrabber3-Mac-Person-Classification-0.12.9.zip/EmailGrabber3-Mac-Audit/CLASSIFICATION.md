# 0.12.9 correction

Validation: 252 portable tests passed. SwiftUI syntax, Xcode project references
and shell syntax passed. Native macOS compilation and GUI/WebKit execution were
not run in this Linux environment.

0.12.8 could mistake capitalized job titles for names in publication excerpts.
0.12.9 recognizes title inboxes before interpreting name evidence, rejects job-title
and shared-inbox terms as names, and requires an exact address match in excerpts.
Existing rows are reclassified on display without changing saved data or removals.
New regressions cover the reported three director inboxes, separator/alias forms,
unknown titles, person/category filtering, genuine staff names beside titles and
false address suffix matches. This changes presentation only, not role exclusions.

# Address classification — 0.12.8

Address type is independent of acceptance, SMTP, ZeroBounce and website publication.
General inbox recognizes shared mailbox terms, including newsroom and role aliases.
Likely person requires a familiar given name and separated name-like surname, or
recorded exact-address publication text with a matching full name. These are hints,
not proof of a person's identity. Unfamiliar names, initials, numeric handles and
single-word addresses stay Uncertain without matching recorded name evidence.
No new network requests are made for classification. Existing excerpts may have
only a mailto address; those do not imply name evidence. New visible mailto text
can retain the surrounding name while preserving the Email link match type.

Choose Address type → Person addresses only to hide other rows, or select General
inbox / Uncertain for review. Click Address type's column header to sort. Hover
its cells or use Show evidence to read the classification reason.
Review category removal captures visible rows under the current status/search
filters. Confirming uses existing address-based removal: all copies of those
addresses are suppressed, including future duplicate discoveries. Restore last
removal undoes the batch. Existing removals and rules remain intact. Review and
Cancel do not remove anything. Clearing the address-type filter restores hidden
rows. CSV export behavior and saved-data schema remain unchanged.

Validation: 248 portable tests passed on Linux using signature-verified Swift
6.0.3, including 8 new classification/publication and removal regressions.
SwiftUI syntax, Xcode object/source references and shell syntax passed.
Native macOS compilation, GUI interactions, native WebKit execution and live CPR
confirmation were not run. No paid verification or public mailbox probes were run.
