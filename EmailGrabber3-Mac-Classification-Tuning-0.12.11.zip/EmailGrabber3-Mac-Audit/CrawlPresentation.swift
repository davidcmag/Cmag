import Foundation

struct CrawlCounters {
    let pages: Int
    let discovered: Int
    let scannedSites: Int
    let message: String
}
struct CrawlDisplayBatch {
    var rows: [FoundEmail] = []
    var counters: CrawlCounters?
    var current: CrawlActivity?
    var queue: CrawlActivity?
    var recent: [CrawlActivity] = []
    var isEmpty: Bool { rows.isEmpty && counters == nil && current == nil && queue == nil && recent.isEmpty }
}

/// Workers never schedule one main-thread closure per event. The UI drains this
/// mailbox on a timer; result deltas retain their order and are never discarded.
final class CrawlDisplayBuffer {
    private let lock = NSLock()
    private var pending = CrawlDisplayBatch()
    func append(_ rows: [FoundEmail]) { lock.lock(); pending.rows.append(contentsOf: rows); lock.unlock() }
    func report(_ counters: CrawlCounters) { lock.lock(); pending.counters = counters; lock.unlock() }
    func report(_ event: CrawlActivity) {
        lock.lock(); defer { lock.unlock() }
        if event.phase == "Queue" { pending.queue = event }
        else { pending.current = event }
        if event.phase == "Completed" || event.phase == "Skipped" {
            pending.recent.append(event)
            if pending.recent.count > 100 { pending.recent.removeFirst(pending.recent.count - 100) }
        }
    }
    func drain() -> CrawlDisplayBatch {
        lock.lock(); defer { lock.unlock() }
        let result = pending; pending = CrawlDisplayBatch(); return result
    }
}

/// Reuses filtered rows for ordinary append-only live updates. Changes to rules,
/// removal, field scope, query, or existing records invalidate the cached filter.
final class ResultsFilterCache {
    private struct Query: Equatable {
        let rules: [SmartRule]
        let removed: Set<String>
        let status: String
        let search: String
        let scope: String
    }
    private var query: Query?
    private var previousRows: [FoundEmail] = []
    private var filtered: [FoundEmail] = []
    private var order: [KeyPathComparator<FoundEmail>] = []
    private var displayed: [FoundEmail] = []
    private(set) var evaluatedRows = 0
    func update(_ rows: [FoundEmail], rules: [SmartRule], removed: Set<String>, status: String, search: String, scope: String, sort: [KeyPathComparator<FoundEmail>]) -> [FoundEmail] {
        let next = Query(rules: rules, removed: removed, status: status, search: search, scope: scope)
        if query == next && previousRows == rows && order == sort { return displayed }
        let appendOnly = query == next && rows.count >= previousRows.count && rows.prefix(previousRows.count).elementsEqual(previousRows)
        let candidates = appendOnly ? Array(rows.dropFirst(previousRows.count)) : rows
        if !appendOnly { filtered.removeAll(keepingCapacity: true) }
        if !candidates.isEmpty {
            evaluatedRows += candidates.count
            filtered.append(contentsOf: ResultPolicy.filtered(candidates, rules: rules, removed: removed, status: status, search: search, scope: scope))
        }
        previousRows = rows; query = next; order = sort
        displayed = ResultOrdering.apply(filtered, order: sort)
        return displayed
    }
}

enum CrawlMemoryScope {
    /// A long-lived Thread does not get the main run loop's per-event pools.
    /// Release temporary Foundation/Objective-C page objects after each step.
    static func perform<T>(_ work: () -> T) -> T {
        #if canImport(ObjectiveC)
        return autoreleasepool(invoking: work)
        #else
        return work()
        #endif
    }
}
