# Optional SMTP mailbox checker — 0.12.3 development candidate

Reconstructed from the failed-workspace handoff on the unchanged 0.11.13 source
baseline. This is a source candidate, not a compiled/notarized Mac release.

## Verified here

- Swift 6.0.3, Swift 5 language mode, Linux x86_64.
- 186 XCTest tests passed: the 128 baseline tests plus 58 SMTP/routing/transport/
  evidence tests. These use scripted SMTP/DNS and actual local socket pairs.
- Xcode project property list, three targets, and all source references validated.
- SwiftUI and native TLS source syntax parsed. This is not Mac type checking.
- No public recipient server was probed. No ZeroBounce request or credit consumed.

## Required Mac validation

Keep the old app. Run `bash verify-mac.sh` in this directory. It backs up existing
application data, then builds the app/core/tests with Xcode. The new Mac-only
SMTPNativeTLSTests generates an ephemeral self-signed certificate and loopback
OpenSSL TLS server. It must reach certificate rejection specifically, and confirm
that no plaintext command is possible afterward. This test has NOT run here.

If Xcode tests pass, `open EmailGrabber3.xcodeproj` and press Command-R. Confirm
additive row/checkbox selection, filters, Found order, removals, autosave/resume,
and concurrent crawl behavior from MAC-ACCEPTANCE.md remain intact. Confirm the
new SMTP fields/actions/columns fit and update correctly. Mac compilation,
SecureTransport behavior and GUI operation are still unverified.

## Use

Enter an EHLO hostname and sender email you control under Optional SMTP mailbox
check. The reserved placeholder is deliberately unusable. Choose Check next 100
via SMTP for unchecked eligible addresses, or select rows and Verify selected
(SMTP) to recheck. The confirmation explains the remote probes and TLS policy.
Stop verification cooperatively cancels bounded socket work; DNS subprocesses may
need up to their four-second timeout to return. Each finished check autosaves.
Three distinct domains with connection failures stop the batch; port 25 may be
restricted. Linux portable tests do not provide a native live TLS transport.

Require verified TLS defaults on. If you explicitly turn it off, plaintext is
permitted only when the server does not advertise STARTTLS. An advertised TLS
failure NEVER falls back to plaintext. Mac SecureTransport uses SNI, TLS 1.2
minimum, system certificate trust and the MX hostname. It is a deprecated Apple
API and does not provide TLS 1.3. Native Mac validation remains required.

For a later comparison, select the SAME rows and Compare selected (ZeroBounce).
The app separately confirms transmission and possible paid credits; it never
runs the provider automatically. Store that key in Mac Keychain, not project
files. Keep original rows and compare both columns/evidence; neither checker is
a guaranteed ground truth.

## Interpretation and limits

The protocol is greeting, EHLO/HELO, optional STARTTLS and a fresh EHLO, then
RSET/MAIL FROM/RCPT TO for the target. Only after target acceptance, two distinct
randomized recipients are tested in separate reset transactions. DATA, AUTH,
VRFY and EXPN are never issued. Connections close after RSET/QUIT where possible.

- Target accepted + both controls explicitly rejected with recipient-specific
  5.1.1: SMTP accepted, not guaranteed delivery.
- Target + both controls accepted: Catch-all; mailbox existence unknown.
- Mixed, blocked, temporary or incomplete controls: Unknown.
- Recipient-specific preferred-MX 5.1.1: SMTP rejected. A backup-MX rejection
  cannot establish invalidity while the preferred server is unavailable.
- Sender/client/relay/auth/policy problems, including 5.7.x: Blocked/Unknown.
- 4xx and mailbox-full 5.2.2: Temporary. 252 remains Unknown.
- DNS NXDOMAIN and explicit null MX reject the domain's mail route. DNS failures
  and absence of usable records remain inconclusive. Implicit A/AAAA fallback
  is used only after a successful MX lookup with no MX records.

Retries, replies, DNS lookups, MX alternatives, sockets and total probe time are
bounded. Temporary outcomes get at most one in-batch retry after a cancellable 30-second wait, then a domain
cooldown; greylisting may need a later user-initiated check. MX records are sorted
by preference. Numeric IPv4/IPv6 destinations are checked as public unicast and
pinned at connect, avoiding a second DNS lookup. Unsafe/private/reserved results
are never connected to. This intentionally rejects some special-purpose routes.

ASCII mailbox syntax only; no SMTPUTF8. Some providers accept all RCPTs, hide
mailbox status, tarpit, rate-limit, require reputation/PTR or block your source
IP. Role/free-provider/disposable flags are advisory, not proof of invalidity.
The bundled CC0 list has 9,963 entries and matches the handoff checksum; license,
upstream commit and checksum are in Resources/.

SMTP and provider results have separate dates, versions and evidence. Failed
provider attempts retain the earlier row conclusion and successful-provider
summary. Export retains the original first five CSV columns and appends both
sources. Verification does not undo exclusions, rules or recoverable removals.
No automatic migration or deletion of saved projects is performed; new fields
are optional for old records. Keep the backup before trying this candidate.

## 0.12.1 Mac compiler correction

The first user Mac build of 0.12.0 failed before tests because Swift does not
import the errSSLServerAuthCompleted C macro alias. Use the canonical Apple
SecBase.h enum constant errSSLPeerAuthCompleted (-9841) instead. This changes
no trust checks or downgrade policy. The earlier candidate is superseded.
The corrected Mac build and native TLS test still require actual Xcode validation.

## 0.12.2 Mac test compiler correction

Qualify the loopback fixture bind/socket/getsockname calls with Darwin to avoid
NSObject/XCTest inherited method lookup. The 0.12.1 Mac build reached a test
compile failure at the unqualified bind call. Corrected Mac tests remain unrun.
To open the project for building in Xcode immediately, use:

```sh
open EmailGrabber3.xcodeproj
```

Then choose EmailGrabber3 / My Mac. Command-B builds, Command-U runs tests, and
Command-R runs the app. The optional verify-mac.sh Terminal workflow also backs
up existing data, but is not a prerequisite for opening Xcode.

## 0.12.3 robustness improvements

- Narrow, explicit nonexistent-recipient text in 550/553 responses can support
  rejection even without enhanced status codes. Generic errors, lookup failures,
  sender/relay/policy/auth failures remain inconclusive. This applies to controls
  too, avoiding needless uncertainty when controls clearly say "no such user".
- A domain cooldown is Deferred / not probed, rather than a fabricated Temporary
  result for an address that was never queried. Connection-attempt status and
  retry time are saved and exported.
- Retry inconclusive (SMTP) selects only due inconclusive checks, respects
  exclusions/removals, and does not automatically re-probe catch-all or accepted
  results. Manually selecting rows can explicitly recheck those when desired.
- Temporary/unknown outcomes have five-minute retry suggestions; policy blocks
  have thirty-minute retry suggestions. Failed-domain cooldowns are at least
  five minutes for temporary replies and thirty minutes for blocks. If an
  in-batch temporary retry is enabled, its cancellable wait is thirty seconds
  instead of one second. Neither wait is a promise greylisting will clear.
- Right-click an email → Show verification evidence to inspect/copy the exact
  server responses and retry time in a scrollable window. Reasons include the
  failing stage, MX hostname, response code and response text where available.
- Up to eight prior SMTP attempts per row are retained, merged independently of
  provider evidence, and included in CSV output. Old projects still decode.
- The sidebar explains when a running crawl/discovery/verification disables SMTP.
- A catch-all-style response can also come from a mail security gateway. It does
  not establish true catch-all configuration, or prove any individual mailbox
  exists. These changes do not pretend to reproduce a paid provider's private
  delivery history or proprietary data. No paid calls/public probes were run.

186 portable XCTest tests pass, including the previous 176 regressions. Mac
compilation and the new evidence window still require actual Mac validation.
The prior Swift TLS constant and Darwin.bind fixes are retained unchanged.
