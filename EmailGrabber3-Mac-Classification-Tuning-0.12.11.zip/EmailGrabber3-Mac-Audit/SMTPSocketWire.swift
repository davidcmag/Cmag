import Foundation
#if canImport(Darwin)
import Darwin
#else
import Glibc
#endif
#if os(macOS)
import Security
#endif

/// Single-thread-owned nonblocking socket. Production connects exclusively to a
/// validated numeric public address on port 25. No DNS lookup occurs here.
final class SMTPSocketWire: SMTPWire {
    private var fd: Int32
    private let timeout: TimeInterval
    private let cancelled: () -> Bool
    private var input = Data()
    private var poisoned = false
    #if os(macOS)
    private var tlsContext: SSLContext?
    #endif
    private var clock: TimeInterval { ProcessInfo.processInfo.systemUptime }
    init(ip: String, host: String, timeout: TimeInterval, cancelled: @escaping () -> Bool) throws {
        guard MailAddressSafety.publicIP(ip), MailAddressSafety.hostname(host) else { throw SMTPFailure.invalidInput }
        self.timeout = min(30, max(0.1, timeout)); self.cancelled = cancelled; self.fd = -1
        #if os(Linux)
        let kind = Int32(SOCK_STREAM.rawValue)
        #else
        let kind = SOCK_STREAM
        #endif
        let family = ip.contains(":") ? AF_INET6 : AF_INET
        fd = socket(family, kind, 0)
        guard fd >= 0 else { throw SMTPFailure.connection }
        do {
            try configure()
            var status: Int32 = -1
            if family == AF_INET {
                var addr = sockaddr_in(); addr.sin_family = sa_family_t(AF_INET); addr.sin_port = UInt16(25).bigEndian
                guard inet_pton(AF_INET, ip, &addr.sin_addr) == 1 else { throw SMTPFailure.invalidInput }
                status = withUnsafePointer(to: &addr) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { systemConnect(fd, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) } }
            } else {
                var addr = sockaddr_in6(); addr.sin6_family = sa_family_t(AF_INET6); addr.sin6_port = UInt16(25).bigEndian
                guard inet_pton(AF_INET6, ip, &addr.sin6_addr) == 1 else { throw SMTPFailure.invalidInput }
                status = withUnsafePointer(to: &addr) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { systemConnect(fd, $0, socklen_t(MemoryLayout<sockaddr_in6>.size)) } }
            }
            if status != 0 {
                guard errno == EINPROGRESS else { throw SMTPFailure.connection }
                try wait(Int16(POLLOUT), deadline: clock + self.timeout)
                var error: Int32 = 0; var length = socklen_t(MemoryLayout<Int32>.size)
                guard getsockopt(fd, SOL_SOCKET, SO_ERROR, &error, &length) == 0, error == 0 else { throw SMTPFailure.connection }
            }
        } catch { close(); throw error }
    }
    /// Internal local-fixture seam: takes ownership of an already-connected FD.
    /// No hostname/port override is exposed by the application.
    init(connectedFD: Int32, timeout: TimeInterval = 1, cancelled: @escaping () -> Bool = { false }) throws {
        self.fd = connectedFD; self.timeout = timeout; self.cancelled = cancelled
        do { try configure() } catch { close(); throw error }
    }
    deinit { close() }
    private func configure() throws {
        guard fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK) != -1 else { throw SMTPFailure.connection }
        _ = fcntl(fd, F_SETFD, FD_CLOEXEC)
        #if os(macOS)
        var yes: Int32 = 1
        guard setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &yes, socklen_t(MemoryLayout<Int32>.size)) == 0 else { throw SMTPFailure.connection }
        #endif
    }
    private func check(_ deadline: TimeInterval) throws {
        guard !cancelled() else { throw SMTPFailure.cancelled }
        guard fd >= 0, !poisoned else { throw SMTPFailure.disconnected }
        guard clock < deadline else { throw SMTPFailure.timeout }
    }
    private func wait(_ events: Int16, deadline: TimeInterval) throws {
        while true {
            try check(deadline)
            var p = pollfd(fd: fd, events: events, revents: 0)
            let result = poll(&p, 1, Int32(min(100, max(1, (deadline - clock) * 1000))))
            if result < 0 { if errno == EINTR { continue }; throw SMTPFailure.connection }
            if result == 0 { continue }
            if p.revents & events != 0 { return }
            if p.revents & Int16(POLLERR | POLLHUP | POLLNVAL) != 0 { throw SMTPFailure.disconnected }
        }
    }
    fileprivate func rawRead(_ buffer: UnsafeMutableRawPointer, _ size: Int) -> Int { recv(fd, buffer, size, 0) }
    fileprivate func rawWrite(_ buffer: UnsafeRawPointer, _ size: Int) -> Int {
        #if os(Linux)
        return send(fd, buffer, size, Int32(MSG_NOSIGNAL))
        #else
        return send(fd, buffer, size, 0)
        #endif
    }
    private func readBytes(deadline: TimeInterval) throws -> Data {
        var buffer = [UInt8](repeating: 0, count: 2048)
        while true {
            try check(deadline)
            #if os(macOS)
            if let context = tlsContext {
                var count = 0
                let status = SSLRead(context, &buffer, buffer.count, &count)
                if count > 0 { return Data(buffer.prefix(count)) }
                if status == errSSLWouldBlock { try wait(Int16(POLLIN), deadline: deadline); continue }
                throw status == errSSLClosedGraceful ? SMTPFailure.disconnected : SMTPFailure.tlsFailed
            }
            #endif
            let count = buffer.withUnsafeMutableBytes { rawRead($0.baseAddress!, $0.count) }
            if count > 0 { return Data(buffer.prefix(count)) }
            if count == 0 { throw SMTPFailure.disconnected }
            if errno == EINTR { continue }
            guard errno == EAGAIN || errno == EWOULDBLOCK else { throw SMTPFailure.connection }
            try wait(Int16(POLLIN), deadline: deadline)
        }
    }
    private func writeBytes(_ data: Data) throws {
        let deadline = clock + timeout; var offset = 0
        while offset < data.count {
            try check(deadline)
            #if os(macOS)
            if let context = tlsContext {
                var count = 0
                let status = data.withUnsafeBytes { SSLWrite(context, $0.baseAddress!.advanced(by: offset), data.count - offset, &count) }
                offset += count
                if status == noErr { continue }
                guard status == errSSLWouldBlock else { throw SMTPFailure.tlsFailed }
                try wait(Int16(POLLOUT), deadline: deadline); continue
            }
            #endif
            let count = data.withUnsafeBytes { rawWrite($0.baseAddress!.advanced(by: offset), data.count - offset) }
            if count > 0 { offset += count; continue }
            if count < 0 && errno == EINTR { continue }
            guard count < 0 && (errno == EAGAIN || errno == EWOULDBLOCK) else { throw SMTPFailure.disconnected }
            try wait(Int16(POLLOUT), deadline: deadline)
        }
    }
    private func line(deadline: TimeInterval) throws -> Data {
        while true {
            try check(deadline)
            if let newline = input.firstIndex(of: 10) {
                let end = input.index(after: newline); let value = Data(input[..<end]); input.removeSubrange(..<end)
                guard value.count <= 2048, value.suffix(2) == Data([13,10]) else { throw SMTPFailure.protocolError }
                return value
            }
            guard input.count < 2048 else { throw SMTPFailure.oversized }
            input.append(try readBytes(deadline: deadline))
            guard input.count <= 4096 else { throw SMTPFailure.oversized }
        }
    }
    func readReply() throws -> SMTPReply {
        let deadline = clock + timeout
        return try SMTPReply.read { try self.line(deadline: deadline) }
    }
    func command(_ value: String) throws -> SMTPReply {
        guard value.utf8.count <= 510, value.utf8.allSatisfy({ (32...126).contains($0) }),
              value == "RSET" || value == "QUIT" || value == "STARTTLS" || value.hasPrefix("EHLO ") || value.hasPrefix("HELO ") || value.hasPrefix("MAIL FROM:<") || value.hasPrefix("RCPT TO:<") else { throw SMTPFailure.invalidInput }
        try writeBytes(Data((value + "\r\n").utf8))
        return try readReply()
    }
    func startTLS(host: String) throws {
        guard input.isEmpty, MailAddressSafety.hostname(host) else { poisoned = true; throw SMTPFailure.tlsFailed }
        #if os(macOS)
        guard tlsContext == nil, let context = SSLCreateContext(nil, .clientSide, .streamType) else { poisoned = true; throw SMTPFailure.tlsFailed }
        tlsContext = context
        do {
            guard SSLSetIOFuncs(context, smtpTLSRead, smtpTLSWrite) == noErr,
                  SSLSetConnection(context, UnsafeRawPointer(Unmanaged.passUnretained(self).toOpaque())) == noErr,
                  SSLSetProtocolVersionMin(context, .tlsProtocol12) == noErr,
                  SSLSetSessionOption(context, .breakOnServerAuth, true) == noErr,
                  host.withCString({ SSLSetPeerDomainName(context, $0, host.utf8.count) }) == noErr else { throw SMTPFailure.tlsFailed }
            let deadline = clock + timeout
            var trusted = false
            while true {
                try check(deadline)
                let status = SSLHandshake(context)
                if status == errSSLPeerAuthCompleted {
                    var trust: SecTrust?
                    guard SSLCopyPeerTrust(context, &trust) == noErr, let trust = trust,
                          SecTrustSetPolicies(trust, SecPolicyCreateSSL(true, host as CFString)) == errSecSuccess else { throw SMTPFailure.tlsFailed }
                    // Use system anchors and hostname checks; no custom trust,
                    // self-signed exception, or certificate-pinning bypass.
                    guard SecTrustSetNetworkFetchAllowed(trust, false) == errSecSuccess else { throw SMTPFailure.tlsFailed }
                    guard SecTrustEvaluateWithError(trust, nil) else { throw SMTPFailure.certificateRejected }
                    trusted = true; continue
                }
                if status == noErr { guard trusted else { throw SMTPFailure.tlsFailed }; return }
                guard status == errSSLWouldBlock else { throw SMTPFailure.tlsFailed }
                // Handshake may be waiting for either direction. A short poll
                // keeps cancellation responsive even when POLLOUT stays ready.
                var p = pollfd(fd: fd, events: Int16(POLLIN | POLLOUT), revents: 0)
                _ = poll(&p, 1, 10)
                Thread.sleep(forTimeInterval: 0.005)
            }
        } catch { poisoned = true; close(); throw error }
        #else
        poisoned = true
        throw SMTPFailure.tlsUnavailable
        #endif
    }
    func close() {
        // Avoid SSL close-notify blocking cancellation or deinit.
        #if os(macOS)
        tlsContext = nil
        #endif
        if fd >= 0 {
            #if canImport(Darwin)
            _ = Darwin.close(fd)
            #else
            _ = Glibc.close(fd)
            #endif
            fd = -1
        }
    }
}
private func systemConnect(_ fd: Int32, _ address: UnsafePointer<sockaddr>, _ length: socklen_t) -> Int32 {
    #if canImport(Darwin)
    return Darwin.connect(fd, address, length)
    #else
    return Glibc.connect(fd, address, length)
    #endif
}
#if os(macOS)
private let smtpTLSRead: SSLReadFunc = { connection, data, length in
    let wire = Unmanaged<SMTPSocketWire>.fromOpaque(connection).takeUnretainedValue()
    let wanted = length.pointee; let count = wire.rawRead(data, wanted)
    length.pointee = max(0, count)
    if count > 0 { return count == wanted ? noErr : errSSLWouldBlock }
    if count == 0 { return errSSLClosedGraceful }
    return errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR ? errSSLWouldBlock : errSecIO
}
private let smtpTLSWrite: SSLWriteFunc = { connection, data, length in
    let wire = Unmanaged<SMTPSocketWire>.fromOpaque(connection).takeUnretainedValue()
    let wanted = length.pointee; let count = wire.rawWrite(data, wanted)
    length.pointee = max(0, count)
    if count > 0 { return count == wanted ? noErr : errSSLWouldBlock }
    return errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR ? errSSLWouldBlock : errSecIO
}
#endif
