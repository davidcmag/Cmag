import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
#if canImport(Security)
import Security
#endif

/// Optional, explicitly confirmed ZeroBounce integration. Keys never enter JSON.
enum AdvancedVerifier {
    private static let service = "com.adeptyx.emailgrabber3.zerobounce"
    private static let account = "api-key"
    static func saveAPIKey(_ key: String) -> Bool {
        #if canImport(Security)
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                   kSecAttrService as String: service,
                                   kSecAttrAccount as String: account]
        let updated = SecItemUpdate(query as CFDictionary, [kSecValueData as String: Data(key.utf8)] as CFDictionary)
        if updated == errSecSuccess { return true }
        guard updated == errSecItemNotFound else { return false }
        let item = query.merging([kSecValueData as String: Data(key.utf8)]) { _, new in new }
        return SecItemAdd(item as CFDictionary, nil) == errSecSuccess
        #else
        return false // No insecure file fallback on systems without Keychain.
        #endif
    }
    static func loadAPIKey() -> String? {
        #if canImport(Security)
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                   kSecAttrService as String: service,
                                   kSecAttrAccount as String: account,
                                   kSecReturnData as String: true,
                                   kSecMatchLimit as String: kSecMatchLimitOne]
        var output: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &output) == errSecSuccess, let data = output as? Data else { return nil }
        return String(data: data, encoding: .utf8)
        #else
        return nil
        #endif
    }
    struct Result { let status: String; let reason: String; var stopBatch = false; var requestFailed = false }
    static func validate(email: String, apiKey: String, perform: ((URLRequest) -> HTTPResult)? = nil) -> Result {
        guard EmailPolicy.validSyntax(email), !apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return Result(status: "Uncertain", reason: "Valid syntax and a nonempty API key are required; no address transmitted", requestFailed: true) }
        let url = URL(string: "https://api.zerobounce.net/v2/validate")!
        var request = URLRequest(url: url, timeoutInterval: 25)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        func enc(_ value: String) -> String { value.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? "" }
        request.httpBody = "api_key=\(enc(apiKey))&email=\(enc(email))&ip_address=".data(using: .utf8)
        let response = perform?(request) ?? HTTPTransport.perform(request, maxBytes: 1_000_000, timeout: 28,
            shouldCancel: { Thread.current.isCancelled }, redirect: { $0.scheme == "https" && $0.host == "api.zerobounce.net" })
        guard response.succeeded, let data = response.data,
              let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else {
            return Result(status: "Uncertain", reason: response.status.map { "Provider HTTP \($0); verification inconclusive" } ?? "Provider request failed; verification inconclusive", stopBatch: response.status == nil || [401,402,403,429,503].contains(response.status ?? 0), requestFailed: true)
        }
        if json["error"] != nil { return Result(status: "Uncertain", reason: "Provider returned an error; check API key and credit balance", stopBatch: true, requestFailed: true) }
        guard let status = json["status"] as? String, !status.isEmpty else { return Result(status: "Uncertain", reason: "Provider returned no status; verification inconclusive", requestFailed: true) }
        let result = ProviderClassification.result(status: json["status"] as? String ?? "unknown", substatus: json["sub_status"] as? String ?? "")
        return Result(status: result.0, reason: result.1)
    }
}
