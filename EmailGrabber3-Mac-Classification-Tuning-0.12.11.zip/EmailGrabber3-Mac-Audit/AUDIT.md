# Mac source audit and repairs

Scope: all five Swift files, Info.plist, build script and setup documentation in the uploaded v0.11.6 Mac archive. Findings apply to that source; the currently installed Mac binary may differ. Original files are preserved outside the audit working copy. The VPS was not modified during this work.

## 0.11.13 resource overhead and link relevance

The user reported approximately two busy CPU cores and 1.89 GB in Activity
Monitor during a 664-page crawl, with 3,572 raw records, 964 Included and 1,922
pending pages; pausing reduced CPU to 0.3%. Those observations establish a
processing-correlated load, not a specific leak diagnosis.

Code inspection identified repeated full filtering on progress changes,
main-thread event fan-out, duplicate JSON checkpoints and a long-lived Thread
without a per-page Objective-C autorelease pool. The candidate coalesces display
events, isolates/caches the result subtree, drains per-page temporary objects,
reuses decoding/parser work, and removes duplicate successful checkpoint writes.
A two-page fixture now writes three snapshots rather than five while preserving
a durable queue before either request and results after each page.

Generic "hosts" prose and incidental "about" substrings could prioritize
unrelated articles. Segment/label scoring and strong-topic terms reduce that
route to relevance drift. Direct contact aliases and explicit profiles remain
eligible; no new total-page, queue-size or crawl-depth cap is introduced.

128 core tests pass. Synthetic before/after measurements are documented in
PERFORMANCE.md. No assertion of a specific Mac CPU/RAM reduction or native GUI
validation follows from those tests. Existing saved results and pending URLs
remain preserved; already queued off-topic pages are not silently discarded.

## 0.11.12 additive selection and legacy Sentry endpoints

The previous grid used native replacement selection and explicit checkboxes
bound to the same set. The repair removes native ownership of the explicit set.
Plain cell clicks and checkbox actions both toggle/add the stable row UUID;
earlier selections survive additional clicks, live batches and order changes.
Cells show explicit-selection highlighting. The existing grid remains in use;
a broader native-table rewrite was not needed after the user clarified the
behavior. Core state tests are not native interaction tests.

Telemetry rejection previously covered ingest.sentry.io variants but missed a
32-hex-character DSN key at bare sentry.io. A shared technical-address policy
now catches that case before extraction acceptance and DNS checks. It preserves
ordinary sentry.io contacts and hexadecimal local parts on unrelated domains.
Saved records are reclassified on restore/resume, with identity/source/timestamp
preserved. Included view and accepted export independently enforce the policy;
All export labels preserved technical records Rejected with a correct reason.

117 core tests pass, including the reported key, near-miss preservation,
legacy-result handling, accepted exports, additive/mixed selection and live
batches. GUI selection remains an explicit Mac acceptance item.

## 0.11.11 wildcard filters and live results

Default sorting no longer starts alphabetically. Found order preserves the
collection sequence, with explicit alphabetical options and column sorting
retained. The table has explicit selection checkboxes, selectable email text,
Copy selected and a per-email copy/remove menu. These controls have no
crawl-running disable condition. Stable row identity is verified through live
batches and the final result replacement. Native interaction remains a GUI
acceptance item, not a cloud-verified claim.

Wildcard search and exclusions use a bounded non-regex matcher. * matches any
text and ? one character, matching a whole case-insensitive field. Literal
substring filtering remains unchanged. Reusable Wildcard rules preview and
apply consistently to existing/new rows and Included exports. 109 core tests
pass, including comparison to an independent wildcard reference and sorting
and streaming regressions. No VPS files were changed.

## 0.11.10 shared queue and concurrency

The candidate now supports 1–8 simultaneous sites, with one worker per site,
and a shared queue owned by the crawl coordinator. The right-hand panel lists
active pages, all pending page URLs and bounded recent activity. No worker owns
a private crawl frontier. Page URLs are deduplicated, unfinished requests stay
checkpointed, and optional page budgets reserve in-flight work. Native page
requests protect host aliases through leases and defer busy redirects back to
the frontier. Per-site delays are enforced without a global sleep in concurrent
native mode. Legacy checkpoints remain readable and default to concurrency 1.

Verification: 99 core tests pass, including measured five-way overlap with
per-site peak 1, shared-page visibility, stop/restart, pause/resume, limits,
host leases, blocked sources and redirect deferral. Application syntax parsing
and project references are checked separately. This candidate has not yet been
built or GUI-tested on macOS; the earlier 0.11.7 Mac build does not verify it.

## Findings repaired

| Finding | Original behavior | Repair and evidence |
|---|---|---|
| Adaptive traversal | Default depth zero did not follow links from an ordinary homepage | Always inspect seed links; follow promising contact/staff/sales/profile paths. Fixture verifies contact/fragment and sales traversal while skipping news. |
| URL aliases/fragments | Root URL aliases were distinct; links containing fragments could be missed | Normalize the empty root path and strip fragments after resolving links. Regression tests verify traversal and no repeated seed fetch during resume. |
| Explicit URL lists | Only the first four URLs per host were seeded | Retain all unique explicit URLs, respecting the user's page cap. Ten-URL and 300-page fixtures verify committed results/checkpoint counts. |
| Manual removal | Removed rows were deleted and appended to blocked terms, with no recovery path | Retain original rows, persist separate removal state, provide removal/restore controls, and keep reusable rules separate. |
| Filtering | All still hid rule matches; prefixes and preview labels were misleading | Centralize status/scope filtering, support Removed, correct prefix semantics, count Included rule impact, and add column sorting. |
| Checkpoint reliability | Errors were swallowed; up to nine pages and all smart-rule/removal metadata could be lost | Atomic checkpoints before requests/after pages; report failures and stop before unsafe progress; retain canceled pages and metadata. |
| Recovery | Completed checkpoints could not restore rows; loading checkpoint rows could overwrite newer verification | Restore results without pending links, autosave whole projects, merge stable identities using newer timestamps, and preserve unreadable/future-format files as recovery copies. |
| Concurrent windows/state changes | Separate window models shared a checkpoint file; opening/importing could change rows during verification | Share one application model; prevent conflicting import/open operations; reject changed-input continuation; use stable row IDs for verification updates. |
| Request limits | URLSession buffered entire responses before checking size; timed-out tasks could continue | Stream through bounded transfers, cancel timeouts, maintain shared native sessions/cookies/connection reuse, and validate redirects. Fixture concurrency/cancellation/limit tests exercise the transport. |
| Robots/rate handling | Wildcards, Allow precedence and named agents were ignored; unavailable robots could mean allow-all | Apply named-agent/longest-match rules, bounded wildcard matching, encoded-path normalization and crawl delays; fail closed on unavailable policy. Stop a restricted search provider rather than hammering its remaining queries. |
| DNS/syntax | Nonempty dig errors and null MX could appear valid; fallback absent; invalid dot/hyphen syntax passed | Parse MX/null-MX responses, distinguish failures, use A/AAAA fallback and stricter ASCII syntax. Never label local checks mailbox-verified. |
| False positives | Unicode addresses could be truncated into ASCII suffixes; some ingest endpoints slipped through; real providers were blanket placeholders | Protect Unicode boundaries and double-@ cases, decode mailto URIs deliberately, reject known telemetry, preserve valid hex locals and legitimate domain.com/email.com addresses. |
| Delimited imports | Swift treats CRLF as one Character; original parser could merge rows and accept malformed quoting | Parse CRLF, multiline fields, escaped quotes and BOMs correctly; reject malformed CSV. |
| Workbooks/subprocesses | Unbounded unzip output, unread stderr pipes, split rich-text addresses and no XML entity defense | Bound time/output/aggregate text, avoid unread stderr pipes, join text runs and reject DTD/external-entity inputs. |
| Exports | Quoting alone did not prevent spreadsheet formulas | Neutralize formula prefixes before CSV quoting. |
| Optional provider | HTTP status ignored; replacing a key deleted the prior key first; errors could continue a batch | Require successful HTTP/JSON; preserve uncertain/catch-all results; stop unavailable/rate-limited batches; update Keychain in place and retain existing keys on failure. Tests send no real addresses or keys. |
| Build metadata | Bundle version lagged the source, no Xcode test project | Versioned source candidate 0.11.7/build 14; added an Xcode app/core/test project and a backup-first verification script. |

## Verification boundaries

The final XCTest run executed 78 tests with zero failures, no skips and no compiler warnings. CORE-TESTS.log records the executed suite. Tests exercise actual portable Swift code with deterministic network/provider fixtures, native URLSession protocol fixtures, temporary files, real bounded unzip/process operations, and a 300-page fixture crawl. No live search coverage or Mac UI performance is inferred from fixture counts. Swift 6 may print a separate unused SwiftTesting zero-test summary after XCTest; the XCTest 'Executed ... tests' result is the relevant runner outcome.

The Swift compiler/toolchain was obtained from the official Swift download service and its detached signature verified with signing keys from the Swift project's official website-source repository. See TOOLCHAIN.md.

The macOS-only UI and Security branches were syntax parsed. The Xcode project property list, target/source references and scheme were checked. AppKit/SwiftUI type checking, Xcode build/test, actual Keychain behavior, UI actions and comparative live discovery have not been executed in this Linux environment. The Xcode project compiles the application as part of its test action so native compiler failures will be captured by verify-mac.sh before GUI acceptance.

## Remaining risks and limits

- No claim of perfection, signing/notarization, complete macOS acceptance or demonstrated live-search improvement is made. Follow MAC-ACCEPTANCE.md.
- The local crawler rejects credential-bearing and common private literal URLs but does not pin native URLSession connections to prevalidated DNS addresses. DNS rebinding/private-address aliases remain a hardening gap; this is not an internet-facing service implementation.
- Search sources, OSM coverage, US geographic expansion, ASCII email support and disposable lists retain the documented scope limits in README.md.
- Large-scale JSON autosaves/checkpoints can be costly; the 300-page fixture is not a days-long or million-record performance claim.
- CSV export and flattened-text XLSX import remain the native feature set; structured XLSX export and full column mapping were not added.
- The working original app must be retained until native acceptance succeeds. The source candidate does not replace it automatically.
