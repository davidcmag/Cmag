import Foundation
#if canImport(Darwin)
import Darwin
#else
import Glibc
#endif

enum MailAddressSafety {
    static func hostname(_ value: String) -> Bool {
        guard value.utf8.count <= 253, value.contains("."), !value.hasSuffix(".local"), !value.hasSuffix(".internal"), !value.hasSuffix(".localhost"), !value.hasSuffix(".home.arpa") else { return false }
        return value.split(separator: ".", omittingEmptySubsequences: false).allSatisfy {
            !$0.isEmpty && $0.utf8.count <= 63 && !$0.hasPrefix("-") && !$0.hasSuffix("-") && $0.utf8.allSatisfy { (48...57).contains($0) || (65...90).contains($0) || (97...122).contains($0) || $0 == 45 }
        } && value.utf8.contains { (65...90).contains($0) || (97...122).contains($0) }
    }
    /// Conservative globally routable unicast addresses only. Numeric destinations
    /// are checked again immediately before connect; DNS is never repeated there.
    static func publicIP(_ value: String) -> Bool {
        var v4 = in_addr(), v6 = in6_addr()
        if inet_pton(AF_INET, value, &v4) == 1 {
            let b = withUnsafeBytes(of: &v4) { Array($0) }; let a = Int(b[0]), c = Int(b[1])
            if [0,10,127].contains(a) || a >= 224 || (a == 100 && (64...127).contains(c)) || (a == 169 && c == 254) || (a == 172 && (16...31).contains(c)) || (a == 192 && [0,2,168].contains(c)) || (a == 198 && [18,19,51].contains(c)) || (a == 203 && c == 0 && b[2] == 113) { return false }
            return true
        }
        if inet_pton(AF_INET6, value, &v6) == 1 {
            let b = withUnsafeBytes(of: &v6) { Array($0) }
            guard (0x20...0x3f).contains(b[0]) else { return false }
            if b[0] == 0x20 && b[1] == 0x02 { return false } // 6to4 embeds another destination.
            if b[0] == 0x20 && b[1] == 0x01 && (b[2] < 2 || (b[2] == 0x0d && b[3] == 0xb8)) { return false }
            if b[0] == 0x3f && b[1] == 0xff { return false } // Documentation prefix.
            return true
        }
        return false
    }
}

struct MailRoute: Equatable {
    var host: String
    var preference: Int
    var addresses: [String]
}
struct MailRoutingResult: Equatable {
    enum State: String { case routes, nxDomain, nullMX, noMail, temporary, unknown }
    var state: State
    var routes: [MailRoute] = []
    var reason: String
}

/// Serial-batch resolver. DNS text is bounded by SafeProcess and only answer
/// records of the requested type are consumed. Failed/partial lookups cannot
/// turn into implicit-MX fallback or a definitive invalid-mailbox verdict.
final class MailRouting {
    typealias Query = (String, String) throws -> String
    private let query: Query
    private let now: () -> Date
    private var cache: [String: (Date, MailRoutingResult)] = [:]
    init(query: @escaping Query = MailRouting.dig, now: @escaping () -> Date = Date.init) { self.query = query; self.now = now }
    static func dig(_ host: String, _ type: String) throws -> String {
        guard MailAddressSafety.hostname(host), ["MX", "A", "AAAA"].contains(type) else { throw SMTPFailure.invalidInput }
        let data = try SafeProcess.run("/usr/bin/dig", ["+time=2", "+tries=1", "+noall", "+comments", "+answer", host, type], maxBytes: 64_000, timeout: 4)
        return String(decoding: data, as: UTF8.self)
    }
    struct Answer {
        var status: String
        var rows: [[String]]
    }
    static func parse(_ text: String, type: String) -> Answer? {
        guard text.utf8.count <= 64_000,
              let range = text.range(of: #"status: ([A-Z]+),"#, options: .regularExpression) else { return nil }
        let status = text[range].replacingOccurrences(of: "status: ", with: "").replacingOccurrences(of: ",", with: "")
        let rows = text.split(whereSeparator: \.isNewline).filter { !$0.hasPrefix(";") }.map { $0.split(whereSeparator: \.isWhitespace).map(String.init) }.filter { $0.count >= 5 && $0[2] == "IN" && $0[3] == type }
        return Answer(status: status, rows: rows)
    }
    func resolve(_ domain: String, cancelled: () -> Bool = { false }) -> MailRoutingResult {
        let domain = domain.lowercased()
        guard MailAddressSafety.hostname(domain) else { return .init(state: .unknown, reason: "Unsupported or non-public domain name") }
        if let (date, result) = cache[domain], now().timeIntervalSince(date) < 60 { return result }
        let result = lookup(domain, cancelled: cancelled)
        if cache.count >= 512 { cache.removeAll() }
        cache[domain] = (now(), result)
        return result
    }
    private func lookup(_ domain: String, cancelled: () -> Bool) -> MailRoutingResult {
        do {
            guard !cancelled() else { throw SMTPFailure.cancelled }
            guard let mx = Self.parse(try query(domain, "MX"), type: "MX") else { return .init(state: .unknown, reason: "Unparseable DNS response") }
            if mx.status == "NXDOMAIN" { return .init(state: .nxDomain, reason: "DNS reports domain does not exist") }
            guard mx.status == "NOERROR" else { return .init(state: .temporary, reason: "DNS " + mx.status) }
            var hosts: [(Int, String)] = []
            for row in mx.rows {
                guard row.count == 6, let preference = UInt16(row[4]) else { return .init(state: .unknown, reason: "Malformed MX record") }
                if row[5] == "." {
                    guard preference == 0, mx.rows.count == 1 else { return .init(state: .unknown, reason: "Conflicting null MX records") }
                    return .init(state: .nullMX, reason: "Explicit null MX: domain accepts no email")
                }
                let host = row[5].hasSuffix(".") ? String(row[5].dropLast()) : row[5]
                guard MailAddressSafety.hostname(host) else { return .init(state: .unknown, reason: "Unsafe MX hostname") }
                hosts.append((Int(preference), host.lowercased()))
            }
            let implicit = hosts.isEmpty
            if implicit { hosts = [(0, domain)] }
            hosts.sort { $0.0 == $1.0 ? $0.1 < $1.1 : $0.0 < $1.0 }
            var routes: [MailRoute] = []; var incomplete = false
            for (priority, host) in hosts.prefix(5) {
                guard !cancelled() else { throw SMTPFailure.cancelled }
                var addresses: [String] = []
                for type in ["A", "AAAA"] {
                    guard !cancelled() else { throw SMTPFailure.cancelled }
                    guard let answer = Self.parse(try query(host, type), type: type), answer.status == "NOERROR" else { incomplete = true; continue }
                    for row in answer.rows {
                        guard row.count == 5, MailAddressSafety.publicIP(row[4]) else { incomplete = true; continue }
                        if !addresses.contains(row[4]) { addresses.append(row[4]) }
                    }
                }
                // Keep unavailable preferred routes so a backup cannot establish
                // invalidity while a higher-priority server was unreachable.
                routes.append(MailRoute(host: host, preference: priority, addresses: Array(addresses.prefix(4))))
            }
            if routes.contains(where: { !$0.addresses.isEmpty }) { return .init(state: .routes, routes: routes, reason: implicit ? "Implicit address-record mail route" : "Explicit MX routes") }
            return .init(state: incomplete ? .temporary : (implicit ? .noMail : .unknown), reason: incomplete ? "DNS incomplete or no safe public destination" : "No usable mail destination")
        } catch { return .init(state: .temporary, reason: cancelled() ? "Cancelled during DNS lookup" : "DNS lookup unavailable or failed") }
    }
}
