import Foundation

/// Only the crawl coordinator changes reservations. Workers return network
/// outcomes through a condition-protected mailbox; they never mutate results,
/// the frontier, or checkpoint files.
final class CrawlFetchPool {
    struct Job {
        let url: URL
        let level: Int
        let host: String
        var key: String { url.absoluteString }
        var sites: Set<String> {
            [host, EmailPolicy.canonicalHost(url.host ?? host)]
        }
    }
    struct Outcome {
        let allowed: Bool
        let response: HTTPResult?
    }
    enum Message {
        case activity(CrawlActivity)
        case finished(Job, Outcome)
    }
    private let condition = NSCondition()
    private var messages: [Message] = []
    private let group = DispatchGroup()
    private(set) var jobs: [String: Job] = [:]
    var count: Int { jobs.count }
    func canStart(_ job: Job) -> Bool {
        !jobs.values.contains { !$0.sites.isDisjoint(with: job.sites) }
    }
    func start(_ job: Job, work: @escaping (@escaping (CrawlActivity) -> Void) -> Outcome) {
        jobs[job.key] = job
        group.enter()
        DispatchQueue.global(qos: .utility).async {
            let result = work { event in self.send(.activity(event)) }
            self.send(.finished(job, result))
            self.group.leave()
        }
    }
    private func send(_ message: Message) {
        condition.lock(); messages.append(message); condition.signal(); condition.unlock()
    }
    func receive(wait: Bool) -> [Message] {
        condition.lock(); defer { condition.unlock() }
        if wait && messages.isEmpty { _ = condition.wait(until: Date().addingTimeInterval(0.1)) }
        let result = messages; messages.removeAll(keepingCapacity: true); return result
    }
    func release(_ job: Job) { jobs.removeValue(forKey: job.key) }
    func join() { group.wait() }
}

/// Covers host aliases encountered through redirects. Cross-host redirects
/// never wait while holding another site's lease (which could deadlock two
/// redirect chains); busy destinations return to the crawl frontier instead.
final class CrawlRequestGate {
    final class Lease { fileprivate let id = UUID(); fileprivate var closed = false }
    private let condition = NSCondition()
    private var owners: [String: UUID] = [:]
    private var availableAt: [String: Date] = [:]
    func claim(_ url: URL, owner: Lease, wait: Bool, cancelled: () -> Bool) -> Bool {
        let host = EmailPolicy.canonicalHost(url.host ?? "")
        while true {
            condition.lock()
            if owner.closed { condition.unlock(); return false }
            let existing = owners[host]
            let delay = availableAt[host]?.timeIntervalSinceNow ?? 0
            if existing == owner.id || (existing == nil && delay <= 0) {
                owners[host] = owner.id
                condition.unlock()
                return true
            }
            if !wait { condition.unlock(); return false }
            _ = condition.wait(until: Date().addingTimeInterval(0.05))
            condition.unlock()
            if cancelled() { return false }
        }
    }
    func release(_ owner: Lease, delay: TimeInterval) {
        condition.lock()
        owner.closed = true
        let hosts = owners.filter { $0.value == owner.id }.map { $0.key }
        for host in hosts {
            owners.removeValue(forKey: host)
            availableAt[host] = Date().addingTimeInterval(delay)
        }
        condition.broadcast(); condition.unlock()
    }
}
