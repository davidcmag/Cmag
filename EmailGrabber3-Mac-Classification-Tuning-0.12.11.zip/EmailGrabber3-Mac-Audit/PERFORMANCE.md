# 0.11.13 resource verification

The screenshot supplied by the user showed a 664-page / 117-scanned-site crawl,
3,572 raw addresses, 964 Included results, 12 rules and 1,922 queued pages.
Activity Monitor showed about 198.7% CPU and 1.89 GB. Paused CPU fell to 0.3%.
No native profiler trace was available; this is not proof of a memory leak.

## Synthetic comparison

Environment: Linux x86_64, Swift 6.0.3, swiftc -O, local fixtures only.
Baseline sources were extracted from the published 0.11.12 ZIP. Both programs
parse 3,000 anchors three times and refresh 3,572 rows against 12 prefix rules
25 times with unchanged records. The candidate uses its incremental cache.
Matching checksums verify the same number of parsed/returned records.

Baseline:
```
anchors=9000, unchanged_result_refreshes=25, rows=3572, rules=12
anchor_seconds=0.8362 filter_seconds=4.3218 checksum=98300
```

Candidate:
```
anchors=9000, unchanged_result_refreshes=25, rows=3572, rules=12
anchor_seconds=0.2320 filter_seconds=0.1420 checksum=98300
```

These are single-run hot-path measurements, not an application-wide speedup,
website throughput measurement, or a macOS CPU/RAM prediction. Tests verify
that 100 unchanged display refreshes evaluate the original 3,572 rows only once,
and an appended row causes one further predicate evaluation. Changes to rules,
removal, scope, query, record status and sort are covered separately.

## Memory and persistence

Display history stays bounded at 100 entries, while all 1,922 pending fixture
URLs remain available. Mailbox draining never drops row deltas; only intermediate
progress/queue snapshots are replaced by their latest version. Final data is
drained before finishing a job. Background native Foundation temporary objects
are drained per processing step using autoreleasepool on macOS.

Full JSON checkpoint cost still grows with job size. Completed-page durability
is preserved; duplicate snapshots of the exact same successful state are removed.
A two-page fixture writes three snapshots: initial, first page, second page.
Failure, cancellation, concurrent work and restart fixtures continue to pass.

The current suite contains 128 passing portable core tests. AppKit/SwiftUI and
the Objective-C pool's real memory effect require the user's Mac. Use the saved
session and the backup made by verify-mac.sh for a reversible comparison.
