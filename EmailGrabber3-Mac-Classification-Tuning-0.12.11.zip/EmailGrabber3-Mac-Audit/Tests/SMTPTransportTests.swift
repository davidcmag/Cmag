import XCTest
import Foundation
#if canImport(Darwin)
import Darwin
#else
import Glibc
#endif
@testable import EmailGrabberCore

final class SMTPTransportTests: XCTestCase {
    func pair() throws -> (SMTPSocketWire, Int32) {
        var fds: [Int32] = [-1,-1]
        #if os(Linux)
        let kind = Int32(SOCK_STREAM.rawValue)
        #else
        let kind = SOCK_STREAM
        #endif
        guard socketpair(AF_UNIX, kind, 0, &fds) == 0 else { throw SMTPFailure.connection }
        return (try SMTPSocketWire(connectedFD: fds[0], timeout: 0.2), fds[1])
    }
    func sendText(_ value: String, _ fd: Int32) {
        let bytes = Array(value.utf8)
        _ = bytes.withUnsafeBytes { write(fd, $0.baseAddress!, bytes.count) }
    }
    func testFragmentedMultilineReplyAndCRLFCommand() throws {
        let (wire, peer) = try pair(); defer { wire.close(); _ = close(peer) }
        let done = expectation(description: "fixture server")
        DispatchQueue.global().async {
            self.sendText("250-m", peer); self.sendText("x\r\n250 ready\r\n", peer)
            var bytes = [UInt8](repeating: 0, count: 256)
            let n = read(peer, &bytes, bytes.count)
            XCTAssertEqual(String(decoding: bytes.prefix(max(0,n)), as: UTF8.self), "RSET\r\n")
            self.sendText("250 reset\r\n", peer); done.fulfill()
        }
        XCTAssertEqual(try wire.readReply().lines, ["mx", "ready"])
        XCTAssertEqual(try wire.command("RSET").code, 250)
        wait(for: [done], timeout: 2)
    }
    func testTimeout() throws {
        let (wire, peer) = try pair(); defer { wire.close(); _ = close(peer) }
        let before = Date(); XCTAssertThrowsError(try wire.readReply()) { XCTAssertEqual($0 as? SMTPFailure, .timeout) }
        XCTAssertLessThan(Date().timeIntervalSince(before), 1)
    }
    func testCancellationBeforeIO() throws {
        var fds: [Int32] = [-1,-1]
        #if os(Linux)
        let kind = Int32(SOCK_STREAM.rawValue)
        #else
        let kind = SOCK_STREAM
        #endif
        XCTAssertEqual(socketpair(AF_UNIX, kind, 0, &fds), 0)
        let wire = try SMTPSocketWire(connectedFD: fds[0], cancelled: { true }); defer { wire.close(); _ = close(fds[1]) }
        XCTAssertThrowsError(try wire.readReply()) { XCTAssertEqual($0 as? SMTPFailure, .cancelled) }
    }
    func testOversizedAndBareLFRepliesRejected() throws {
        for text in [String(repeating: "x", count: 2100), "250 bare\n"] {
            let (wire, peer) = try pair(); defer { wire.close(); _ = close(peer) }
            sendText(text, peer); XCTAssertThrowsError(try wire.readReply())
        }
    }
    func testCommandInjectionAndMessageCommandsRejected() throws {
        let (wire, peer) = try pair(); defer { wire.close(); _ = close(peer) }
        for value in ["EHLO sender.org\r\nDATA", "DATA", "VRFY a@b.org", "EXPN list", "AUTH PLAIN abc", String(repeating: "x", count: 511)] { XCTAssertThrowsError(try wire.command(value)) { XCTAssertEqual($0 as? SMTPFailure, .invalidInput) } }
    }
    func testClosedPeerIsNotSuccessfulReply() throws {
        let (wire, peer) = try pair(); _ = close(peer); defer { wire.close() }
        XCTAssertThrowsError(try wire.readReply())
    }
    func testProductionInitializerRejectsPrivateDestinationBeforeConnect() {
        XCTAssertThrowsError(try SMTPSocketWire(ip: "127.0.0.1", host: "mx.public.org", timeout: 1, cancelled: { false })) { XCTAssertEqual($0 as? SMTPFailure, .invalidInput) }
    }
    func testCancellationInterruptsBlockedRead() throws {
        var fds: [Int32] = [-1,-1]
        #if os(Linux)
        let kind = Int32(SOCK_STREAM.rawValue)
        #else
        let kind = SOCK_STREAM
        #endif
        XCTAssertEqual(socketpair(AF_UNIX, kind, 0, &fds), 0)
        let control = CrawlControl()
        let wire = try SMTPSocketWire(connectedFD: fds[0], timeout: 5, cancelled: { control.wasCancelled })
        defer { wire.close(); _ = close(fds[1]) }
        DispatchQueue.global().asyncAfter(deadline: .now() + 0.05) { control.cancel() }
        let before = Date()
        XCTAssertThrowsError(try wire.readReply()) { XCTAssertEqual($0 as? SMTPFailure, .cancelled) }
        XCTAssertLessThan(Date().timeIntervalSince(before), 0.5)
    }

}
