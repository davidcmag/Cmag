import XCTest
import Foundation
@testable import EmailGrabberCore

final class RecoveryAndFilteringTests: DiskTests {
    func testManualClassificationSurvivesProjectReopenAndRecrawlDuplicates() throws {
        var session = project()
        let original = session.rows[0]
        session.rows = ClassificationEdits.set(session.rows, selected: [original.id], category: .general)
        XCTAssertTrue(CrawlDisk.saveProject(session))
        let restored = try XCTUnwrap(CrawlDisk.loadProject())
        XCTAssertEqual(restored.rows[0].addressClassification.category, .general)
        let options = GrabSettings(depth: 0, maxPages: 0, maxPagesPerDomain: 0, exclude: "", duplicates: false, role: false, free: false, disposable: false, dns: false)
        let engine = GrabEngine(settings: options, sleep: { _ in })
        let result = engine.run(mode: .pasted, terms: [original.address], existing: restored.rows, liveRows: { batch in
            XCTAssertEqual(batch.first?.addressClassification.category, .general)
        }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(result.count, 2)
        XCTAssertTrue(result.allSatisfy { $0.classificationDecision == restored.rows[0].classificationDecision })
    }
    func testManualResetSurvivesLateCheckpointWrites() throws {
        let original = makeEmailFixture("info@public.org")
        let edited = ClassificationEdits.set([original], selected: [original.id], category: .person, at: Date(timeIntervalSince1970: 1))
        let reset = ClassificationEdits.set(edited, selected: [original.id], category: nil, at: Date(timeIntervalSince1970: 2))
        var snapshot = CrawlProgress(queue: [], visited: [], queued: [], robotRules: [:], domainPageCount: [:], discoveredCount: 0, scanned: 0, rows: edited, selectedSites: [], settings: CrawlOptions(depth: 0, maxPages: 0, maxPagesPerDomain: 0, excluded: "", stripDuplicates: true, excludeRole: false, excludeFree: false, excludeDisposable: false, checkDNS: false), input: "")
        CrawlDisk.updatePresentation(rules: [], removal: RemovalState(), classifications: reset)
        XCTAssertTrue(CrawlDisk.save(snapshot))
        XCTAssertEqual(CrawlDisk.load()?.rows[0].addressClassification.category, .general)
        snapshot.rows = edited // worker still has its older copy
        XCTAssertTrue(CrawlDisk.save(snapshot))
        XCTAssertEqual(CrawlDisk.load()?.rows[0].classificationDecision, reset[0].classificationDecision)
    }
    func project() -> GrabSession {
        GrabSession(mode: .website, input: "https://public.org", excluded: "", depth: 0, maxPages: 0, maxPagesPerDomain: 0, stripDuplicates: true, excludeRole: false, excludeFree: false, excludeDisposable: true, checkDNS: false, rows: [makeEmailFixture("jane@public.org")], discoveredSites: [], directoryDiscovery: false, osmStateCode: "", smartRules: [], removedAddresses: ["old@public.org"], removalHistory: [["old@public.org"]], projectID: UUID())
    }
    func testAutosaveRoundTripIncludesRecoveryStateButNoAPIKey() throws {
        let value = project(); XCTAssertTrue(CrawlDisk.saveProject(value))
        let restored = CrawlDisk.loadProject()!
        XCTAssertEqual(restored.rows.count, 1); XCTAssertEqual(restored.projectID, value.projectID)
        XCTAssertEqual(restored.removedAddresses, value.removedAddresses)
        let contents = try String(contentsOf: CrawlDisk.projectURL)
        XCTAssertFalse(contents.contains("api_key")); XCTAssertFalse(contents.contains("verifierKey"))
    }
    func testCorruptAutosaveIsPreservedAndReported() throws {
        let bad = Data("not-json".utf8); try bad.write(to: CrawlDisk.projectURL)
        XCTAssertNil(CrawlDisk.loadProject()); XCTAssertNotNil(CrawlDisk.lastError)
        XCTAssertEqual(try Data(contentsOf: CrawlDisk.projectURL), bad)
        let copies = try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil).filter { $0.lastPathComponent.hasPrefix("recovery-") }
        XCTAssertEqual(copies.count, 1); XCTAssertEqual(try Data(contentsOf: copies[0]), bad)
    }
    func testMergeKeepsCheckpointRowsAndNewerVerification() {
        let old = makeEmailFixture("jane@public.org"); var newer = old; newer.status = "Verified"; newer.checkedAt = old.checkedAt.addingTimeInterval(1)
        let other = makeEmailFixture("other@public.org")
        let merged = ResultMerge.combine([old,other], [newer])
        XCTAssertEqual(merged.count, 2); XCTAssertEqual(merged.first?.status, "Verified")
    }
    func testDuplicateSavedIDsDoNotTrapRecovery() {
        let row = makeEmailFixture("jane@public.org")
        XCTAssertEqual(ResultMerge.combine([row,row], [row]).count, 1)
    }
    func testAllIncludedRemovedAndExcludedViewsAreConsistent() {
        let rows = [makeEmailFixture("jane@public.org"),makeEmailFixture("info@public.org"),makeEmailFixture("other@public.org")]
        let rules = [SmartRule(kind: "Address", pattern: "jane@public.org")]
        let removed: Set<String> = ["info@public.org"]
        func view(_ value: String) -> [FoundEmail] { ResultPolicy.filtered(rows, rules: rules, removed: removed, status: value, search: "", scope: "Email") }
        XCTAssertEqual(view("All").count, 3)
        XCTAssertEqual(view("Included").map(\.address), ["other@public.org"])
        XCTAssertEqual(view("Removed").map(\.address), ["info@public.org"])
        XCTAssertEqual(view("Excluded").map(\.address), ["jane@public.org"])
    }
    func testEmailSearchDoesNotMatchSourceByDefault() {
        let rows = [makeEmailFixture("jane@public.org")]
        XCTAssertTrue(ResultPolicy.filtered(rows, rules: [], removed: [], status: "Included", search: "fixture", scope: "Email").isEmpty)
        XCTAssertEqual(ResultPolicy.filtered(rows, rules: [], removed: [], status: "Included", search: "fixture", scope: "Source").count, 1)
    }
    func testLiteralPrivateDestinationsAndAlternateLoopbackFormsAreRejected() {
        for text in ["http://localhost/","http://127.0.0.1/","http://127.1/","http://2130706433/","http://0x7f000001/","http://10.0.0.1/","http://169.254.169.254/","http://[::1]/","http://[fe80::1]/"] {
            XCTAssertFalse(EmailPolicy.httpURL(URL(string: text)!), text)
        }
        XCTAssertTrue(EmailPolicy.httpURL(URL(string: "https://public.org/")!))
    }
    func testDeclaredLatin1EncodingIsHonored() {
        let result = HTTPResult(data: Data([74,233]), status: 200, charset: "iso-8859-1")
        XCTAssertEqual(result.decodedText, "Jé")
    }
    func testRealDomainAndEmailProviderAreNotBlanketPlaceholders() {
        let engine = GrabEngine(settings: settings(), sleep: { _ in })
        let rows = engine.run(mode: .pasted, terms: ["support@domain.com member@email.com"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(rows.filter { $0.status == "Accepted" }.count, 2)
    }
    func testDirectSentryIngestAndWixTelemetrySubdomainAreExcluded() {
        let engine = GrabEngine(settings: settings(), sleep: { _ in })
        let rows = engine.run(mode: .pasted, terms: ["id@ingest.sentry.io id@region.sentry-next.wixpress.com"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertTrue(rows.isEmpty)
    }
}

final class EfficiencyTests: DiskTests {
    func testLiveResultsAreBatchesOfNewRowsRatherThanFullRepeatedArrays() {
        var live: [FoundEmail] = []; var callbacks = 0
        let engine = GrabEngine(settings: settings(), sleep: { _ in })
        let text = (0..<100).map { "person\($0)@public.org" }.joined(separator: " ")
        let rows = engine.run(mode: .pasted, terms: [text], existing: [], liveRows: { live += $0; callbacks += 1 }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(rows.count, 100); XCTAssertEqual(live.count, 100); XCTAssertLessThanOrEqual(callbacks, 5)
        XCTAssertEqual(Set(live.map(\.id)).count, 100)
    }
    func testAllExplicitPagesOnSameHostAreRetained() {
        let engine = GrabEngine(settings: settings(), fetcher: { url in
            response(url.path == "/robots.txt" ? "User-agent: *" : "person\(url.lastPathComponent)@public.org", url)
        }, sleep: { _ in })
        let urls = (0..<10).map { "https://public.org/people/\($0)" }
        let rows = engine.run(mode: .website, terms: urls, existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(rows.count, 10); XCTAssertEqual(CrawlDisk.load()?.scanned, 10)
    }
    func testThreeHundredPageCrawlCompletesWithRecoverableResults() {
        let engine = GrabEngine(settings: settings(), fetcher: { url in
            response(url.path == "/robots.txt" ? "User-agent: *" : "person\(url.lastPathComponent)@public.org", url)
        }, sleep: { _ in })
        let urls = (0..<300).map { "https://public.org/people/\($0)" }
        let rows = engine.run(mode: .website, terms: urls, existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(rows.count, 300); XCTAssertEqual(CrawlDisk.load()?.scanned, 300)
        XCTAssertEqual(CrawlDisk.load()?.rows.count, 300); XCTAssertTrue(CrawlDisk.load()?.queue.isEmpty == true)
    }
}

final class UnicodeBoundaryTests: DiskTests {
    func testUnsupportedUnicodeAddressDoesNotBecomeFalseASCIISuffix() {
        let engine = GrabEngine(settings: settings(), sleep: { _ in })
        let rows = engine.run(mode: .pasted, terms: ["mañana@public.org jane@public.orgé"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertTrue(rows.isEmpty)
    }
}

final class RobotsBoundsTests: XCTestCase {
    func testPercentEncodedUnreservedPathsMatchTheirRules() {
        let rules = RobotsPolicy("User-agent: *\nDisallow: /%63ontact")
        XCTAssertFalse(rules.allows(URL(string: "https://public.org/contact")!))
    }
    func testQueryAndEndAnchorDoNotHideLongerPaths() {
        let rules = RobotsPolicy("User-agent: *\nDisallow: /*?private=1$")
        XCTAssertFalse(rules.allows(URL(string: "https://public.org/contact?private=1")!))
        XCTAssertTrue(rules.allows(URL(string: "https://public.org/contact?private=10")!))
    }
    func testPathologicalPatternIsBoundedAndFailsClosed() {
        let rules = RobotsPolicy(rules: [.init(allow: true, pattern: "/"), .init(allow: false, pattern: "/*"+String(repeating: "a", count: 2000)+"b$")])
        XCTAssertFalse(rules.allows(URL(string: "https://public.org/"+String(repeating: "a", count: 12_000))!))
    }
    func testOversizedRulesFailClosed() {
        XCTAssertFalse(RobotsPolicy(rules: [.init(allow: false, pattern: "/"+String(repeating: "a", count: 5000))]).allows(URL(string: "https://public.org/")!))
    }
}

final class MailtoTests: DiskTests {
    func collect(_ text: String) -> [FoundEmail] {
        GrabEngine(settings: settings(), sleep: { _ in }).run(mode: .pasted, terms: [text], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
    }
    func testPercentEncodedMailtoIsDecoded() { XCTAssertEqual(collect("<a href='mailto:jane%2Btag%40public.org'>Email</a>").map(\.address), ["jane+tag@public.org"]) }
    func testLiteralPercentInPlainEmailIsPreserved() { XCTAssertEqual(collect("jane%40sales@public.org").map(\.address), ["jane%40sales@public.org"]) }
    func testMalformedDoubleAtDoesNotBecomeAnotherMailbox() { XCTAssertTrue(collect("one@jane@public.org").isEmpty) }
}
