import XCTest
import Foundation
@testable import EmailGrabberCore

final class SelectionAndTelemetryTests: DiskTests {
    let sentryKey = "8c4075d5481d476e945486754f783364"
    func testReportedRootSentryKeyIsRejectedBeforeValidation() {
        var dnsCalls = 0
        let engine = GrabEngine(settings: settings(dns: true), dns: { _ in dnsCalls += 1; return .mx }, sleep: { _ in })
        let rows = engine.run(mode: .pasted, terms: [sentryKey + "@sentry.io"], existing: [], liveRows: { _ in XCTFail("Telemetry must never enter live results") }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertTrue(rows.isEmpty)
        XCTAssertEqual(dnsCalls, 0)
    }
    func testKnownTelemetryAndAssetsAreRejectedButRealAddressesArePreserved() {
        for value in [
            sentryKey + "@sentry.io", sentryKey.uppercased() + "@SENTRY.IO",
            sentryKey + "@errors.sentry.io", "key@o123.ingest.us.sentry.io",
            "key@sentry.wixpress.com", "key@sentry-next.wixpress.com", "logo@2x.png"
        ] {
            XCTAssertNotNil(TechnicalAddressPolicy.rejectionReason(value), value)
        }
        for value in ["support@sentry.io","care@sentry.io","support@wixpress.com",sentryKey + "@public.org",sentryKey + "@not-sentry.io"] {
            XCTAssertNil(TechnicalAddressPolicy.rejectionReason(value), value)
        }
    }
    func testExistingSentryResultLeavesIncludedAndAcceptedExportsButRemainsRecoverable() {
        var bad = makeEmailFixture(sentryKey + "@sentry.io")
        bad.status = "Verified"; bad.reason = "Old provider result"
        let good = makeEmailFixture("person@public.org")
        let rows = [bad,good]
        let included = ResultPolicy.filtered(rows, rules: [], removed: [], status: "Included", search: "", scope: "Email")
        let rejected = ResultPolicy.filtered(rows, rules: [], removed: [], status: "Rejected", search: "", scope: "Email")
        XCTAssertEqual(included.map(\.id), [good.id])
        XCTAssertEqual(rejected.map(\.id), [bad.id])
        XCTAssertEqual(ResultPolicy.displayedStatus(bad, rules: [], removed: []), "Rejected")
        XCTAssertTrue(ResultPolicy.displayedReason(bad).contains("telemetry"))
        XCTAssertEqual(ResultPolicy.exportRows(rows, rules: [], removed: [], onlyAccepted: true).map(\.id), [good.id])
        let all = ResultPolicy.exportRows(rows, rules: [], removed: [], onlyAccepted: false)
        XCTAssertEqual(all.map(\.id), [bad.id,good.id])
        XCTAssertEqual(all.first?.status, "Rejected")
        XCTAssertEqual(all.first?.source, bad.source)
        XCTAssertEqual(all.first?.checkedAt, bad.checkedAt)
        XCTAssertEqual(bad.status, "Verified") // Classification of a value-copy does not destroy evidence.
    }
    func testResumeReclassifiesExistingTechnicalRecordAndRetainsItsIdentity() {
        let old = makeEmailFixture(sentryKey + "@sentry.io")
        let engine = GrabEngine(settings: settings(), sleep: { _ in })
        let rows = engine.run(mode: .pasted, terms: ["support@sentry.io person@public.org"], existing: [old], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(rows.first?.id, old.id)
        XCTAssertEqual(rows.first?.status, "Rejected")
        XCTAssertEqual(rows.filter { $0.status == "Accepted" }.count, 2)
    }
    func testAcceptedExportStillHonorsRulesAndManualRemoval() {
        let rows = ["info@public.org","person@public.org","jane@other.org"].map(makeEmailFixture)
        let rules = [SmartRule(kind: "Wildcard", pattern: "info@*")]
        XCTAssertEqual(ResultPolicy.exportRows(rows, rules: rules, removed: ["person@public.org"], onlyAccepted: true).map(\.address), ["jane@other.org"])
    }
    func testPlainClicksAccumulateSelectionAndToggleOnlyTheClickedRow() {
        let ids = (0..<4).map { _ in UUID() }
        var selected = Set<UUID>()
        for id in ids { selected = ResultSelection.updated(selected, id: id) }
        XCTAssertEqual(selected, Set(ids))
        selected = ResultSelection.updated(selected, id: ids[1])
        XCTAssertEqual(selected, Set([ids[0],ids[2],ids[3]]))
        selected = ResultSelection.updated(selected, id: ids[1])
        XCTAssertEqual(selected, Set(ids))
    }
    func testCheckboxAndRowActionsShareAnAdditiveSelection() {
        let first = UUID(), second = UUID(), third = UUID()
        var selected = ResultSelection.updated([], id: first)
        selected = ResultSelection.updated(selected, id: second, selected: true)
        selected = ResultSelection.updated(selected, id: second, selected: true)
        selected = ResultSelection.updated(selected, id: third)
        XCTAssertEqual(selected, [first,second,third])
        selected = ResultSelection.updated(selected, id: first, selected: false)
        XCTAssertEqual(selected, [second,third])
    }
    func testMultiSelectionSurvivesLiveBatchesAndOrderChanges() {
        var selected = Set<UUID>()
        var streamed: [FoundEmail] = []
        let engine = GrabEngine(settings: settings(), sleep: { _ in })
        let final = engine.run(mode: .pasted, terms: [(0..<80).map { "person\($0)@public.org" }.joined(separator: " ")], existing: [], liveRows: { batch in
            streamed.append(contentsOf: batch)
            if selected.isEmpty {
                for row in batch.prefix(3) { selected = ResultSelection.updated(selected, id: row.id) }
            }
            let sorted = ResultOrdering.apply(streamed, order: ResultOrdering.comparators("Email A–Z")!)
            XCTAssertEqual(sorted.filter { selected.contains($0.id) }.count, 3)
        }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(final.filter { selected.contains($0.id) }.count, 3)
        XCTAssertEqual(final.map(\.id), streamed.map(\.id))
    }
}
