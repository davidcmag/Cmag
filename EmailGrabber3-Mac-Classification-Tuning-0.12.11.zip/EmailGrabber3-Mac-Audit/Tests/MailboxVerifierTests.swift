import XCTest
@testable import EmailGrabberCore

final class ScriptedSMTP: SMTPWire {
    var commands: [String] = []
    var replies: [String]
    var failTLS = false
    var didTLS = false
    var closed = false
    init(_ replies: [String]) { self.replies = replies }
    func readReply() throws -> SMTPReply {
        guard !replies.isEmpty else { throw SMTPFailure.disconnected }
        let reply = replies.removeFirst()
        var lines = reply.components(separatedBy: "\r\n").filter { !$0.isEmpty }
        return try SMTPReply.read { guard !lines.isEmpty else { throw SMTPFailure.disconnected }; return Data((lines.removeFirst() + "\r\n").utf8) }
    }
    func command(_ value: String) throws -> SMTPReply { commands.append(value); return try readReply() }
    func startTLS(host: String) throws { if failTLS { throw SMTPFailure.tlsFailed }; didTLS = true }
    func close() { closed = true }
}
final class MailboxVerifierTests: XCTestCase {
    let route = MailRoute(host: "mx.public.org", preference: 10, addresses: ["8.8.8.8"])
    var options: SMTPOptions { SMTPOptions(ehlo: "mail.sender.org", sender: "check@sender.org") }
    func verifier(_ wire: ScriptedSMTP, routes: [MailRoute]? = nil) -> MailboxVerifier {
        MailboxVerifier(resolve: { _,_ in .init(state: .routes, routes: routes ?? [self.route], reason: "fixture") }, connect: { _,_,_,_ in wire })
    }
    func sequence(_ target: String = "250 target", _ a: String = "550 5.1.1 no user", _ b: String = "550 5.1.1 no user", tls: Bool = true) -> [String] {
        var s = ["220 ready", tls ? "250-mx\r\n250 STARTTLS" : "250 hello"]
        if tls { s += ["220 begin TLS", "250 hello TLS"] }
        s += ["250 reset", "250 sender", target]
        if target.hasPrefix("250") || target.hasPrefix("251") { s += ["250 reset", "250 sender", a, "250 reset", "250 sender", b] }
        return s + ["250 reset", "221 bye"]
    }
    func testTargetAndTwoRejectedControlsEstablishAcceptanceOnly() {
        let wire = ScriptedSMTP(sequence()); let answer = verifier(wire).verify("person@public.org", options: options)
        XCTAssertEqual(answer.verdict, .accepted); XCTAssertTrue(answer.reason.contains("not guaranteed"))
        XCTAssertTrue(wire.didTLS); XCTAssertTrue(wire.closed)
        let recipients = wire.commands.filter { $0.hasPrefix("RCPT TO:") }
        XCTAssertEqual(recipients.count, 3); XCTAssertEqual(Set(recipients).count, 3)
        XCTAssertEqual(recipients.first, "RCPT TO:<person@public.org>")
        XCTAssertEqual(wire.commands.filter { $0 == "RSET" }.count, 4)
        XCTAssertFalse(wire.commands.contains { ["DATA", "AUTH", "VRFY", "EXPN"].contains($0.components(separatedBy: " ")[0]) })
        XCTAssertTrue(answer.observations.contains { $0.tls && $0.stage == "target RCPT" })
    }
    func testAllRecipientsAcceptedAreCatchAll() {
        XCTAssertEqual(verifier(ScriptedSMTP(sequence("250 ok", "250 ok", "250 ok"))).verify("a@public.org", options: options).verdict, .catchAll)
    }
    func testMixedControlsAreUnknown() {
        for control in ["250 ok", "450 4.7.1 retry", "550 5.7.1 policy", "252 unknown"] {
            XCTAssertEqual(verifier(ScriptedSMTP(sequence("250 ok", "550 5.1.1 missing", control))).verify("a@public.org", options: options).verdict, .unknown)
        }
    }
    func testIncompleteControlsCannotBecomeAccepted() {
        let wire = ScriptedSMTP(Array(sequence().prefix(9)))
        XCTAssertEqual(verifier(wire).verify("a@public.org", options: options).verdict, .unknown)
    }
    func testRecipientSpecificRejectSkipsControls() {
        let wire = ScriptedSMTP(sequence("550 5.1.1 no user"))
        XCTAssertEqual(verifier(wire).verify("a@public.org", options: options).verdict, .rejected)
        XCTAssertEqual(wire.commands.filter { $0.hasPrefix("RCPT") }.count, 1)
    }
    func testConservativeReplyClassification() {
        for (text, verdict) in [("550 5.7.1 blocked", SMTPVerification.Verdict.blocked), ("550 5.2.2 full", .temporary), ("450 4.1.1 retry", .temporary), ("252 cannot verify", .unknown), ("550 rejected", .unknown), ("550 5.1.1 missing", .rejected), ("251 forward", .accepted)] {
            let wire = ScriptedSMTP([text]); XCTAssertEqual(MailboxVerifier.classify(try! wire.readReply()), verdict)
        }
    }
    func testSenderRejectionCannotRejectMailbox() {
        let wire = ScriptedSMTP(["220 ready", "250 hi", "250 reset", "550 5.1.1 sender unknown"])
        var opt = options; opt.requireTLS = false
        XCTAssertEqual(verifier(wire).verify("a@public.org", options: opt).verdict, .blocked)
        XCTAssertFalse(wire.commands.contains { $0.hasPrefix("RCPT") })
    }
    func testTLSRequiredByDefault() {
        let wire = ScriptedSMTP(sequence(tls: false))
        XCTAssertEqual(verifier(wire).verify("a@public.org", options: options).verdict, .unknown)
        XCTAssertFalse(wire.commands.contains { $0.hasPrefix("MAIL") })
    }
    func testPlaintextRequiresExplicitPermissionAndNoStartTLSOffer() {
        let wire = ScriptedSMTP(sequence(tls: false)); var opt = options; opt.requireTLS = false
        XCTAssertEqual(verifier(wire).verify("a@public.org", options: opt).verdict, .accepted); XCTAssertFalse(wire.didTLS)
    }
    func testFailedTLSNeverDowngradesEvenWithPlaintextPermission() {
        let wire = ScriptedSMTP(sequence()); wire.failTLS = true
        var opt = options; opt.requireTLS = false
        XCTAssertEqual(verifier(wire).verify("a@public.org", options: opt).verdict, .unknown)
        XCTAssertFalse(wire.commands.contains { $0.hasPrefix("MAIL") })
    }
    func testBackupMXCannotEstablishRecipientInvalidity() {
        let backup = MailRoute(host: "backup.public.org", preference: 20, addresses: ["8.8.4.4"])
        let wire = ScriptedSMTP(sequence("550 5.1.1 missing"))
        let v = MailboxVerifier(resolve: { _,_ in .init(state: .routes, routes: [self.route,backup], reason: "fixture") }, connect: { ip,_,_,_ in if ip == "8.8.8.8" { throw SMTPFailure.connection }; return wire })
        XCTAssertEqual(v.verify("a@public.org", options: options).verdict, .unknown)
    }
    func testConnectionFailuresRemainUnknown() {
        let v = MailboxVerifier(resolve: { _,_ in .init(state: .routes, routes: [self.route], reason: "fixture") }, connect: { _,_,_,_ in throw SMTPFailure.connection })
        let answer = v.verify("a@public.org", options: options)
        XCTAssertEqual(answer.verdict, .unknown); XCTAssertTrue(answer.connectionFailed)
    }
    func testTemporaryRetryIsBoundedAndDomainCooldownApplies() {
        var attempts = 0
        let v = MailboxVerifier(resolve: { _,_ in .init(state: .routes, routes: [self.route], reason: "fixture") }, connect: { _,_,_,_ in attempts += 1; return ScriptedSMTP(["421 4.7.1 later"]) })
        XCTAssertEqual(v.verify("a@public.org", options: options).verdict, .temporary)
        XCTAssertEqual(attempts, 2)
        XCTAssertEqual(v.verify("b@public.org", options: options).verdict, .deferred)
        XCTAssertEqual(attempts, 2)
    }
    func testUnsupportedSyntaxAndMissingIdentityNeverConnect() {
        let v = MailboxVerifier(resolve: { _,_ in XCTFail("Unexpected DNS"); return .init(state: .unknown, reason: "") }, connect: { _,_,_,_ in XCTFail("Unexpected connect"); throw SMTPFailure.connection })
        XCTAssertEqual(v.verify("é@public.org", options: options).verdict, .unknown)
        XCTAssertEqual(v.verify("a@public.org", options: SMTPOptions()).verdict, .unknown)
        XCTAssertEqual(v.verify("a@public.org", options: options, cancelled: { true }).verdict, .cancelled)
        var opt = options; opt.ehlo = "x.sender.org\r\nDATA"
        XCTAssertEqual(v.verify("a@public.org", options: opt).verdict, .unknown)
    }
    func testDNSNoMailAndFailureOutcomes() {
        for (state, verdict) in [(MailRoutingResult.State.nullMX, SMTPVerification.Verdict.rejected), (.nxDomain, .rejected), (.noMail, .unknown), (.temporary, .temporary), (.unknown, .unknown)] {
            let v = MailboxVerifier(resolve: { _,_ in .init(state: state, reason: "fixture") }, connect: { _,_,_,_ in XCTFail("Unexpected connect"); throw SMTPFailure.connection })
            XCTAssertEqual(v.verify("a@public.org", options: options).verdict, verdict)
        }
    }
    func testMultilineRepliesRejectMismatchedCodesAndBounds() {
        XCTAssertEqual(try! ScriptedSMTP(["250-one\r\n250 two"]).readReply().lines, ["one", "two"])
        for text in ["250-one\r\n550 two", "bad", "199 invalid", "250" + String(repeating: "x", count: 3000), Array(repeating: "250-more", count: 65).joined(separator: "\r\n")] {
            XCTAssertThrowsError(try ScriptedSMTP([text]).readReply())
        }
    }
    func testAddressBatchDeduplicatesAndRespectsRemovalsAndRules() {
        var a = makeEmailFixture("Person@public.org"); let b = makeEmailFixture("person@public.org")
        let c = makeEmailFixture("c@public.org"); var d = makeEmailFixture("d@public.org"); d.status = "Excluded"
        let rows = [a,b,c,d]
        XCTAssertEqual(VerificationApplication.targets(rows, rules: [], removed: []), [a.address,c.address])
        XCTAssertEqual(VerificationApplication.targets(rows, selected: [b.id], rules: [], removed: []), [b.address])
        XCTAssertTrue(VerificationApplication.targets(rows, rules: [.init(kind: "Domain", pattern: "public.org")], removed: []).isEmpty)
        XCTAssertEqual(VerificationApplication.targets(rows, rules: [], removed: ["person@public.org"]), [c.address])
        a.smtpVerification = .init(verdict: .unknown, reason: "fixture")
        XCTAssertTrue(VerificationApplication.targets([a], rules: [], removed: [], uncheckedOnly: true).isEmpty)
    }
    func testOldRowsDecodeAndEvidenceSurvivesRoundTripAndCSV() throws {
        var row = makeEmailFixture("a@public.org")
        let old = try JSONEncoder().encode(row)
        XCTAssertNil(try JSONDecoder().decode(FoundEmail.self, from: old).smtpVerification)
        let result = SMTPVerification(verdict: .accepted, reason: "Accepted, not guaranteed")
        VerificationApplication.smtp(result, to: &row)
        VerificationApplication.provider(.init(status: "Verified", reason: "ZeroBounce valid"), to: &row)
        XCTAssertEqual(try JSONDecoder().decode(FoundEmail.self, from: JSONEncoder().encode(row)), row)
        XCTAssertEqual(row.smtpVerification, result)
        let line = VerificationCSV.line(row)
        XCTAssertTrue(VerificationCSV.header.hasPrefix("email,status,reason,source,checked_at,"))
        XCTAssertTrue(line.contains("SMTP accepted")); XCTAssertTrue(line.contains("ZeroBounce valid"))
    }
    func testProviderErrorsPreserveEarlierConclusionAndBothEvidenceSources() {
        var row = makeEmailFixture("a@public.org")
        VerificationApplication.smtp(.init(verdict: .accepted, reason: "SMTP evidence"), to: &row)
        let status = row.status, reason = row.reason
        VerificationApplication.provider(.init(status: "Uncertain", reason: "HTTP 429", requestFailed: true), to: &row)
        XCTAssertEqual(row.status, status); XCTAssertEqual(row.reason, reason)
        XCTAssertNotNil(row.smtpVerification); XCTAssertTrue(row.providerVerification!.requestFailed)
    }
    func testExclusionsNeverReincludedByEitherChecker() {
        var row = makeEmailFixture("a@public.org"); row.status = "Excluded"
        VerificationApplication.smtp(.init(verdict: .accepted, reason: "fixture"), to: &row)
        VerificationApplication.provider(.init(status: "Verified", reason: "fixture"), to: &row)
        XCTAssertEqual(row.status, "Excluded")
    }
    func testMergeRetainsBothIndependentEvidenceRecords() {
        var older = makeEmailFixture("a@public.org"); older.smtpVerification = .init(verdict: .catchAll, reason: "fixture")
        var newer = older; newer.smtpVerification = nil; newer.checkedAt = older.checkedAt.addingTimeInterval(1); newer.providerVerification = .init(status: "Uncertain", reason: "unknown")
        let merged = ResultMerge.combine([older], [newer])[0]
        XCTAssertEqual(merged.smtpVerification, older.smtpVerification); XCTAssertEqual(merged.providerVerification, newer.providerVerification)
    }
    func testDisposableResourceAndFreeProviderProtection() {
        XCTAssertEqual(DisposableDomainData.loadedCount, 9963)
        XCTAssertTrue(DisposableDomainData.flags("info@mailinator.com").contains("Disposable domain (advisory)"))
        XCTAssertFalse(DisposableDomainData.flags("a@gmail.com").contains("Disposable domain (advisory)"))
        XCTAssertTrue(DisposableDomainData.flags("support@gmail.com").contains("Role-based (advisory)"))
    }
    func testPolicyWordingWithRecipientEnhancedCodeIsStillBlocked() {
        let reply = try! ScriptedSMTP(["550 5.1.1 relay access denied"]).readReply()
        XCTAssertEqual(MailboxVerifier.classify(reply), .blocked)
    }
    func testAlternativeMXCanAcceptAfterPreferredConnectionFailure() {
        let backup = MailRoute(host: "backup.public.org", preference: 20, addresses: ["8.8.4.4"])
        let wire = ScriptedSMTP(sequence())
        let v = MailboxVerifier(resolve: { _,_ in .init(state: .routes, routes: [self.route, backup], reason: "fixture") }, connect: { ip,_,_,_ in
            if ip == "8.8.8.8" { throw SMTPFailure.connection }; return wire
        })
        XCTAssertEqual(v.verify("a@public.org", options: options).verdict, .accepted)
    }
    func testTemporaryRetryCanSucceed() {
        var attempts = 0
        let v = MailboxVerifier(resolve: { _,_ in .init(state: .routes, routes: [self.route], reason: "fixture") }, connect: { _,_,_,_ in
            attempts += 1
            return ScriptedSMTP(attempts == 1 ? ["421 4.7.1 retry"] : self.sequence())
        })
        XCTAssertEqual(v.verify("a@public.org", options: options).verdict, .accepted)
        XCTAssertEqual(attempts, 2)
    }
    func testCancellationAfterConnectStopsBeforeRecipientCommand() {
        let wire = ScriptedSMTP(sequence()); var stop = false
        let v = MailboxVerifier(resolve: { _,_ in .init(state: .routes, routes: [self.route], reason: "fixture") }, connect: { _,_,_,_ in stop = true; return wire })
        XCTAssertEqual(v.verify("a@public.org", options: options, cancelled: { stop }).verdict, .cancelled)
        XCTAssertTrue(wire.commands.isEmpty); XCTAssertTrue(wire.closed)
    }
    func testProviderFailureRetainsPreviousSuccessfulProviderEvidence() {
        var row = makeEmailFixture("a@public.org")
        VerificationApplication.provider(.init(status: "Verified", reason: "original valid result"), to: &row)
        VerificationApplication.provider(.init(status: "Uncertain", reason: "HTTP 429", requestFailed: true), to: &row)
        VerificationApplication.provider(.init(status: "Uncertain", reason: "HTTP 503", requestFailed: true), to: &row)
        XCTAssertEqual(row.status, "Verified")
        XCTAssertEqual(row.providerVerification?.lastConclusionStatus, "Verified")
        XCTAssertEqual(row.providerVerification?.lastConclusionReason, "original valid result")
    }
    func testProviderHTTPAndMalformedResultsAreMarkedFailedAttempts() {
        for (body, status) in [("{}", 429), ("not JSON", 200), ("{}", 200), (#"{"error":"credits"}"#, 200)] {
            let answer = AdvancedVerifier.validate(email: "a@public.org", apiKey: "fixture", perform: { response(body, $0.url!, status: status) })
            XCTAssertTrue(answer.requestFailed)
        }
    }
    func testNewSMTPAttemptDoesNotEraseProviderConclusion() {
        var row = makeEmailFixture("a@public.org")
        VerificationApplication.provider(.init(status: "Verified", reason: "provider valid"), to: &row)
        VerificationApplication.smtp(.init(verdict: .catchAll, reason: "controls accepted"), to: &row)
        XCTAssertEqual(row.status, "Verified")
        XCTAssertEqual(row.smtpVerification?.verdict, .catchAll)
        XCTAssertEqual(row.providerVerification?.status, "Verified")
    }
    func testSessionStoresOptionalSMTPIdentityAndOldSessionsDecode() throws {
        var session = GrabSession(mode: .pasted, input: "", excluded: "", depth: 0, maxPages: 0, stripDuplicates: true, excludeRole: false, excludeFree: false, excludeDisposable: false, checkDNS: false, rows: [])
        XCTAssertNil(try JSONDecoder().decode(GrabSession.self, from: JSONEncoder().encode(session)).smtpOptions)
        session.smtpOptions = options
        XCTAssertEqual(try JSONDecoder().decode(GrabSession.self, from: JSONEncoder().encode(session)).smtpOptions, options)
    }

    func testPlain550RecipientControlsCanSupportAcceptance() {
        let wire = ScriptedSMTP(sequence("250 accepted", "550 No such user here", "550 Recipient does not exist"))
        let answer = verifier(wire).verify("a@public.org", options: options)
        XCTAssertEqual(answer.verdict, .accepted)
        XCTAssertEqual(answer.probeAttempted, true)
        XCTAssertFalse(answer.reason.contains("[control"))
    }
    func testPlain550TargetCanRejectOnlyExplicitMissingRecipient() {
        let wire = ScriptedSMTP(sequence("550 User unknown"))
        let answer = verifier(wire).verify("a@public.org", options: options)
        XCTAssertEqual(answer.verdict, .rejected)
        XCTAssertEqual(wire.commands.filter { $0.hasPrefix("RCPT") }.count, 1)
    }
    func testPlainRejectionCannotOverridePolicyOrAmbiguousResponse() {
        for text in ["550 user unknown, sender rejected", "550 unknown user; authentication required", "550 unknown recipient: relay denied", "550 recipient not found in whitelist", "550 mailbox not found in directory cache", "550 user unknown, account suspended", "550 user unknown: directory lookup failed", "550 no such user; try again later"] {
            XCTAssertNotEqual(MailboxVerifier.classify(try! ScriptedSMTP([text]).readReply()), .rejected, text)
        }
        for text in ["550 unavailable", "553 address rejected", "550 mailbox disabled", "550 rejected", "503 5.1.1 bad command sequence"] {
            XCTAssertEqual(MailboxVerifier.classify(try! ScriptedSMTP([text]).readReply()), .unknown, text)
        }
    }
    func testDeferredMeansNoProbeAndShowsExactRetryTime() {
        var attempts = 0; var date = Date(timeIntervalSince1970: 1000)
        let v = MailboxVerifier(resolve: { _,_ in .init(state: .routes, routes: [self.route], reason: "fixture") }, connect: { _,_,_,_ in attempts += 1; throw SMTPFailure.connection }, now: { date })
        let first = v.verify("a@public.org", options: options)
        XCTAssertEqual(first.probeAttempted, true)
        let second = v.verify("b@public.org", options: options)
        XCTAssertEqual(second.verdict, .deferred); XCTAssertEqual(second.probeAttempted, false)
        XCTAssertTrue(second.observations.isEmpty); XCTAssertEqual(attempts, 1)
        XCTAssertEqual(second.retryAfter, date.addingTimeInterval(60))
        date = date.addingTimeInterval(61)
        _ = v.verify("b@public.org", options: options); XCTAssertEqual(attempts, 2)
    }
    func testRetryTargetsSelectOnlyInconclusiveChecksThatAreDue() {
        let date = Date(timeIntervalSince1970: 1000)
        var due = makeEmailFixture("a@public.org"), later = makeEmailFixture("b@public.org"), accepted = makeEmailFixture("c@public.org"), catchAll = makeEmailFixture("d@public.org")
        due.smtpVerification = .init(verdict: .temporary, reason: "later", retryAfter: date)
        later.smtpVerification = .init(verdict: .unknown, reason: "later", retryAfter: date.addingTimeInterval(300))
        accepted.smtpVerification = .init(verdict: .accepted, reason: "accepted")
        catchAll.smtpVerification = .init(verdict: .catchAll, reason: "catch-all")
        let rows = [due,later,accepted,catchAll,makeEmailFixture("unchecked@public.org")]
        XCTAssertEqual(VerificationApplication.targets(rows, rules: [], removed: [], retryDueOnly: true, now: date), [due.address])
        XCTAssertTrue(VerificationApplication.targets(rows, rules: [], removed: [due.address], retryDueOnly: true, now: date).isEmpty)
        XCTAssertEqual(VerificationApplication.targets(rows, rules: [], removed: [], retryDueOnly: true, now: date.addingTimeInterval(301)), [due.address,later.address])
    }
    func testTemporaryReasonIncludesActualStageServerCodeAndReply() {
        let wire = ScriptedSMTP(sequence("450 4.7.1 Greylisted; try later"))
        var opt = options; opt.temporaryRetries = 0
        let answer = verifier(wire).verify("a@public.org", options: opt)
        XCTAssertEqual(answer.verdict, .temporary)
        XCTAssertTrue(answer.reason.contains("target RCPT @ mx.public.org: 450 4.7.1 Greylisted"))
        XCTAssertNotNil(answer.retryAfter)
    }
    func testEvidenceTextAndCSVExposeRetryTimeAndPreserveEarlierChecks() throws {
        var row = makeEmailFixture("a@public.org")
        let first = SMTPVerification(verdict: .catchAll, reason: "three recipients accepted", checkedAt: Date(timeIntervalSince1970: 1000))
        VerificationApplication.smtp(first, to: &row)
        VerificationApplication.smtp(.init(verdict: .deferred, reason: "cooldown", retryAfter: Date(timeIntervalSince1970: 1500), probeAttempted: false), to: &row)
        XCTAssertEqual(row.status, "Uncertain")
        XCTAssertEqual(row.smtpHistory, [first])
        XCTAssertTrue(VerificationEvidence.text(row).contains("Recipient-server connection attempted: false"))
        XCTAssertTrue(VerificationEvidence.text(row).contains("three recipients accepted"))
        XCTAssertTrue(VerificationCSV.line(row).contains("three recipients accepted"))
        XCTAssertEqual(try JSONDecoder().decode(FoundEmail.self, from: JSONEncoder().encode(row)), row)
    }
    func testCancelledAndDeferredAttemptsDoNotChangeExistingConclusion() {
        for verdict in [SMTPVerification.Verdict.deferred, .cancelled] {
            var row = makeEmailFixture("a@public.org")
            VerificationApplication.smtp(.init(verdict: verdict, reason: "not completed"), to: &row)
            XCTAssertEqual(row.status, "Accepted"); XCTAssertEqual(row.reason, "Local syntax only")
        }
    }
    func testHistoryMergeRetainsDistinctAttemptsAndBoundsMemory() {
        var row = makeEmailFixture("a@public.org")
        for i in 0..<20 {
            VerificationApplication.smtp(.init(verdict: .temporary, reason: "attempt " + String(i), checkedAt: Date(timeIntervalSince1970: Double(i))), to: &row)
        }
        XCTAssertEqual(row.smtpHistory?.count, 8)
        var project = row
        VerificationApplication.smtp(.init(verdict: .catchAll, reason: "new finding", checkedAt: Date(timeIntervalSince1970: 30)), to: &project)
        let merged = ResultMerge.combine([row], [project])[0]
        XCTAssertEqual(merged.smtpVerification?.reason, "new finding")
        XCTAssertEqual(merged.smtpHistory?.count, 8)
        XCTAssertEqual(Set(merged.smtpHistory ?? []).count, 8)
    }
    func testOldSMTPResultsDecodeWithNoNewFields() throws {
        let old = SMTPVerification(verdict: .unknown, reason: "old check")
        let decoded = try JSONDecoder().decode(SMTPVerification.self, from: JSONEncoder().encode(old))
        XCTAssertNil(decoded.retryAfter); XCTAssertNil(decoded.probeAttempted)
        XCTAssertTrue(decoded.retryIsDue(at: Date()))
    }

}
