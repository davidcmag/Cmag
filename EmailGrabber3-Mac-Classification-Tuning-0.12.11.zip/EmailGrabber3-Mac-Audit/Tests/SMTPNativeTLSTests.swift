#if os(macOS)
import XCTest
import Foundation
import Darwin
@testable import EmailGrabberCore

/// Uses only an ephemeral loopback TLS server. No SMTP recipient or paid API is
/// contacted. The system trust store must reject the self-signed certificate.
final class SMTPNativeTLSTests: XCTestCase {
    func testUntrustedNativeTLSCertificateIsRejected() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        let key = directory.appendingPathComponent("key.pem").path
        let cert = directory.appendingPathComponent("cert.pem").path
        _ = try SafeProcess.run("/usr/bin/openssl", ["req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", key, "-out", cert, "-days", "1", "-subj", "/CN=mx.fixture.org"], timeout: 20)
        let listener = Darwin.socket(AF_INET, SOCK_STREAM, 0)
        XCTAssertGreaterThanOrEqual(listener, 0)
        var local = sockaddr_in(); local.sin_family = sa_family_t(AF_INET); local.sin_port = 0
        local.sin_addr.s_addr = Darwin.inet_addr("127.0.0.1")
        let bound = withUnsafePointer(to: &local) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { Darwin.bind(listener, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) } }
        guard bound == 0 else { _ = Darwin.close(listener); throw SMTPFailure.connection }
        var length = socklen_t(MemoryLayout<sockaddr_in>.size)
        let named = withUnsafeMutablePointer(to: &local) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { Darwin.getsockname(listener, $0, &length) } }
        XCTAssertEqual(named, 0)
        let port = UInt16(bigEndian: local.sin_port)
        _ = Darwin.close(listener)
        let server = Process(); server.executableURL = URL(fileURLWithPath: "/usr/bin/openssl")
        server.arguments = ["s_server", "-accept", "127.0.0.1:\(port)", "-cert", cert, "-key", key, "-quiet", "-tls1_2"]
        server.standardOutput = FileHandle.nullDevice; server.standardError = FileHandle.nullDevice
        let stdin = Pipe(); server.standardInput = stdin // Keep the TLS server's input open.
        try server.run()
        defer {
            if server.isRunning { server.terminate() }
            try? stdin.fileHandleForWriting.close()
            if server.isRunning { _ = Darwin.kill(server.processIdentifier, SIGKILL) }
            server.waitUntilExit()
        }
        var connected: Int32 = -1
        local.sin_port = port.bigEndian
        for _ in 0..<100 {
            let fd = Darwin.socket(AF_INET, SOCK_STREAM, 0)
            let status = withUnsafePointer(to: &local) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { Darwin.connect(fd, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) } }
            if status == 0 { connected = fd; break }
            _ = Darwin.close(fd); Thread.sleep(forTimeInterval: 0.02)
        }
        guard connected >= 0 else { XCTFail("Local TLS fixture did not start"); return }
        let wire = try SMTPSocketWire(connectedFD: connected, timeout: 5)
        defer { wire.close() }
        XCTAssertThrowsError(try wire.startTLS(host: "mx.fixture.org")) { XCTAssertEqual($0 as? SMTPFailure, .certificateRejected) }
        // Once TLS fails the socket is unusable; plaintext cannot be sent.
        XCTAssertThrowsError(try wire.command("EHLO sender.org"))
    }
}
#endif
