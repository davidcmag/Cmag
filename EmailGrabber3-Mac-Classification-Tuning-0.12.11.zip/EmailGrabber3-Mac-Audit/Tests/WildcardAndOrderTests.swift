import XCTest
import Foundation
@testable import EmailGrabberCore

final class WildcardAndOrderTests: DiskTests {
    func testWholeEmailWildcardsAreCaseInsensitiveAndLiteralSafe() {
        for (pattern,value,expected) in [
            ("info@*", "INFO@public.org", true),
            ("*@public.org", "person@public.org", true),
            ("*@public.org", "person@public.org.invalid", false),
            ("*support*", "help-support@public.org", true),
            ("a?@public.org", "ab@public.org", true),
            ("a?@public.org", "a@public.org", false),
            ("a?@public.org", "abc@public.org", false),
            ("*+tag@*.org", "john+tag@dept.public.org", true),
            ("*@public.org", "person@publicXorg", false),
            ("*", "*abc", true),
            ("**a***b*", "aaabzz", true)
        ] {
            XCTAssertEqual(SafeWildcard(pattern).matches(value), expected, pattern + " versus " + value)
        }
    }
    func testWildcardMatcherAgainstIndependentReference() {
        func reference(_ text: String, _ pattern: String) -> Bool {
            let text = Array(text), pattern = Array(pattern)
            var row = [Bool](repeating: false, count: text.count + 1); row[0] = true
            for token in pattern {
                var next = [Bool](repeating: false, count: text.count + 1)
                if token == "*" { next[0] = row[0] }
                if !text.isEmpty {
                    for n in 1...text.count {
                        next[n] = token == "*" ? (row[n] || next[n-1]) : (row[n-1] && (token == "?" || token == text[n-1]))
                    }
                }
                row = next
            }
            return row[text.count]
        }
        var patterns = [""], level = [""]
        for _ in 0..<4 {
            level = level.flatMap { prefix in ["a","b","*","?"].map { prefix + $0 } }
            patterns += level
        }
        for pattern in patterns {
            for value in ["","a","b","aa","ab","ba","bbb","a?","*ab","ba*b","aaaab"] {
                XCTAssertEqual(SafeWildcard(pattern).matches(value), reference(value,pattern), pattern + " / " + value)
            }
        }
    }
    func testOversizedWildcardPatternIsRejectedWithoutRegexExecution() {
        XCTAssertFalse(SafeWildcard(String(repeating: "*a", count: 300)).matches("aaa"))
        XCTAssertFalse(SafeWildcard("*").matches(String(repeating: "a", count: 16_385)))
    }
    func testSearchUsesWildcardInEmailDomainSourceAndAllFields() {
        var first = makeEmailFixture("info@public.org"); first.source = "https://public.org/contact"
        var second = makeEmailFixture("jane@other.org"); second.source = "https://other.org/staff"
        let rows = [first,second]
        func find(_ query: String, _ scope: String) -> [String] {
            ResultPolicy.filtered(rows, rules: [], removed: [], status: "Included", search: query, scope: scope).map(\.address)
        }
        XCTAssertEqual(find("*@public.org", "Email"), ["info@public.org"])
        XCTAssertEqual(find("pub*.org", "Domain"), ["info@public.org"])
        XCTAssertEqual(find("*/contact", "Source"), ["info@public.org"])
        XCTAssertEqual(find("*@other.org", "All fields"), ["jane@other.org"])
        XCTAssertEqual(find("public", "Email"), ["info@public.org"])
        XCTAssertEqual(find("info", "Email"), ["info@public.org"])
        XCTAssertTrue(find("*@public.org.invalid", "Email").isEmpty)
    }
    func testReusableWildcardRulePreviewAndIncludedViewAgree() {
        let rows = ["info@public.org","info@other.org","jane@public.org"].map(makeEmailFixture)
        let rule = SmartRule(kind: "Wildcard", pattern: "INFO@*")
        XCTAssertEqual(rows.filter { rule.matches($0.address) }.count, 2)
        let included = ResultPolicy.filtered(rows, rules: [rule], removed: [], status: "Included", search: "", scope: "Email")
        XCTAssertEqual(included.map(\.address), ["jane@public.org"])
        let excluded = ResultPolicy.filtered(rows, rules: [rule], removed: [], status: "Excluded", search: "", scope: "Email")
        XCTAssertEqual(excluded.count, 2)
        XCTAssertEqual(ResultPolicy.filtered(rows, rules: [], removed: [], status: "Included", search: "", scope: "Email").count, 3)
        XCTAssertEqual(ResultPolicy.displayedStatus(rows[0], rules: [rule], removed: []), "Excluded by rule")
    }
    func testBlockedInputSupportsWildcardAndPreservesLiteralPrefixes() {
        let options = GrabSettings(depth: 0, maxPages: 0, maxPagesPerDomain: 0, exclude: "info@*\n*@blocked.org\ncare@", duplicates: true, role: false, free: false, disposable: true, dns: false)
        let engine = GrabEngine(settings: options, sleep: { _ in })
        let rows = engine.run(mode: .pasted, terms: ["info@public.org jane@blocked.org care@other.org person@public.org"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(rows.filter { $0.status == "Excluded" }.count, 3)
        XCTAssertEqual(rows.filter { $0.status == "Accepted" }.map(\.address), ["person@public.org"])
    }
    func testFoundOrderPreservesSequenceAndIDsAsNewRowsArrive() {
        let original = ["z@public.org","a@public.org","m@public.org"].map(makeEmailFixture)
        let before = ResultOrdering.apply(Array(original.prefix(2)), order: [])
        let after = ResultOrdering.apply(original, order: [])
        XCTAssertEqual(before.map(\.id), Array(after.prefix(2)).map(\.id))
        XCTAssertEqual(after.map(\.address), original.map(\.address))
        XCTAssertEqual(ResultOrdering.label([]), "Found order")
        let selected = Set([original[0].id])
        XCTAssertEqual(after.filter { selected.contains($0.id) }.map(\.address), ["z@public.org"])
    }
    func testAlphabeticalOptionsAndHeaderSortingRemainAvailable() {
        let rows = ["z@public.org","a@public.org","m@public.org"].map(makeEmailFixture)
        let ascending = ResultOrdering.comparators("Email A–Z")!
        let descending = ResultOrdering.comparators("Email Z–A")!
        XCTAssertEqual(ResultOrdering.apply(rows, order: ascending).map(\.address), ["a@public.org","m@public.org","z@public.org"])
        XCTAssertEqual(ResultOrdering.apply(rows, order: descending).map(\.address), ["z@public.org","m@public.org","a@public.org"])
        XCTAssertEqual(ResultOrdering.label(ascending), "Email A–Z")
        XCTAssertEqual(ResultOrdering.label(descending), "Email Z–A")
        XCTAssertEqual(ResultOrdering.label([KeyPathComparator(\FoundEmail.source)]), "Column sort")
        XCTAssertEqual(ResultOrdering.comparators("Found order"), [])
        XCTAssertNil(ResultOrdering.comparators("Column sort"))
    }
    func testLiveExtractionKeepsSelectedRowIdentityThroughFinalUpdate() {
        let input = (0..<70).map { "person\($0)@public.org" }.joined(separator: " ")
        var streamed: [FoundEmail] = []
        var selected: UUID?
        let engine = GrabEngine(settings: settings(), sleep: { _ in })
        let result = engine.run(mode: .pasted, terms: [input], existing: [], liveRows: { added in
            streamed.append(contentsOf: added)
            if selected == nil { selected = added.first?.id }
            XCTAssertEqual(streamed.first?.id, selected)
        }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(result.map(\.id), streamed.map(\.id))
        XCTAssertEqual(result.first?.id, selected)
        XCTAssertEqual(result.map(\.address), (0..<70).map { "person\($0)@public.org" })
    }
    func testWildcardRuleSurvivesProjectEncoding() throws {
        let rule = SmartRule(kind: "Wildcard", pattern: "*@public.org")
        let decoded = try JSONDecoder().decode(SmartRule.self, from: JSONEncoder().encode(rule))
        XCTAssertEqual(decoded.id, rule.id)
        XCTAssertTrue(decoded.matches("Jane@Public.org"))
    }
}
