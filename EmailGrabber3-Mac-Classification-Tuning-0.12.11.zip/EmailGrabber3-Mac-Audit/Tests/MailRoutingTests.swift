import XCTest
@testable import EmailGrabberCore

final class MailRoutingTests: XCTestCase {
    func answer(_ type: String, _ data: String = "", status: String = "NOERROR", host: String = "public.org") -> String {
        ";; ->>HEADER<<- opcode: QUERY, status: \(status), id: 1\n" + data.split(separator: "\n").map { "\(host). 60 IN \(type) \($0)\n" }.joined()
    }
    func testMXPreferenceAndPublicDestinationResolution() {
        let routing = MailRouting(query: { host,type in
            if type == "MX" { return self.answer(type, "20 backup.public.org.\n10 mx.public.org.") }
            return self.answer(type, type == "A" ? "8.8.8.8" : "2606:4700:4700::1111", host: host)
        })
        let result = routing.resolve("public.org")
        XCTAssertEqual(result.state, .routes); XCTAssertEqual(result.routes.map(\.preference), [10,20])
        XCTAssertEqual(result.routes[0].addresses, ["8.8.8.8", "2606:4700:4700::1111"])
    }
    func testNullMXAndNXDOMAINAreDistinct() {
        for (data, status, expected) in [("0 .", "NOERROR", MailRoutingResult.State.nullMX), ("", "NXDOMAIN", .nxDomain), ("", "SERVFAIL", .temporary)] {
            let r = MailRouting(query: { _,type in self.answer(type, data, status: status) }).resolve("public.org")
            XCTAssertEqual(r.state, expected)
        }
    }
    func testImplicitFallbackRequiresSuccessfulEmptyMX() {
        let result = MailRouting(query: { _,type in self.answer(type, type == "A" ? "8.8.8.8" : "") }).resolve("public.org")
        XCTAssertEqual(result.state, .routes); XCTAssertTrue(result.reason.contains("Implicit"))
        var queried: [String] = []
        let broken = MailRouting(query: { _,type in queried.append(type); return "lookup timed out" }).resolve("public.org")
        XCTAssertEqual(broken.state, .unknown); XCTAssertEqual(queried, ["MX"])
    }
    func testConflictingNullMXIsUnknown() {
        XCTAssertEqual(MailRouting(query: { _,type in self.answer(type, "0 .\n10 mx.public.org.") }).resolve("public.org").state, .unknown)
    }
    func testPrivateAndDocumentationAnswersAreNeverDestinations() {
        let result = MailRouting(query: { _,type in self.answer(type, type == "MX" ? "10 mx.public.org." : type == "A" ? "127.0.0.1" : "::1") }).resolve("public.org")
        XCTAssertEqual(result.state, .temporary); XCTAssertTrue(result.routes.isEmpty)
    }
    func testNoRecordsIsNotNXDOMAIN() {
        let result = MailRouting(query: { _,type in self.answer(type) }).resolve("public.org")
        XCTAssertEqual(result.state, .noMail)
    }
    func testUnavailablePreferredMXIsRetainedWhenBackupResolves() {
        let result = MailRouting(query: { host,type in
            if type == "MX" { return self.answer(type, "10 mx.public.org.\n20 backup.public.org.") }
            return self.answer(type, host == "backup.public.org" && type == "A" ? "8.8.8.8" : "")
        }).resolve("public.org")
        XCTAssertEqual(result.state, .routes); XCTAssertTrue(result.routes[0].addresses.isEmpty); XCTAssertFalse(result.routes[1].addresses.isEmpty)
    }
    func testCacheExpiresAndUsesCanonicalDomain() {
        var count = 0; var date = Date()
        let routing = MailRouting(query: { _,type in count += 1; return self.answer(type, "", status: "NXDOMAIN") }, now: { date })
        _ = routing.resolve("PUBLIC.org"); _ = routing.resolve("public.org"); XCTAssertEqual(count, 1)
        date = date.addingTimeInterval(61); _ = routing.resolve("public.org"); XCTAssertEqual(count, 2)
    }
    func testCancellationAndUnsafeHostPreventQuery() {
        let routing = MailRouting(query: { _,_ in XCTFail("Unexpected query"); return "" })
        XCTAssertEqual(routing.resolve("mx.local").state, .unknown)
        XCTAssertEqual(routing.resolve("a.org\nDATA").state, .unknown)
        XCTAssertEqual(routing.resolve("public.org", cancelled: { true }).state, .temporary)
    }
    func testPublicIPValidationIPv4AndIPv6() {
        for ip in ["127.0.0.1", "10.0.0.1", "172.16.0.1", "192.168.1.1", "169.254.169.254", "100.64.0.1", "192.0.2.1", "198.51.100.1", "203.0.113.1", "224.0.0.1", "0.0.0.0", "255.255.255.255", "::", "::1", "::ffff:8.8.8.8", "fc00::1", "fe80::1", "2002:0808:0808::1", "2001:db8::1", "2001::1", "3fff::1", "8.8.8.8%en0", "0x08080808", "134744072"] { XCTAssertFalse(MailAddressSafety.publicIP(ip), ip) }
        for ip in ["8.8.8.8", "1.1.1.1", "2606:4700:4700::1111", "2001:4860:4860::8888"] { XCTAssertTrue(MailAddressSafety.publicIP(ip), ip) }
    }
}
