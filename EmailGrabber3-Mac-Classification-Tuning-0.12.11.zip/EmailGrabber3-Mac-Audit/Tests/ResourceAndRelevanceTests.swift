import XCTest
import Foundation
@testable import EmailGrabberCore

final class ResourceAndRelevanceTests: DiskTests {
    func testUnchangedProgressDoesNotRefilter3572ResultsAgainst12Rules() {
        let rows = (0..<3572).map { makeEmailFixture("person\($0)@public.org") }
        let rules = (0..<12).map { SmartRule(kind: "Prefix", pattern: "excluded\($0)@") }
        let cache = ResultsFilterCache()
        func refresh(_ input: [FoundEmail]) -> [FoundEmail] {
            cache.update(input, rules: rules, removed: [], status: "Included", search: "", scope: "Email", sort: [])
        }
        XCTAssertEqual(refresh(rows).count, 3572)
        for _ in 0..<100 { XCTAssertEqual(refresh(rows).count, 3572) }
        XCTAssertEqual(cache.evaluatedRows, 3572)
        let appended = rows + [makeEmailFixture("new@public.org")]
        XCTAssertEqual(refresh(appended).map(\.id), appended.map(\.id))
        XCTAssertEqual(cache.evaluatedRows, 3573)
    }
    func testCacheInvalidatesForRulesRemovalFieldScopeAndEditedRecords() {
        let rows = ["info@public.org","jane@public.org","person@other.org"].map(makeEmailFixture)
        let cache = ResultsFilterCache()
        let changes: [([SmartRule], Set<String>, String, String, String)] = [
            ([], [], "Included", "", "Email"),
            ([SmartRule(kind: "Wildcard", pattern: "info@*")], [], "Included", "", "Email"),
            ([], ["jane@public.org"], "Included", "", "Email"),
            ([], [], "Included", "fixture", "Source"),
            ([], [], "Included", "fixture", "Email"),
            ([], [], "All", "*@public.org", "Email")
        ]
        for (rules,removed,status,search,scope) in changes {
            let actual = cache.update(rows, rules: rules, removed: removed, status: status, search: search, scope: scope, sort: [])
            let expected = ResultPolicy.filtered(rows, rules: rules, removed: removed, status: status, search: search, scope: scope)
            XCTAssertEqual(actual, expected)
        }
        var edited = rows; edited[0].status = "Rejected"
        XCTAssertEqual(cache.update(edited, rules: [], removed: [], status: "Included", search: "", scope: "Email", sort: []).count, 2)
        XCTAssertEqual(cache.update([], rules: [], removed: [], status: "Included", search: "", scope: "Email", sort: []).count, 0)
    }
    func testChangingSortDoesNotRepeatFilteringOrLoseFoundSequence() {
        let rows = ["z@public.org","a@public.org"].map(makeEmailFixture)
        let cache = ResultsFilterCache()
        func refresh(_ order: [KeyPathComparator<FoundEmail>]) -> [FoundEmail] {
            cache.update(rows, rules: [], removed: [], status: "Included", search: "", scope: "Email", sort: order)
        }
        XCTAssertEqual(refresh([]).map(\.id), rows.map(\.id))
        XCTAssertEqual(refresh(ResultOrdering.comparators("Email A–Z")!).first?.address, "a@public.org")
        XCTAssertEqual(cache.evaluatedRows, 2)
        XCTAssertEqual(refresh([]).map(\.id), rows.map(\.id))
    }
    func testDisplayBatchRetainsRowsAndOnlyLatestQueueAndCounters() {
        let buffer = CrawlDisplayBuffer()
        let rows = (0..<70).map { makeEmailFixture("person\($0)@public.org") }
        buffer.append(Array(rows.prefix(25))); buffer.append(Array(rows.dropFirst(25)))
        for n in 0..<20 {
            buffer.report(CrawlCounters(pages: n, discovered: n, scannedSites: n, message: "\(n)"))
            buffer.report(CrawlActivity(url: "", phase: "Queue", pending: n, message: "", queuedPages: ["https://public.org/\(n)"]))
        }
        let batch = buffer.drain()
        XCTAssertEqual(batch.rows.map(\.id), rows.map(\.id))
        XCTAssertEqual(batch.counters?.pages, 19)
        XCTAssertEqual(batch.queue?.queuedPages, ["https://public.org/19"])
        XCTAssertTrue(buffer.drain().isEmpty)
    }
    func testDisplayHistoryIsBoundedButPendingPageListIsNotCapped() {
        let buffer = CrawlDisplayBuffer()
        for n in 0..<150 { buffer.report(CrawlActivity(url: "https://public.org/\(n)", phase: "Completed", pending: 0, message: "")) }
        let pending = (0..<1922).map { "https://public.org/contact/\($0)" }
        buffer.report(CrawlActivity(url: "", phase: "Queue", pending: pending.count, message: "", queuedPages: pending))
        buffer.report(CrawlActivity(url: "", phase: "Idle", pending: pending.count, message: "Saved", activeSites: [], queuedPages: pending))
        let batch = buffer.drain()
        XCTAssertEqual(batch.recent.count, 100)
        XCTAssertEqual(batch.recent.first?.url, "https://public.org/50")
        XCTAssertEqual(batch.queue?.queuedPages?.count, 1922)
        XCTAssertEqual(batch.current?.phase, "Idle")
    }
    func testConcurrentDisplayProducersDoNotLoseRows() {
        let buffer = CrawlDisplayBuffer(), group = DispatchGroup()
        for n in 0..<50 {
            group.enter()
            DispatchQueue.global().async { buffer.append([makeEmailFixture("person\(n)@public.org")]); group.leave() }
        }
        group.wait()
        let batch = buffer.drain()
        XCTAssertEqual(Set(batch.rows.map(\.address)).count, 50)
        XCTAssertTrue(buffer.drain().isEmpty)
    }
    func testEveryPageRemainsCheckpointedWithoutDuplicateSuccessWrites() {
        let initialWrites = CrawlDisk.checkpointWriteCount
        let engine = GrabEngine(settings: settings(), fetcher: { url in
            if url.path == "/robots.txt" { return response("User-agent: *", url) }
            if url.path == "/contact" {
                XCTAssertEqual(CrawlDisk.load()?.scanned, 1)
                XCTAssertTrue(CrawlDisk.load()?.queue.contains { $0.url == url.absoluteString } ?? false)
            }
            return response(url.path == "/" ? "<a href='/contact'>Contact</a>" : "person@public.org", url)
        }, sleep: { _ in })
        _ = engine.run(mode: .website, terms: ["https://public.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(CrawlDisk.checkpointWriteCount - initialWrites, 3)
        XCTAssertEqual(CrawlDisk.load()?.scanned, 2)
        XCTAssertTrue(CrawlDisk.load()?.queue.isEmpty ?? false)
    }
    func testRemovingOverBudgetPagesPersistsTheEmptyFrontier() {
        var options = settings(perSite: 1); options.concurrentSites = 5
        let engine = GrabEngine(settings: options, fetcher: { url in
            response(url.path == "/robots.txt" ? "User-agent: *" : "<a href='/contact'>Contact</a>", url)
        }, sleep: { _ in })
        _ = engine.run(mode: .website, terms: ["https://public.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertTrue(CrawlDisk.load()?.queue.isEmpty ?? false)
    }
    func testGenericHostWordCannotCarryPodcastCrawlToUnrelatedSites() {
        let source = URL(string: "https://podcasts.public.org/")!
        let sports = CrawlLink(url: URL(string: "https://sports.org/college-football/arizona-preseason-poll")!, label: "Arizona hosts preseason event", nofollow: false)
        let hosting = CrawlLink(url: URL(string: "https://hosting.org/")!, label: "Website hosts", nofollow: false)
        XCTAssertFalse(LinkRelevance.relevant(sports, from: source, topic: "podcast hosts"))
        XCTAssertFalse(LinkRelevance.relevant(hosting, from: source, topic: "podcast hosts"))
        XCTAssertTrue(LinkRelevance.relevant(CrawlLink(url: URL(string: "https://other.org/")!, label: "Podcast hosts", nofollow: false), from: source, topic: "podcast hosts"))
        XCTAssertFalse(LinkRelevance.topicWords("hosts").isEmpty)
    }
    func testAdaptiveContactScoringDoesNotTreatArticleProseAsAStaffPage() {
        for (path,label) in [("/college-football/arizona-preseason-poll","Arizona hosts preseason event"),("/news/all-about-shoes","All about shoes"),("/news/stafford-interview","Stafford interview")] {
            XCTAssertLessThanOrEqual(LinkRelevance.priority(CrawlLink(url: URL(string: "https://public.org" + path)!, label: label, nofollow: false)), 0)
        }
        for (path,label) in [("/contact-us","Contact us"),("/people/renee-parks","Renee Parks"),("/hosts/jane","Jane"),("/page?id=6","Meet the hosts"),("/ContactUs.jsp","Contact"),("/staff_directory.html","Directory")] {
            XCTAssertGreaterThan(LinkRelevance.priority(CrawlLink(url: URL(string: "https://public.org" + path)!, label: label, nofollow: false)), 0)
        }
    }
    func testDecodedLabelsAndResponsibleLinkHandlingArePreserved() {
        let links = LinkRelevance.links("<a href='/contact'><b>Contact</b> &amp; sales</a><a href='/staff' rel='nofollow'>Staff</a>", base: URL(string: "https://public.org/")!)
        XCTAssertTrue(links.first?.label.contains("Contact") ?? false)
        XCTAssertTrue(links.first?.label.contains("& sales") ?? false)
        XCTAssertEqual(links.last?.nofollow, true)
        XCTAssertEqual(CrawlMemoryScope.perform { 42 }, 42)
    }
}
