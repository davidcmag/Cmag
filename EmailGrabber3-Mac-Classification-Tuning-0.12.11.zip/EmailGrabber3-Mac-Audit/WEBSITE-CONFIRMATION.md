# Fresh website confirmation — 0.12.7 source candidate

## Use

Quit the earlier app and retain a saved-data backup before trying this candidate.
In the app, select Dan's row (or other desired rows), then click **Confirm
selected on website**. Right-click → **Confirm on website** checks one row.
The left sidebar's **Confirm next 100 on website** processes unchecked records;
select rows to explicitly recheck already-checked addresses. **Stop verification**
cancels website and SMTP work. Another active crawl/discovery/verification must
finish or stop before starting a new check. No EHLO, sender address, API key or
provider credits are needed for website-only checks.

SMTP verification now also revisits the saved source URLs for the selected
addresses. Its confirmation explains both operations. A Website column displays
the separate publication result. Hover for the reason, date and URL; right-click
→ Show verification evidence to inspect/copy the URL, timestamp, match method,
excerpt and earlier checks. CSV retains its original first five columns and
appends website evidence and history. Each completed check autosaves.

## Meaning

- **Published by organization**: exact address in downloaded or browser-rendered page text or a mailto
  recipient link; final website host equals the email domain or a subdomain.
- **Published on source**: exact match on the recorded third-party source page.
- **Not found on page**: the retrieved successful HTML/plain-text page did not
  contain an exact match. This never marks the address invalid. The page may
  have changed, require JavaScript, or hide contacts.
- **Page unavailable**: blocked/rate-limited response, timeout, unsupported or
  oversized content, challenge page, unsafe redirect, or inconclusive fetch.
- **No website source**: Source is pasted/imported text or an unsupported URL.
- **Cancelled**: the request did not complete as a confirmation.

A recent website listing corroborates publication, not mailbox existence or
future delivery. Catch-all SMTP results remain Catch-all/Uncertain. Publication
never overwrites SMTP/provider findings, overall acceptance, exclusions or
recoverable removals. Up to three earlier website checks are retained as history.
A failed recheck shows its actual current outcome rather than presenting an old
positive finding as fresh. Old projects without the new optional fields decode.

## Request and matching behavior

Every user-initiated batch creates a new checker and requests saved Source URLs
with local/remote cache-bypass policy, no-cache/no-store headers, and cookie
handling disabled. It makes no search-provider or verification-provider calls.
Only HTTP/HTTPS domain hosts on standard web ports are accepted. Literal/private
hosts, credentials and local names are rejected by the existing URL policies.
Redirects are restricted to the source host/www equivalent; HTTPS cannot be
silently downgraded. The existing native HTTP transport bounds redirects, bytes,
timeout and cancellation. Up to 100 page requests are allowed per batch, each
capped at 1 MB and twelve seconds. The eight-page in-batch cache avoids repeating
requests when several addresses share one page, retaining the actual fetch time.
It is not reused by a later check.

Matching is case-insensitive but exact; a similar name, longer mailbox or longer
domain is insufficient. The checker decodes HTML entities and percent-encoded
mailto recipient addresses, and supports inline text markup. Mailto subject,
body and cc fields do not count as recipient links. Scripts, styles, comments,
head metadata and template/noscript content are ignored. Attribute contents are
not mistaken for page text, and fake data-href attributes are not mailto links.
A target address reflected in the source/final URL query is not independent
publication evidence. No guessed addresses or [at]/[dot] reconstruction are used.

Direct HTTP checks use static source inspection. The app can then use its
WebKit fallback, described below, to execute the page normally and read its DOM.
Neither path solves CAPTCHAs, interprets all CSS visibility, or proves a page's author/end-user identity. A listing may itself be stale or
incorrect. HTTP (rather than HTTPS) sources are explicitly noted as unencrypted.
The HTTP client's existing DNS-rebinding limits documented in README/AUDIT remain;
do not deploy this desktop core as an internet-facing verification service.

## Validation

240 portable XCTest tests pass, including saved-CPR contact and browser fallback regressions.
Coverage includes exact/entity/encoded matches, negative substring cases,
misleading attributes, failed/blocked/oversized pages, content types, cancellation,
cache bypass and fresh subsequent checks, request budgets, recipient eligibility,
source/domain labeling, evidence history/merging, old records and CSV preservation.
HTTP integration tests exercise the native streaming transport with URLProtocol
fixtures. No real public mailbox or paid API was contacted.

Xcode project app/core/test membership and source references are validated; source
and shell syntax checks pass. macOS compilation, the Website UI and real CPR
website behavior have NOT been validated in this Linux environment. CPR access
is blocked by this environment's network policy. The Mac app uses the user's
normal website connection. Actual Mac verification remains necessary:

```sh
bash verify-mac.sh
```

The established one-command download/build/launch workflow can use build-mac.sh
and then open dist/EmailGrabber3.app. Keep backups and the previous candidate.
The earlier Mac TLS status and Darwin.bind compiler fixes are retained.

## 0.12.5: discovery evidence and profile/contact follow-up

The crawler now captures exact page-text/mailto publication evidence from the
response it already downloaded. Page publication matching runs once per page;
addresses use the precomputed matches rather than re-decoding/re-scanning the
HTML for each mailbox. No additional network request is made for this capture.
This evidence is included in newly emitted rows and checkpoints. If a later
page contains a duplicate address with stronger/newer evidence, that finding is
retained without adding a duplicate row or replacing its original Source URL.
These duplicate upgrades are checkpointed and appear when the crawl finishes
or stops; the append-only live display is preserved. Adaptive crawling now
recognizes singular /author/ paths as profile/contact navigation.

Fresh checks first revisit the saved Source. If it has no exact match, they
follow promising same-site staff/profile/contact links, prefer the address's
last published page, and consider common profile paths for dotted personal
mailbox names. For example, dan.boyce can suggest /author/dan-boyce/. Candidate
page paths are only search hints: a name or a plausible URL never establishes
publication. The exact email must be observed on the successfully fetched page.
Organization-domain pages can also seed a homepage/contact/staff follow-up;
third-party sources do not get guessed organization profile paths.

Follow-up stays on the source host/www equivalent, never silently downgrades
HTTPS, skips sensitive/off-site/nofollow links, and is capped at seven page checks
and thirty-five seconds per email plus the existing hundred-request batch
budget. A page found via follow-up retains the original sourceURL and records
the actual matching finalURL. Pages checked, timestamps, statuses and outcomes
are available in Show verification evidence and CSV. A bounded miss is labeled
Not found in checked pages, not "not anywhere on the website" or "invalid".

The screenshots' CPR index → /author/dan-boyce/ situation is covered by a local
fixture regression. Other tests cover linked profile priority, a staff-directory
chain, no match from name alone, same-site limits, a remembered positive page,
discovery without refetch, and duplicate evidence upgrades under adaptive mode.
234 portable tests pass. This is not a claim that the live CPR site was fetched;
network policy still prevents that here. Mac build/UI remain unverified here.

## 0.12.6: evidence access without a right-click menu

Select exactly one row using its checkbox. Click the visible **Show evidence**
button beside Copy selected, above the results table. The window has a
**Copy evidence** button. Do not rely on right-clicking selectable email text:
macOS can replace the app's menu with its own text/data-detector menu.

This release changes the UI entry point and version/documentation only; the
234-test portable checker baseline and website behavior are unchanged. Source
syntax/project checks pass; the actual Mac button/window still requires Mac
validation. Website matching failures still need their page-check trace; this
UI fix does not pretend to diagnose those failures without evidence.


## 0.12.7 in-app browser fallback

The app enables an isolated, nonpersistent WKWebView fallback after direct HTML
checks fail to confirm publication (including HTTP 403/challenge responses).
It tries at most two pages per address and ten browser loads per batch, within
the existing 35-second address deadline; each load has a ten-second deadline.
Named profile URLs are preferred. Stop verification cancels the fallback too.
The view uses a 1024×768 viewport; after load it reads the DOM up to four times
at half-second intervals. It does not reuse Safari/Chrome cookies or logins.
Main-frame navigation remains on the source website without HTTPS downgrade.
Page assets and scripts load as they would in a browser; dialogs are dismissed,
popups and unsupported main-frame content are refused. There is no CAPTCHA bypass.
An exact match is still required. Blocks, failures and timeouts remain unconfirmed.
Browser evidence is marked in Show evidence; original Source and SMTP are preserved.
The portable checker defaults to no renderer so all fixture tests stay offline;
the app explicitly enables the macOS renderer.

The complete user-saved CPR page passes the existing static matcher. Its exact
contact anchor is retained as a regression fixture. A missing direct response
followed by this rendered contact now confirms publication in the fallback test.
This validates the fallback path, not a live CPR request or native WebKit runtime.
