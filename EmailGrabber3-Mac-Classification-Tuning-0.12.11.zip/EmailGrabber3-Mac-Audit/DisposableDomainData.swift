import Foundation

private final class DisposableBundleMarker {}

enum DisposableDomainData {
    static let freeProviders: Set<String> = ["gmail.com", "googlemail.com", "outlook.com", "hotmail.com", "live.com", "yahoo.com", "icloud.com", "me.com", "aol.com", "proton.me", "protonmail.com", "gmx.com", "mail.com", "yandex.com"]
    static let roleNames: Set<String> = ["info", "admin", "support", "sales", "office", "contact", "care", "hello", "billing", "abuse", "postmaster", "webmaster", "noreply", "no-reply"]
    private static let domains: Set<String> = {
        #if SWIFT_PACKAGE
        let url = Bundle.module.url(forResource: "disposable_email_blocklist", withExtension: "conf", subdirectory: "Resources")
        #else
        let bundles = [Bundle.main, Bundle(for: DisposableBundleMarker.self)] + Bundle.allBundles + Bundle.allFrameworks
        let url = bundles.compactMap { $0.url(forResource: "disposable_email_blocklist", withExtension: "conf") }.first
        #endif
        guard let url = url, let text = try? String(contentsOf: url, encoding: .utf8) else { return [] }
        return Set(text.split(whereSeparator: \.isNewline).map { $0.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() }.filter { !$0.isEmpty && !$0.hasPrefix("#") })
    }()
    static var loadedCount: Int { domains.count }
    static func flags(_ address: String) -> [String] {
        let parts = address.lowercased().split(separator: "@", omittingEmptySubsequences: false)
        guard parts.count == 2 else { return [] }
        let local = String(parts[0]), domain = String(parts[1]); var result: [String] = []
        if roleNames.contains(local) { result.append("Role-based (advisory)") }
        if freeProviders.contains(domain) { result.append("Free provider (advisory)") }
        else {
            let labels = domain.split(separator: ".")
            if (0..<max(0, labels.count - 1)).contains(where: { domains.contains(labels[$0...].joined(separator: ".")) }) { result.append("Disposable domain (advisory)") }
        }
        if domains.isEmpty { result.append("Disposable dataset unavailable") }
        return result
    }
}
