import Foundation

struct FoundEmail: Identifiable, Codable, Hashable {
    var id = UUID()
    var address: String
    var source: String
    var status: String
    var reason: String
    var checkedAt = Date()
    var smtpVerification: SMTPVerification?
    var providerVerification: ProviderVerification?
}

struct DiscoveredSite: Identifiable, Codable, Hashable {
    var id: String { url }
    var url: String
    var origin: String
    var selected = true
    var host: String { URL(string: url)?.host ?? url }
}

enum SourceMode: String, CaseIterable, Identifiable, Codable {
    case website = "Websites / domains"
    case keywords = "Keywords (web discovery)"
    case pasted = "Pasted text / emails"
    var id: String { rawValue }
}

/// Thread-safe cooperative pause, resume and cancel control. A current network
/// request is allowed to finish; the next crawl checkpoint will wait or stop.
final class CrawlControl {
    private let condition = NSCondition()
    private var isPaused = false
    private var isCancelled = false

    func pause() { condition.lock(); isPaused = true; condition.unlock() }
    func resume() { condition.lock(); isPaused = false; condition.broadcast(); condition.unlock() }
    func cancel() { condition.lock(); isCancelled = true; isPaused = false; condition.broadcast(); condition.unlock() }
    func checkpoint() -> Bool {
        condition.lock()
        while isPaused && !isCancelled { condition.wait() }
        let cancelled = isCancelled
        condition.unlock()
        return cancelled
    }
    var wasCancelled: Bool { condition.lock(); defer { condition.unlock() }; return isCancelled }
}

struct SmartRule: Codable, Identifiable, Hashable {
    var id = UUID()
    var kind: String // Address, Prefix, Domain, Contains, Wildcard
    var pattern: String
    func matches(_ email: String) -> Bool {
        let value = email.lowercased()
        let token = pattern.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)
        guard !token.isEmpty else { return false }
        let components = value.split(separator: "@", omittingEmptySubsequences: false)
        guard components.count == 2 else { return false }
        switch kind {
        case "Wildcard": return SafeWildcard(token).matches(value)
        case "Address": return value == token
        case "Prefix": return value.hasPrefix(token)
        case "Domain": return String(components[1]) == token.replacingOccurrences(of: "@", with: "") || String(components[1]).hasSuffix("." + token.replacingOccurrences(of: "@", with: ""))
        default: return value.contains(token)
        }
    }
}

struct GrabSession: Codable {
    var version = 3
    var mode: SourceMode
    var input: String
    var excluded: String
    var depth: Int
    var maxPages: Int
    var maxPagesPerDomain: Int?
    var stripDuplicates: Bool
    var excludeRole: Bool
    var excludeFree: Bool
    var excludeDisposable: Bool
    var checkDNS: Bool
    var rows: [FoundEmail]
    var discoveredSites: [DiscoveredSite]?
    var directoryDiscovery: Bool?
    var osmStateCode: String?
    var smartRules: [SmartRule]?
    var removedAddresses: Set<String>?
    var removalHistory: [[String]]?
    var projectID: UUID?
    var followExternalLinks: Bool?
    var topicContext: String?
    var concurrentSites: Int?
    var smtpOptions: SMTPOptions?
}


struct CrawlInputContext: Equatable {
    let mode: SourceMode
    let input: String
    let reviewedSites: [String]
}

struct GrabSettings: Equatable {
    let depth: Int
    let maxPages: Int
    let maxPagesPerDomain: Int
    let exclude: String
    let duplicates: Bool
    let role: Bool
    let free: Bool
    let disposable: Bool
    let dns: Bool
    var followExternalLinks = false
    var topic = ""
    var concurrentSites = 1
    var workerLimit: Int { min(8, max(1, concurrentSites)) }
}

// Persisted crawl progress. Written atomically before requests and after each page.
struct CrawlProgress: Codable {
    struct Link: Codable { var url: String; var level: Int; var host: String }
    var queue: [Link]
    var visited: Set<String>
    var queued: Set<String>
    var robotRules: [String: [String]]
    var discoveredHosts: Set<String>?
    var domainPageCount: [String: Int]
    var discoveredCount: Int
    var scanned: Int
    var rows: [FoundEmail]
    var selectedSites: [String]
    var settings: CrawlOptions
    var input: String
    var smartRules: [SmartRule]?
    var removedAddresses: Set<String>?
    var removalHistory: [[String]]?
    var projectID: UUID?
    var followExternalLinks: Bool?
    var topicContext: String?
}
struct CrawlOptions: Codable {
    var depth: Int
    var maxPages: Int
    var maxPagesPerDomain: Int
    var excluded: String
    var stripDuplicates: Bool
    var excludeRole: Bool
    var excludeFree: Bool
    var excludeDisposable: Bool
    var checkDNS: Bool
    var followExternalLinks: Bool?
    var topic: String?
    var concurrentSites: Int?
}
struct RemovalState: Codable, Equatable {
    private(set) var addresses: Set<String> = []
    private(set) var history: [[String]] = []
    init(addresses: Set<String> = [], history: [[String]] = []) { self.addresses = Set(addresses.map { $0.lowercased() }); self.history = history.map { $0.map { $0.lowercased() } } }
    mutating func remove(_ values: Set<String>) {
        let fresh = Set(values.map { $0.lowercased() }).subtracting(addresses)
        guard !fresh.isEmpty else { return }
        addresses.formUnion(fresh); history.append(fresh.sorted())
    }
    mutating func undo() { guard let batch = history.popLast() else { return }; addresses.subtract(batch) }
    mutating func restoreAll() { addresses.removeAll(); history.removeAll() }
}

/// Atomic files and a single lock prevent the worker checkpoint from overwriting
/// newer rule/removal metadata. Automatic storage is private to this Mac user.
enum CrawlDisk {
    static var directoryOverride: URL?
    private static let lock = NSRecursiveLock()
    private static var rules: [SmartRule] = []
    private(set) static var checkpointWriteCount = 0
    private static var removal = RemovalState()
    private static var failure: String?
    private static var projectID: UUID?
    private static var quarantined = Set<URL>()
    static var lastError: String? { lock.lock(); defer { lock.unlock() }; return failure }
    static var folderURL: URL {
        directoryOverride ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("EmailGrabber3", isDirectory: true)
    }
    static var fileURL: URL { folderURL.appendingPathComponent("crawl-checkpoint.json") }
    static var projectURL: URL { folderURL.appendingPathComponent("autosave-project.json") }
    private static func write(_ data: Data, to url: URL) throws {
        try FileManager.default.createDirectory(at: folderURL, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        try FileManager.default.setAttributes([.posixPermissions: 0o700], ofItemAtPath: folderURL.path)
        try data.write(to: url, options: .atomic)
        quarantined.remove(url)
        try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
    }
    @discardableResult static func save(_ snapshot: CrawlProgress) -> Bool {
        lock.lock(); defer { lock.unlock() }
        var value = snapshot
        value.projectID = projectID
        value.smartRules = rules; value.removedAddresses = removal.addresses; value.removalHistory = removal.history
        do { try write(JSONEncoder().encode(value), to: fileURL); checkpointWriteCount += 1; failure = nil; return true }
        catch { failure = error.localizedDescription; return false }
    }
    static func updatePresentation(rules newRules: [SmartRule], removal newRemoval: RemovalState, projectID newID: UUID? = nil) {
        lock.lock(); defer { lock.unlock() }
        rules = newRules; removal = newRemoval
        if let newID = newID { projectID = newID }
        if let snapshot = load() { save(snapshot) }
    }
    static func load() -> CrawlProgress? {
        lock.lock(); defer { lock.unlock() }
        guard let data = try? Data(contentsOf: fileURL) else { return nil }
        do { return try JSONDecoder().decode(CrawlProgress.self, from: data) }
        catch { preserveUnreadable(fileURL, error: error); return nil }
    }
    @discardableResult static func saveProject(_ project: GrabSession) -> Bool {
        lock.lock(); defer { lock.unlock() }
        do { try write(JSONEncoder().encode(project), to: projectURL); failure = nil; return true }
        catch { failure = error.localizedDescription; return false }
    }
    static func loadProject() -> GrabSession? {
        lock.lock(); defer { lock.unlock() }
        guard let data = try? Data(contentsOf: projectURL) else { return nil }
        do {
            let project = try JSONDecoder().decode(GrabSession.self, from: data)
            guard project.version <= 3 else {
                preserveUnreadable(projectURL, error: NSError(domain: "EmailGrabber3", code: 1, userInfo: [NSLocalizedDescriptionKey: "Saved project requires a newer app version"]))
                return nil
            }
            return project
        }
        catch { preserveUnreadable(projectURL, error: error); return nil }
    }
    private static func preserveUnreadable(_ url: URL, error: Error) {
        failure = "Unreadable saved file: " + error.localizedDescription
        guard !quarantined.contains(url) else { return }
        let backup = folderURL.appendingPathComponent("recovery-" + UUID().uuidString + "-" + url.lastPathComponent)
        do { try FileManager.default.copyItem(at: url, to: backup); try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: backup.path); quarantined.insert(url) }
        catch { failure = "Could not preserve unreadable file: " + error.localizedDescription }
    }
    static func clear() {
        lock.lock(); defer { lock.unlock() }
        do { if FileManager.default.fileExists(atPath: fileURL.path) { try FileManager.default.removeItem(at: fileURL) }; failure = nil }
        catch { failure = error.localizedDescription }
    }
}


// Transient crawl activity; result persistence remains independent.
struct CrawlActivity: Identifiable {
    let id = UUID()
    let time = Date()
    let url: String
    let phase: String
    let pending: Int
    let message: String
    var requestURL: String? = nil
    var activeSites: [String]? = nil
    var queuedPages: [String]? = nil
}
