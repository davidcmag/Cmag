import Foundation

enum SMTPFailure: Error, Equatable { case invalidInput, cancelled, timeout, disconnected, protocolError, oversized, connection, tlsUnavailable, tlsFailed, certificateRejected }
struct SMTPReply: Equatable {
    var code: Int
    var lines: [String]
    var text: String { lines.joined(separator: "\n") }
    var enhanced: String? {
        for line in lines {
            if let r = line.range(of: #"(?:^|\s)[245]\.[0-9]{1,3}\.[0-9]{1,3}(?:\s|$)"#, options: .regularExpression) { return line[r].trimmingCharacters(in: .whitespacesAndNewlines) }
        }
        return nil
    }
    static func read(line: () throws -> Data) throws -> SMTPReply {
        var lines: [String] = []; var expected: Int?; var bytes = 0
        for _ in 0..<64 {
            let data = try line(); bytes += data.count
            guard bytes <= 32_768, data.count <= 2048 else { throw SMTPFailure.oversized }
            guard data.count >= 4, data.suffix(2) == Data([13,10]) else { throw SMTPFailure.protocolError }
            let raw = Array(data.dropLast(2))
            guard raw.count >= 3, raw.prefix(3).allSatisfy({ (48...57).contains($0) }), let code = Int(String(decoding: raw.prefix(3), as: UTF8.self)), (200...599).contains(code), raw.count == 3 || raw[3] == 32 || raw[3] == 45 else { throw SMTPFailure.protocolError }
            guard expected == nil || expected == code else { throw SMTPFailure.protocolError }
            expected = code
            lines.append(String(decoding: raw.dropFirst(min(4, raw.count)), as: UTF8.self))
            if raw.count == 3 || raw[3] == 32 { return SMTPReply(code: code, lines: lines) }
        }
        throw SMTPFailure.oversized
    }
}
protocol SMTPWire: AnyObject {
    func readReply() throws -> SMTPReply
    func command(_ value: String) throws -> SMTPReply
    func startTLS(host: String) throws
    func close()
}
struct SMTPOptions: Codable, Hashable {
    var ehlo = "emailgrabber.invalid"
    var sender = ""
    var requireTLS = true
    var timeout: TimeInterval = 10
    var temporaryRetries = 1
    var cooldown: TimeInterval = 30
    var valid: Bool { MailAddressSafety.hostname(ehlo) && EmailPolicy.validSyntax(sender) && !ehlo.lowercased().hasSuffix(".invalid") && !sender.lowercased().hasSuffix(".invalid") }
}
struct SMTPObservation: Codable, Hashable {
    var at = Date()
    var server: String
    var ip: String
    var stage: String
    var code: Int?
    var text: String
    var tls: Bool
}
struct SMTPVerification: Codable, Hashable {
    enum Verdict: String, Codable { case accepted = "SMTP accepted", rejected = "SMTP rejected", catchAll = "Catch-all", temporary = "Temporary", blocked = "Blocked", unknown = "Unknown", cancelled = "Cancelled" }
    var verdict: Verdict
    var reason: String
    var checkedAt = Date()
    var checkerVersion = "smtp-0.12.0-dev"
    var observations: [SMTPObservation] = []
    var flags: [String] = []
    var connectionFailed = false
    var options: SMTPOptions?
}
struct ProviderVerification: Codable, Hashable {
    var status: String
    var reason: String
    var checkedAt = Date()
    var checkerVersion = "ZeroBounce-v2"
    var requestFailed = false
    var lastConclusionStatus: String?
    var lastConclusionReason: String?
    var lastConclusionAt: Date?
}

/// One instance per serial batch. There is never a message body, authentication,
/// VRFY or EXPN. RCPT acceptance is evidence, not a delivery guarantee.
final class MailboxVerifier {
    typealias Connect = (String, String, TimeInterval, @escaping () -> Bool) throws -> SMTPWire
    private let resolve: (String, () -> Bool) -> MailRoutingResult
    private let connect: Connect
    private let now: () -> Date
    private let sleep: (TimeInterval) -> Void
    private var cooldowns: [String: Date] = [:]
    init(routing: MailRouting = MailRouting(), connect: @escaping Connect = { try SMTPSocketWire(ip: $0, host: $1, timeout: $2, cancelled: $3) }, now: @escaping () -> Date = Date.init, sleep: @escaping (TimeInterval) -> Void = Thread.sleep(forTimeInterval:)) {
        self.resolve = { routing.resolve($0, cancelled: $1) }; self.connect = connect; self.now = now; self.sleep = sleep
    }
    init(resolve: @escaping (String, () -> Bool) -> MailRoutingResult, connect: @escaping Connect, now: @escaping () -> Date = Date.init, sleep: @escaping (TimeInterval) -> Void = { _ in }) {
        self.resolve = resolve; self.connect = connect; self.now = now; self.sleep = sleep
    }
    static func classify(_ reply: SMTPReply) -> SMTPVerification.Verdict {
        if [250,251].contains(reply.code) { return .accepted }
        if reply.code == 252 { return .unknown }
        if (400...499).contains(reply.code) || reply.enhanced == "5.2.2" { return .temporary }
        let lower = reply.text.lowercased()
        if reply.code >= 500 && ["relay", "authentication", "sender", "client ip", "client host", "blacklist", "blocklist", "policy", "access denied"].contains(where: lower.contains) { return .blocked }
        if reply.enhanced?.hasPrefix("5.7.") == true { return .blocked }
        if (500...599).contains(reply.code), reply.enhanced == "5.1.1" { return .rejected }
        return .unknown
    }
    func verify(_ address: String, options: SMTPOptions, cancelled: @escaping () -> Bool = { false }) -> SMTPVerification {
        var evidence: [SMTPObservation] = []
        let flags = DisposableDomainData.flags(address)
        func result(_ verdict: SMTPVerification.Verdict, _ reason: String, connectionFailed: Bool = false) -> SMTPVerification {
            SMTPVerification(verdict: verdict, reason: reason, checkedAt: now(), observations: evidence, flags: flags, connectionFailed: connectionFailed, options: options)
        }
        guard !cancelled() else { return result(.cancelled, "Cancelled") }
        guard EmailPolicy.validSyntax(address) else { return result(.unknown, "Unsupported address syntax; no probe sent") }
        guard options.valid else { return result(.unknown, "Supply your own valid EHLO hostname and sender identity; no probe sent") }
        let domain = String(address.split(separator: "@")[1]).lowercased()
        if let until = cooldowns[domain], until > now() { return result(.temporary, "Domain cooldown after an inconclusive or throttled check") }
        let routing = resolve(domain, cancelled)
        guard !cancelled() else { return result(.cancelled, "Cancelled") }
        switch routing.state {
        case .nxDomain, .nullMX: return result(.rejected, routing.reason)
        case .temporary: return result(.temporary, routing.reason)
        case .unknown, .noMail: return result(.unknown, routing.reason)
        case .routes: break
        }
        let deadline = now().addingTimeInterval(120)
        var connected = false; var last: SMTPVerification.Verdict = .unknown
        let preferred = routing.routes.map(\.preference).min() ?? 0
        for route in routing.routes.prefix(3) {
            for ip in route.addresses.prefix(2) {
                guard MailAddressSafety.publicIP(ip) else { continue }
                for retry in 0...min(1, max(0, options.temporaryRetries)) {
                    guard !cancelled() else { return result(.cancelled, "Cancelled") }
                    guard now() < deadline else { return result(.temporary, "Overall verification time limit reached") }
                    var tls = false
                    func record(_ stage: String, _ reply: SMTPReply) {
                        if evidence.count < 128 { evidence.append(.init(at: now(), server: route.host, ip: ip, stage: stage, code: reply.code, text: reply.text, tls: tls)) }
                    }
                    do {
                        let wire = try connect(ip, route.host, min(20, max(1, options.timeout)), { cancelled() || self.now() >= deadline })
                        connected = true
                        defer { wire.close() }
                        func cmd(_ text: String, stage: String? = nil) throws -> SMTPReply {
                            guard !cancelled() else { throw SMTPFailure.cancelled }
                            let reply = try wire.command(text); record(stage ?? text.components(separatedBy: " ")[0], reply); return reply
                        }
                        let greeting = try wire.readReply(); record("greeting", greeting)
                        guard greeting.code == 220 else { last = greeting.code / 100 == 4 ? .temporary : .blocked; throw SMTPFailure.protocolError }
                        var hello = try cmd("EHLO " + options.ehlo)
                        if [500,502,504].contains(hello.code) { hello = try cmd("HELO " + options.ehlo) }
                        guard hello.code == 250 else { last = hello.code / 100 == 4 ? .temporary : .blocked; throw SMTPFailure.protocolError }
                        let supportsTLS = hello.lines.contains { $0.uppercased().split(whereSeparator: \.isWhitespace).first == "STARTTLS" }
                        if supportsTLS {
                            guard try cmd("STARTTLS").code == 220 else { throw SMTPFailure.tlsFailed }
                            try wire.startTLS(host: route.host); tls = true
                            guard try cmd("EHLO " + options.ehlo).code == 250 else { throw SMTPFailure.protocolError }
                        } else if options.requireTLS { throw SMTPFailure.tlsUnavailable }
                        func recipient(_ value: String, stage: String) throws -> SMTPReply {
                            // Each target/control uses a new transaction, never DATA.
                            let reset = try cmd("RSET")
                            guard reset.code == 250 else { throw SMTPFailure.protocolError }
                            let mail = try cmd("MAIL FROM:<" + options.sender + ">")
                            guard mail.code == 250 else { last = mail.code / 100 == 4 ? .temporary : .blocked; throw SMTPFailure.protocolError }
                            return try cmd("RCPT TO:<" + value + ">", stage: stage)
                        }
                        let target = try recipient(address, stage: "target RCPT")
                        last = Self.classify(target)
                        if last == .accepted {
                            var a = "eg-check-" + UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased() + "@" + domain
                            while a.lowercased() == address.lowercased() { a = "eg-check-" + UUID().uuidString.lowercased() + "@" + domain }
                            var b = "eg-check-" + UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased() + "@" + domain
                            while b == a || b.lowercased() == address.lowercased() { b = "eg-check-" + UUID().uuidString.lowercased() + "@" + domain }
                            let controlA = Self.classify(try recipient(a, stage: "control 1 RCPT"))
                            let controlB = Self.classify(try recipient(b, stage: "control 2 RCPT"))
                            _ = try? cmd("RSET"); _ = try? cmd("QUIT")
                            if controlA == .rejected && controlB == .rejected { return result(.accepted, "Target accepted; two random controls rejected. Delivery is not guaranteed.") }
                            if controlA == .accepted && controlB == .accepted { return result(.catchAll, "Target and both random controls accepted; individual mailbox existence unknown") }
                            cooldowns[domain] = now().addingTimeInterval(max(5, options.cooldown))
                            return result(.unknown, "Target accepted but controls were mixed, blocked, temporary or inconclusive")
                        }
                        _ = try? cmd("RSET"); _ = try? cmd("QUIT")
                        if last == .rejected && route.preference == preferred { return result(.rejected, "Preferred mail server returned recipient-specific 5.1.1") }
                        if last == .rejected { last = .unknown } // Backup rejection is not definitive.
                        if last == .blocked || last == .unknown { break }
                    } catch {
                        if cancelled() { return result(.cancelled, "Cancelled") }
                        if last == .accepted { last = .unknown }
                        if evidence.count < 128 { evidence.append(.init(at: now(), server: route.host, ip: ip, stage: "transport", code: nil, text: String(describing: error), tls: tls)) }
                        if error as? SMTPFailure == .tlsFailed || error as? SMTPFailure == .tlsUnavailable || error as? SMTPFailure == .certificateRejected { last = .unknown; break }
                    }
                    if last != .temporary || retry >= min(1, max(0, options.temporaryRetries)) { break }
                    // Short cancellable backoff; longer greylisting is left to a
                    // later user-initiated batch rather than hammering a server.
                    for _ in 0..<10 { if cancelled() { break }; sleep(0.1) }
                }
            }
        }
        cooldowns[domain] = now().addingTimeInterval(max(5, options.cooldown))
        return result(last, connected ? "Mail server response was inconclusive; inspect SMTP evidence" : "Could not connect to recipient servers; outbound port 25 may be restricted", connectionFailed: !connected)
    }
}

enum VerificationApplication {
    static func eligible(_ row: FoundEmail, rules: [SmartRule], removed: Set<String>) -> Bool {
        !removed.contains(row.address.lowercased()) && !rules.contains { $0.matches(row.address) } && !row.status.hasPrefix("Excluded") && row.status != "Removed" && TechnicalAddressPolicy.rejectionReason(row.address) == nil && EmailPolicy.validSyntax(row.address)
    }
    static func targets(_ rows: [FoundEmail], selected: Set<UUID>? = nil, rules: [SmartRule], removed: Set<String>, uncheckedOnly: Bool = false) -> [String] {
        var seen = Set<String>()
        return rows.filter { (selected == nil || selected!.contains($0.id)) && eligible($0, rules: rules, removed: removed) && (!uncheckedOnly || $0.smtpVerification == nil) }.compactMap {
            seen.insert($0.address.lowercased()).inserted ? $0.address : nil
        }.prefix(100).map { $0 }
    }
    static func smtp(_ result: SMTPVerification, to row: inout FoundEmail) {
        row.smtpVerification = result
        guard !row.status.hasPrefix("Excluded") && row.status != "Removed" && TechnicalAddressPolicy.rejectionReason(row.address) == nil else { return }
        // Keep the provider conclusion separate and visible until explicitly
        // compared. A new SMTP attempt must not erase it.
        guard row.providerVerification?.requestFailed != false else { row.checkedAt = max(row.checkedAt, result.checkedAt); return }
        switch result.verdict {
        case .accepted: row.status = "Accepted"
        case .rejected: row.status = "Rejected"
        case .catchAll, .blocked, .temporary, .unknown: row.status = "Uncertain"
        case .cancelled: return
        }
        row.reason = result.verdict.rawValue + ": " + result.reason; row.checkedAt = result.checkedAt
    }
    static func provider(_ result: ProviderVerification, to row: inout FoundEmail) {
        var record = result
        if result.requestFailed, let previous = row.providerVerification {
            record.lastConclusionStatus = previous.requestFailed ? previous.lastConclusionStatus : previous.status
            record.lastConclusionReason = previous.requestFailed ? previous.lastConclusionReason : previous.reason
            record.lastConclusionAt = previous.requestFailed ? previous.lastConclusionAt : previous.checkedAt
        }
        row.providerVerification = record
        guard !result.requestFailed, !row.status.hasPrefix("Excluded") && row.status != "Removed", TechnicalAddressPolicy.rejectionReason(row.address) == nil else { return }
        row.status = result.status; row.reason = result.reason; row.checkedAt = result.checkedAt
    }
}

enum VerificationCSV {
    static let header = "email,status,reason,source,checked_at,smtp_verdict,smtp_reason,smtp_checked_at,smtp_checker,smtp_evidence,smtp_flags,zerobounce_status,zerobounce_reason,zerobounce_checked_at,zerobounce_checker,zerobounce_request_failed,zerobounce_last_conclusion,zerobounce_last_conclusion_reason,zerobounce_last_conclusion_at,smtp_ehlo,smtp_sender,smtp_tls_required"
    static func line(_ row: FoundEmail) -> String {
        let date = ISO8601DateFormatter()
        var fields = [row.address, row.status, row.reason, row.source, date.string(from: row.checkedAt)]
        fields.append(row.smtpVerification?.verdict.rawValue ?? "")
        fields.append(row.smtpVerification?.reason ?? "")
        fields.append(row.smtpVerification.map { date.string(from: $0.checkedAt) } ?? "")
        fields.append(row.smtpVerification?.checkerVersion ?? "")
        fields.append(row.smtpVerification.flatMap { try? JSONEncoder().encode($0.observations) }.map { String(decoding: $0, as: UTF8.self) } ?? "")
        fields.append(row.smtpVerification?.flags.joined(separator: "; ") ?? "")
        fields.append(row.providerVerification?.status ?? "")
        fields.append(row.providerVerification?.reason ?? "")
        fields.append(row.providerVerification.map { date.string(from: $0.checkedAt) } ?? "")
        fields.append(row.providerVerification?.checkerVersion ?? "")
        fields.append(row.providerVerification.map { String($0.requestFailed) } ?? "")
        fields.append(row.providerVerification?.lastConclusionStatus ?? "")
        fields.append(row.providerVerification?.lastConclusionReason ?? "")
        fields.append(row.providerVerification?.lastConclusionAt.map { date.string(from: $0) } ?? "")
        fields.append(row.smtpVerification?.options?.ehlo ?? "")
        fields.append(row.smtpVerification?.options?.sender ?? "")
        fields.append(row.smtpVerification?.options.map { String($0.requireTLS) } ?? "")
        return fields.map(EmailPolicy.csvField).joined(separator: ",")
    }
}
