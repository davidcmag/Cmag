import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

struct HTTPResult {
    var data: Data? = nil
    var status: Int? = nil
    var finalURL: URL? = nil
    var error: String? = nil
    var charset: String? = nil
    var deferredURL: URL? = nil
    var decodedText: String? {
        guard let data = data else { return nil }
        let encoding: String.Encoding
        switch charset?.lowercased() {
        case "iso-8859-1", "latin1": encoding = .isoLatin1
        case "windows-1252": encoding = .windowsCP1252
        case "utf-16", "utf16": encoding = .utf16
        case "utf-16le": encoding = .utf16LittleEndian
        case "utf-16be": encoding = .utf16BigEndian
        default: encoding = .utf8
        }
        return String(data: data, encoding: encoding) ?? String(data: data, encoding: .utf8)
    }
    var succeeded: Bool { error == nil && status.map { (200..<300).contains($0) } == true && data != nil }
}

/// Streaming URLSession transfer: preserves the native Mac network stack,
/// bounds response memory while downloading, and cancels timed-out requests.
enum HTTPTransport {
    private static let poolLock = NSLock()
    private static let shared = Pool(protocolClasses: nil)
    private static var fixturePools: [[ObjectIdentifier]: Pool] = [:]
    private static func pool(_ classes: [AnyClass]?) -> Pool {
        guard let classes = classes else { return shared }
        let key = classes.map(ObjectIdentifier.init)
        poolLock.lock(); defer { poolLock.unlock() }
        if let existing = fixturePools[key] { return existing }
        let value = Pool(protocolClasses: classes); fixturePools[key] = value; return value
    }
    static func perform(_ request: URLRequest, maxBytes: Int = 3_000_000, timeout: TimeInterval = 15,
                        shouldCancel: () -> Bool = { false }, protocolClasses: [AnyClass]? = nil, redirect: @escaping (URL) -> Bool = EmailPolicy.httpURL) -> HTTPResult {
        guard let url = request.url, EmailPolicy.httpURL(url) else { return HTTPResult(error: "Invalid HTTP URL") }
        let transfer = Transfer(limit: maxBytes, redirect: redirect)
        let task = pool(protocolClasses).start(request, transfer: transfer)
        let deadline = Date().addingTimeInterval(timeout)
        while true {
            transfer.condition.lock()
            if transfer.done {
                let result = transfer.result; transfer.condition.unlock(); return result
            }
            _ = transfer.condition.wait(until: min(deadline, Date().addingTimeInterval(0.1)))
            let finished = transfer.done
            transfer.condition.unlock()
            if finished { continue }
            let cancelled = shouldCancel()
            transfer.condition.lock(); let finishedAfterControl = transfer.done; transfer.condition.unlock()
            if finishedAfterControl && !cancelled { continue }
            if cancelled || Date() >= deadline {
                task.cancel()
                return HTTPResult(finalURL: request.url, error: Date() >= deadline ? "Request timed out" : "Cancelled")
            }
        }
    }
    /// Shared native sessions preserve connection reuse instead of creating a new
    /// TLS connection/session for every page. The delegate queue remains serial.
    private final class Pool: NSObject, URLSessionDataDelegate, @unchecked Sendable {
        private let lock = NSLock()
        private var transfers: [Int: Transfer] = [:]
        private var session: URLSession!
        init(protocolClasses: [AnyClass]?) {
            super.init()
            let configuration = URLSessionConfiguration.ephemeral
            configuration.httpCookieStorage = HTTPCookieStorage.shared
            configuration.timeoutIntervalForResource = 70
            if let classes = protocolClasses { configuration.protocolClasses = classes }
            session = URLSession(configuration: configuration, delegate: self, delegateQueue: nil)
        }
        func start(_ request: URLRequest, transfer: Transfer) -> URLSessionDataTask {
            let task = session.dataTask(with: request)
            lock.lock(); transfers[task.taskIdentifier] = transfer; lock.unlock()
            task.resume(); return task
        }
        private func transfer(_ task: URLSessionTask) -> Transfer? {
            lock.lock(); defer { lock.unlock() }; return transfers[task.taskIdentifier]
        }
        func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
            guard let value = transfer(dataTask) else { completionHandler(.cancel); return }
            value.urlSession(session, dataTask: dataTask, didReceive: response, completionHandler: completionHandler)
        }
        func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) { transfer(dataTask)?.urlSession(session, dataTask: dataTask, didReceive: data) }
        func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
            lock.lock(); let value = transfers.removeValue(forKey: task.taskIdentifier); lock.unlock()
            value?.urlSession(session, task: task, didCompleteWithError: error)
        }
        func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
            guard let value = transfer(task) else { completionHandler(nil); return }
            // Robots checks may make another request. Run policy off the serial
            // delegate queue so that nested request can receive its response.
            DispatchQueue.global().async { value.urlSession(session, task: task, willPerformHTTPRedirection: response, newRequest: request, completionHandler: completionHandler) }
        }
    }
    private final class Transfer: NSObject, URLSessionDataDelegate, @unchecked Sendable {
        let condition = NSCondition()
        let limit: Int
        let redirect: (URL) -> Bool
        var result = HTTPResult()
        var done = false
        var hops = 0
        init(limit: Int, redirect: @escaping (URL) -> Bool) { self.limit = limit; self.redirect = redirect }
        func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse,
                        completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
            condition.lock()
            result.charset = response.textEncodingName
            result.status = (response as? HTTPURLResponse)?.statusCode
            result.finalURL = response.url
            let tooLarge = response.expectedContentLength > Int64(limit)
            if tooLarge { result.error = "Response exceeds download limit" }
            condition.unlock()
            completionHandler(tooLarge ? .cancel : .allow)
        }
        func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
            condition.lock()
            let tooLarge = (result.data?.count ?? 0) + data.count > limit
            if tooLarge { result.error = "Response exceeds download limit" }
            else { if result.data == nil { result.data = Data() }; result.data!.append(data) }
            condition.unlock()
            if tooLarge { dataTask.cancel() }
        }
        func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
            condition.lock(); defer { condition.unlock() }
            if let error = error, result.error == nil { result.error = error.localizedDescription }
            if result.data == nil && result.error == nil { result.data = Data() }
            done = true; condition.broadcast()
        }
        func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                        newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
            condition.lock(); hops += 1; let active = !done; let count = hops; condition.unlock()
            let allowed = active && count <= 5 && request.url.map { EmailPolicy.httpURL($0) && redirect($0) } == true
            if !allowed {
                condition.lock(); result.error = "Unsafe or disallowed redirect"; condition.unlock()
            }
            completionHandler(allowed ? request : nil)
        }
    }
}
