"""Topic-agnostic public search with deduplication and bounded, polite pagination."""
import base64
import html
import time
import urllib.parse
from html.parser import HTMLParser
from defusedxml import ElementTree as ET

SEARCH_HOSTS=('bing.com','duckduckgo.com','microsoft.com','msn.com')

class Results(HTMLParser):
    def __init__(self,text):
        super().__init__(convert_charrefs=True)
        self.urls=[];self.forms=[];self.form=None
        self.feed(text)
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='a' and a.get('href'):
            if 'result__a' in a.get('class','').split():self.urls.append(a['href'])
        elif tag=='form':self.form={'action':a.get('action',''),'fields':{}}
        elif tag=='input' and self.form is not None and a.get('name'):
            self.form['fields'][a['name']]=a.get('value','')
    def handle_endtag(self,tag):
        if tag=='form' and self.form is not None:
            self.forms.append(self.form);self.form=None

def result_url(raw,base):
    link=urllib.parse.urljoin(base,html.unescape(raw))
    p=urllib.parse.urlsplit(link)
    host=(p.hostname or '').lower()
    args=urllib.parse.parse_qs(p.query)
    if host.endswith('duckduckgo.com') and args.get('uddg'):
        link=args['uddg'][0]
    elif (host=='bing.com' or host.endswith('.bing.com')) and p.path=='/ck/a' and args.get('u'):
        value=args['u'][0]
        if value.startswith('a1'):
            try:link=base64.urlsafe_b64decode(value[2:]+'='*(-len(value[2:])%4)).decode()
            except (ValueError,UnicodeError):return None
    p=urllib.parse.urlsplit(link);host=(p.hostname or '').lower()
    if p.scheme not in ('http','https') or not host or p.username or p.password:return None
    if any(host==h or host.endswith('.'+h) for h in SEARCH_HOSTS):return None
    return urllib.parse.urlunsplit((p.scheme,p.netloc,p.path or '/',p.query,''))

def queries(query):
    return list(dict.fromkeys([query]+[query+' '+suffix for suffix in ('contact','email','staff','team','directory','people','profiles')]))

def discover(network,query,control,report,progress=lambda info:None,pages=3,wait=None):
    wait=wait or time.sleep
    found={};requests=0
    for term in queries(query):
        for provider in ('bing','duckduckgo'):
            previous=None;seen_pages=set();next_url=None
            for page in range(pages):
                if not control():return list(found.values())
                url=next_url or ('https://www.bing.com/search?'+urllib.parse.urlencode({'format':'rss','q':term,'first':page*10+1}) if provider=='bing' else 'https://html.duckduckgo.com/html/?'+urllib.parse.urlencode({'q':term}))
                if url in seen_pages:break
                seen_pages.add(url);next_url=None
                try:
                    text,_=network.fetch(url);requests+=1
                    if provider=='bing':
                        raw=[x.text for x in ET.fromstring(text).findall('.//item/link') if x.text]
                    else:
                        parsed=Results(text);raw=parsed.urls
                        for form in parsed.forms:
                            fields=form['fields']
                            if 's' not in fields or not fields['s'].isdigit() or int(fields['s'])<=page*10:continue
                            target=urllib.parse.urljoin(url,form['action'])
                            p=urllib.parse.urlsplit(target)
                            if p.scheme=='https' and p.hostname=='html.duckduckgo.com' and p.path in ('/html/','/html'):
                                fields={k:v for k,v in fields.items() if k in ('q','s','dc','v','o','api','kl','nextParams')}
                                fields.setdefault('q',term)
                                next_url=urllib.parse.urlunsplit((p.scheme,p.netloc,p.path,urllib.parse.urlencode(fields),''));break
                    candidates=[link for x in raw if (link:=result_url(x,url))]
                    fingerprint=tuple(sorted(set(candidates)))
                    for link in candidates:
                        host=(urllib.parse.urlsplit(link).hostname or '').lower().removeprefix('www.')
                        found.setdefault(host,link)
                    progress({'source':provider,'query':term,'hosts':list(found),'requests':requests})
                    # Bing RSS can ignore offsets. Do not waste requests claiming
                    # those repeated responses are additional result pages.
                    if not candidates or fingerprint==previous:break
                    previous=fingerprint
                    if provider=='duckduckgo' and not next_url:break
                except Exception as e:
                    report(f'{provider}: {type(e).__name__}: {e}');break
                finally:
                    wait(1)
    return list(found.values())
