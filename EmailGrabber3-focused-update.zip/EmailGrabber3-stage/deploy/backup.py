"""Run as root on the inspected VPS; creates private backups, never restarts services."""
import hashlib
import os
from pathlib import Path
import sqlite3
import subprocess
import tarfile
from datetime import datetime, timezone

os.umask(0o077)
app = Path('/opt/emailgrabber3/app/EmailGrabber3-VPS')
db = Path('/var/lib/emailgrabber3/results.sqlite3')
if os.geteuid() != 0 or not app.is_dir() or not db.is_file():
    raise SystemExit('Expected root account, application, and database not found; nothing changed')
backup = Path('/root/emailgrabber-backup') / ('codex-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
backup.mkdir(parents=True, mode=0o700)
paths = [app, Path('/etc/systemd/system/emailgrabber.service'), Path('/etc/systemd/system/emailgrabber.service.d'), Path('/etc/nginx/conf.d/vhosts/grabber.spymastermagazine.com.ssl.conf'), Path('/etc/nginx/emailgrabber-proxy.conf'), Path('/etc/nginx/emailgrabber.htpasswd')]
archive = backup / 'application-and-config.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for path in paths:
        if path.exists():
            tar.add(path, arcname=str(path).lstrip('/'))
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getnames()
    if 'opt/emailgrabber3/app/EmailGrabber3-VPS/server.py' not in members:
        raise SystemExit('Backup validation failed: server.py missing')
source = sqlite3.connect(db.as_uri() + '?mode=ro', uri=True)
target = sqlite3.connect(backup / 'results.sqlite3')
try:
    source.backup(target)
    if target.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
        raise SystemExit('Database backup failed integrity check')
finally:
    target.close()
    source.close()
unit = subprocess.run(['systemctl', 'cat', 'emailgrabber'], check=True, capture_output=True)
(backup / 'emailgrabber-effective-unit.txt').write_bytes(unit.stdout)
print('Verified private backup:', backup)
print('Running service unchanged.')
print('Current server.py SHA256:', hashlib.sha256((app/'server.py').read_bytes()).hexdigest())
