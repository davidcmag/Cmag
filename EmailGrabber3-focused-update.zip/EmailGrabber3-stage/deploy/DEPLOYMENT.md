# Controlled deployment plan — not yet executed

## Access and inspection gate

Verify the SSH ED25519 host fingerprint out of band before authenticating:

`SHA256:Q1GBa3mbEdulixVbFFeuaNv7eaMq4L3ItxZkCKcte9Q`

The supplied host is 173.231.242.91, SSH port 22, user root. A dedicated temporary public key was installed by the operator. Its private key is not part of this package. Remove the matching `codex-emailgrabber-temporary` authorized key after work.

Before modifications inspect (without printing credentials):

- Actual application directory `/opt/emailgrabber3/app/EmailGrabber3-VPS` and files.
- Python `/opt/emailgrabber3/venv/bin/python`, version 3.12.x.
- Systemd service `/etc/systemd/system/emailgrabber.service`, drop-ins, executable, working directory, user, bind address and database binding.
- Database `/var/lib/emailgrabber3/results.sqlite3`, owner and permissions.
- HTTPS vhost `/etc/nginx/conf.d/vhosts/grabber.spymastermagazine.com.ssl.conf` and include `/etc/nginx/emailgrabber-proxy.conf`. Do not print or copy password-file contents into logs.
- Current service health and response; Basic Auth denial on `/`, `/api/state`, `/api/results`, `/api/jobs`, `/api/export`, and state-changing requests.
- Listening sockets and firewall: 8787 must remain loopback-only.

Do not replace Nginx, Apache, system Python, the existing service account, or unrelated CWP configuration.

## Stage and back up

1. Stage this package in a new versioned release directory outside the current application. Verify package checksums.
2. Create a new release-specific venv using the installed Python 3.12. Install only requirements.txt. Preserve TLS/package verification; do not alter the existing venv in place.
3. Run integration tests in staging (requirements-dev.txt and Chromium are for testing only). Use a temporary database, not production results. Audit changed network behavior and authentication before release.
4. Stop emailgrabber cleanly. Back up the complete existing application tree, the SQLite database using SQLite's backup API, service configuration including drop-ins, and affected Nginx configuration to a root-owned mode-700 timestamped directory under `/root/emailgrabber-backup`. Preserve ownership, modes and ACLs. Include WAL state through the SQLite backup API; do not copy only an actively written .sqlite3 file.
5. Verify that backups open, SQLite integrity_check returns ok, archives list successfully and recovery paths are recorded before changing application files. Keep backups off the public web root and out of distributable packages.

## Switch and verify

Use the inspected service layout to choose an atomic release switch or a small backed-up systemd drop-in. Keep the restricted emailgrabber account, existing database path, local bind, TLS and proxy authentication. Additive database migrations are performed on opening the new service; retain the pre-migration backup.

Verify local UI, import, direct URL crawl, arbitrary-keyword discovery, obfuscated extraction, blocked-site continuation, filtering, bulk delete/undo, CSV and XLSX exports, and persistent jobs. Stop and restart the service with committed results and pending links, then explicitly resume the saved job. Compare results and job state.

Verify authenticated behavior through https://grabber.spymastermagazine.com. Supply Basic Auth through a secure prompt or protected credential binding; never embed it in URLs or command lines. Test unauthenticated denial on all routes, CSRF rejection, private-IP and redirect rejection, and absence of a public port 8787 listener. Confirm real robots restrictions and rates. Do not treat HTTP 200 or an open port as acceptance.

## Roll back

Stop the new service. Restore the former executable/working directory or remove only the deployment's new drop-in; restore previously saved configuration if touched. Restore the pre-migration database using SQLite backup, and restore recorded ownership/modes. Preserve the newer database separately first so collected results can be reconciled. Run systemctl daemon-reload if service configuration changed, start the former service, verify local behavior and authenticated public routes. No Nginx reload is necessary unless its configuration was actually changed; if changed, run nginx -t before reloading.

An executable deployment script will be tailored only after inspecting the actual VPS. This document does not establish deployability or public verification.
