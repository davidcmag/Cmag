"""Report honest crawler GET responses; does not spoof a browser or bypass protection."""
import sys
from pathlib import Path
import urllib.parse,urllib.error
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from crawler import Network
url=sys.argv[1] if len(sys.argv)>1 else 'https://murphyfuneralnc.com/'
p=urllib.parse.urlsplit(url)
for path in ('/robots.txt',p.path or '/'):
    target=urllib.parse.urlunsplit((p.scheme,p.netloc,path,'',''))
    try:
        body,final=Network().fetch(target)
        print(path,': HTTP 200; text bytes:',len(body.encode()),'; final:',final,flush=True)
    except urllib.error.HTTPError as e:
        print(path,': HTTP',e.code,'; server:',e.headers.get('Server','unknown'),flush=True)
    except Exception as e:
        print(path,':',type(e).__name__,str(e),flush=True)
