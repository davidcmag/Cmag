"""Activate this staged candidate with a fresh backup and automatic code rollback."""
import hashlib
import json
import os
from pathlib import Path
import pwd
import shutil
import sqlite3
import subprocess
import time
import urllib.error
import urllib.request
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parents[1]
PREVIOUS=Path('/opt/emailgrabber3-releases/stage-c275cca6b623')
DB=Path('/var/lib/emailgrabber3/results.sqlite3')
DROPIN=Path('/etc/systemd/system/emailgrabber.service.d/90-release.conf')

def command(*args):subprocess.run(args,check=True,timeout=90)
def property_value(name):return subprocess.check_output(['systemctl','show','emailgrabber','--value','-p',name],text=True).strip()
def database_backup(target):
    with sqlite3.connect(DB.as_uri()+'?mode=ro',uri=True) as source,sqlite3.connect(target) as dest:
        source.backup(dest)
        if dest.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('Database backup integrity check failed')
def members():
    with sqlite3.connect(DB.as_uri()+'?mode=ro',uri=True) as c:
        return set(c.execute('SELECT id,email FROM emails'))
def readiness():
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    deadline=time.monotonic()+30
    while True:
        try:
            with opener.open('http://127.0.0.1:8787/api/state',timeout=5) as r:state=json.load(r)
            with opener.open('http://127.0.0.1:8787/',timeout=5) as r:page=r.read().decode()
            if 'id="crawlMode"' not in page:raise RuntimeError('Focused interface was not served')
            return state
        except (OSError,ValueError,RuntimeError):
            if time.monotonic()>=deadline:raise
            time.sleep(1)

def main(release_parent=Path('/opt/emailgrabber3-releases'),owner_uid=0,backup_parent=Path('/root/emailgrabber-backup')):
    if os.geteuid()!=owner_uid:raise RuntimeError('Run as root')
    if ROOT.parent!=release_parent or ROOT.is_symlink() or ROOT.stat().st_uid!=owner_uid:
        raise RuntimeError('Run only from the root-owned staged release')
    proof=json.loads((ROOT/'stage-passed.json').read_text())
    if proof['manifest']!=hashlib.sha256((ROOT/'SHA256SUMS').read_bytes()).hexdigest():raise RuntimeError('Staging proof does not match this package')
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        digest,name=line.split('  ',1)
        path=ROOT/name
        if path.is_symlink() or ROOT not in path.resolve().parents or hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
            raise RuntimeError('Package checksum failed: '+name)
    if property_value('User')!='emailgrabber' or property_value('WorkingDirectory')!=str(PREVIOUS):
        raise RuntimeError('Service differs from the inspected production release')
    # This update changes crawling/UI, not persistence. Keeping the same DB on
    # code rollback therefore preserves any records committed after activation.
    if (ROOT/'core.py').read_bytes()!=(PREVIOUS/'core.py').read_bytes():
        raise RuntimeError('Persistence code differs; this rollback strategy is not applicable')
    user=pwd.getpwnam('emailgrabber')
    if any(p.stat().st_gid!=user.pw_gid for p in (DB,DB.parent)):
        raise RuntimeError('Database directory/group requires inspection before restricting permissions')
    if DROPIN.is_symlink() or not DROPIN.is_file():raise RuntimeError('Expected release drop-in not found')
    os.umask(0o077)
    backup=backup_parent/('focus-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    backup.mkdir(mode=0o700)
    shutil.copy2(DROPIN,backup/'90-release.conf')
    (backup/'effective-unit.txt').write_bytes(subprocess.check_output(['systemctl','cat','emailgrabber']))
    print('Private rollback backup:',backup,flush=True)
    stopped=False;switched=False
    try:
        command('systemctl','stop','emailgrabber');stopped=True
        database_backup(backup/'results.sqlite3')
        committed=members()
        print('Fresh database backup verified; committed records:',len(committed),flush=True)
        text=f'[Service]\nExecStart=\nExecStart={ROOT}/venv/bin/python {ROOT}/server.py\nWorkingDirectory={ROOT}\nEnvironment=EMAILGRABBER_DB={DB}\n'
        temporary=DROPIN.with_suffix('.tmp')
        temporary.write_text(text);temporary.replace(DROPIN);switched=True
        os.chmod(DB.parent,0o750);os.chmod(DB,0o640)
        for suffix in ('-wal','-shm'):
            p=Path(str(DB)+suffix)
            if p.exists():os.chmod(p,0o640)
        command('systemctl','daemon-reload');command('systemctl','start','emailgrabber')
        state=readiness()
        if not committed.issubset(members()):raise RuntimeError('Committed records missing after activation')
        if property_value('WorkingDirectory')!=str(ROOT):raise RuntimeError('Wrong release active')
        print('ACTIVE RELEASE:',ROOT,flush=True)
        print('Committed records preserved. Saved jobs remain available; resume explicitly if interrupted.',flush=True)
        print('Local readiness passed. Authenticated public acceptance is still required.',flush=True)
    except BaseException:
        if switched:
            subprocess.run(['systemctl','stop','emailgrabber'],timeout=90)
            shutil.copy2(backup/'90-release.conf',DROPIN)
            subprocess.run(['systemctl','daemon-reload'],timeout=90)
        if stopped:subprocess.run(['systemctl','start','emailgrabber'],timeout=90)
        print('Activation failed; previous service configuration restored. Database retained to preserve committed results.',flush=True)
        raise

if __name__=='__main__':
    try:main()
    except Exception as e:raise SystemExit(str(e))
