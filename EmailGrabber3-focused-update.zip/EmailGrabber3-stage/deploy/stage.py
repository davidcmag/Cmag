"""Stage and test a new isolated release; never edit/restart the production service."""
import hashlib
import json
import os
from pathlib import Path
import pwd
import shutil
import sqlite3
import subprocess
import sys
import tarfile

ROOT=Path(__file__).resolve().parents[1]
BASELINES={'65ae49d9df2e0c9991ee11ca02b743477b18a3065986a1d0526372ce80d6194a','a715ef409e1249885d9333a16d126c1302df86a8ac37ee1e2f5f9d8d2eaacc99'}

def run(*args):
    subprocess.run(args,check=True)

if os.geteuid()!=0 or sys.version_info[:2]!=(3,12):
    raise SystemExit('Run using the VPS Python 3.12 as root')
app=Path(subprocess.check_output(['systemctl','show','emailgrabber','--value','-p','WorkingDirectory'],text=True).strip())
if str(app) not in ('/opt/emailgrabber3/app/EmailGrabber3-VPS','/opt/emailgrabber3-releases/stage-c275cca6b623'):
    raise SystemExit('Service working directory differs from the inspected releases')
if hashlib.sha256((app/'server.py').read_bytes()).hexdigest() not in BASELINES:
    raise SystemExit('Production code differs from inspected baseline; stop and inspect')
for prop,expected in [('User','emailgrabber'),('WorkingDirectory',str(app))]:
    actual=subprocess.check_output(['systemctl','show','emailgrabber','--value','-p',prop],text=True).strip()
    if actual!=expected:raise SystemExit('Unexpected service '+prop)
backup=Path('/root/emailgrabber-backup/codex-pre-repair')
with tarfile.open(backup/'app-config.tgz') as tar:
    if 'opt/emailgrabber3/app/EmailGrabber3-VPS/server.py' not in tar.getnames():
        raise SystemExit('Application backup is incomplete')
with sqlite3.connect((backup/'results.sqlite3').as_uri()+'?mode=ro',uri=True) as c:
    if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise SystemExit('Backup DB invalid')
user=pwd.getpwnam('emailgrabber')
manifest=ROOT/'SHA256SUMS'
for line in manifest.read_text().splitlines():
    digest,name=line.split('  ',1)
    path=ROOT/name
    if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
        raise SystemExit('Package checksum failed: '+name)
ident=hashlib.sha256(manifest.read_bytes()).hexdigest()[:12]
os.umask(0o022)
parent=Path('/opt/emailgrabber3-releases')
if parent.is_symlink():raise SystemExit('Staging parent cannot be a symlink')
parent.mkdir(mode=0o755,exist_ok=True)
if parent.stat().st_uid!=0 or parent.stat().st_mode & 0o022:
    raise SystemExit('Staging parent must be root-owned without group/other write access')
release=parent/('stage-'+ident)
if release.exists():
    raise SystemExit('This staging directory already exists; inspect previous results before rerunning: '+str(release))
release.mkdir(mode=0o755)
for line in manifest.read_text().splitlines():
    _,name=line.split('  ',1)
    target=release/name;target.parent.mkdir(parents=True,exist_ok=True,mode=0o755)
    shutil.copyfile(ROOT/name,target);target.chmod(0o644)
shutil.copyfile(manifest,release/'SHA256SUMS');(release/'SHA256SUMS').chmod(0o644)
print('Staging directory:',release,flush=True)
run(sys.executable,'-m','venv',str(release/'venv'))
run(str(release/'venv/bin/python'),'-m','pip','install','-r',str(release/'requirements.txt'))
# A root-owned venv/release lets the restricted service account read but not edit code.
run('runuser','-u',user.pw_name,'--',str(release/'venv/bin/python'),str(release/'deploy/verify_stage.py'))
(release/'stage-passed.json').write_text(json.dumps({'manifest':hashlib.sha256((release/'SHA256SUMS').read_bytes()).hexdigest()}))
(release/'stage-passed.json').chmod(0o644)
print('Staging passed:',release,flush=True)
print('Activate with: '+str(release/'venv/bin/python')+' '+str(release/'deploy/activate.py'),flush=True)
print('The existing emailgrabber service and production database have not been changed.',flush=True)
