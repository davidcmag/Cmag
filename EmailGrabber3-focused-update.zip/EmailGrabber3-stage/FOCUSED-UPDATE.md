# Focused crawling and removal update

This candidate has passed 58 local tests, including two Chromium browser tests. It has not yet been staged or activated on the VPS. Real search-provider coverage must be checked on that server; no website/email count is promised.

## Changes

- Focused crawling is the default for new jobs. It follows contact, sales, staff, team, directory, faculty, people, author/host and related pages. It reads anchor labels as well as paths, follows directory/profile descendants, and skips unrelated blog, legal, shopping, login and calendar links. Explicitly entered URLs are still scanned. Broad crawling remains selectable.
- Seed sites are scanned before deeper links, then higher-value links take priority over ordinary queued pages, including deeper contact links. Focused mode and queued priorities survive stop/restart/resume. Old saved jobs keep their original broad behavior rather than silently changing scope.
- Discovery uses eight topic-agnostic query variations and Bing RSS plus DuckDuckGo. It stops requesting repeated RSS result pages, supports DuckDuckGo next-result forms as GET queries, deduplicates hosts, and shows progress during discovery. Search providers can still restrict requests or ignore pagination. This is a broader strategy, not evidence of improved live coverage until the VPS run completes.
- Each result row has a Remove button next to its email. It soft-deletes that record without creating an exclusion rule, requires no rule dialog, and supports Undo last removal. Other addresses with the same name/domain remain eligible. Removed records remain recoverable and stay out of Included exports.
- HTTP 403 reports distinguish robots.txt denial from a page denial. No browser impersonation, Cloudflare challenge bypass, security disabling, or alternate-network evasion is added. The separate site diagnostic makes honest crawler GET requests to robots.txt and the supplied page.

## Mac comparison

The Mac source ranked contact/staff/team/people/directory/about/leadership pages above ordinary links and penalized legal/blog/news/gallery pages. It did not exclusively scan contact pages in every mode. The new focused setting implements the user's more selective workflow while retaining a broad option.

## VPS staging and activation

Download and verify the ZIP, then extract into a new private directory. Run deploy/stage.py using the installed /opt/emailgrabber3/venv/bin/python. It recognizes the original inspected release and the deployed stage-c275cca6b623 service. It creates a separate immutable candidate, runs the backend and live-public-site checks as emailgrabber, and writes stage-passed.json only after all required checks succeed. It prints the exact activation command. The live service is not changed by staging.

Run the printed activation command only after staging passes. activate.py targets the verified running stage-c275cca6b623 release and requires persistence code to be byte-identical, so code rollback can retain the database without losing committed records. It creates a fresh private database/configuration backup, verifies integrity, stops the old service, changes only the existing release drop-in, starts the new service, checks the focused interface and retained records, and automatically restores the prior configuration if activation fails. It tightens the database directory/files to service-group access after verifying the group. HTTPS, Nginx, Apache and the service account are unchanged.

The activation logic was tested with real temporary SQLite databases and mocked service commands, including a failed startup that restores the old configuration while retaining a record committed after the switch. Actual VPS activation and authenticated public acceptance remain unverified for this candidate.

Keep /opt/emailgrabber3-releases/stage-c275cca6b623 for rollback. After activation, the printed private backup directory contains the previous 90-release.conf. To manually revert later: stop emailgrabber, copy that saved file back to /etc/systemd/system/emailgrabber.service.d/90-release.conf, run systemctl daemon-reload, then start emailgrabber. Keep the current database; persistence code is identical. Do not restore an older database routinely, because that would discard newer results.
