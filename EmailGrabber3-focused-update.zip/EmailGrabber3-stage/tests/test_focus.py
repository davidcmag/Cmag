import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_system import TempStore,FixtureNetwork
import test_system as helpers
from crawler import Crawler,Network,link_rank
from discovery import discover,result_url
from unittest.mock import patch
import unittest,json,urllib.parse

class FocusTests(TempStore):
    def test_prioritizes_label_links_and_skips_blog(self):
        class Site(FixtureNetwork):
            def fetch(self,url,limit=0):
                self.calls.append(url)
                if url.endswith('/'):
                    return '<a href="/blog/post">Read post</a><a href="/p?id=1">Contact sales</a><a href="/people">Our people</a><a href="/calendar">Events</a>',url
                if url.endswith('/people'):return '<a href="/people/jane-doe">Jane Doe</a>',url
                return 'jane@public.org',url
        n=Site();c=Crawler(self.store,n,0)
        c.start(['https://public.org/'],depth=3,crawl_mode='focused');c.worker.join(5)
        self.assertFalse(c.worker.is_alive())
        self.assertIn('https://public.org/p?id=1',n.calls)
        self.assertIn('https://public.org/people/jane-doe',n.calls)
        self.assertFalse(any('/blog' in x or '/calendar' in x for x in n.calls))
        self.assertEqual(len(self.store.records()[0]),1)
    def test_broad_mode_keeps_ordinary_pages_available(self):
        class Site(FixtureNetwork):
            def fetch(self,url,limit=0):
                self.calls.append(url)
                return ('<a href="/blog">Blog</a>' if url.endswith('/') else 'jane@public.org'),url
        n=Site();c=Crawler(self.store,n,0)
        c.start(['https://public.org/'],depth=2,crawl_mode='broad');c.worker.join(5)
        self.assertIn('https://public.org/blog',n.calls)
    def test_explicit_article_seed_is_scanned_in_focused_mode(self):
        n=FixtureNetwork();c=Crawler(self.store,n,0)
        c.start(['https://other.org/blog/article'],depth=1,crawl_mode='focused');c.worker.join(5)
        self.assertEqual(c.status()['pages'],1)
    def test_sales_and_directory_children_rank_above_legal_pages(self):
        self.assertLess(link_rank('https://public.org/sales'),link_rank('https://public.org/privacy'))
        self.assertEqual(link_rank('https://public.org/faculty/jane','Jane','https://public.org/faculty'),0)
    def test_deep_contact_page_is_not_stuck_behind_ordinary_backlog(self):
        class Site(FixtureNetwork):
            def fetch(self,url,limit=0):
                self.calls.append(url)
                if url.endswith('/'):return '<a href="/company">Company</a><a href="/article">Article</a>',url
                if url.endswith('/company'):return '<a href="/contact">Contact</a>',url
                return 'jane@public.org',url
        n=Site();c=Crawler(self.store,n,0)
        c.start(['https://public.org/'],depth=3,crawl_mode='broad',max_pages=3);c.worker.join(5)
        self.assertEqual(n.calls,['https://public.org/','https://public.org/company','https://public.org/contact'])

class SearchTests(unittest.TestCase):
    def test_duplicate_rss_pages_stop_and_queries_expand(self):
        calls=[];progress=[]
        class Search:
            def fetch(self,url):
                calls.append(url)
                q=urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)['q'][0]
                key=q.replace(' ','-')
                if 'bing.com' in url:return f'<rss><channel><item><link>https://{key}.org/</link></item></channel></rss>',url
                return '<html></html>',url
        results=discover(Search(),'astronomy',lambda:True,lambda x:None,progress.append,wait=lambda x:None)
        self.assertEqual(len(results),8)
        self.assertEqual(len(calls),24)
        self.assertTrue(any('astronomy staff'==urllib.parse.parse_qs(urllib.parse.urlsplit(u).query)['q'][0] for u in calls))
        self.assertEqual(len(progress[-1]['hosts']),8)
    def test_duckduckgo_next_page_and_canonical_deduplication(self):
        class Search:
            def fetch(self,url):
                if 'bing.com' in url:return '<rss/>',url
                if 's=30' in url:return '<a class="result__a" href="https://second.org/">second</a>',url
                return '<a class="result__a" href="https://www.first.org/">first</a><form action="/html/"><input name="s" value="30"><input name="q" value="astronomy"></form>',url
        results=discover(Search(),'astronomy',lambda:True,lambda x:None,wait=lambda x:None)
        self.assertEqual(results,['https://www.first.org/','https://second.org/'])
    def test_wrapped_bing_url_decodes_without_accepting_credentials(self):
        import base64
        u=base64.urlsafe_b64encode(b'https://public.org/contact').decode().rstrip('=')
        self.assertEqual(result_url('/ck/a?u=a1'+u,'https://www.bing.com'),'https://public.org/contact')
        self.assertIsNone(result_url('https://user:password@public.org/','https://www.bing.com'))
    def test_stop_prevents_further_search_requests(self):
        class Search:
            def fetch(self,url):raise AssertionError('Should not make a request')
        self.assertEqual(discover(Search(),'astronomy',lambda:False,lambda x:None,wait=lambda x:None),[])

class RemovalTests(TempStore):
    setUp=helpers.HTTPTests.setUp
    tearDown=helpers.HTTPTests.tearDown
    request=helpers.HTTPTests.request
    def test_remove_one_creates_no_rule_and_undo_restores(self):
        self.request('/api/import',{'entries':['jane@public.org','jane2@public.org']})
        before=json.loads(self.request('/api/results')[1]);target=before['rows'][0]
        self.request('/api/delete',{'ids':[target['id']]})
        after=json.loads(self.request('/api/results')[1])
        self.assertEqual(after['total'],1);self.assertEqual(after['rules'],before['rules'])
        self.request('/api/import',{'entries':['jane3@public.org']})
        self.assertEqual(json.loads(self.request('/api/results')[1])['total'],2)
        self.request('/api/undo-delete',{})
        self.assertEqual(json.loads(self.request('/api/results')[1])['total'],3)

class RowRemovalBrowserTests(TempStore):
    setUp=helpers.HTTPTests.setUp
    tearDown=helpers.HTTPTests.tearDown
    request=helpers.HTTPTests.request
    def test_remove_button_needs_no_rule_and_undo_restores_row(self):
        from playwright.sync_api import sync_playwright,expect
        self.request('/api/import',{'entries':['jane@public.org','other@public.org']})
        with sync_playwright() as p:
            browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
            try:
                page=browser.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(self.base)
                expect(page.locator('#crawlMode')).to_have_value('focused')
                expect(page.locator('#body tr')).to_have_count(2)
                page.locator('#body tr').first.get_by_role('button',name='Remove',exact=True).click()
                expect(page.locator('#body tr')).to_have_count(1)
                self.assertEqual(self.app.store.records(view='all')[1],[])
                page.locator('#undoDelete').click()
                expect(page.locator('#body tr')).to_have_count(2)
                self.assertEqual(errors,[])
            finally:browser.close()

class FocusRecoveryTests(TempStore):
    def test_focused_mode_and_deeper_queue_survive_resume(self):
        class Site(FixtureNetwork):
            def fetch(self,url,limit=0):
                self.calls.append(url)
                if url.endswith('/'):return '<a href="/staff">Staff</a><a href="/blog">Blog</a>',url
                return 'jane@public.org',url
        n=Site();c=Crawler(self.store,n,0)
        c.start(['https://public.org/'],depth=2,max_pages=1,crawl_mode='focused');c.worker.join(5)
        ident=c.status()['job_id'];self.assertEqual(self.store.job(ident)['options']['crawl_mode'],'focused')
        restored=Crawler(self.store,n,0);restored.start(resume=ident);restored.worker.join(5)
        self.assertIn('https://public.org/staff',n.calls)
        self.assertNotIn('https://public.org/blog',n.calls)
    def test_robots_denial_is_identified_separately_from_homepage(self):
        import urllib.error
        class Denied(FixtureNetwork):
            def robots(self,url):raise urllib.error.HTTPError('https://public.org/robots.txt',403,'Forbidden',{},None)
            def fetch(self,*a):raise AssertionError('Page should not be requested after robots denial')
        c=Crawler(self.store,Denied(),0);c.start(['https://public.org/'],depth=2,crawl_mode='focused');c.worker.join(5)
        self.assertEqual(c.status()['blocked_sites'],1)
        self.assertIn('robots.txt returned HTTP 403',c.status()['last_error'])
