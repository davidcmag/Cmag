import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import types
import unittest
from unittest.mock import patch

class ActivationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.base=Path(self.temp.name)
        self.parent=self.base/'releases';self.parent.mkdir()
        self.root=self.parent/'stage-new';self.root.mkdir()
        self.previous=self.parent/'stage-c275cca6b623';self.previous.mkdir()
        for directory in (self.root,self.previous):(directory/'core.py').write_text('# same persistence\n')
        line=hashlib.sha256((self.root/'core.py').read_bytes()).hexdigest()+'  core.py\n'
        (self.root/'SHA256SUMS').write_text(line)
        (self.root/'stage-passed.json').write_text(json.dumps({'manifest':hashlib.sha256(line.encode()).hexdigest()}))
        self.db=self.base/'data/results.sqlite3';self.db.parent.mkdir()
        with sqlite3.connect(self.db) as c:
            c.execute('CREATE TABLE emails(id INTEGER PRIMARY KEY,email TEXT)')
            c.execute("INSERT INTO emails VALUES(1,'jane@public.org')")
        self.dropin=self.base/'systemd/90-release.conf';self.dropin.parent.mkdir()
        self.old='[Service]\nWorkingDirectory='+str(self.previous)+'\n';self.dropin.write_text(self.old)
        self.backups=self.base/'backups';self.backups.mkdir()
        spec=importlib.util.spec_from_file_location('activate_under_test',Path(__file__).resolve().parents[1]/'deploy/activate.py')
        self.mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.mod)
        self.mod.ROOT=self.root;self.mod.PREVIOUS=self.previous;self.mod.DB=self.db;self.mod.DROPIN=self.dropin
        self.calls=[]
    def tearDown(self):self.temp.cleanup()
    def execute(self,readiness):
        def prop(name):
            if name=='User':return 'emailgrabber'
            return str(self.root) if str(self.root) in self.dropin.read_text() else str(self.previous)
        def run(*args,**kwargs):self.calls.append(args);return types.SimpleNamespace(returncode=0)
        with patch.object(self.mod,'property_value',side_effect=prop),patch.object(self.mod,'readiness',side_effect=readiness),patch.object(self.mod.subprocess,'run',side_effect=run),patch.object(self.mod.subprocess,'check_output',return_value=b'original unit'),patch.object(self.mod.pwd,'getpwnam',return_value=types.SimpleNamespace(pw_gid=os.getgid())),contextlib.redirect_stdout(io.StringIO()):
            self.mod.main(self.parent,os.geteuid(),self.backups)
    def test_activation_verifies_backup_and_preserves_committed_data(self):
        self.execute(lambda:{'running':False})
        self.assertIn(str(self.root),self.dropin.read_text())
        backups=list(self.backups.glob('*/results.sqlite3'));self.assertEqual(len(backups),1)
        with sqlite3.connect(backups[0]) as c:self.assertEqual(c.execute('PRAGMA integrity_check').fetchone()[0],'ok')
        self.assertEqual(self.db.stat().st_mode & 0o777,0o640)
        self.assertEqual(self.db.parent.stat().st_mode & 0o777,0o750)
    def test_failed_readiness_restores_code_without_losing_new_commits(self):
        def fail():
            with sqlite3.connect(self.db) as c:c.execute("INSERT INTO emails VALUES(2,'new@public.org')")
            raise RuntimeError('startup failure')
        with self.assertRaisesRegex(RuntimeError,'startup failure'):self.execute(fail)
        self.assertEqual(self.dropin.read_text(),self.old)
        with sqlite3.connect(self.db) as c:self.assertEqual(c.execute('SELECT count(*) FROM emails').fetchone()[0],2)
    def test_persistence_incompatibility_stops_before_service_changes(self):
        (self.root/'core.py').write_text('# incompatible change\n')
        line=hashlib.sha256((self.root/'core.py').read_bytes()).hexdigest()+'  core.py\n'
        (self.root/'SHA256SUMS').write_text(line)
        (self.root/'stage-passed.json').write_text(json.dumps({'manifest':hashlib.sha256(line.encode()).hexdigest()}))
        with self.assertRaisesRegex(RuntimeError,'Persistence code differs'):self.execute(lambda:{})
        self.assertEqual(self.calls,[]);self.assertEqual(self.dropin.read_text(),self.old)
