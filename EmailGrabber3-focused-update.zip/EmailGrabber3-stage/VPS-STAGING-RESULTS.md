# VPS staging evidence supplied by operator

Candidate ZIP SHA256: 46caf8e4527e656cd4b4df99454241b92fc08192eec87d94043965e6662af090
Staging release: /opt/emailgrabber3-releases/stage-c275cca6b623
Interpreter: installed VPS Python 3.12.15. Checks ran under emailgrabber, UID 387.

All 41 backend tests passed in 13.450 seconds. The browser test was intentionally excluded on the VPS; it passed in the complete 42-test local run before packaging.

Public HTTPS unauthenticated GET requests to /, /api/state, /api/results, /api/export and /api/jobs returned HTTP 401. The script also required HTTP 401 for a safe nonexistent API POST endpoint before continuing.

Actual direct public URL crawl via staging HTTP API: 6 pages scanned across 2 discovered/scanned sites; 0 blocked/failed; 4 publicly sourced Included records. CSV and XLSX exports passed functional header checks. Page-budget stop preserved pending links.

Actual arbitrary-keyword crawl via staging HTTP API (astronomy observatory): 8 sites discovered, 2 pages scanned on 2 sites, 3 blocked sites, 1 failed site. Processing continued. Last reported failure was space.com exceeding the configured page download limit; the script did not disable the limit or attempt to bypass access restrictions.

Actual DNS check for python.org: MX configured, individual mailbox unverified.

Reopening the temporary SQLite database preserved committed results. Earlier backend tests covered process kill/restart/resume and 500-page fixture crawling.

Stage script completed with STAGING CHECKS PASSED. It did not alter the original application, production database, service, or reverse proxy. This is staging validation, not authenticated public acceptance of the repaired app, which is not yet live. Production service settings must be inspected before selecting the exact reversible switch commands. Latest production data must be backed up immediately before migration/switch, in addition to the earlier verified pre-repair archive/database backup.
