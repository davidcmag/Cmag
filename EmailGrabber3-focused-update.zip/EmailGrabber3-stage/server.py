#!/usr/bin/env python3
"""Loopback web service. Keep HTTPS and Basic authentication at the reverse proxy."""
import base64
import binascii
import hmac
import json
import os
import secrets
import signal
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from core import Store
from crawler import Crawler

ROOT=Path(__file__).resolve().parent

class Application:
    def __init__(self,db,network=None):
        self.store=Store(db)
        self.crawler=Crawler(self.store,network)
        self.token=secrets.token_urlsafe(32)
        self.validation_lock=threading.Lock()
        self.validating=False
        self.validation_error=''

    def validate(self):
        try:
            self.store.validate()
        except Exception as e:
            self.validation_error=f'{type(e).__name__}: {e}'
        finally:
            self.validating=False
            self.validation_lock.release()


def handler_for(app):
    class Handler(BaseHTTPRequestHandler):
        server_version='EmailGrabber3'
        def log_message(self,*args):
            pass
        def reply(self,data,code=200,kind='application/json',filename=None):
            out=json.dumps(data).encode() if kind=='application/json' else data
            self.send_response(code)
            self.send_header('Content-Type',kind+('; charset=utf-8' if kind.startswith(('text/','application/json')) else ''))
            self.send_header('Content-Length',str(len(out)))
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('X-Frame-Options','DENY')
            self.send_header('Referrer-Policy','no-referrer')
            self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
            if code==401:
                self.send_header('WWW-Authenticate','Basic realm="Email Grabber 3"')
            if filename:
                self.send_header('Content-Disposition',f'attachment; filename="{filename}"')
            self.end_headers(); self.wfile.write(out)
        def authorized(self):
            # An optional dedicated backend password adds defense in depth.
            # Existing Nginx Basic Auth must cover / AND every /api/ route.
            password=os.environ.get('EMAILGRABBER_AUTH_PASSWORD')
            if not password:
                return True
            try:
                scheme,encoded=self.headers.get('Authorization','').split(' ',1)
                user,pwd=base64.b64decode(encoded,validate=True).decode().split(':',1)
                return scheme.lower()=='basic' and hmac.compare_digest(user,os.environ.get('EMAILGRABBER_AUTH_USER','emailgrabber')) and hmac.compare_digest(pwd,password)
            except (ValueError,UnicodeError,binascii.Error):
                return False
        def dispatch(self,write=False):
            if not self.authorized():
                return self.reply({'error':'Authentication required'},401)
            try:
                if write:
                    if not hmac.compare_digest(self.headers.get('X-Local-Token',''),app.token):
                        return self.reply({'error':'Invalid CSRF token; refresh the page'},403)
                    origin=self.headers.get('Origin')
                    if origin and urllib.parse.urlsplit(origin).netloc != self.headers.get('Host'):
                        return self.reply({'error':'Cross-origin request rejected'},403)
                    if self.headers.get('Content-Type','').split(';')[0]!='application/json':
                        return self.reply({'error':'JSON required'},415)
                    n=int(self.headers.get('Content-Length','0'))
                    if not 0<n<=12_000_000:
                        return self.reply({'error':'Request size must be 1–12000000 bytes'},413)
                    data=json.loads(self.rfile.read(n))
                    if not isinstance(data,dict):
                        raise ValueError('JSON object required')
                    return self.post(data)
                return self.get()
            except (ValueError,TypeError,KeyError,binascii.Error) as e:
                return self.reply({'error':str(e)},400)
            except RuntimeError as e:
                return self.reply({'error':str(e)},409)
            except Exception:
                return self.reply({'error':'Internal operation failed; inspect service logs'},500)
        def do_GET(self):
            self.dispatch()
        def do_POST(self):
            self.dispatch(True)
        def params(self):
            return {k:v[-1] for k,v in urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query).items()}
        def get(self):
            path=urllib.parse.urlsplit(self.path).path
            q=self.params()
            if path=='/':
                return self.reply((ROOT/'index.template.html').read_text().replace('__LOCAL_TOKEN__',app.token).encode(),kind='text/html')
            if path=='/api/state':
                return self.reply({**app.crawler.status(),'validating':app.validating,'validation_error':app.validation_error,'exclude_roles':app.store.roles_excluded()})
            if path=='/api/jobs':
                return self.reply({'jobs':[{'id':j['id'],'state':j['state'],'pages':j.get('pages',0),'message':j.get('message','')} for j in app.store.jobs()]})
            if path=='/api/results':
                offset=max(0,int(q.pop('offset',0))); limit=min(500,max(1,int(q.pop('limit',100))))
                rows,rules=app.store.records(**q)
                return self.reply({'total':len(rows),'rows':rows[offset:offset+limit],'rules':rules})
            if path=='/api/export':
                fmt=q.pop('format','csv'); q.pop('offset',None); q.pop('limit',None)
                out=app.store.export(fmt,**q)
                return self.reply(out,kind='text/csv' if fmt=='csv' else 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',filename='EmailGrabber3-results.'+fmt)
            return self.reply({'error':'Not found'},404)
        def post(self,d):
            path=urllib.parse.urlsplit(self.path).path
            if path=='/api/role-filter':
                app.store.set_roles(bool(d.get('enabled'))); return self.reply({'ok':True})
            if path=='/api/import-file':
                raw=base64.b64decode(d['data'],validate=True)
                return self.reply({'added':app.store.import_file(raw,d['format'],bool(d.get('exclude_roles')))})
            if path=='/api/import':
                count=0
                from core import extract
                for x in d.get('entries',[])[:250000]:
                    text=x.get('email','') if isinstance(x,dict) else str(x)
                    source=x.get('source','Imported list') if isinstance(x,dict) else 'Imported list'
                    for email in extract(text):
                        count+=app.store.insert(email,source,bool(d.get('exclude_roles')))
                return self.reply({'added':count})
            if path in ('/api/rule','/api/rule-preview'):
                count=app.store.rule(d['kind'],str(d['value']),preview=path.endswith('preview'))
                return self.reply({'ok':True,'count':count})
            if path=='/api/undo-rule':
                with app.store.db() as c:
                    c.execute('DELETE FROM rules WHERE id=(SELECT MAX(id) FROM rules)')
                return self.reply({'ok':True})
            if path=='/api/delete':
                return self.reply({'removed':app.store.remove([int(x) for x in d.get('ids',[])])})
            if path=='/api/delete-matching':
                filters=d.get('filters',{})
                if not filters.get('q'):
                    raise ValueError('A nonempty filter is required')
                rows,_=app.store.records(**filters)
                return self.reply({'removed':app.store.remove([x['id'] for x in rows])})
            if path=='/api/undo-delete':
                app.store.undo_delete(); return self.reply({'ok':True})
            if path=='/api/restore':
                with app.store.db() as c:
                    c.execute('UPDATE emails SET deleted=0'); c.execute('DELETE FROM actions')
                return self.reply({'ok':True})
            if path=='/api/validate':
                if not app.validation_lock.acquire(blocking=False):
                    raise RuntimeError('Validation already running')
                app.validating=True; app.validation_error=''
                threading.Thread(target=app.validate,daemon=True).start()
                return self.reply({'ok':True})
            if path=='/api/start':
                opts={k:int(d.get(k,default)) for k,default in [('max_pages',0),('per_site',0),('depth',3)]}
                if any(x<0 for x in opts.values()) or opts['depth']>50:
                    raise ValueError('Invalid page limits or depth')
                mode=d.get('crawl_mode','focused')
                if mode not in ('focused','broad'):raise ValueError('Invalid crawl mode')
                opts['crawl_mode']=mode
                opts.update(exclude_roles=bool(d.get('exclude_roles')),geography=str(d.get('geography',''))[:200])
                app.store.set_roles(opts['exclude_roles'])
                app.crawler.start(str(d.get('inputs','')).splitlines(),**opts)
                return self.reply({'ok':True})
            if path=='/api/resume':
                app.crawler.start(resume=d['job_id']); return self.reply({'ok':True})
            if path=='/api/pause':
                if not app.crawler.status()['running']:
                    raise RuntimeError('No running job')
                app.crawler.pause(); return self.reply({'ok':True})
            if path=='/api/stop':
                app.crawler.stop(); return self.reply({'ok':True})
            return self.reply({'error':'Not found'},404)
    return Handler

if __name__=='__main__':
    os.umask(0o077)
    db=os.environ.get('EMAILGRABBER_DB',str(Path.home()/'.emailgrabber3-web/results.sqlite3'))
    app=Application(db)
    server=ThreadingHTTPServer(('127.0.0.1',int(os.environ.get('EMAILGRABBER_PORT','8787'))),handler_for(app))
    def terminate(signum,frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM,terminate)
    print('Email Grabber 3 listening on loopback',flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        app.crawler.stop()
        if app.crawler.worker:
            app.crawler.worker.join(timeout=20)
    finally:
        server.server_close()
