"""Persistence, extraction and filtering. Local checks never verify a mailbox."""
import csv
import io
import json
import re
import sqlite3
import threading
import html
from datetime import datetime, timezone
from pathlib import Path
from contextlib import contextmanager
import dns.resolver
import dns.exception
from openpyxl import Workbook, load_workbook

ROLE = set('info care support office contact admin administrator sales marketing hello service customerservice customersupport help team general noreply no-reply webmaster press media billing reception enquiries inquiries'.split())
DISPOSABLE = {'mailinator.com', 'guerrillamail.com', '10minutemail.com', 'tempmail.com', 'yopmail.com'}
ASSET = set('png jpg jpeg webp gif svg avif ico css js woff woff2 ttf otf pdf mp4 mp3 webm map json xml zip'.split())
EMAIL_RE = re.compile(r'(?<![\w.+-])[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,63}(?![\w.-])', re.I)
TECH = re.compile(r'(?:^|\.)(?:sentry(?:-next)?\.wixpress\.com|(?:ingest\.)?sentry\.io)$', re.I)

def now():
    return datetime.now(timezone.utc).isoformat()

def reason_for(email):
    if not EMAIL_RE.fullmatch(email) or len(email) > 254:
        return 'Invalid email syntax'
    local, domain = email.rsplit('@', 1)
    if len(local) > 64 or local.startswith('.') or local.endswith('.') or '..' in email:
        return 'Invalid email syntax'
    if any(len(x) > 63 or x.startswith('-') or x.endswith('-') for x in domain.split('.')):
        return 'Invalid email syntax'
    if TECH.search(domain) or 'telemetry' in domain or re.fullmatch(r'[a-f0-9]{24,}', local):
        return 'Monitoring/telemetry identifier'
    if domain.rsplit('.', 1)[-1] in ASSET:
        return 'Image or asset filename'
    if domain in {'yoursite.com','yourdomain.com','example.com','example.org','example.net','test.com'}:
        return 'Placeholder domain'
    return ''

def extract(text):
    text = re.sub(r'\\u([0-9a-fA-F]{4})', lambda m: chr(int(m[1],16)), text)
    text = html.unescape(urllib_unquote(text))
    text = re.sub(r'\s*(?:\[at\]|\(at\))\s*', '@', text, flags=re.I)
    text = re.sub(r'\s*(?:\[dot\]|\(dot\))\s*', '.', text, flags=re.I)
    return sorted(set(x.lower() for x in EMAIL_RE.findall(text)))

def urllib_unquote(text):
    from urllib.parse import unquote
    return unquote(text)

def rule_matches(email, kind, value):
    email, value = email.lower(), value.strip().lower()
    local, _, domain = email.partition('@')
    if not value:
        return False
    return {'address': lambda: email == value,
            'prefix': lambda: email.startswith(value),
            'domain': lambda: domain == value.lstrip('@') or domain.endswith('.'+value.lstrip('@')),
            'contains': lambda: value in email,
            'role': lambda: local in ROLE}.get(kind, lambda: False)()

def dns_check(domain, resolver=None):
    resolver = resolver or dns.resolver.Resolver()
    resolver.lifetime = 5
    try:
        answers = resolver.resolve(domain, 'MX')
        if any(str(x.exchange) != '.' for x in answers):
            return 'mx', 'MX configured; individual mailbox unverified'
        return 'no-mail', 'Null MX: domain does not accept email'
    except dns.resolver.NXDOMAIN:
        return 'no-domain', 'Domain does not exist'
    except dns.resolver.NoAnswer:
        pass
    except (dns.exception.DNSException, OSError):
        return 'unknown', 'DNS lookup failed; individual mailbox unverified'
    for kind in ('A', 'AAAA'):
        try:
            if resolver.resolve(domain, kind):
                return 'fallback', 'No MX; address-record fallback available; mailbox unverified'
        except dns.resolver.NXDOMAIN:
            return 'no-domain', 'Domain does not exist'
        except dns.resolver.NoAnswer:
            continue
        except (dns.exception.DNSException, OSError):
            return 'unknown', 'DNS lookup failed; individual mailbox unverified'
    return 'no-mail', 'No MX or address-record fallback'

class Store:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        with self.db() as c:
            c.execute('PRAGMA journal_mode=WAL')
            c.executescript('''
            CREATE TABLE IF NOT EXISTS emails(id INTEGER PRIMARY KEY, email TEXT UNIQUE COLLATE NOCASE,
                source TEXT, status TEXT, reason TEXT, discovered TEXT DEFAULT CURRENT_TIMESTAMP, deleted INTEGER DEFAULT 0);
            CREATE TABLE IF NOT EXISTS rules(id INTEGER PRIMARY KEY, kind TEXT, value TEXT, created TEXT DEFAULT CURRENT_TIMESTAMP);
            CREATE TABLE IF NOT EXISTS sources(email TEXT, url TEXT, PRIMARY KEY(email,url));
            CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY, data TEXT NOT NULL, updated TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS actions(id INTEGER PRIMARY KEY, ids TEXT NOT NULL);
            ''')
            cols = {x[1] for x in c.execute('PRAGMA table_info(emails)')}
            for name, typ in [('validated','TEXT'),('dns','TEXT'),('role','INTEGER DEFAULT 0'),('disposable','INTEGER DEFAULT 0')]:
                if name not in cols:
                    c.execute(f'ALTER TABLE emails ADD COLUMN {name} {typ}')
            c.execute('INSERT OR IGNORE INTO sources SELECT email,source FROM emails')
            # Legacy builds stored rule matches permanently as Excluded. Make
            # these dynamic so undoing the original rule actually restores rows.
            c.execute("UPDATE emails SET status='Unverified', reason='Syntax valid; individual mailbox unverified' WHERE status='Excluded' AND reason='Matches filtering rule'")
            legacy_role = c.execute("SELECT 1 FROM emails WHERE reason='Generic role account' LIMIT 1").fetchone()
            if legacy_role:
                if not c.execute("SELECT 1 FROM rules WHERE kind='role'").fetchone():
                    c.execute("INSERT INTO rules(kind,value) VALUES('role','generic')")
                c.execute("UPDATE emails SET status='Unverified',reason='Syntax valid; individual mailbox unverified' WHERE reason='Generic role account'")
            for row in c.execute('SELECT id,email FROM emails').fetchall():
                email=row['email'].lower()
                reason=reason_for(email)
                c.execute('UPDATE emails SET role=?,disposable=? WHERE id=?', (email.partition('@')[0] in ROLE,email.partition('@')[2] in DISPOSABLE,row['id']))
                if reason:
                    c.execute("UPDATE emails SET status='Rejected',reason=? WHERE id=?", (reason,row['id']))

    @contextmanager
    def db(self):
        with self.lock:
            c = sqlite3.connect(self.path, timeout=30)
            c.row_factory = sqlite3.Row
            try:
                yield c
                c.commit()
            except Exception:
                c.rollback()
                raise
            finally:
                c.close()

    def insert(self, email, source, exclude_roles=False):
        email = email.strip().lower()
        if not EMAIL_RE.fullmatch(email):
            return False
        reason = reason_for(email)
        role = email.partition('@')[0] in ROLE
        disposable = email.partition('@')[2] in DISPOSABLE
        if not reason and disposable:
            reason = 'Known disposable domain (starter list)'
        if exclude_roles:
            self.set_roles(True)
        status = 'Rejected' if reason else 'Unverified'
        with self.db() as c:
            c.execute('INSERT OR IGNORE INTO sources VALUES(?,?)', (email, source))
            n = c.execute('INSERT OR IGNORE INTO emails(email,source,status,reason,role,disposable) VALUES(?,?,?,?,?,?)',
                         (email,source,status,reason or 'Syntax valid; individual mailbox unverified',role,disposable)).rowcount
        return bool(n)

    def records(self, q='', scope='email', view='included', sort='id', direction='desc', **unused):
        if scope not in ('email','domain','source','all') or view not in ('included','excluded','all'):
            raise ValueError('Invalid results scope or view')
        if sort not in ('id','email','source','status','discovered','validated') or direction not in ('asc','desc'):
            raise ValueError('Invalid sort')
        with self.db() as c:
            rules = [dict(x) for x in c.execute('SELECT * FROM rules ORDER BY id DESC')]
            rows = [dict(x) for x in c.execute(f'SELECT * FROM emails ORDER BY {sort} {direction}, id {direction}')]
        result = []
        for r in rows:
            matched = [x for x in rules if rule_matches(r['email'],x['kind'],x['value'])]
            r['blocked'] = bool(r['deleted'] or r['status'] in ('Excluded','Rejected') or matched)
            if r['deleted']:
                r['status']='Removed'; r['reason']='Manually removed; recoverable'
            elif matched and r['status']!='Rejected':
                r['status']='Excluded'; r['reason']='Generic role account' if any(x['kind']=='role' for x in matched) else 'Matches filtering rule'
            if (view == 'included' and r['blocked']) or (view == 'excluded' and not r['blocked']):
                continue
            text = r['email'] if scope == 'email' else r['email'].partition('@')[2] if scope == 'domain' else r['source'] if scope == 'source' else ' '.join(str(x) for x in r.values())
            if q.lower() in (text or '').lower():
                result.append(r)
        return result, rules

    def rule(self, kind, value, preview=False):
        if kind not in ('address','prefix','domain','contains','role') or not value.strip() or len(value)>254 or (kind=='prefix' and not value.strip().rstrip('@')):
            raise ValueError('Invalid rule')
        with self.db() as c:
            count = sum(rule_matches(x['email'],kind,value) for x in c.execute('SELECT email FROM emails'))
            if not preview:
                c.execute('INSERT INTO rules(kind,value) VALUES(?,?)',(kind,value.strip().lower()))
        return count

    def set_roles(self, enabled):
        with self.db() as c:
            if enabled:
                if not c.execute("SELECT 1 FROM rules WHERE kind='role'").fetchone():
                    c.execute("INSERT INTO rules(kind,value) VALUES('role','generic')")
            else:
                c.execute("DELETE FROM rules WHERE kind='role'")

    def roles_excluded(self):
        with self.db() as c:
            return bool(c.execute("SELECT 1 FROM rules WHERE kind='role'").fetchone())

    def remove(self, ids):
        with self.db() as c:
            existing = {x[0] for x in c.execute('SELECT id FROM emails WHERE deleted=0')}
            ids = sorted(existing.intersection(ids))
            c.executemany('UPDATE emails SET deleted=1 WHERE id=?',[(i,) for i in ids])
            if ids:
                c.execute('INSERT INTO actions(ids) VALUES(?)',(json.dumps(ids),))
        return len(ids)

    def undo_delete(self):
        with self.db() as c:
            action = c.execute('SELECT * FROM actions ORDER BY id DESC LIMIT 1').fetchone()
            if action:
                c.executemany('UPDATE emails SET deleted=0 WHERE id=?',[(i,) for i in json.loads(action['ids'])])
                c.execute('DELETE FROM actions WHERE id=?',(action['id'],))

    def validate(self, check=dns_check):
        with self.db() as c:
            rows = [dict(x) for x in c.execute('SELECT * FROM emails')]
        cache = {}
        for r in rows:
            reason = reason_for(r['email'])
            if reason:
                continue
            domain = r['email'].partition('@')[2]
            if domain not in cache:
                cache[domain] = check(domain)
            state, reason = cache[domain]
            status = 'Uncertain' if state in ('unknown','no-domain','no-mail') else 'Unverified'
            # Exclusions are independent of validation; preserve them.
            with self.db() as c:
                c.execute('UPDATE emails SET dns=?,validated=?,status=CASE WHEN status="Excluded" THEN status ELSE ? END,reason=CASE WHEN status="Excluded" THEN reason ELSE ? END WHERE id=?',
                          (state,now(),status,reason,r['id']))
        return len(rows)

    def save_job(self, job):
        with self.db() as c:
            if job.get('id'):
                c.execute('UPDATE jobs SET data=?,updated=? WHERE id=?',(json.dumps(job),now(),job['id']))
            else:
                job['id'] = c.execute('INSERT INTO jobs(data,updated) VALUES(?,?)',(json.dumps(job),now())).lastrowid
                c.execute('UPDATE jobs SET data=? WHERE id=?',(json.dumps(job),job['id']))

    def job(self, ident=None):
        with self.db() as c:
            r = c.execute('SELECT data FROM jobs WHERE id=?',(ident,)).fetchone() if ident else c.execute('SELECT data FROM jobs ORDER BY id DESC LIMIT 1').fetchone()
            return json.loads(r[0]) if r else None

    def jobs(self):
        with self.db() as c:
            return [json.loads(x[0]) for x in c.execute('SELECT data FROM jobs ORDER BY id DESC LIMIT 100')]

    def export(self, fmt='csv', **filters):
        rows, _ = self.records(**filters)
        fields = ['email','status','reason','source','discovered','validated','dns','role','disposable']
        values = [[r.get(k) or '' for k in fields] for r in rows]
        # Prevent spreadsheet formulas from executing on exported source strings.
        def safe(x):
            return "'"+x if isinstance(x,str) and x.startswith(('=','+','-','@','\t','\r','\n')) else x
        values = [[safe(x) for x in row] for row in values]
        if fmt == 'csv':
            buf = io.StringIO(); w = csv.writer(buf); w.writerow(fields); w.writerows(values)
            return buf.getvalue().encode('utf-8-sig')
        if fmt != 'xlsx':
            raise ValueError('Invalid export format')
        wb = Workbook(write_only=True); ws = wb.create_sheet('Emails'); ws.append(fields)
        for row in values:
            ws.append(row)
        buf = io.BytesIO(); wb.save(buf); return buf.getvalue()

    def import_file(self, data, fmt, exclude_roles=False):
        if fmt == 'xlsx':
            import zipfile
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                if sum(x.file_size for x in z.infolist()) > 64_000_000:
                    raise ValueError('Spreadsheet expands beyond 64 MB')
            wb = load_workbook(io.BytesIO(data),read_only=True,data_only=True)
            try:
                rows = [list(row) for ws in wb for row in ws.iter_rows(values_only=True)]
            finally:
                wb.close()
        elif fmt in ('csv','tsv','txt'):
            text = data.decode('utf-8-sig')
            rows = list(csv.reader(io.StringIO(text),delimiter='\t' if fmt=='tsv' else ','))
        else:
            raise ValueError('Unsupported import format')
        if not rows:
            return 0
        headers = [str(x or '').lower() for x in rows[0]]
        email_col = headers.index('email') if 'email' in headers else None
        source_col = headers.index('source') if 'source' in headers else None
        count = 0
        for row in rows[1:] if email_col is not None else rows:
            if not row:
                continue
            source = str(row[source_col] or 'Imported list') if source_col is not None and len(row)>source_col else 'Imported list'
            text = str(row[email_col]) if email_col is not None and len(row)>email_col else ' '.join(str(x or '') for x in row)
            for address in extract(text):
                count += self.insert(address,source,exclude_roles)
        return count
