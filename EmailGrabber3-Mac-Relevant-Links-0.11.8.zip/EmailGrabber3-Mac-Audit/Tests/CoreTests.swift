import XCTest
import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
@testable import EmailGrabberCore

func settings(depth: Int = 0, pages: Int = 0, perSite: Int = 0, dns: Bool = false, role: Bool = false) -> GrabSettings {
    GrabSettings(depth: depth, maxPages: pages, maxPagesPerDomain: perSite, exclude: "", duplicates: true, role: role, free: false, disposable: true, dns: dns)
}
func response(_ text: String, _ url: URL, status: Int = 200) -> HTTPResult { HTTPResult(data: Data(text.utf8), status: status, finalURL: url) }
func makeEmailFixture(_ address: String) -> FoundEmail { FoundEmail(address: address, source: "fixture", status: "Accepted", reason: "Local syntax only") }

class DiskTests: XCTestCase {
    var directory: URL!
    override func setUpWithError() throws {
        directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        CrawlDisk.directoryOverride = directory
        CrawlDisk.updatePresentation(rules: [], removal: RemovalState())
    }
    override func tearDownWithError() throws { CrawlDisk.directoryOverride = nil; try? FileManager.default.removeItem(at: directory) }
}

final class ExtractionTests: DiskTests {
    func collect(_ text: String, dns: Bool = false, role: Bool = false, assessment: DNSAssessment = .mx) -> [FoundEmail] {
        GrabEngine(settings: settings(dns: dns, role: role), dns: { _ in assessment }, sleep: { _ in }).run(mode: .pasted, terms: [text], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
    }
    func testPlainAndObfuscatedAddressesDeduplicate() {
        let rows = collect("Jane@public.org jane [at] public [dot] org jane&#64;public&#46;org")
        XCTAssertEqual(rows.map(\.address), ["jane@public.org"])
    }
    func testJSONEscapesDoNotBecomeMailboxPrefixes() {
        XCTAssertEqual(collect(#"\u003ejane\u0040public\u002eorg"#).map(\.address), ["jane@public.org"])
    }
    func testAssetAndTelemetryAreNeverStored() {
        XCTAssertTrue(collect("logo@2x.png key@sentry.wixpress.com key@sentry-next.wixpress.com id@o1.ingest.us.sentry.io").isEmpty)
    }
    func testHexMailboxOnNormalDomainIsPreserved() {
        XCTAssertEqual(collect("0123456789abcdef0123456789abcdef@public.org").count, 1)
    }
    func testPlaceholdersAreExcluded() { XCTAssertEqual(collect("info@yoursite.com").first?.status, "Excluded") }
    func testInvalidDotsAndDomainHyphensAreRejected() {
        for value in ["a..b@public.org", ".a@public.org", "a.@public.org", "a@-public.org", "a@public-.org"] { XCTAssertFalse(EmailPolicy.validSyntax(value), value) }
    }
    func testGenericRolesIncludeCareOfficeAndSupport() {
        for value in ["info","care","office","support","contact"] { XCTAssertEqual(collect(value+"@public.org", role: true).first?.status, "Excluded") }
    }
    func testSyntaxOnlyDoesNotClaimMailboxVerification() {
        let row = collect("jane@public.org").first!
        XCTAssertEqual(row.status, "Accepted"); XCTAssertTrue(row.reason.contains("not independently confirmed"))
    }
    func testDNSFallbackAndUnknownRemainDistinct() {
        XCTAssertEqual(collect("jane@public.org", dns: true, assessment: .fallback).first?.status, "Accepted")
        XCTAssertEqual(collect("jane@public.org", dns: true, assessment: .unknown).first?.status, "Uncertain")
        XCTAssertEqual(collect("jane@public.org", dns: true, assessment: .noMail).first?.status, "Uncertain")
    }
    func testDNSIsCachedPerDomain() {
        var queries = 0
        let engine = GrabEngine(settings: settings(dns: true), dns: { _ in queries += 1; return .mx })
        let rows = engine.run(mode: .pasted, terms: ["a@public.org b@public.org"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(rows.count, 2); XCTAssertEqual(queries, 1)
    }
}

final class CrawlTests: DiskTests {
    func testAdaptiveHomepageFollowsContactAndSalesButNotNews() {
        var fetched: [String] = []
        let engine = GrabEngine(settings: settings(), fetcher: { url in
            fetched.append(url.path)
            if url.path == "/robots.txt" { return response("User-agent: *\nDisallow: /private", url) }
            if url.path == "/" { return response("<a href='/contact#team'>Contact</a><a href='/sales'>Sales</a><a href='/news/article'>News</a>", url) }
            return response("jane@public.org", url)
        }, sleep: { _ in })
        let rows = engine.run(mode: .website, terms: ["https://public.org"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(rows.map(\.address), ["jane@public.org"])
        XCTAssertTrue(fetched.contains("/contact")); XCTAssertTrue(fetched.contains("/sales")); XCTAssertFalse(fetched.contains("/news/article"))
    }
    func testRobotWildcardAllowAndSpecificAgent() {
        let text = "User-agent: *\nDisallow: /\n\nUser-agent: EmailGrabber3\nDisallow: /private/*\nAllow: /private/contact$\nCrawl-delay: 2"
        let rules = RobotsPolicy(text)
        XCTAssertTrue(rules.allows(URL(string: "https://public.org/")!))
        XCTAssertFalse(rules.allows(URL(string: "https://public.org/private/one")!))
        XCTAssertTrue(rules.allows(URL(string: "https://public.org/private/contact")!))
        XCTAssertFalse(rules.allows(URL(string: "https://public.org/private/contact/more")!))
        XCTAssertEqual(rules.delay, 2)
    }
    func testRobotsAllowWinsEqualLength() {
        let rules = RobotsPolicy("User-agent: *\nDisallow: /contact\nAllow: /contact")
        XCTAssertTrue(rules.allows(URL(string: "https://public.org/contact")!))
    }
    func testBlockedWebsiteDoesNotEndWholeSearch() {
        let engine = GrabEngine(settings: settings(depth: 1), fetcher: { url in
            if url.host == "blocked.org" { return response("blocked", url, status: 403) }
            return response(url.path == "/robots.txt" ? "User-agent: *" : "jane@public.org", url)
        }, sleep: { _ in })
        let rows = engine.run(mode: .website, terms: ["https://blocked.org", "https://public.org"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(rows.count, 1)
    }
    func testCancellationDuringRobotsPreservesPendingPage() {
        var stop = false
        let engine = GrabEngine(settings: settings(), fetcher: { url in stop = true; return HTTPResult(finalURL: url, error: "Cancelled") }, sleep: { _ in })
        _ = engine.run(mode: .website, terms: ["https://public.org"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { stop })
        let saved = CrawlDisk.load()!
        XCTAssertEqual(saved.queue.count, 1); XCTAssertFalse(saved.visited.contains("https://public.org"))
    }
    func testBatchResumePreservesRowsAndVisitsNewPages() {
        var fetched: [String] = []
        let get: (URL) -> HTTPResult = { url in
            fetched.append(url.path)
            if url.path == "/robots.txt" { return response("User-agent: *", url) }
            return response(url.path == "/" ? "first@public.org <a href='/contact'>Contact</a>" : "second@public.org", url)
        }
        let options = settings(pages: 1)
        let engine = GrabEngine(settings: options, fetcher: get, sleep: { _ in })
        let first = engine.run(mode: .website, terms: ["https://public.org"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        let snapshot = CrawlDisk.load()!; XCTAssertEqual(snapshot.scanned, 1); XCTAssertFalse(snapshot.queue.isEmpty)
        let resumed = GrabEngine(settings: options, fetcher: get, sleep: { _ in }); resumed.restore(snapshot)
        let final = resumed.run(mode: .website, terms: snapshot.selectedSites, existing: first, liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(Set(final.map(\.address)), ["first@public.org","second@public.org"])
        XCTAssertEqual(fetched.filter { $0 == "/" }.count, 1)
    }
    func testUnwritableCheckpointStopsBeforeFetching() throws {
        let bad = directory.appendingPathComponent("not-a-directory")
        try Data("x".utf8).write(to: bad); CrawlDisk.directoryOverride = bad
        var calls = 0
        let engine = GrabEngine(settings: settings(), fetcher: { url in calls += 1; return response("", url) }, sleep: { _ in })
        _ = engine.run(mode: .website, terms: ["https://public.org"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(calls, 0); XCTAssertNotNil(engine.lastFailure)
    }
    func testURLRejectsCredentialsAndNonHTTP() {
        XCTAssertNil(GrabEngine.normalizedURL("file:///etc/passwd"))
        XCTAssertNil(GrabEngine.normalizedURL("https://user:password@public.org/"))
        XCTAssertNil(GrabEngine.normalizedURL("javascript:alert(1)"))
    }
    func testSearchQueryPreservesAmpersandAndPlus() {
        let url = EmailPolicy.searchURL("arts & science + people")!
        XCTAssertEqual(URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.first { $0.name == "q" }?.value, "arts & science + people")
    }
}

final class RuleAndPersistenceTests: DiskTests {
    func testPrefixAtDoesNotMatchLongerName() {
        XCTAssertTrue(SmartRule(kind: "Prefix", pattern: "info@").matches("info@public.org"))
        XCTAssertFalse(SmartRule(kind: "Prefix", pattern: "info@").matches("information@public.org"))
        XCTAssertTrue(SmartRule(kind: "Prefix", pattern: "info").matches("information@public.org"))
    }
    func testDomainRuleHonorsBoundaries() {
        let rule = SmartRule(kind: "Domain", pattern: "@public.org")
        XCTAssertTrue(rule.matches("x@sub.public.org")); XCTAssertFalse(rule.matches("x@notpublic.org"))
    }
    func testManualRemovalHasNoRuleAndUndoRestores() {
        let rules = [SmartRule(kind: "Domain", pattern: "excluded.org")]
        var removed = RemovalState(); removed.remove(["Jane@public.org"])
        XCTAssertTrue(removed.addresses.contains("jane@public.org")); XCTAssertEqual(rules.count, 1)
        removed.undo(); XCTAssertTrue(removed.addresses.isEmpty)
    }
    func testRemovalUndoIsScopedToLastBatch() {
        var state = RemovalState(); state.remove(["one@public.org"]); state.remove(["two@public.org"]); state.undo()
        XCTAssertEqual(state.addresses, ["one@public.org"])
    }
    func snapshot() -> CrawlProgress {
        CrawlProgress(queue: [], visited: [], queued: [], robotRules: [:], domainPageCount: [:], discoveredCount: 0, scanned: 0, rows: [makeEmailFixture("jane@public.org")], selectedSites: [], settings: CrawlOptions(depth: 0, maxPages: 0, maxPagesPerDomain: 0, excluded: "", stripDuplicates: true, excludeRole: false, excludeFree: false, excludeDisposable: true, checkDNS: false), input: "")
    }
    func testCheckpointPreservesRulesAndRecoverableRemoval() {
        var removal = RemovalState(); removal.remove(["jane@public.org"])
        CrawlDisk.updatePresentation(rules: [SmartRule(kind: "Prefix", pattern: "info@")], removal: removal)
        XCTAssertTrue(CrawlDisk.save(snapshot()))
        let loaded = CrawlDisk.load()!
        XCTAssertEqual(loaded.rows.count, 1); XCTAssertEqual(loaded.smartRules?.count, 1)
        XCTAssertEqual(loaded.removedAddresses, ["jane@public.org"])
    }
    func testRuleChangeUpdatesAlreadySavedCheckpoint() {
        XCTAssertTrue(CrawlDisk.save(snapshot()))
        CrawlDisk.updatePresentation(rules: [SmartRule(kind: "Domain", pattern: "public.org")], removal: RemovalState())
        XCTAssertEqual(CrawlDisk.load()?.smartRules?.first?.pattern, "public.org")
    }
    func testOldCheckpointDecodesWithoutNewMetadata() throws {
        let data = try JSONEncoder().encode(snapshot())
        var object = try JSONSerialization.jsonObject(with: data) as! [String:Any]
        object.removeValue(forKey: "smartRules"); object.removeValue(forKey: "removedAddresses"); object.removeValue(forKey: "removalHistory")
        let loaded = try JSONDecoder().decode(CrawlProgress.self, from: JSONSerialization.data(withJSONObject: object))
        XCTAssertEqual(loaded.rows.count, 1); XCTAssertNil(loaded.smartRules)
    }
    func testAutomaticCheckpointPermissionsArePrivate() throws {
        XCTAssertTrue(CrawlDisk.save(snapshot()))
        let attrs = try FileManager.default.attributesOfItem(atPath: CrawlDisk.fileURL.path)
        XCTAssertEqual((attrs[.posixPermissions] as? NSNumber)?.intValue, 0o600)
    }
    func testCSVFormulaPrefixesAreNeutralized() {
        XCTAssertEqual(EmailPolicy.csvField("=1+1"), "\"'=1+1\"")
        XCTAssertEqual(EmailPolicy.csvField("jane@public.org"), "\"jane@public.org\"")
    }
}

final class ParsingTests: XCTestCase {
    func testCRLFCSVAndQuotedCommasRoundTrip() throws {
        let rows = try FileImport.parseDelimited("email,source\r\n\"jane@public.org\",\"one,two\"\r\n", separator: ",")
        XCTAssertEqual(rows, [["email","source"],["jane@public.org","one,two"]])
    }
    func testMultilineFieldsEscapesAndBOM() throws {
        XCTAssertEqual(try FileImport.parseDelimited("\u{FEFF}\"one\r\ntwo\",\"say \"\"hi\"\"\"\n", separator: ","), [["one\r\ntwo","say \"hi\""]])
    }
    func testMalformedCSVIsRejected() { XCTAssertThrowsError(try FileImport.parseDelimited("\"unfinished", separator: ",")); XCTAssertThrowsError(try FileImport.parseDelimited("\"one\"bad,two", separator: ",")) }
    func testNullMXAndTimeoutTextAreNotMailServers() {
        XCTAssertEqual(DNSAssessment.parseMX("0 .\n"), .noMail)
        XCTAssertEqual(DNSAssessment.parseMX("0 .\n10 mail.public.org.\n"), .unknown)
        XCTAssertEqual(DNSAssessment.parseMX("10 mail.public.org.\n"), .mx)
        XCTAssertNil(DNSAssessment.parseMX(";; connection timed out\n"))
    }
    func testCatchAllAndUnknownAreNeverVerified() {
        for state in ["catch-all","unknown","risky","unexpected"] { XCTAssertEqual(ProviderClassification.result(status: state, substatus: "").0, "Uncertain") }
        XCTAssertEqual(ProviderClassification.result(status: "valid", substatus: "").0, "Verified")
    }
    func testSearchRedirectDecodesAndRejectsCredentialURL() {
        let page = "<a class='result__a' href='//duckduckgo.com/l/?uddg=https%3A%2F%2Fpublic.org%2Fcontact'>Result</a>"
        XCTAssertEqual(AdditionalSearchDiscovery.extractResultURLs(from: page).first?.absoluteString, "https://public.org/contact")
        XCTAssertTrue(AdditionalSearchDiscovery.extractResultURLs(from: "<a class='result__a' href='https://u:p@public.org'>x</a>").isEmpty)
    }
    func testSafeProcessEnforcesTimeoutAndOutputLimit() throws {
        XCTAssertThrowsError(try SafeProcess.run("/bin/sleep", ["5"], timeout: 0.05))
        XCTAssertThrowsError(try SafeProcess.run("/usr/bin/yes", [], maxBytes: 1024, timeout: 2))
        XCTAssertEqual(try SafeProcess.run("/usr/bin/printf", ["literal;not-shell"]), Data("literal;not-shell".utf8))
    }
}
