import XCTest
import Foundation
@testable import EmailGrabberCore

final class ExternalLinkTests: DiskTests {
    func options(pages: Int = 0) -> GrabSettings {
        var value = settings(pages: pages)
        value.followExternalLinks = true
        value.topic = "podcast"
        return value
    }
    func testRelevantChainCrossesWebsitesAndStopsAtExhaustedFrontier() {
        var fetched = Set<String>()
        let engine = GrabEngine(settings: options(), fetcher: { url in
            if url.path == "/robots.txt" { return response("User-agent: *", url) }
            fetched.insert(url.host!)
            if url.host == "first.org" { return response("<a href='https://second.org/'>Podcast hosts</a><a href='https://ads.org/'>Buy shoes</a>", url) }
            if url.host == "second.org" { return response("<a href='https://third.org/'>Podcast team</a><a href='https://first.org/'>Podcast</a>", url) }
            return response("person@third.org", url)
        }, sleep: { _ in })
        let rows = engine.run(mode: .website, terms: ["https://first.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(fetched, ["first.org","second.org","third.org"])
        XCTAssertEqual(rows.map(\.address), ["person@third.org"])
        XCTAssertFalse(engine.hasRemainingPages)
        XCTAssertEqual(CrawlDisk.load()?.discoveredCount, 3)
    }
    func testUnlimitedAdaptiveFollowsBeyondTwentyLevels() {
        var pages = 0
        let engine = GrabEngine(settings: options(), fetcher: { url in
            if url.path == "/robots.txt" { return response("User-agent: *", url) }
            pages += 1
            let n = Int(url.lastPathComponent) ?? 0
            return response(n < 25 ? "<a href='/contact/\(n+1)'>Contact</a>" : "person@public.org", url)
        }, sleep: { _ in })
        _ = engine.run(mode: .website, terms: ["https://public.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(pages, 26)
    }
    func testExternalFrontierAndOptionsSurviveRestart() {
        let fetch: (URL) -> HTTPResult = { url in
            if url.path == "/robots.txt" { return response("User-agent: *", url) }
            return response(url.host == "first.org" ? "<a href='https://second.org/'>Podcast</a>" : "person@second.org", url)
        }
        let engine = GrabEngine(settings: options(pages: 1), fetcher: fetch, sleep: { _ in })
        _ = engine.run(mode: .website, terms: ["https://first.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        let saved = CrawlDisk.load()!
        XCTAssertEqual(saved.settings.followExternalLinks, true)
        XCTAssertEqual(saved.settings.topic, "podcast")
        XCTAssertEqual(saved.queue.first?.host, "second.org")
        let resumed = GrabEngine(settings: options(), fetcher: fetch, sleep: { _ in })
        resumed.restore(saved)
        let rows = resumed.run(mode: .website, terms: saved.selectedSites, existing: saved.rows, liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(rows.map(\.address), ["person@second.org"])
        XCTAssertEqual(CrawlDisk.load()?.discoveredCount, 2)
    }
    func testIrrelevantSponsoredSocialAndUnsafeLinksRejected() {
        let source = URL(string: "https://public.org/")!
        for (target,label,nofollow) in [
            ("https://other.org/","Shoes",false),
            ("https://facebook.com/podcast","Podcast",false),
            ("https://other.org/","Podcast",true),
            ("https://other.org/","Podcast website by",false),
            ("http://127.0.0.1/","Podcast",false)
        ] {
            XCTAssertFalse(LinkRelevance.relevant(CrawlLink(url: URL(string: target)!, label: label, nofollow: nofollow), from: source, topic: "podcast"))
        }
    }
    func testMoreThanTwoHundredRelevantLinksAreQueued() {
        let engine = GrabEngine(settings: options(pages: 1), fetcher: { url in
            if url.path == "/robots.txt" { return response("User-agent: *", url) }
            return response((0..<230).map { "<a href='/contact/\($0)'>Contact</a>" }.joined(), url)
        }, sleep: { _ in })
        _ = engine.run(mode: .website, terms: ["https://public.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(CrawlDisk.load()?.queue.count, 230)
    }
    func testBlockedExternalSiteDoesNotPreventNextRelevantSite() {
        var fetched = Set<String>()
        let engine = GrabEngine(settings: options(), fetcher: { url in
            if url.path == "/robots.txt" { return response("User-agent: *", url) }
            fetched.insert(url.host!)
            if url.host == "first.org" { return response("<a href='https://blocked.org/'>Podcast</a><a href='https://good.org/'>Podcast</a>", url) }
            return response(url.host == "blocked.org" ? "" : "person@good.org", url, status: url.host == "blocked.org" ? 403 : 200)
        }, sleep: { _ in })
        let rows = engine.run(mode: .website, terms: ["https://first.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(rows.map(\.address), ["person@good.org"])
        XCTAssertTrue(fetched.contains("blocked.org"))
    }
    func testTrackingCanonicalizationPreservesProfileIdentity() {
        let links = LinkRelevance.links("<a href='/profile?id=7&amp;utm_source=x#bio'>Contact</a>", base: URL(string: "https://public.org/")!)
        XCTAssertEqual(links.first?.url.absoluteString, "https://public.org/profile?id=7")
        XCTAssertTrue(LinkRelevance.relevant(CrawlLink(url: URL(string: "https://other.org/")!, label: "Contact team", nofollow: false), from: URL(string: "https://public.org/")!, topic: ""))
    }
}
