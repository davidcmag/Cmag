import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

final class GrabEngine {
    let settings: GrabSettings
    private struct CrawlState {
        var queue: [(URL, Int, String)]
        var queued: Set<String>
        var visited: Set<String>
        var robotRules: [String: [String]]
        var domainPageCount: [String: Int]
        var discoveredCount: Int
        var scanned: Int
    }
    private var savedState: CrawlState?
    private var knownHosts = Set<String>()
    var hasRemainingPages: Bool { !(savedState?.queue.isEmpty ?? true) }
    private let injectedFetch: ((URL) -> HTTPResult)?
    private let assessDNS: (String) -> DNSAssessment
    private let sleep: (TimeInterval) -> Void
    private var shouldCancel: () -> Bool = { false }
    private var policies: [String: RobotsPolicy] = [:]
    private let policyLock = NSRecursiveLock()
    private(set) var lastFailure: String?
    private(set) var discoveryWarning: String?
    private let independentSearch: (String, () -> Bool) -> AdditionalSearchDiscovery.SearchResult
    init(settings: GrabSettings, fetcher: ((URL) -> HTTPResult)? = nil, dns: @escaping (String) -> DNSAssessment = DNSChecker.check, sleep: @escaping (TimeInterval) -> Void = Thread.sleep(forTimeInterval:), search: @escaping (String, () -> Bool) -> AdditionalSearchDiscovery.SearchResult = { query, stop in AdditionalSearchDiscovery.searchResult(query, shouldStop: stop) }) {
        self.settings = settings; self.injectedFetch = fetcher; self.assessDNS = dns; self.sleep = sleep; self.independentSearch = search
    }
    func restore(_ snapshot: CrawlProgress) {
        knownHosts = snapshot.discoveredHosts ?? Set(snapshot.queue.map(\.host)).union(snapshot.domainPageCount.keys)
        savedState = CrawlState(queue: snapshot.queue.compactMap { item in
            guard let url = URL(string: item.url) else { return nil }; return (url, item.level, item.host)
        }, queued: snapshot.queued, visited: snapshot.visited, robotRules: snapshot.robotRules, domainPageCount: snapshot.domainPageCount, discoveredCount: snapshot.discoveredCount, scanned: snapshot.scanned)
    }

    private let emailPattern = #"(?i)(?<![\p{L}\p{N}._%+@\-])[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}(?![\p{L}\p{N}.@\-])"#
    private let roleNames: Set<String> = ["info", "admin", "support", "sales", "contact", "hello", "office", "help", "webmaster", "noreply", "no-reply", "marketing", "privacy", "billing", "care", "enquiries", "inquiries", "enquiry", "inquiry", "customerservice", "customer-service", "service", "reception", "receptionist", "general", "team", "staff", "jobs", "careers", "hr", "humanresources", "media", "press", "events", "donations", "donate", "accounts", "accounting", "orders", "booking", "bookings", "reservations", "feedback", "questions", "mail", "email", "contactus", "operations", "officeadmin", "administrator"]
    private let freeDomains: Set<String> = ["gmail.com", "yahoo.com", "outlook.com", "hotmail.com", "aol.com", "icloud.com", "proton.me", "protonmail.com", "live.com"]
    private let disposableDomains: Set<String> = ["mailinator.com", "10minutemail.com", "guerrillamail.com", "tempmail.com", "yopmail.com", "trashmail.com"]

    func run(mode: SourceMode, terms: [String], existing: [FoundEmail], liveRows: ([FoundEmail]) -> Void, update: (Int, Int, Int, String) -> Void, shouldStop: @escaping () -> Bool) -> [FoundEmail] {
        policyLock.lock(); shouldCancel = shouldStop; lastFailure = nil; policies.removeAll(); policyLock.unlock()
        if mode == .pasted && hasRemainingPages {
            lastFailure = "Cannot parse different pasted input while continuing a saved crawl"
            update(savedState?.scanned ?? 0, savedState?.discoveredCount ?? 0, savedState?.domainPageCount.count ?? 0, lastFailure!)
            return existing
        }
        var rows = existing
        var seen = Set(existing.map { $0.address.lowercased() })
        let block = settings.exclude.split(whereSeparator: \.isNewline).map { $0.trimmingCharacters(in: .whitespaces).lowercased() }.filter { !$0.isEmpty }
        let regex = try! NSRegularExpression(pattern: emailPattern)
        var dnsCache: [String: DNSAssessment] = [:]

        @discardableResult func appendAddresses(_ text: String, source: String) -> Bool {
            // Websites frequently serialize HTML in JSON with escaped angle
            // brackets (e.g. \\u003einfo@example.org). Decode these first so
            // the escape's 'u003e' does not become a fake mailbox prefix.
            var pending: [FoundEmail] = []; var lastLive = Date()
            func flush() { if !pending.isEmpty { liveRows(pending); pending.removeAll(keepingCapacity: true); lastLive = Date() } }
            let normalized = Self.normalizeEncodedText(text)
            let range = NSRange(normalized.startIndex..<normalized.endIndex, in: normalized)
            for match in regex.matches(in: normalized, range: range) {
                if shouldStop() { flush(); return false }
                guard let r = Range(match.range, in: normalized) else { continue }
                let address = String(normalized[r]).lowercased().trimmingCharacters(in: CharacterSet(charactersIn: ".,;:!?)"))
                guard address.utf8.count <= 254 else { continue }
                if settings.duplicates && seen.contains(address) { continue }
                seen.insert(address)
                let fields = address.split(separator: "@")
                guard fields.count == 2 else { continue }
                let local = String(fields[0]), domain = String(fields[1])
                // Web asset filenames often contain @2x / @3x (retina images),
                // which superficially resembles an email address. Never store
                // asset paths or filenames as email records, even as Uncertain.
                guard !Self.isAssetFilenameDisguisedAsEmail(local: local, domain: domain) else { continue }
                // Sentry DSN public keys, including Wix-hosted Sentry telemetry
                // are machine identifiers, not mailboxes. Reject *before* DNS
                // checks and before adding rows to the live results table.
                guard !Self.isTelemetryIdentifier(local: local, domain: domain) else { continue }
                var reason = "Syntax valid; mailbox not independently confirmed"
                var status = "Accepted"
                if !EmailPolicy.validSyntax(address) {
                    status = "Rejected"; reason = "Invalid address format"
                } else if Self.isPlaceholder(address: address, domain: domain) {
                    status = "Excluded"; reason = "Placeholder or example email address"
                } else if block.contains(where: { address.contains($0) || domain == $0 }) {
                    status = "Excluded"; reason = "Matched exclusion rule"
                } else if settings.role && roleNames.contains(local) {
                    status = "Excluded"; reason = "Role-based mailbox"
                } else if settings.free && freeDomains.contains(domain) {
                    status = "Excluded"; reason = "Free email provider"
                } else if settings.disposable && disposableDomains.contains(domain) {
                    status = "Excluded"; reason = "Known disposable domain (starter list)"
                } else if settings.dns {
                    let assessment: DNSAssessment
                    if let cached = dnsCache[domain] { assessment = cached }
                    else { assessment = assessDNS(domain); dnsCache[domain] = assessment }
                    status = (assessment == .mx || assessment == .fallback) ? "Accepted" : "Uncertain"
                    reason = assessment.reason
                }
                let row = FoundEmail(address: address, source: source, status: status, reason: reason)
                rows.append(row); pending.append(row)
                if pending.count >= 25 || Date().timeIntervalSince(lastLive) >= 0.25 { flush() }
            }
            flush(); return true
        }

        if mode == .pasted {
            appendAddresses(terms.joined(separator: "\n"), source: "Pasted / imported input")
            update(0, 0, 0, "Parsed imported text")
            return rows
        }

        var seeds: [URL] = []
        if savedState == nil && mode == .website {
            seeds = terms.compactMap { Self.normalizedURL($0) }
        } else if savedState == nil {
            seeds = discoverSites(terms: terms, exploreDirectories: false, nationwide: true, shouldStop: shouldStop, progress: { _ in }).compactMap { URL(string: $0.url) }
        }
        var visited = savedState?.visited ?? Set<String>()
        var queued = savedState?.queued ?? Set<String>()
        let robotRules: [String: [String]] = [:]
        var domainPageCount: [String: Int] = savedState?.domainPageCount ?? [:]
        var queue: [(URL, Int, String)] = savedState?.queue ?? []
        // Seed one page per discovered host first, so the global page budget
        // reaches distinct businesses before exploring deep within a site.
        var seedsByHost: [String: [URL]] = [:]
        var uniqueSeeds = Set<String>()
        for url in seeds {
            guard let host = url.host?.lowercased(), !host.isEmpty else { continue }
            let canonical = host.hasPrefix("www.") ? String(host.dropFirst(4)) : host
            if uniqueSeeds.insert(url.absoluteString).inserted { seedsByHost[canonical, default: []].append(url) }
        }
        if savedState == nil { knownHosts.removeAll() }
        knownHosts.formUnion(seedsByHost.keys)
        var discoveredCount = savedState?.discoveredCount ?? knownHosts.count
        for (host, links) in seedsByHost.sorted(by: { $0.key < $1.key }) {
            if let first = links.first { queue.append((first, 0, host)); queued.insert(first.absoluteString) }
        }
        for (host, links) in seedsByHost.sorted(by: { $0.key < $1.key }) {
            for extra in links.dropFirst() {
                if queued.insert(extra.absoluteString).inserted { queue.append((extra, 0, host)) }
            }
        }
        var count = savedState?.scanned ?? 0
        let batchEnd = settings.maxPages == 0 ? Int.max : (count > Int.max - settings.maxPages ? Int.max : count + settings.maxPages)
        while !queue.isEmpty && count < batchEnd && !shouldStop() {
            // Persist before taking a page out of the queue. A crash during its
            // request will replay that page instead of silently losing it.
            if !checkpoint(queue: queue, queued: queued, visited: visited, robotRules: robotRules, domainPageCount: domainPageCount, discoveredCount: discoveredCount, count: count, rows: rows, terms: terms) { lastFailure = "Could not save crawl checkpoint: " + (CrawlDisk.lastError ?? "unknown error"); break }
            let (url, level, rootHost) = queue.removeFirst()
            let key = url.absoluteString
            guard !visited.contains(key) else { continue }
            visited.insert(key)
            if settings.maxPagesPerDomain > 0 && domainPageCount[rootHost, default: 0] >= settings.maxPagesPerDomain { continue }
            guard let host = url.host?.lowercased() else { continue }
            guard allowedByRobots(url) else {
                if shouldStop() { visited.remove(key); queue.insert((url, level, rootHost), at: 0); break }
                update(count, discoveredCount, domainPageCount.count, "Skipped \(host): robots.txt denied access or could not be checked")
                continue
            }
            let response = fetchResponse(url, checkRobots: true)
            guard response.succeeded, let html = response.decodedText else {
                if shouldStop() { visited.remove(key); queue.insert((url, level, rootHost), at: 0); break }
                let message = response.status.map { "HTTP \($0)" } ?? response.error ?? "Unsupported page encoding"
                update(count, discoveredCount, domainPageCount.count, "Skipped \(host): \(message); continuing other websites")
                continue
            }
            let sourceURL = response.finalURL ?? url
            guard appendAddresses(html, source: sourceURL.absoluteString) else { visited.remove(key); queue.insert((url, level, rootHost), at: 0); break }
            count += 1
            domainPageCount[rootHost, default: 0] += 1
            update(count, discoveredCount, domainPageCount.count, "Scanned \(count) pages on \(domainPageCount.count) sites; found \(rows.count) addresses")
            let unlimitedAdaptive = settings.depth == 0 && settings.followExternalLinks
            let followInternal = level < settings.depth || (settings.depth == 0 && (unlimitedAdaptive || level < 20))
            var candidates = LinkRelevance.links(html, base: sourceURL).sorted { Self.linkPriority($0.url) > Self.linkPriority($1.url) }
            if !settings.followExternalLinks { candidates = Array(candidates.prefix(200)) }
            let scope = EmailPolicy.canonicalHost(sourceURL.host ?? rootHost)
            for candidate in candidates {
                let link = candidate.url
                let hostname = EmailPolicy.canonicalHost(link.host ?? "")
                let internalLink = hostname == scope || hostname.hasSuffix("." + scope)
                if candidate.nofollow { continue }
                let path = link.path.lowercased()
                if [".jpg", ".jpeg", ".png", ".gif", ".zip", ".pdf", ".mp4", ".svg", ".css", ".js", ".woff", ".woff2"].contains(where: path.hasSuffix) { continue }
                if internalLink {
                    guard followInternal else { continue }
                    if settings.depth == 0 && Self.linkPriority(link) <= 0 && Self.textPriority(candidate.label) <= 0 { continue }
                } else {
                    guard settings.followExternalLinks, LinkRelevance.relevant(candidate, from: sourceURL, topic: settings.topic) else { continue }
                }
                if queued.insert(link.absoluteString).inserted {
                    let nextHost = internalLink ? rootHost : hostname
                    queue.append((link, internalLink ? level + 1 : 0, nextHost))
                    if !internalLink && knownHosts.insert(nextHost).inserted { discoveredCount += 1 }
                }
            }
            if !checkpoint(queue: queue, queued: queued, visited: visited, robotRules: robotRules, domainPageCount: domainPageCount, discoveredCount: discoveredCount, count: count, rows: rows, terms: terms) { lastFailure = "Could not save crawl checkpoint: " + (CrawlDisk.lastError ?? "unknown error"); break }
            sleep(max(0.3, policy(for: sourceURL).delay))
        }
        savedState = CrawlState(queue: queue, queued: queued, visited: visited, robotRules: robotRules, domainPageCount: domainPageCount, discoveredCount: discoveredCount, scanned: count)
        if !checkpoint(queue: queue, queued: queued, visited: visited, robotRules: robotRules, domainPageCount: domainPageCount, discoveredCount: discoveredCount, count: count, rows: rows, terms: terms) { lastFailure = "Could not save crawl checkpoint: " + (CrawlDisk.lastError ?? "unknown error") }
        update(count, discoveredCount, domainPageCount.count, lastFailure ?? (queue.isEmpty ? "Finished: \(count) pages across \(domainPageCount.count) websites; \(rows.count) records." : "Batch finished at \(count) pages; \(queue.count) links remain in queue."))
        return rows
    }

    @discardableResult private func checkpoint(queue: [(URL, Int, String)], queued: Set<String>, visited: Set<String>, robotRules: [String: [String]], domainPageCount: [String: Int], discoveredCount: Int, count: Int, rows: [FoundEmail], terms: [String]) -> Bool {
        let options = CrawlOptions(depth: settings.depth, maxPages: settings.maxPages, maxPagesPerDomain: settings.maxPagesPerDomain, excluded: settings.exclude, stripDuplicates: settings.duplicates, excludeRole: settings.role, excludeFree: settings.free, excludeDisposable: settings.disposable, checkDNS: settings.dns, followExternalLinks: settings.followExternalLinks, topic: settings.topic)
        return CrawlDisk.save(CrawlProgress(queue: queue.map { CrawlProgress.Link(url: $0.0.absoluteString, level: $0.1, host: $0.2) }, visited: visited, queued: queued, robotRules: robotRules, discoveredHosts: knownHosts, domainPageCount: domainPageCount, discoveredCount: discoveredCount, scanned: count, rows: rows, selectedSites: terms, settings: options, input: terms.joined(separator: "\n")))
    }

    func discoverSites(terms: [String], exploreDirectories: Bool, nationwide: Bool, shouldStop: @escaping () -> Bool, progress: (String) -> Void) -> [DiscoveredSite] {
        shouldCancel = shouldStop; discoveryWarning = nil
        func warn(_ text: String) { discoveryWarning = [discoveryWarning, text].compactMap { $0 }.joined(separator: "; "); progress(text) }
        var candidates: [DiscoveredSite] = []
        var knownHosts = Set<String>()
        func add(_ url: URL, origin: String) {
            guard EmailPolicy.httpURL(url),
                  let rawHost = url.host?.lowercased() else { return }
            let host = rawHost.hasPrefix("www.") ? String(rawHost.dropFirst(4)) : rawHost
            if knownHosts.insert(host).inserted && candidates.count < 3000 {
                candidates.append(DiscoveredSite(url: url.absoluteString, origin: origin))
            }
        }
        var queries: [String] = []
        for term in terms.prefix(5) {
            queries.append(term)
            queries.append("\(term) contact")
            if nationwide {
                // A broad search only exposes a tiny slice of the web. Search
                // distinct geographic partitions to reach independent sites.
                for state in USStates.all {
                    queries.append("\(term) \(state.name)")
                }
                for metro in ["New York City", "Los Angeles", "Chicago", "Houston", "Phoenix", "Philadelphia", "San Antonio", "San Diego", "Dallas", "Jacksonville", "Fort Worth", "Columbus Ohio", "Indianapolis", "Charlotte", "Washington DC", "Nashville", "Oklahoma City", "El Paso", "Detroit", "Memphis", "Louisville", "Baltimore", "Boston", "Seattle", "Denver", "Atlanta", "Miami", "Portland Oregon", "Las Vegas", "New Orleans"] {
                    queries.append("\(term) \(metro)")
                }
            } else {
                queries.append("\(term) website")
                queries.append("\(term) contact email")
            }
        }
        // Independent discovery source: merge candidates with the RSS provider.
        // Bound public HTML requests so a broad nationwide run stays polite.
        let independentQueries = Array(queries.prefix(nationwide ? 12 : 3))
        for (index, query) in independentQueries.enumerated() {
            if shouldStop() { break }
            let independent = independentSearch(query, shouldStop)
            if let code = independent.status, [403,429,503].contains(code) { warn("DuckDuckGo unavailable/rate-limited (HTTP \(code)); skipping remaining requests to that provider"); break }
            for site in independent.urls {
                add(site, origin: "Independent web search")
            }
            progress("Independent discovery \(index + 1)/\(independentQueries.count): \(candidates.count) websites")
            sleep(1.0)
        }
                let rssPattern = #"<link>\s*(https?://[^<]+)</link>"#
        let regex = try? NSRegularExpression(pattern: rssPattern, options: [.caseInsensitive])
        let excludedSearchHosts = ["facebook.com", "instagram.com", "linkedin.com", "twitter.com", "x.com", "youtube.com", "google.com", "bing.com", "yelp.com"]
        for (index, query) in queries.enumerated() {
            if shouldStop() { break }
            defer { sleep(0.3) }
            guard let url = EmailPolicy.searchURL(query) else { continue }
            let response = fetchResponse(url)
            if let code = response.status, [403,429,503].contains(code) { warn("Bing unavailable/rate-limited (HTTP \(code)); skipping remaining requests to that provider"); break }
            guard response.succeeded, let data = response.data, let xml = String(data: data, encoding: .utf8), let regex = regex else { continue }
            let ns = NSRange(xml.startIndex..<xml.endIndex, in: xml)
            for match in regex.matches(in: xml, range: ns).prefix(35) {
                guard let range = Range(match.range(at: 1), in: xml),
                      let site = URL(string: String(xml[range]).replacingOccurrences(of: "&amp;", with: "&")) else { continue }
                guard let host = site.host?.lowercased(), !excludedSearchHosts.contains(where: { host == $0 || host.hasSuffix("." + $0) }) else { continue }
                add(site, origin: "Search")
            }
            progress("Discovery query \(index + 1)/\(queries.count): \(candidates.count) websites")
            if candidates.count >= 3000 { break }

        }
        if exploreDirectories {
            let directoryCandidates = candidates.filter { candidate in
                let host = candidate.host.lowercased()
                return ["directory", "directories", "listing", "association", "chamber"].contains(where: host.contains)
            }
            let excludedHosts = ["facebook.com", "instagram.com", "linkedin.com", "twitter.com", "x.com", "youtube.com", "google.com", "bing.com", "yelp.com", "maps.google.com"]
            for directory in directoryCandidates.prefix(8) {
                if shouldStop() { break }
                guard let url = URL(string: directory.url) else { continue }
                if !allowedByRobots(url) { continue }
                guard let data = fetch(url), let html = String(data: data, encoding: .utf8) else { continue }
                var added = 0
                for link in Self.links(html, base: url) {
                    guard let host = link.host?.lowercased(), host != url.host?.lowercased() else { continue }
                    if excludedHosts.contains(where: { host == $0 || host.hasSuffix("." + $0) }) { continue }
                    let prior = candidates.count
                    add(link, origin: "Directory: \(directory.host)")
                    if candidates.count > prior { added += 1 }
                    if added >= 100 || candidates.count >= 3000 { break }
                }
                progress("Explored directory \(directory.host): \(candidates.count) websites")
                sleep(0.3)
            }
        }
        return candidates
    }

    private static func isAssetFilenameDisguisedAsEmail(local: String, domain: String) -> Bool {
        let assetExtensions: Set<String> = [
            "png", "jpg", "jpeg", "gif", "webp", "svg", "avif", "ico", "bmp", "tif", "tiff",
            "heic", "apng", "jfif", "woff", "woff2", "ttf", "otf", "eot", "css", "js", "map"
        ]
        let pieces = domain.lowercased().split(separator: ".")
        guard let suffix = pieces.last.map(String.init) else { return false }
        // These are file extensions, not email-domain TLDs. Reject regardless
        // of whether the filename uses @2x or another asset naming convention.
        if assetExtensions.contains(suffix) { return true }
        // Example: image@2x.png?v=2 is already caught by .png after normalization,
        // but explicit retina names also cannot be recipient domains.
        if pieces.count == 1 && (domain == "2x" || domain == "3x") { return true }
        return false
    }

    private static func isTelemetryIdentifier(local: String, domain: String) -> Bool {
        let host = domain.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: "."))
        let parts = host.split(separator: ".").map(String.init)

        // Sentry's own ingest servers (including region-specific hosts).
        if parts.count >= 3 && parts.suffix(2) == ["sentry", "io"] && parts.dropLast(2).contains("ingest") {
            return true
        }

        // Wix embeds Sentry public-key DSNs in website JavaScript. These
        // strings are telemetry endpoints, not contact mailboxes. Reject only
        // the known telemetry hosts; do not blanket-exclude wixpress.com.
        let wixTelemetryHosts: Set<String> = [
            "sentry.wixpress.com", "sentry-next.wixpress.com"
        ]
        if wixTelemetryHosts.contains(where: { host == $0 || host.hasSuffix("." + $0) }) { return true }

        // Hex identifiers elsewhere are not automatically telemetry: a real
        // mailbox may use a hexadecimal local part. Preserve those unless
        // their destination is a recognized instrumentation endpoint.
        _ = local
        return false
    }

    private static func isPlaceholder(address: String, domain: String) -> Bool {
        let placeholders: Set<String> = ["example.com", "example.org", "example.net", "yourdomain.com", "yoursite.com", "placeholder.com"]
        if placeholders.contains(where: { domain == $0 || domain.hasSuffix("." + $0) }) { return true }
        return ["name@domain.tld", "email@domain.tld", "name@domain.com", "email@domain.com"].contains(address)
    }

    private static func linkPriority(_ url: URL) -> Int {
        return textPriority(url.path)
    }

    private static func textPriority(_ value: String) -> Int {
        let text = value.lowercased()
        if ["contact", "staff", "team", "people", "directory", "about", "leadership", "sales", "profile", "faculty", "hosts", "authors", "contributors"].contains(where: text.contains) { return 10 }
        if ["privacy", "terms", "legal", "blog", "news", "events", "gallery"].contains(where: text.contains) { return -5 }
        return 0
    }

    private static func normalizeEncodedText(_ text: String) -> String {
        let replacements: [(String, String)] = [
            (#"\u003c"#, "<"), (#"\u003e"#, ">"),
            (#"\u0040"#, "@"), (#"\u002e"#, "."),
            (#"\u0026"#, "&"),
            ("&lt;", "<"), ("&gt;", ">"),
            ("&#60;", "<"), ("&#62;", ">"),
            ("&#64;", "@"), ("&#x40;", "@")
        ]
        var output = text
        for (encoded, decoded) in replacements {
            output = output.replacingOccurrences(of: encoded, with: decoded, options: [.caseInsensitive])
        }
        // Common deliberate obfuscations on contact pages. Only bracketed
        // tokens are changed, not ordinary occurrences of 'at' or 'dot'.
        output = output.replacingOccurrences(of: #"(?i)\s*(?:\[at\]|\(at\))\s*"#, with: "@", options: [.regularExpression])
        output = output.replacingOccurrences(of: #"(?i)\s*(?:\[dot\]|\(dot\))\s*"#, with: ".", options: [.regularExpression])
        output = EmailPolicy.decodeHTML(output)
        if let regex = try? NSRegularExpression(pattern: #"(?i)mailto:([^\s"'<>?]+)"#) {
            let matches = regex.matches(in: output, range: NSRange(output.startIndex..., in: output))
            for match in matches.reversed() {
                guard let range = Range(match.range(at: 1), in: output), let decoded = String(output[range]).removingPercentEncoding else { continue }
                output.replaceSubrange(range, with: decoded)
            }
        }
        return output
    }

    static func normalizedURL(_ string: String) -> URL? {
        let cleaned = string.trimmingCharacters(in: .whitespacesAndNewlines)
        let withScheme = cleaned.contains("://") ? cleaned : "https://" + cleaned
        guard let u = URL(string: withScheme), EmailPolicy.httpURL(u) else { return nil }
        var components = URLComponents(url: u, resolvingAgainstBaseURL: false); components?.fragment = nil
        if components?.path.isEmpty == true { components?.path = "/" }
        return components?.url
    }

    private func fetchResponse(_ url: URL, checkRobots: Bool = false) -> HTTPResult {
        guard EmailPolicy.httpURL(url) else { return HTTPResult(error: "Invalid HTTP destination") }
        if let fetcher = injectedFetch { return fetcher(url) }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 12)
        request.setValue("EmailGrabber3/1.0 (local user-initiated contact discovery)", forHTTPHeaderField: "User-Agent")
        return HTTPTransport.perform(request, shouldCancel: shouldCancel, redirect: { [weak self] target in
            EmailPolicy.httpURL(target) && (!checkRobots || self?.allowedByRobots(target) == true)
        })
    }
    private func fetch(_ url: URL) -> Data? { let result = fetchResponse(url); return result.succeeded ? result.data : nil }
    private func policy(for url: URL) -> RobotsPolicy {
        policyLock.lock(); defer { policyLock.unlock() }
        guard var c = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return .denyAll }
        c.path = "/robots.txt"; c.query = nil; c.fragment = nil
        guard let robotsURL = c.url else { return .denyAll }
        let key = robotsURL.absoluteString
        if let value = policies[key] { return value }
        let result = fetchResponse(robotsURL)
        let value: RobotsPolicy
        if result.status == 404 || result.status == 410 { value = RobotsPolicy() }
        else if result.succeeded, let data = result.data, let text = String(data: data, encoding: .utf8) { value = RobotsPolicy(text) }
        else { value = .denyAll }
        policies[key] = value; return value
    }
    private func allowedByRobots(_ url: URL) -> Bool { policy(for: url).allows(url) }

    private static func links(_ html: String, base: URL) -> [URL] {
        guard let regex = try? NSRegularExpression(pattern: #"(?i)href\s*=\s*["']([^"']+)["']"#) else { return [] }
        let ns = NSRange(html.startIndex..<html.endIndex, in: html)
        return regex.matches(in: html, range: ns).compactMap { m in
            guard let r = Range(m.range(at: 1), in: html) else { return nil }
            let raw = String(html[r]).replacingOccurrences(of: "&amp;", with: "&")
            guard let url = URL(string: raw, relativeTo: base)?.absoluteURL else { return nil }
            return URLComponents(url: url, resolvingAgainstBaseURL: false).map { components -> URL? in
                var c = components; c.fragment = nil; return c.url
            } ?? nil
        }
    }

}
