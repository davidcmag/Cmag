import Foundation

struct CrawlLink {
    let url: URL
    let label: String
    let nofollow: Bool
}

enum LinkRelevance {
    private static let utilityHosts = ["facebook.com","instagram.com","twitter.com","x.com","linkedin.com","youtube.com","tiktok.com","pinterest.com","google.com","bing.com","duckduckgo.com","doubleclick.net","googlesyndication.com","paypal.com"]
    private static let stopWords: Set<String> = ["the","and","for","with","from","that","this","website","websites","www","com","org","net","http","https","official"]
    static func tokens(_ value: String) -> Set<String> {
        let text = value.folding(options: [.caseInsensitive,.diacriticInsensitive], locale: Locale(identifier: "en_US_POSIX"))
        let pieces = text.components(separatedBy: CharacterSet.alphanumerics.inverted)
        return Set(pieces.filter { $0.count >= 3 && !stopWords.contains($0) }.map { $0.count > 4 && $0.hasSuffix("s") ? String($0.dropLast()) : $0 })
    }
    static func canonical(_ url: URL) -> URL? {
        guard EmailPolicy.httpURL(url), var c = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return nil }
        c.fragment = nil
        if c.path.isEmpty { c.path = "/" }
        c.queryItems = c.queryItems?.filter { !$0.name.lowercased().hasPrefix("utm_") && !["fbclid","gclid","msclkid"].contains($0.name.lowercased()) }
        if c.queryItems?.isEmpty == true { c.queryItems = nil }
        return c.url
    }
    static func links(_ html: String, base: URL) -> [CrawlLink] {
        guard let anchors = try? NSRegularExpression(pattern: #"(?is)<a\b([^>]*?)>(.*?)</a\s*>"#),
              let href = try? NSRegularExpression(pattern: #"(?i)\bhref\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))"#),
              let rel = try? NSRegularExpression(pattern: #"(?i)\brel\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))"#) else { return [] }
        var result: [CrawlLink] = []
        for a in anchors.matches(in: html, range: NSRange(html.startIndex..., in: html)) {
            guard let attrs = Range(a.range(at: 1), in: html), let content = Range(a.range(at: 2), in: html) else { continue }
            let text = String(html[attrs])
            guard let h = href.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)), let capture = (1...3).compactMap({ Range(h.range(at: $0), in: text) }).first else { continue }
            let raw = EmailPolicy.decodeHTML(String(text[capture]))
            guard !raw.isEmpty, let resolved = URL(string: raw, relativeTo: base)?.absoluteURL, let url = canonical(resolved) else { continue }
            let label = EmailPolicy.decodeHTML(String(html[content]).replacingOccurrences(of: #"<[^>]+>"#, with: " ", options: .regularExpression))
            var relation = ""
            if let r = rel.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)), let capture = (1...3).compactMap({ Range(r.range(at: $0), in: text) }).first { relation = String(text[capture]).lowercased() }
            let directives = Set(relation.split(whereSeparator: \.isWhitespace).map(String.init))
            result.append(CrawlLink(url: url, label: String(label.prefix(2048)), nofollow: !directives.isDisjoint(with: ["nofollow","sponsored"])))
        }
        return result
    }
    static func relevant(_ link: CrawlLink, from source: URL, topic: String) -> Bool {
        guard !link.nofollow, EmailPolicy.httpURL(link.url), let rawHost = link.url.host else { return false }
        let host = EmailPolicy.canonicalHost(rawHost)
        guard !utilityHosts.contains(where: { host == $0 || host.hasSuffix("."+$0) }) else { return false }
        let label = link.label.lowercased()
        if ["website by","web design","powered by","developed by","advertis","sponsored","privacy policy","terms of","share on"].contains(where: label.contains) { return false }
        let words = tokens(link.url.path + " " + link.label)
        if !words.isDisjoint(with: ["privacy","login","signin","checkout","cookie","sharer"]) { return false }
        let topicWords = tokens(topic)
        let directory = !tokens(source.path + " " + (source.host ?? "")).isDisjoint(with: ["directory","listing","member","partner","association","resource"])
        if !topicWords.isEmpty {
            if !words.isDisjoint(with: topicWords) { return true }
            // A relevant directory can identify people/sites by name, without
            // repeating the search topic on every "official website" link.
            let named = !tokens(link.label).isEmpty
            let directoryMatchesTopic = !tokens(source.absoluteString).isDisjoint(with: topicWords)
            return directory && directoryMatchesTopic && (named || label.contains("website"))
        }
        // Direct URL crawls have no supplied topic: require an explicit useful
        // relationship or a named directory entry, rather than every footer link.
        return !words.isDisjoint(with: ["contact","staff","team","people","sales","faculty","profile","directory","member","partner","association"]) || (directory && !tokens(link.label).isEmpty)
    }
}
