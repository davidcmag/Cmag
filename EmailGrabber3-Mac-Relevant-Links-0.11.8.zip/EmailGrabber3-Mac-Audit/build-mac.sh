#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ "$(uname -s)" != Darwin ]]; then
  echo "The SwiftUI application requires macOS and Xcode. Portable core tests: swift test --jobs 2" >&2
  exit 1
fi
xcrun --find swiftc >/dev/null
mkdir -p dist/EmailGrabber3.app/Contents/MacOS
xcrun swiftc -swift-version 5 -O -parse-as-library -framework SwiftUI -framework AppKit -framework Foundation -framework Security -framework UniformTypeIdentifiers \
  EmailGrabber3.swift DomainModels.swift GrabEngine.swift AuditSupport.swift LinkRelevance.swift HTTPTransport.swift SafeProcess.swift \
  FileImport.swift AdvancedVerifier.swift OpenStreetMapDiscovery.swift AdditionalSearchDiscovery.swift \
  -o dist/EmailGrabber3.app/Contents/MacOS/EmailGrabber3
cp Info.plist dist/EmailGrabber3.app/Contents/Info.plist
echo "Built locally: $(pwd)/dist/EmailGrabber3.app"
echo "Keep your previous app until this build has passed the Mac acceptance checklist."
