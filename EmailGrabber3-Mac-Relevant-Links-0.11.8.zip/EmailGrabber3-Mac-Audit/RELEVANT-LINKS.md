Email Grabber 3 Mac 0.11.8 candidate

New searches default to following relevant links across websites. Adaptive depth,
unlimited total pages and adaptive pages per website have no fixed traversal cap
in this mode. Contact/staff/team/directory links remain prioritized. External
links are selected using the search topic, anchor text and directory context.
For direct website input, an optional topic field improves relevance.

The crawl stops when requested or when the eligible queue is exhausted.
Finite useful links, blocked pages and relevance decisions mean continuous
discovery is not guaranteed. Download bounds, robots rules and request delays
remain active. Existing saved crawl options retain their previous behavior.
Page limits remain available when the user wants a bounded batch.

Checkpoints include external sites, their pending URLs, topic, and traversal
setting. Social, sponsored, nofollow, utility, unsafe literal URLs, and obvious
irrelevant links are rejected. Email validation does not verify mailbox existence.

Validation: automated Swift core suite includes recursive external links, cycle
deduplication, more than 20 internal levels, more than 200 links per page,
blocked external websites, tracking URL cleanup, and restart recovery.
The updated macOS app still requires Xcode build/test and live GUI checks.
Run bash verify-mac.sh, then Run the app from Xcode. The script backs up local
app data; keep the previous source/app until the candidate is verified.
