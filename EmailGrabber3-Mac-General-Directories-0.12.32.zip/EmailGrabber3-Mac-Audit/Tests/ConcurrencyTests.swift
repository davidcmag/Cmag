import XCTest
import Foundation
@testable import EmailGrabberCore

private final class RequestTracker {
    let condition = NSCondition()
    var active = 0
    var peak = 0
    var bySite: [String: Int] = [:]
    var sitePeaks: [String: Int] = [:]
    var pages: [String] = []
    var started = 0
    func fetch(_ url: URL, barrier: Int = 0) -> HTTPResult {
        if url.path == "/robots.txt" { return response("User-agent: *", url) }
        let site = EmailPolicy.canonicalHost(url.host!)
        condition.lock()
        active += 1; started += 1; peak = max(peak, active)
        bySite[site, default: 0] += 1
        sitePeaks[site] = max(sitePeaks[site, default: 0], bySite[site, default: 0])
        pages.append(url.absoluteString)
        condition.broadcast()
        let deadline = Date().addingTimeInterval(2)
        while barrier > 0 && started < barrier && Date() < deadline { _ = condition.wait(until: deadline) }
        condition.unlock()
        Thread.sleep(forTimeInterval: 0.02)
        condition.lock()
        active -= 1; bySite[site, default: 0] -= 1
        condition.unlock()
        return response("person@\(site) <a href='/contact'>Contact</a>", url)
    }
}

final class ConcurrencyTests: DiskTests {
    func testExtractionDeadlineRetainsUncommittedPage() throws {
        let engine = GrabEngine(settings: options(workers: 1), fetcher: { url in
            response(url.path == "/robots.txt" ? "User-agent: *" : String(repeating: "<a href=unfinished ", count: 4000), url)
        }, sleep: { _ in }, extractionTimeout: 0.05)
        let began = ProcessInfo.processInfo.systemUptime
        _ = engine.run(mode: .website, terms: ["https://public.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertLessThan(ProcessInfo.processInfo.systemUptime - began, 1.5)
        let saved = try XCTUnwrap(CrawlDisk.load())
        XCTAssertEqual(saved.queue.map(\.url), ["https://public.org/"])
        XCTAssertEqual(saved.scanned, 0)
        XCTAssertFalse(saved.visited.contains("https://public.org/"))
        XCTAssertTrue(engine.lastFailure?.contains("Extraction time limit") == true)
    }
    func testPauseThenStopDuringExtractionDoesNotResumeCrawl() throws {
        let control = CrawlControl()
        var stopped = false
        let engine = GrabEngine(settings: options(workers: 1), fetcher: { url in
            response(url.path == "/robots.txt" ? "User-agent: *" : "<p>Jane Doe jane@public.org</p>", url)
        }, sleep: { _ in })
        _ = engine.run(mode: .website, terms: ["https://public.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { control.checkpoint() }, cancellationCheck: { control.wasCancelled }, activity: { event in
            if event.phase == "Extracting" && !stopped { control.pause(); control.cancel(); stopped = true }
        })
        XCTAssertTrue(stopped)
        XCTAssertTrue(control.wasCancelled)
        XCTAssertTrue(control.checkpoint())
        let saved = try XCTUnwrap(CrawlDisk.load())
        XCTAssertEqual(saved.scanned, 0)
        XCTAssertEqual(saved.queue.map(\.url), ["https://public.org/"])
    }
    func testEarlyRobotsFailureKeepsActualCauseAndPage() throws {
        var events: [CrawlActivity] = []
        let engine = GrabEngine(settings: options(), fetcher: { _ in HTTPResult(error: "Connection failed immediately") })
        _ = engine.run(mode: .website, terms: ["https://public.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false }, activity: { events.append($0) })
        let message = try XCTUnwrap(events.first { $0.phase == "Deferred" }?.message)
        XCTAssertTrue(message.contains("Connection failed immediately"))
        XCTAssertTrue(message.contains("0.0s"))
        XCTAssertFalse(message.contains("timed out"))
        XCTAssertEqual(engine.deferredPageCount, 1)
        XCTAssertEqual(CrawlDisk.load()?.queue.count, 1)
    }
    func testLongWebsiteDelayHasBoundedWaitWithoutIgnoringServerDelay() {
        let gate = CrawlRequestGate(), owner = CrawlRequestGate.Lease()
        let url = URL(string: "https://public.org/contact")!
        XCTAssertTrue(gate.claim(url, owner: owner, wait: false, cancelled: { false }))
        gate.release(owner, delay: 3600)
        let began = ProcessInfo.processInfo.systemUptime
        var elapsed: [Int] = []
        XCTAssertFalse(gate.claim(url, owner: CrawlRequestGate.Lease(), wait: true, cancelled: { false }, timeout: 0.12, progress: { elapsed.append($0) }))
        XCTAssertLessThan(ProcessInfo.processInfo.systemUptime - began, 1)
        XCTAssertFalse(elapsed.isEmpty)
        XCTAssertFalse(gate.claim(url, owner: CrawlRequestGate.Lease(), wait: false, cancelled: { false }))
    }
    func testCancelledLeaseCannotStartEvenWhenWebsiteIsFree() {
        let gate = CrawlRequestGate()
        XCTAssertFalse(gate.claim(URL(string: "https://public.org/")!, owner: CrawlRequestGate.Lease(), wait: true, cancelled: { true }))
    }
    func testTimedOutPagesStayPendingWhileHealthyWebsiteFinishesAndResumeRecovers() throws {
        for workers in [1, 5] {
            var events: [CrawlActivity] = []
            let engine = GrabEngine(settings: options(workers: workers, perSite: 1), fetcher: { url in
                if url.path == "/robots.txt" { return response("User-agent: *", url) }
                if url.host == "slow.org" { return HTTPResult(error: "Request timed out", retryable: true) }
                return response("jane@healthy.org", url)
            }, sleep: { _ in })
            let rows = engine.run(mode: .website, terms: ["https://slow.org/", "https://healthy.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false }, activity: { events.append($0) })
            let saved = try XCTUnwrap(CrawlDisk.load())
            XCTAssertEqual(saved.scanned, 1)
            XCTAssertEqual(saved.queue.map(\.url), ["https://slow.org/"])
            XCTAssertFalse(saved.visited.contains("https://slow.org/"))
            XCTAssertEqual(rows.map(\.address), ["jane@healthy.org"])
            XCTAssertTrue(events.contains { $0.phase == "Deferred" })
            XCTAssertTrue(engine.hasRemainingPages)
            let resumed = GrabEngine(settings: options(workers: workers, perSite: 1), fetcher: { url in
                response(url.path == "/robots.txt" ? "User-agent: *" : "jane@slow.org", url)
            }, sleep: { _ in })
            resumed.restore(saved)
            let final = resumed.run(mode: .website, terms: saved.selectedSites, existing: rows, liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
            XCTAssertEqual(Set(final.map(\.address)), ["jane@healthy.org", "jane@slow.org"])
            XCTAssertEqual(CrawlDisk.load()?.scanned, 2)
            XCTAssertFalse(resumed.hasRemainingPages)
        }
    }
    func testRobotsTimeoutRetainsPageInsteadOfRecordingADenial() throws {
        for workers in [1, 5] {
            let engine = GrabEngine(settings: options(workers: workers), fetcher: { _ in HTTPResult(error: "Request timed out", retryable: true) })
            _ = engine.run(mode: .website, terms: ["https://slow.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
            let saved = try XCTUnwrap(CrawlDisk.load())
            XCTAssertEqual(saved.queue.map(\.url), ["https://slow.org/"])
            XCTAssertFalse(saved.visited.contains("https://slow.org/"))
            XCTAssertEqual(saved.scanned, 0)
        }
    }
    func options(workers: Int = 5, pages: Int = 0, perSite: Int = 0) -> GrabSettings {
        var value = settings(depth: 1, pages: pages, perSite: perSite)
        value.concurrentSites = workers
        return value
    }
    func testFiveDifferentWebsitesOverlapButSameWebsiteNeverDoes() {
        let tracker = RequestTracker()
        let sites = (1...7).map { "https://site\($0).org/" }
        var activity: [CrawlActivity] = []
        let engine = GrabEngine(settings: options(), fetcher: { tracker.fetch($0, barrier: 5) }, sleep: { _ in })
        let rows = engine.run(mode: .website, terms: sites + ["https://site1.org/contact"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false }, activity: { activity.append($0) })
        XCTAssertEqual(tracker.peak, 5)
        XCTAssertTrue(tracker.sitePeaks.values.allSatisfy { $0 == 1 })
        XCTAssertEqual(tracker.pages.count, 14)
        XCTAssertEqual(Set(tracker.pages).count, tracker.pages.count)
        XCTAssertEqual(rows.count, 7)
        XCTAssertTrue(activity.contains { $0.activeSites?.count == 5 && ($0.queuedPages?.count ?? 0) >= 2 })
        XCTAssertEqual(activity.last?.activeSites, [])
        XCTAssertEqual(activity.last?.queuedPages, [])
    }
    func testWorkerSettingAndPageBudgetsAreHonored() {
        for workers in [1,2,5] {
            let tracker = RequestTracker()
            let engine = GrabEngine(settings: options(workers: workers, pages: 3, perSite: 1), fetcher: { tracker.fetch($0) }, sleep: { _ in })
            _ = engine.run(mode: .website, terms: (1...8).map { "https://site\($0).org/" }, existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
            XCTAssertEqual(tracker.pages.count, 3)
            XCTAssertLessThanOrEqual(tracker.peak, workers)
            XCTAssertEqual(CrawlDisk.load()?.scanned, 3)
            XCTAssertEqual(CrawlDisk.load()?.settings.concurrentSites, workers)
            XCTAssertTrue(engine.hasRemainingPages)
        }
    }
    func testStopKeepsEveryUncommittedInFlightPageForRestart() {
        let control = CrawlControl()
        let engine = GrabEngine(settings: options(), fetcher: { url in
            if url.path == "/robots.txt" { return response("User-agent: *", url) }
            control.cancel()
            Thread.sleep(forTimeInterval: 0.02)
            return response("person@public.org", url)
        }, sleep: { _ in })
        let sites = (1...7).map { "https://site\($0).org/" }
        _ = engine.run(mode: .website, terms: sites, existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { control.checkpoint() })
        let saved = CrawlDisk.load()!
        XCTAssertEqual(saved.queue.count, 7)
        XCTAssertEqual(saved.scanned, 0)
        let tracker = RequestTracker()
        let resumed = GrabEngine(settings: options(perSite: 1), fetcher: { tracker.fetch($0) }, sleep: { _ in })
        resumed.restore(saved)
        let rows = resumed.run(mode: .website, terms: saved.selectedSites, existing: saved.rows, liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        XCTAssertEqual(rows.count, 7)
        XCTAssertEqual(Set(tracker.pages).count, 7)
    }
    func testOneReservationCoversWWWAndRootSiteAlias() {
        let pool = CrawlFetchPool()
        let latch = DispatchSemaphore(value: 0)
        let job = CrawlFetchPool.Job(url: URL(string: "https://www.public.org/")!, level: 0, host: "public.org")
        pool.start(job) { _ in latch.wait(); return CrawlFetchPool.Outcome(allowed: false, response: nil) }
        XCTAssertFalse(pool.canStart(CrawlFetchPool.Job(url: URL(string: "https://public.org/contact")!, level: 1, host: "public.org")))
        XCTAssertTrue(pool.canStart(CrawlFetchPool.Job(url: URL(string: "https://other.org/")!, level: 0, host: "other.org")))
        latch.signal(); pool.join()
    }
    func testPausePreventsNewWorkAndResumeCompletesQueue() {
        let control = CrawlControl()
        let lock = NSLock()
        let release = DispatchSemaphore(value: 0)
        let startedFive = expectation(description: "five websites started")
        let finishedFive = expectation(description: "five responses finished")
        let done = expectation(description: "crawl completed")
        var started = 0, finished = 0
        let engine = GrabEngine(settings: options(perSite: 1), fetcher: { url in
            if url.path == "/robots.txt" { return response("User-agent: *", url) }
            lock.lock(); started += 1; let number = started; lock.unlock()
            if number == 5 { startedFive.fulfill() }
            if number <= 5 { _ = release.wait(timeout: .now() + 4) }
            lock.lock(); finished += 1; let completed = finished; lock.unlock()
            if completed == 5 { finishedFive.fulfill() }
            return response("person@\(url.host!)", url)
        }, sleep: { _ in })
        defer { control.cancel(); for _ in 0..<10 { release.signal() } }
        DispatchQueue.global().async {
            _ = engine.run(mode: .website, terms: (1...10).map { "https://site\($0).org/" }, existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { control.checkpoint() })
            done.fulfill()
        }
        wait(for: [startedFive], timeout: 4)
        control.pause()
        for _ in 0..<5 { release.signal() }
        wait(for: [finishedFive], timeout: 4)
        lock.lock(); let pausedStarts = started; lock.unlock()
        XCTAssertEqual(pausedStarts, 5)
        control.resume()
        wait(for: [done], timeout: 4)
        lock.lock(); let finalStarts = started; lock.unlock()
        XCTAssertEqual(finalStarts, 10)
        XCTAssertEqual(CrawlDisk.load()?.scanned, 10)
    }
    func testHostGateCoversRedirectAliasesAndRejectsClosedLease() {
        let gate = CrawlRequestGate()
        let first = CrawlRequestGate.Lease(), second = CrawlRequestGate.Lease()
        let root = URL(string: "https://public.org/")!
        let www = URL(string: "https://www.public.org/contact")!
        XCTAssertTrue(gate.claim(root, owner: first, wait: false, cancelled: { false }))
        XCTAssertFalse(gate.claim(www, owner: second, wait: false, cancelled: { false }))
        XCTAssertTrue(gate.claim(www, owner: first, wait: false, cancelled: { false }))
        gate.release(first, delay: 0)
        XCTAssertFalse(gate.claim(root, owner: first, wait: false, cancelled: { false }))
        XCTAssertTrue(gate.claim(www, owner: second, wait: false, cancelled: { false }))
        gate.release(second, delay: 0)
    }
    func testHostGateRespectsDelayAndCancellation() {
        let gate = CrawlRequestGate(), owner = CrawlRequestGate.Lease()
        let url = URL(string: "https://public.org/")!
        XCTAssertTrue(gate.claim(url, owner: owner, wait: false, cancelled: { false }))
        gate.release(owner, delay: 0.03)
        let next = CrawlRequestGate.Lease()
        XCTAssertFalse(gate.claim(url, owner: next, wait: false, cancelled: { false }))
        let began = Date()
        XCTAssertTrue(gate.claim(url, owner: next, wait: true, cancelled: { false }))
        XCTAssertGreaterThanOrEqual(Date().timeIntervalSince(began), 0.025)
        XCTAssertFalse(gate.claim(url, owner: CrawlRequestGate.Lease(), wait: true, cancelled: { true }))
        gate.release(next, delay: 0)
    }
    func testOldCheckpointWithoutConcurrencyStillDecodes() throws {
        let engine = GrabEngine(settings: options(pages: 1), fetcher: { url in
            response(url.path == "/robots.txt" ? "User-agent: *" : "<a href='/contact'>Contact</a>", url)
        }, sleep: { _ in })
        _ = engine.run(mode: .website, terms: ["https://public.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false })
        let data = try JSONEncoder().encode(CrawlDisk.load()!)
        var object = try JSONSerialization.jsonObject(with: data) as! [String: Any]
        var settings = object["settings"] as! [String: Any]
        settings.removeValue(forKey: "concurrentSites"); object["settings"] = settings
        let legacy = try JSONDecoder().decode(CrawlProgress.self, from: JSONSerialization.data(withJSONObject: object))
        XCTAssertNil(legacy.settings.concurrentSites)
    }
    func testEveryDiscoveredPageIsVisibleInSharedQueueBeforeAssignment() {
        var events: [CrawlActivity] = []
        let deep = GrabSettings(depth: 3, maxPages: 0, maxPagesPerDomain: 0, exclude: "", duplicates: true, role: false, free: false, disposable: true, dns: false, concurrentSites: 5)
        let crawl = GrabEngine(settings: deep, fetcher: { url in
            if url.path == "/robots.txt" { return response("User-agent: *", url) }
            if url.path == "/" { return response("<a href='/contact'>Contact</a>", url) }
            if url.path == "/contact" { return response("<a href='/team-one'>Team one</a><a href='/team-two'>Team two</a>", url) }
            return response("person@public.org", url)
        }, sleep: { _ in })
        _ = crawl.run(mode: .website, terms: ["https://public.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false }, activity: { events.append($0) })
        XCTAssertTrue(events.contains { Set($0.queuedPages ?? []) == ["https://public.org/team-one","https://public.org/team-two"] })
        XCTAssertTrue(events.contains { $0.queuedPages == ["https://public.org/contact"] })
        for event in events where event.phase == "Queue" {
            XCTAssertTrue(Set(event.activeSites ?? []).isDisjoint(with: Set(event.queuedPages ?? [])))
            XCTAssertEqual(event.pending, event.queuedPages?.count)
            XCTAssertLessThanOrEqual(event.activeSites?.count ?? 0, 5)
        }
        XCTAssertEqual(CrawlDisk.load()?.scanned, 4)
    }
    func testBusyRedirectReturnsTargetToSharedQueueExactlyOnce() {
        let lock = NSLock()
        var contactFetches = 0
        var events: [CrawlActivity] = []
        let target = URL(string: "https://public.org/contact")!
        let engine = GrabEngine(settings: options(), fetcher: { url in
            if url.path == "/robots.txt" { return response("User-agent: *", url) }
            if url.host == "alias.org" { return HTTPResult(status: 302, finalURL: url, deferredURL: target) }
            if url.path == "/contact" {
                lock.lock(); contactFetches += 1; lock.unlock()
                return response("person@public.org", url)
            }
            return response("<a href='/contact'>Contact</a>", url)
        }, sleep: { _ in })
        let rows = engine.run(mode: .website, terms: ["https://alias.org/","https://public.org/"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false }, activity: { events.append($0) })
        XCTAssertEqual(contactFetches, 1)
        XCTAssertEqual(rows.map(\.address), ["person@public.org"])
        XCTAssertTrue(events.contains { ($0.queuedPages ?? []).contains(target.absoluteString) })
    }
    func testBlockedAndRobotsRestrictedWebsitesDoNotStopParallelWork() {
        var events: [CrawlActivity] = []
        let engine = GrabEngine(settings: options(perSite: 1), fetcher: { url in
            if url.path == "/robots.txt" {
                return response(url.host == "denied.org" ? "User-agent: *\nDisallow: /" : "User-agent: *", url)
            }
            return response("person@\(url.host!)", url, status: url.host == "blocked.org" ? 403 : 200)
        }, sleep: { _ in })
        let rows = engine.run(mode: .website, terms: ["denied.org","blocked.org","good1.org","good2.org","good3.org"], existing: [], liveRows: { _ in }, update: { _,_,_,_ in }, shouldStop: { false }, activity: { events.append($0) })
        XCTAssertEqual(rows.count, 3)
        XCTAssertEqual(events.filter { $0.phase == "Skipped" }.count, 2)
        XCTAssertEqual(CrawlDisk.load()?.scanned, 3)
        XCTAssertTrue(CrawlDisk.load()?.queue.isEmpty ?? false)
    }
    func testSettingClampsUnsafeValues() {
        XCTAssertEqual(options(workers: 0).workerLimit, 1)
        XCTAssertEqual(options(workers: 500).workerLimit, 8)
    }
}
