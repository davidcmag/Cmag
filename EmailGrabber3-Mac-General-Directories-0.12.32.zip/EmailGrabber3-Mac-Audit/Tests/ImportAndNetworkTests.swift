import XCTest
import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
@testable import EmailGrabberCore

final class WorkbookTests: XCTestCase {
    func fixture(_ name: String) -> URL {
        #if SWIFT_PACKAGE
        return Bundle.module.url(forResource: name, withExtension: "xlsx", subdirectory: "Fixtures")!
        #else
        return Bundle(for: Self.self).url(forResource: name, withExtension: "xlsx", subdirectory: "Fixtures")!
        #endif
    }
    func testRichTextRunsStayInSameEmailAddress() throws {
        let text = try FileImport.text(from: fixture("rich-text"))
        XCTAssertTrue(text.contains("jane@public.org")); XCTAssertTrue(text.contains("inline@public.org"))
    }
    func testExternalEntitiesAreRejected() { XCTAssertThrowsError(try FileImport.text(from: fixture("external-entity"))) }
    func testCompressedExpansionIsBounded() { XCTAssertThrowsError(try FileImport.text(from: fixture("over-limit"))) }
    func testOversizedInputRejectedBeforeReading() throws {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString+".csv")
        defer { try? FileManager.default.removeItem(at: url) }
        XCTAssertTrue(FileManager.default.createFile(atPath: url.path, contents: nil))
        let handle = try FileHandle(forWritingTo: url); try handle.truncate(atOffset: 65_000_000); try handle.close()
        XCTAssertThrowsError(try FileImport.text(from: url))
    }
}

private final class FixtureProtocol: URLProtocol, @unchecked Sendable {
    override class func canInit(with request: URLRequest) -> Bool { request.url?.host == "fixture.public.org" }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        let path = request.url!.path
        if path == "/hang" { return }
        if path == "/drip" {
            let response = HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: "HTTP/1.1", headerFields: ["Content-Type":"text/html"])!
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            let timer = DispatchSource.makeTimerSource()
            self.timer = timer
            timer.schedule(deadline: .now(), repeating: .milliseconds(15))
            timer.setEventHandler { [weak self] in
                guard let self = self else { return }
                self.client?.urlProtocol(self, didLoad: Data([65]))
            }
            timer.resume()
            return
        }
        let status = path == "/failed" ? 503 : 200
        let response = HTTPURLResponse(url: request.url!, statusCode: status, httpVersion: "HTTP/1.1", headerFields: ["Content-Type":"text/html"])!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: Data(repeating: 65, count: path == "/large" ? 4096 : 5))
        client?.urlProtocolDidFinishLoading(self)
    }
    private var timer: DispatchSourceTimer?
    override func stopLoading() { timer?.cancel(); timer = nil }
}

final class NativeTransportTests: XCTestCase {
    func testChildProcessCancellationDoesNotWaitForItsTimeout() {
        let began = ProcessInfo.processInfo.systemUptime
        XCTAssertThrowsError(try SafeProcess.run("/bin/sleep", ["5"], timeout: 10, cancelled: { ProcessInfo.processInfo.systemUptime - began > 0.05 })) {
            guard case SafeProcess.Failure.cancelled = $0 else { return XCTFail("Expected cancellation, got \($0)") }
        }
        XCTAssertLessThan(ProcessInfo.processInfo.systemUptime - began, 1.5)
    }
    func testRegexCanBeInterruptedBeforeItFindsAnyMatch() throws {
        let regex = try NSRegularExpression(pattern: #"<a\b((?:[^>"']|"[^"]*"|'[^']*')*)>(.*?)</a\s*>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
        let text = String(repeating: "<a href=unfinished ", count: 4000)
        let began = ProcessInfo.processInfo.systemUptime
        let matches = TextScan.matches(regex, in: text, cancelled: { ProcessInfo.processInfo.systemUptime - began > 0.04 })
        XCTAssertTrue(matches.isEmpty)
        XCTAssertLessThan(ProcessInfo.processInfo.systemUptime - began, 1)
    }
    func testPublishedNameScanCanCancelMalformedHTML() {
        let began = ProcessInfo.processInfo.systemUptime
        let names = SourcePersonMatcher.collect(String(repeating: "<a href=unfinished ", count: 4000), cancelled: { ProcessInfo.processInfo.systemUptime - began > 0.04 })
        XCTAssertTrue(names.isEmpty)
        XCTAssertLessThan(ProcessInfo.processInfo.systemUptime - began, 1)
    }
    func testBulkEntitiesStillDecodeWithoutChangingInvalidEntities() {
        XCTAssertEqual(EmailPolicy.decodeHTML(String(repeating: "&#65;&#x42;&amp;", count: 20_000)), String(repeating: "AB&", count: 20_000))
        XCTAssertEqual(EmailPolicy.decodeHTML("&#9999999999; &#xD800;"), "&#9999999999; &#xD800;")
    }
    func fetch(_ path: String, max: Int = 100, timeout: TimeInterval = 2, cancel: () -> Bool = { false }) -> HTTPResult {
        HTTPTransport.perform(URLRequest(url: URL(string: "https://fixture.public.org"+path)!), maxBytes: max, timeout: timeout, shouldCancel: cancel, protocolClasses: [FixtureProtocol.self])
    }
    func testStreamingResponseSucceeds() { let r = fetch("/"); XCTAssertTrue(r.succeeded); XCTAssertEqual(r.data?.count, 5) }
    func testHTTPFailureDoesNotBecomeSuccess() { let r = fetch("/failed"); XCTAssertFalse(r.succeeded); XCTAssertEqual(r.status, 503) }
    func testStreamingBodyLimitCancelsTransfer() { let r = fetch("/large"); XCTAssertFalse(r.succeeded); XCTAssertTrue(r.error?.contains("limit") == true); XCTAssertLessThanOrEqual(r.data?.count ?? 0, 100) }
    func testTimeoutReturnsWithoutWaitingForUnresponsiveRequest() {
        let begin = Date(); let r = fetch("/hang", timeout: 0.15)
        XCTAssertFalse(r.succeeded); XCTAssertLessThan(Date().timeIntervalSince(begin), 2)
    }
    func testCancellationReturnsWithoutCompletingRequest() { XCTAssertFalse(fetch("/hang", cancel: { true }).succeeded) }
    func testSlowContinuousBytesCannotExtendTotalDeadline() {
        let began = ProcessInfo.processInfo.systemUptime
        let result = fetch("/drip", max: 100_000, timeout: 0.22)
        XCTAssertTrue(result.retryable)
        XCTAssertTrue(result.error?.contains("timed out") == true)
        XCTAssertLessThan(ProcessInfo.processInfo.systemUptime - began, 1.5)
        XCTAssertTrue(fetch("/").succeeded, "Timed-out transfer must not block the reused session")
    }
    func testPausedControlDoesNotBlockNetworkDeadline() {
        let control = CrawlControl(); control.pause()
        let began = ProcessInfo.processInfo.systemUptime
        let result = fetch("/hang", timeout: 0.15, cancel: { control.wasCancelled })
        XCTAssertTrue(result.retryable)
        XCTAssertLessThan(ProcessInfo.processInfo.systemUptime - began, 1)
        control.resume()
    }
    func testStopCancelsPausedNetworkWithoutWaitingForDeadline() {
        let control = CrawlControl(); control.pause(); control.cancel()
        let began = ProcessInfo.processInfo.systemUptime
        let result = fetch("/hang", timeout: 10, cancel: { control.wasCancelled })
        XCTAssertEqual(result.error, "Cancelled")
        XCTAssertFalse(result.retryable)
        XCTAssertLessThan(ProcessInfo.processInfo.systemUptime - began, 1)
    }
    func testTransportReportsElapsedDownloadTime() {
        var elapsed: [Int] = []
        let result = HTTPTransport.perform(URLRequest(url: URL(string: "https://fixture.public.org/hang")!), timeout: 1.2, protocolClasses: [FixtureProtocol.self], progress: { elapsed.append($0) })
        XCTAssertTrue(result.retryable)
        XCTAssertEqual(elapsed, [0, 1])
    }
}

final class SharedSessionTests: XCTestCase {
    private final class Results: @unchecked Sendable {
        let lock = NSLock(); var successes = 0
        func add(_ result: HTTPResult) { lock.lock(); defer { lock.unlock() }; if result.succeeded && result.data?.count == 5 { successes += 1 } }
    }
    func testConcurrentTransfersDoNotCrossContaminateSharedSessionResults() {
        let values = Results()
        DispatchQueue.concurrentPerform(iterations: 12) { _ in
            let request = URLRequest(url: URL(string: "https://fixture.public.org/")!)
            values.add(HTTPTransport.perform(request, maxBytes: 100, timeout: 3, protocolClasses: [FixtureProtocol.self]))
        }
        XCTAssertEqual(values.successes, 12)
    }
}
