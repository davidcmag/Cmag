import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

final class GrabEngine {
    let settings: GrabSettings
    private struct CrawlState {
        var queue: [(URL, Int, String)]
        var queued: Set<String>
        var visited: Set<String>
        var robotRules: [String: [String]]
        var domainPageCount: [String: Int]
        var discoveredCount: Int
        var scanned: Int
    }
    private var savedState: CrawlState?
    private var archiveBeforeQueueRepair = false
    private var knownHosts = Set<String>()
    private var directoryProfiles = Set<String>()
    var hasRemainingPages: Bool { !(savedState?.queue.isEmpty ?? true) }
    private let injectedFetch: ((URL) -> HTTPResult)?
    private let assessDNS: ((String) -> DNSAssessment)?
    private let sleep: (TimeInterval) -> Void
    private let checkpointClock: () -> Date
    private let extractionTimeout: TimeInterval
    private var shouldCancel: () -> Bool = { false }
    private var policies: [String: RobotsPolicy] = [:]
    private var transientRobots: [String: String] = [:]
    private let policyLock = NSRecursiveLock()
    private let requestGate = CrawlRequestGate()
    private(set) var lastFailure: String?
    private(set) var deferredPageCount = 0
    private(set) var newAddressCount = 0
    private(set) var duplicateSkippedCount = 0
    private(set) var discoveryWarning: String?
    private let independentSearch: (String, () -> Bool) -> AdditionalSearchDiscovery.SearchResult
    init(settings: GrabSettings, fetcher: ((URL) -> HTTPResult)? = nil, dns: ((String) -> DNSAssessment)? = nil, sleep: @escaping (TimeInterval) -> Void = Thread.sleep(forTimeInterval:), search: @escaping (String, () -> Bool) -> AdditionalSearchDiscovery.SearchResult = { query, stop in AdditionalSearchDiscovery.searchResult(query, shouldStop: stop) }, checkpointClock: @escaping () -> Date = Date.init, extractionTimeout: TimeInterval = 10) {
        self.settings = settings; self.injectedFetch = fetcher; self.assessDNS = dns; self.sleep = sleep; self.independentSearch = search
        self.checkpointClock = checkpointClock; self.extractionTimeout = extractionTimeout
    }
    func restore(_ snapshot: CrawlProgress) {
        directoryProfiles = snapshot.directoryProfiles ?? []
        archiveBeforeQueueRepair = (snapshot.frontierPolicyVersion ?? 0) < 1
        knownHosts = snapshot.discoveredHosts ?? Set(snapshot.queue.map(\.host)).union(snapshot.domainPageCount.keys)
        savedState = CrawlState(queue: snapshot.queue.compactMap { item in
            guard let url = URL(string: item.url) else { return nil }; return (url, item.level, item.host)
        }, queued: snapshot.queued, visited: snapshot.visited, robotRules: snapshot.robotRules, domainPageCount: snapshot.domainPageCount, discoveredCount: snapshot.discoveredCount, scanned: snapshot.scanned)
    }

    private let emailPattern = #"(?i)(?<![\p{L}\p{N}._%+@\-])[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}(?![\p{L}\p{N}.@\-])"#
    private let roleNames = AddressClassification.roleNames
    private let freeDomains: Set<String> = ["gmail.com", "yahoo.com", "outlook.com", "hotmail.com", "aol.com", "icloud.com", "proton.me", "protonmail.com", "live.com"]
    private let disposableDomains: Set<String> = ["mailinator.com", "10minutemail.com", "guerrillamail.com", "tempmail.com", "yopmail.com", "trashmail.com"]

    func run(mode: SourceMode, terms: [String], existing: [FoundEmail], liveRows: ([FoundEmail]) -> Void, update: (Int, Int, Int, String) -> Void, shouldStop: @escaping () -> Bool, cancellationCheck: (() -> Bool)? = nil, activity: (CrawlActivity) -> Void = { _ in }) -> [FoundEmail] {
        deferredPageCount = 0; newAddressCount = 0; duplicateSkippedCount = 0
        policyLock.lock(); shouldCancel = cancellationCheck ?? shouldStop; lastFailure = nil; policies.removeAll(); transientRobots.removeAll(); policyLock.unlock()
        if mode == .pasted && hasRemainingPages {
            lastFailure = "Cannot parse different pasted input while continuing a saved crawl"
            update(savedState?.scanned ?? 0, savedState?.discoveredCount ?? 0, savedState?.domainPageCount.count ?? 0, lastFailure!)
            return existing
        }
        var rows = ClassificationEdits.inheriting(TechnicalAddressPolicy.reclassify(existing), from: [])
        let classificationDecisions = ClassificationEdits.decisions(in: rows)
        var seen = Set(existing.map { $0.address.lowercased() })
        var indicesByAddress: [String: [Int]] = [:]
        for index in rows.indices { indicesByAddress[rows[index].address.lowercased(), default: []].append(index) }
        let block = settings.exclude.split(whereSeparator: \.isNewline).map { $0.trimmingCharacters(in: .whitespaces).lowercased() }.filter { !$0.isEmpty }
        let exclusions = block.map { (literal: $0, wildcard: SafeWildcard.containsWildcard($0) ? SafeWildcard($0) : nil) }
        let regex = try! NSRegularExpression(pattern: emailPattern)
        var dnsCache: [String: DNSAssessment] = [:]

        @discardableResult func appendAddresses(_ text: String, source: String, publicationPage: HTTPResult? = nil) -> Bool {
            let observedAt = Date()
            let began = ProcessInfo.processInfo.systemUptime
            var stage = "Checking publication evidence"
            var lastSecond = -1
            func interrupted() -> Bool {
                if shouldCancel() { return true }
                let elapsed = ProcessInfo.processInfo.systemUptime - began
                if publicationPage != nil && elapsed >= extractionTimeout {
                    lastFailure = "Extraction time limit reached; current page and remaining queue retained for resume"
                    return true
                }
                let second = Int(elapsed)
                if publicationPage != nil && second != lastSecond {
                    lastSecond = second
                    activity(CrawlActivity(url: source, phase: "Extracting", pending: 0, message: "\(stage): \(second)s elapsed; \(Int(extractionTimeout))s extraction limit"))
                }
                return false
            }
            guard !interrupted() else { return false }
            let publications = publicationPage.map { WebsiteConfirmer.isChallenge(text) ? [:] : WebsitePublicationMatcher.collect(in: text, html: $0.mimeType != "text/plain", cancelled: interrupted) } ?? [:]
            guard !interrupted() else { return false }
            stage = "Checking published names"
            let personNames = publicationPage != nil && !WebsiteConfirmer.isChallenge(text) ? SourcePersonMatcher.collect(text, cancelled: interrupted) : [:]
            guard !interrupted() else { return false }
            func evidence(_ address: String) -> WebsiteConfirmation? {
                guard let page = publicationPage, publications[address] != nil else { return nil }
                let found = WebsiteConfirmer.observe(address: address, source: source, response: page, checkedAt: observedAt, decodedText: text, publications: publications, personAssociations: personNames, cancelled: interrupted)
                guard found.outcome == .published else { return nil }
                var proof = found
                proof.reason += " Recorded from the page already downloaded during discovery; no extra request."
                return proof
            }
            // Websites frequently serialize HTML in JSON with escaped angle
            // brackets (e.g. \\u003einfo@example.org). Decode these first so
            // the escape's 'u003e' does not become a fake mailbox prefix.
            var pending: [FoundEmail] = []; var lastLive = Date()
            func flush() { if !pending.isEmpty { liveRows(pending); pending.removeAll(keepingCapacity: true); lastLive = Date() } }
            stage = "Decoding contact text"
            let normalized = Self.normalizeEncodedText(text, cancelled: interrupted)
            guard !interrupted() else { return false }
            stage = "Finding email addresses"
            let matches = TextScan.matches(regex, in: normalized, cancelled: interrupted)
            guard !interrupted() else { return false }
            for match in matches {
                if interrupted() || shouldStop() { flush(); return false }
                guard let r = Range(match.range, in: normalized) else { continue }
                let address = String(normalized[r]).lowercased().trimmingCharacters(in: CharacterSet(charactersIn: ".,;:!?)"))
                guard address.utf8.count <= 254 else { continue }
                if settings.duplicates && seen.contains(address) {
                    duplicateSkippedCount += 1
                    if let proof = evidence(address) {
                        for index in indicesByAddress[address] ?? [] {
                            let previous = rows[index].websiteConfirmation
                            if previous?.outcome != .published || (previous?.organizationDomain != true && proof.organizationDomain == true) || (previous?.organizationDomain == proof.organizationDomain && proof.checkedAt > previous!.checkedAt) {
                                WebsiteConfirmationPolicy.apply(proof, to: &rows[index])
                            }
                        }
                    }
                    continue
                }
                seen.insert(address)
                let fields = address.split(separator: "@")
                guard fields.count == 2 else { continue }
                let local = String(fields[0]), domain = String(fields[1])
                // Web asset filenames often contain @2x / @3x (retina images),
                // which superficially resembles an email address. Never store
                // asset paths or filenames as email records, even as Uncertain.
                guard TechnicalAddressPolicy.rejectionReason(address) == nil else { continue }
                // Sentry DSN public keys, including Wix-hosted Sentry telemetry
                // are machine identifiers, not mailboxes. Reject *before* DNS
                // checks and before adding rows to the live results table.
                var reason = "Syntax valid; mailbox not independently confirmed"
                var status = "Accepted"
                if !EmailPolicy.validSyntax(address) {
                    status = "Rejected"; reason = "Invalid address format"
                } else if Self.isPlaceholder(address: address, domain: domain) {
                    status = "Excluded"; reason = "Placeholder or example email address"
                } else if exclusions.contains(where: { $0.wildcard?.matches(address) ?? (address.contains($0.literal) || domain == $0.literal) }) {
                    status = "Excluded"; reason = "Matched exclusion rule"
                } else if settings.role && roleNames.contains(local) {
                    status = "Excluded"; reason = "Role-based mailbox"
                } else if settings.free && freeDomains.contains(domain) {
                    status = "Excluded"; reason = "Free email provider"
                } else if settings.disposable && disposableDomains.contains(domain) {
                    status = "Excluded"; reason = "Known disposable domain (starter list)"
                } else if settings.dns {
                    let assessment: DNSAssessment
                    if let cached = dnsCache[domain] { assessment = cached }
                    else {
                        stage = "Checking DNS for " + domain
                        assessment = assessDNS?(domain) ?? DNSChecker.check(domain, cancelled: interrupted)
                        if interrupted() { flush(); return false }
                        dnsCache[domain] = assessment
                        stage = "Finding email addresses"
                    }
                    status = (assessment == .mx || assessment == .fallback) ? "Accepted" : "Uncertain"
                    reason = assessment.reason
                }
                var row = FoundEmail(address: address, source: source, status: status, reason: reason)
                if let proof = evidence(address) { WebsiteConfirmationPolicy.apply(proof, to: &row) }
                indicesByAddress[address, default: []].append(rows.count)
                row.classificationDecision = classificationDecisions[address.lowercased()]
                rows.append(row); pending.append(row); newAddressCount += 1
                if pending.count >= 25 || Date().timeIntervalSince(lastLive) >= 0.25 { flush() }
            }
            flush(); return true
        }

        if mode == .pasted {
            appendAddresses(terms.joined(separator: "\n"), source: "Pasted / imported input")
            update(0, 0, 0, "Parsed imported text")
            return rows
        }

        var seeds: [URL] = []
        if savedState == nil && mode == .website {
            seeds = terms.compactMap { Self.normalizedURL($0) }
        } else if savedState == nil {
            seeds = discoverSites(terms: terms, exploreDirectories: false, nationwide: true, shouldStop: shouldStop, progress: { _ in }).compactMap { URL(string: $0.url) }
        }
        var visited = savedState?.visited ?? Set<String>()
        var queued = savedState?.queued ?? Set<String>()
        let robotRules: [String: [String]] = [:]
        var domainPageCount: [String: Int] = savedState?.domainPageCount ?? [:]
        var queue: [(URL, Int, String)] = savedState?.queue ?? []
        // Seed one page per discovered host first, so the global page budget
        // reaches distinct businesses before exploring deep within a site.
        var seedsByHost: [String: [URL]] = [:]
        var uniqueSeeds = Set<String>()
        for url in seeds {
            guard let host = url.host?.lowercased(), !host.isEmpty else { continue }
            if let reason = LinkRelevance.crawlTrapReason(url) {
                activity(CrawlActivity(url: url.absoluteString, phase: "Skipped", pending: queue.count, message: reason))
                continue
            }
            let canonical = host.hasPrefix("www.") ? String(host.dropFirst(4)) : host
            if uniqueSeeds.insert(url.absoluteString).inserted { seedsByHost[canonical, default: []].append(url) }
        }
        if savedState == nil { knownHosts.removeAll() }
        knownHosts.formUnion(seedsByHost.keys)
        var discoveredCount = savedState?.discoveredCount ?? knownHosts.count
        for (host, links) in seedsByHost.sorted(by: { $0.key < $1.key }) {
            if let first = links.first { queue.append((first, 0, host)); queued.insert(first.absoluteString) }
        }
        for (host, links) in seedsByHost.sorted(by: { $0.key < $1.key }) {
            for extra in links.dropFirst() {
                if queued.insert(extra.absoluteString).inserted { queue.append((extra, 0, host)) }
            }
        }
        var count = savedState?.scanned ?? 0
        let selectedKeys = Set(terms.compactMap { Self.normalizedURL($0).flatMap(LinkRelevance.canonical)?.absoluteString })
        if savedState != nil {
            if archiveBeforeQueueRepair {
                activity(CrawlActivity(url: "", phase: "Preserving queue", pending: queue.count, message: "Archiving original checkpoint before queue cleanup"))
                guard CrawlDisk.archiveQueueBeforeRepair() else {
                    lastFailure = CrawlDisk.lastError
                    update(count, discoveredCount, domainPageCount.count, lastFailure ?? "Could not preserve the original queue")
                    return rows
                }
                archiveBeforeQueueRepair = false
            }
            let previousCount = queue.count
            let normalizedVisited = visited.compactMap { URL(string: $0).flatMap(LinkRelevance.canonical)?.absoluteString }
            visited.formUnion(normalizedVisited)
            var unique = Set<String>()
            queue = queue.compactMap { item in
                guard LinkRelevance.crawlTrapReason(item.0) == nil,
                      let url = LinkRelevance.canonical(item.0),
                      !visited.contains(url.absoluteString) else { return nil }
                if settings.depth == 0, !selectedKeys.contains(url.absoluteString), LinkRelevance.priority(CrawlLink(url: url, label: "", nofollow: false)) < 0 { return nil }
                guard unique.insert(url.absoluteString).inserted else { return nil }
                return (url, item.1, item.2)
            }
            queued = visited.union(unique)
            if previousCount != queue.count {
                update(count, discoveredCount, domainPageCount.count, "Queue cleanup: removed \(previousCount - queue.count) out-of-scope or duplicate URLs; \(queue.count) remain. Saved records retained.")
            }
        }
        // The working frontier now owns all pending work. Release the restored
        // pre-cleanup arrays instead of retaining a second huge queue all run.
        savedState = nil
        let batchEnd = settings.maxPages == 0 ? Int.max : (count > Int.max - settings.maxPages ? Int.max : count + settings.maxPages)
        let topicWords = LinkRelevance.topicWords(settings.topic)
        let pool = CrawlFetchPool()
        var ready: [(CrawlFetchPool.Job, CrawlFetchPool.Outcome)] = []
        // Retry transient failures on the next explicit resume, never in a tight
        // loop. They remain pending and durable while other websites continue.
        var deferredPages: [(URL, Int, String)] = []
        var frontierDirty = true
        var needsQueuePrune = true
        var lastCheckpoint: Date?
        var checkpointPages = count
        func persistProgress(force: Bool = false) -> Bool {
            guard frontierDirty else { return true }
            // Large frontiers are expensive to serialize. A previous durable
            // ancestor remains replayable until this batch is committed.
            if !force, queue.count > 5000, let previous = lastCheckpoint,
               count - checkpointPages < 10, checkpointClock().timeIntervalSince(previous) < 5 { return true }
            activity(CrawlActivity(url: "", phase: "Saving progress", pending: max(0, queue.count + deferredPages.count - pool.count), message: "Saving results and pending pages"))
            let pending = deferredPages.isEmpty ? queue : queue + deferredPages
            guard checkpoint(queue: pending, queued: queued, visited: visited, robotRules: robotRules, domainPageCount: domainPageCount, discoveredCount: discoveredCount, count: count, rows: rows, terms: terms) else {
                lastFailure = "Could not save crawl checkpoint: " + (CrawlDisk.lastError ?? "unknown error")
                return false
            }
            lastCheckpoint = checkpointClock(); checkpointPages = count; frontierDirty = false
            return true
        }
        func publishQueue(processing: String? = nil) {
            var active = pool.jobs.values.map { $0.url.absoluteString }
            if let current = processing { active.append(current) }
            active.sort()
            let reserved = Set(active)
            var waiting = Array(queue.lazy.map { $0.0.absoluteString }.filter { !reserved.contains($0) }.prefix(LinkRelevance.queuePreviewLimit))
            if waiting.count < LinkRelevance.queuePreviewLimit {
                waiting.append(contentsOf: deferredPages.lazy.map { $0.0.absoluteString }.prefix(LinkRelevance.queuePreviewLimit - waiting.count))
            }
            activity(CrawlActivity(url: "", phase: "Queue", pending: max(0, queue.count + deferredPages.count - pool.count), message: "", activeSites: active, queuedPages: waiting))
        }
        defer { pool.join() }
        func processNextPage() -> Bool {
            // Small frontiers commit each page. Large ones can replay a durable
            // ancestor until their bounded batch is committed or stopped.
            if frontierDirty {
                if !persistProgress() { return true }
            }
            var prefetched: CrawlFetchPool.Outcome?
            let url: URL, level: Int, rootHost: String
            if settings.workerLimit > 1 {
                if needsQueuePrune {
                    let oldCount = queue.count
                    queue.removeAll { item in
                        visited.contains(item.0.absoluteString) ||
                        (settings.maxPagesPerDomain > 0 && domainPageCount[item.2, default: 0] >= settings.maxPagesPerDomain)
                    }
                    if queue.count != oldCount { frontierDirty = true }
                    needsQueuePrune = false
                }
                let beforeLaunch = pool.count
                while pool.count < settings.workerLimit && pool.count < batchEnd - count {
                    guard let item = queue.first(where: { item in
                        let job = CrawlFetchPool.Job(url: item.0, level: item.1, host: item.2)
                        return pool.jobs[job.key] == nil && pool.canStart(job)
                    }) else { break }
                    let job = CrawlFetchPool.Job(url: item.0, level: item.1, host: item.2)
                    let pending = max(0, queue.count - pool.count - 1)
                    pool.start(job) { emit in
                        emit(CrawlActivity(url: job.key, phase: "Checking robots", pending: pending, message: "Checking access rules"))
                        guard self.allowedByRobots(job.url) else {
                            let failure = self.robotsTemporaryFailure(job.url)
                            return CrawlFetchPool.Outcome(allowed: failure != nil, response: failure.map { HTTPResult(error: $0, retryable: true) })
                        }
                        return CrawlFetchPool.Outcome(allowed: true, response: self.fetchResponse(job.url, checkRobots: true, report: { phase, message in
                            emit(CrawlActivity(url: job.key, phase: phase, pending: pending, message: message))
                        }))
                    }
                }
                if pool.count != beforeLaunch || frontierDirty {
                    publishQueue()
                }
                for message in pool.receive(wait: ready.isEmpty) {
                    switch message {
                    case .activity(let event): activity(event)
                    case .finished(let job, let outcome): ready.append((job, outcome))
                    }
                }
                guard !shouldStop() else { return true }
                if ready.isEmpty {
                    if pool.count == 0 { return true }
                    return false
                }
                let (job, outcome) = ready.removeFirst()
                pool.release(job)
                guard let index = queue.firstIndex(where: { $0.0.absoluteString == job.key }) else { return false }
                queue.remove(at: index)
                url = job.url; level = job.level; rootHost = job.host; prefetched = outcome
            } else {
                (url, level, rootHost) = queue.removeFirst()
            }
            frontierDirty = true; needsQueuePrune = true
            let key = url.absoluteString
            publishQueue(processing: key)
            guard !visited.contains(key) else { return false }
            visited.insert(key)
            if settings.maxPagesPerDomain > 0 && domainPageCount[rootHost, default: 0] >= settings.maxPagesPerDomain { return false }
            guard let host = url.host?.lowercased() else { return false }
            if prefetched == nil { activity(CrawlActivity(url: key, phase: "Checking robots", pending: queue.count, message: "Checking access rules")) }
            guard prefetched?.allowed ?? allowedByRobots(url) else {
                if shouldStop() { visited.remove(key); queue.insert((url, level, rootHost), at: 0); return true }
                if let robotsFailure = robotsTemporaryFailure(url) {
                    visited.remove(key); deferredPages.append((url, level, rootHost)); deferredPageCount += 1
                    activity(CrawlActivity(url: key, phase: "Deferred", pending: queue.count + deferredPages.count, message: robotsFailure + "; page retained for next resume"))
                    publishQueue()
                    return false
                }
                activity(CrawlActivity(url: key, phase: "Skipped", pending: queue.count, message: "Robots denied access or could not be checked"))
                update(count, discoveredCount, domainPageCount.count, "Skipped \(host): robots.txt denied access or could not be checked")
                publishQueue()
                return false
            }
            if prefetched == nil { activity(CrawlActivity(url: key, phase: "Fetching", pending: queue.count, message: "Downloading page")) }
            let response = prefetched?.response ?? fetchResponse(url, checkRobots: true, report: { phase, message in
                activity(CrawlActivity(url: key, phase: phase, pending: queue.count + deferredPages.count, message: message))
            })
            guard response.succeeded, let html = response.decodedText else {
                if shouldStop() { visited.remove(key); queue.insert((url, level, rootHost), at: 0); return true }
                if response.retryable {
                    visited.remove(key)
                    deferredPages.append((url, level, rootHost)); deferredPageCount += 1
                    activity(CrawlActivity(url: key, phase: "Deferred", pending: queue.count + deferredPages.count, message: (response.error ?? "Temporary network failure") + "; page retained for next resume"))
                    update(count, discoveredCount, domainPageCount.count, "Page deferred; continuing other websites. \(deferredPages.count) pages retained for next resume.")
                    publishQueue()
                    return false
                }
                if let target = response.deferredURL, let canonical = LinkRelevance.canonical(target), !visited.contains(canonical.absoluteString), queued.insert(canonical.absoluteString).inserted {
                    let host = EmailPolicy.canonicalHost(canonical.host ?? rootHost)
                    queue.append((canonical, level, host))
                    if knownHosts.insert(host).inserted { discoveredCount += 1 }
                }
                let message = response.deferredURL != nil ? "Redirect destination busy; target queued once" : (response.status.map { "HTTP \($0)" } ?? response.error ?? "Unsupported page encoding")
                activity(CrawlActivity(url: key, phase: "Skipped", pending: queue.count, message: message))
                update(count, discoveredCount, domainPageCount.count, "Skipped \(host): \(message); continuing other websites")
                publishQueue()
                return false
            }
            let sourceURL = response.finalURL ?? url
            activity(CrawlActivity(url: sourceURL.absoluteString, phase: "Extracting", pending: queue.count, message: "Extracting and locally checking addresses", requestURL: key))
            guard appendAddresses(html, source: sourceURL.absoluteString, publicationPage: response) else { visited.remove(key); queue.insert((url, level, rootHost), at: 0); return true }
            let unlimitedAdaptive = settings.depth == 0 && settings.followExternalLinks
            let followInternal = level < settings.depth || (settings.depth == 0 && (unlimitedAdaptive || level < 20))
            let linkDeadline = ProcessInfo.processInfo.systemUptime + extractionTimeout
            func stopLinks() -> Bool { shouldCancel() || ProcessInfo.processInfo.systemUptime >= linkDeadline }
            activity(CrawlActivity(url: key, phase: "Extracting", pending: queue.count, message: "Finding contact and directory links"))
            let parsedLinks = LinkRelevance.links(html, base: sourceURL, cancelled: stopLinks)
            let entryURLs = LinkRelevance.directoryEntries(parsedLinks, from: sourceURL)
            func linkPriority(_ link: CrawlLink) -> Int { LinkRelevance.priority(link, from: sourceURL, directoryEntry: entryURLs.contains(link.url.absoluteString)) }
            var candidates = parsedLinks.map { ($0, linkPriority($0)) }.sorted { $0.1 > $1.1 }.map { $0.0 }
            if !settings.followExternalLinks { candidates = Array(candidates.prefix(200)) }
            let scope = EmailPolicy.canonicalHost(sourceURL.host ?? rootHost)
            var linksQueued = 0
            for candidate in candidates {
                if stopLinks() { break }
                let link = candidate.url
                let hostname = EmailPolicy.canonicalHost(link.host ?? "")
                let internalLink = hostname == scope || hostname.hasSuffix("." + scope)
                if candidate.nofollow { continue }
                if LinkRelevance.crawlTrapReason(link) != nil { continue }
                if settings.depth == 0 && linkPriority(candidate) < 0 { continue }
                let path = link.path.lowercased()
                if [".jpg", ".jpeg", ".png", ".gif", ".zip", ".pdf", ".mp4", ".svg", ".css", ".js", ".woff", ".woff2"].contains(where: path.hasSuffix) { continue }
                if internalLink {
                    guard followInternal else { continue }
                    if settings.depth == 0 && linkPriority(candidate) <= 0 { continue }
                } else {
                    guard settings.followExternalLinks, LinkRelevance.relevant(candidate, from: sourceURL, topicWords: topicWords, directoryProfile: directoryProfiles.contains(key)) else { continue }
                }
                if internalLink && entryURLs.contains(link.absoluteString) &&
                    (topicWords.isEmpty || !LinkRelevance.tokens(sourceURL.absoluteString + " " + candidate.label + " " + link.absoluteString).isDisjoint(with: topicWords)) {
                    directoryProfiles.insert(link.absoluteString)
                }
                if queued.insert(link.absoluteString).inserted {
                    linksQueued += 1
                    let nextHost = internalLink ? rootHost : hostname
                    queue.append((link, internalLink ? level + 1 : 0, nextHost))
                    if !internalLink && knownHosts.insert(nextHost).inserted { discoveredCount += 1 }
                }
            }
            if stopLinks() {
                visited.remove(key); queue.insert((url, level, rootHost), at: 0)
                if !shouldCancel() { lastFailure = "Link extraction time limit reached; page and pending queue retained for resume" }
                return true
            }
            directoryProfiles.remove(key)
            count += 1
            domainPageCount[rootHost, default: 0] += 1
            update(count, discoveredCount, domainPageCount.count, "Scanned \(count) pages on \(domainPageCount.count) sites; \(newAddressCount) added to saved; \(duplicateSkippedCount) duplicates skipped; \(rows.count) total saved")
            if !persistProgress() { return true }
            activity(CrawlActivity(url: sourceURL.absoluteString, phase: "Completed", pending: queue.count, message: "Page scanned; \(candidates.count) links considered; \(linksQueued) new pages queued", requestURL: key))
            publishQueue()
            if injectedFetch != nil { sleep(max(0.3, policy(for: sourceURL).delay)) }
            return false
        }
        while !queue.isEmpty && count < batchEnd && !shouldStop() {
            if CrawlMemoryScope.perform({ processNextPage() }) { break }
        }
        pool.join()
        queue.append(contentsOf: deferredPages)
        deferredPages.removeAll()
        savedState = CrawlState(queue: queue, queued: queued, visited: visited, robotRules: robotRules, domainPageCount: domainPageCount, discoveredCount: discoveredCount, scanned: count)
        if frontierDirty { _ = persistProgress(force: true) }
        activity(CrawlActivity(url: "", phase: "Idle", pending: queue.count, message: lastFailure ?? (queue.isEmpty ? "No eligible links remain" : "Remaining pages saved"), activeSites: [], queuedPages: queue.prefix(LinkRelevance.queuePreviewLimit).map { $0.0.absoluteString }))
        update(count, discoveredCount, domainPageCount.count, lastFailure ?? (queue.isEmpty ? "Finished: \(count) pages across \(domainPageCount.count) websites; \(rows.count) records." : "Batch finished at \(count) pages; \(queue.count) links remain in queue."))
        return rows
    }

    @discardableResult private func checkpoint(queue: [(URL, Int, String)], queued: Set<String>, visited: Set<String>, robotRules: [String: [String]], domainPageCount: [String: Int], discoveredCount: Int, count: Int, rows: [FoundEmail], terms: [String]) -> Bool {
        let options = CrawlOptions(depth: settings.depth, maxPages: settings.maxPages, maxPagesPerDomain: settings.maxPagesPerDomain, excluded: settings.exclude, stripDuplicates: settings.duplicates, excludeRole: settings.role, excludeFree: settings.free, excludeDisposable: settings.disposable, checkDNS: settings.dns, followExternalLinks: settings.followExternalLinks, topic: settings.topic, concurrentSites: settings.workerLimit)
        return CrawlDisk.save(CrawlProgress(queue: queue.map { CrawlProgress.Link(url: $0.0.absoluteString, level: $0.1, host: $0.2) }, visited: visited, queued: queued, robotRules: robotRules, discoveredHosts: knownHosts, domainPageCount: domainPageCount, discoveredCount: discoveredCount, scanned: count, rows: rows, selectedSites: terms, settings: options, input: terms.joined(separator: "\n"), directoryProfiles: directoryProfiles))
    }

    func discoverSites(terms: [String], exploreDirectories: Bool, nationwide: Bool, shouldStop: @escaping () -> Bool, progress: (String) -> Void) -> [DiscoveredSite] {
        shouldCancel = shouldStop; discoveryWarning = nil
        func warn(_ text: String) { discoveryWarning = [discoveryWarning, text].compactMap { $0 }.joined(separator: "; "); progress(text) }
        var candidates: [DiscoveredSite] = []
        var knownHosts = Set<String>()
        var candidateIndices: [String: Int] = [:]
        func add(_ url: URL, origin: String) {
            guard LinkRelevance.crawlTrapReason(url) == nil else { return }
            guard EmailPolicy.httpURL(url),
                  let rawHost = url.host?.lowercased() else { return }
            let host = rawHost.hasPrefix("www.") ? String(rawHost.dropFirst(4)) : rawHost
            if knownHosts.insert(host).inserted && candidates.count < 3000 {
                candidateIndices[host] = candidates.count
                candidates.append(DiscoveredSite(url: url.absoluteString, origin: origin))
            } else if let index = candidateIndices[host], AdditionalSearchDiscovery.candidatePriority(url) > AdditionalSearchDiscovery.candidatePriority(URL(string: candidates[index].url)!) {
                candidates[index] = DiscoveredSite(url: url.absoluteString, origin: origin)
            }
        }
        var queries = AdditionalSearchDiscovery.peopleQueries(terms)
        for term in terms.prefix(5) {
            queries.append(term)
            queries.append("\(term) contact")
            if nationwide {
                // A broad search only exposes a tiny slice of the web. Search
                // distinct geographic partitions to reach independent sites.
                for state in USStates.all {
                    queries.append("\(term) \(state.name)")
                }
                for metro in ["New York City", "Los Angeles", "Chicago", "Houston", "Phoenix", "Philadelphia", "San Antonio", "San Diego", "Dallas", "Jacksonville", "Fort Worth", "Columbus Ohio", "Indianapolis", "Charlotte", "Washington DC", "Nashville", "Oklahoma City", "El Paso", "Detroit", "Memphis", "Louisville", "Baltimore", "Boston", "Seattle", "Denver", "Atlanta", "Miami", "Portland Oregon", "Las Vegas", "New Orleans"] {
                    queries.append("\(term) \(metro)")
                }
            } else {
                queries.append("\(term) website")
                queries.append("\(term) contact email")
            }
        }
        // Independent discovery source: merge candidates with the RSS provider.
        // Bound public HTML requests so a broad nationwide run stays polite.
        let independentQueries = Array(queries.prefix(nationwide ? 12 : 3))
        for (index, query) in independentQueries.enumerated() {
            if shouldStop() { break }
            let independent = independentSearch(query, shouldStop)
            if let code = independent.status, [403,429,503].contains(code) { warn("DuckDuckGo unavailable/rate-limited (HTTP \(code)); skipping remaining requests to that provider"); break }
            for site in independent.urls {
                add(site, origin: "Independent web search")
            }
            progress("Independent discovery \(index + 1)/\(independentQueries.count): \(candidates.count) websites")
            sleep(1.0)
        }
                let rssPattern = #"<link>\s*(https?://[^<]+)</link>"#
        let regex = try? NSRegularExpression(pattern: rssPattern, options: [.caseInsensitive])
        let excludedSearchHosts = ["facebook.com", "instagram.com", "linkedin.com", "twitter.com", "x.com", "youtube.com", "google.com", "bing.com", "yelp.com"]
        for (index, query) in queries.enumerated() {
            if shouldStop() { break }
            defer { sleep(0.3) }
            guard let url = EmailPolicy.searchURL(query) else { continue }
            let response = fetchResponse(url)
            if let code = response.status, [403,429,503].contains(code) { warn("Bing unavailable/rate-limited (HTTP \(code)); skipping remaining requests to that provider"); break }
            guard response.succeeded, let data = response.data, let xml = String(data: data, encoding: .utf8), let regex = regex else { continue }
            let ns = NSRange(xml.startIndex..<xml.endIndex, in: xml)
            for match in regex.matches(in: xml, range: ns).prefix(35) {
                guard let range = Range(match.range(at: 1), in: xml),
                      let site = URL(string: String(xml[range]).replacingOccurrences(of: "&amp;", with: "&")) else { continue }
                guard let host = site.host?.lowercased(), !excludedSearchHosts.contains(where: { host == $0 || host.hasSuffix("." + $0) }) else { continue }
                add(site, origin: "Search")
            }
            progress("Discovery query \(index + 1)/\(queries.count): \(candidates.count) websites")
            if candidates.count >= 3000 { break }

        }
        if exploreDirectories {
            let directoryCandidates = candidates.filter { candidate in
                let host = candidate.host.lowercased()
                return ["directory", "directories", "listing", "association", "chamber"].contains(where: host.contains)
            }
            let excludedHosts = ["facebook.com", "instagram.com", "linkedin.com", "twitter.com", "x.com", "youtube.com", "google.com", "bing.com", "yelp.com", "maps.google.com"]
            for directory in directoryCandidates.prefix(8) {
                if shouldStop() { break }
                guard let url = URL(string: directory.url) else { continue }
                if !allowedByRobots(url) { continue }
                guard let data = fetch(url), let html = String(data: data, encoding: .utf8) else { continue }
                var added = 0
                for link in Self.links(html, base: url) {
                    guard let host = link.host?.lowercased(), host != url.host?.lowercased() else { continue }
                    if excludedHosts.contains(where: { host == $0 || host.hasSuffix("." + $0) }) { continue }
                    let prior = candidates.count
                    add(link, origin: "Directory: \(directory.host)")
                    if candidates.count > prior { added += 1 }
                    if added >= 100 || candidates.count >= 3000 { break }
                }
                progress("Explored directory \(directory.host): \(candidates.count) websites")
                sleep(0.3)
            }
        }
        return candidates.enumerated().sorted { a, b in
            let first = AdditionalSearchDiscovery.candidatePriority(URL(string: a.element.url)!)
            let second = AdditionalSearchDiscovery.candidatePriority(URL(string: b.element.url)!)
            return first == second ? a.offset < b.offset : first > second
        }.map(\.element)
    }

    private static func isPlaceholder(address: String, domain: String) -> Bool {
        let placeholders: Set<String> = ["example.com", "example.org", "example.net", "yourdomain.com", "yoursite.com", "placeholder.com"]
        if placeholders.contains(where: { domain == $0 || domain.hasSuffix("." + $0) }) { return true }
        return ["name@domain.tld", "email@domain.tld", "name@domain.com", "email@domain.com"].contains(address)
    }

    private static func normalizeEncodedText(_ text: String, cancelled: () -> Bool = { false }) -> String {
        let replacements: [(String, String)] = [
            (#"\u003c"#, "<"), (#"\u003e"#, ">"),
            (#"\u0040"#, "@"), (#"\u002e"#, "."),
            (#"\u0026"#, "&"),
            ("&lt;", "<"), ("&gt;", ">"),
            ("&#60;", "<"), ("&#62;", ">"),
            ("&#64;", "@"), ("&#x40;", "@")
        ]
        var output = text
        for (encoded, decoded) in replacements {
            if cancelled() { return text }
            output = output.replacingOccurrences(of: encoded, with: decoded, options: [.caseInsensitive])
        }
        // Common deliberate obfuscations on contact pages. Only bracketed
        // tokens are changed, not ordinary occurrences of 'at' or 'dot'.
        output = TextScan.replacing(try! NSRegularExpression(pattern: #"(?i)\s*(?:\[at\]|\(at\))\s*"#), in: output, with: "@", cancelled: cancelled)
        output = TextScan.replacing(try! NSRegularExpression(pattern: #"(?i)\s*(?:\[dot\]|\(dot\))\s*"#), in: output, with: ".", cancelled: cancelled)
        output = EmailPolicy.decodeHTML(output, cancelled: cancelled)
        if let regex = try? NSRegularExpression(pattern: #"(?i)mailto:([^\s"'<>?]+)"#) {
            output = TextScan.transform(regex, in: output, cancelled: cancelled) { match, source in
                let full = source.substring(with: match.range)
                let raw = source.substring(with: match.range(at: 1))
                guard let decoded = raw.removingPercentEncoding else { return full }
                return "mailto:" + decoded
            }
        }
        return output
    }

    static func normalizedURL(_ string: String) -> URL? {
        let cleaned = string.trimmingCharacters(in: .whitespacesAndNewlines)
        let withScheme = cleaned.contains("://") ? cleaned : "https://" + cleaned
        guard let u = URL(string: withScheme), EmailPolicy.httpURL(u) else { return nil }
        var components = URLComponents(url: u, resolvingAgainstBaseURL: false); components?.fragment = nil
        if components?.path.isEmpty == true { components?.path = "/" }
        return components?.url
    }

    private func fetchResponse(_ url: URL, checkRobots: Bool = false, report: (String, String) -> Void = { _,_ in }) -> HTTPResult {
        guard EmailPolicy.httpURL(url) else { return HTTPResult(error: "Invalid HTTP destination") }
        if let fetcher = injectedFetch { return fetcher(url) }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 12)
        request.setValue("EmailGrabber3/1.0 (local user-initiated contact discovery)", forHTTPHeaderField: "User-Agent")
        let gated = checkRobots
        let owner = CrawlRequestGate.Lease()
        if gated && !requestGate.claim(url, owner: owner, wait: true, cancelled: shouldCancel, progress: { seconds in
            report("Waiting for website", "Respecting website crawl delay / active request: \(seconds)s elapsed; 30s wait limit")
        }) {
            let cancelled = shouldCancel()
            return HTTPResult(error: cancelled ? "Cancelled" : "Website wait limit reached", retryable: !cancelled)
        }
        report("Fetching", "Downloading page: 0s elapsed; 15s total download limit")
        let deferredLock = NSLock()
        var deferred: URL?
        var redirectRobotsUnavailable = false
        var result = HTTPTransport.perform(request, shouldCancel: shouldCancel, progress: { seconds in
            report("Fetching", "Downloading page: \(seconds)s elapsed; 15s total download limit")
        }, redirect: { [weak self] target in
            guard let self = self, EmailPolicy.httpURL(target) else { return false }
            if gated && !self.requestGate.claim(target, owner: owner, wait: false, cancelled: self.shouldCancel) {
                deferredLock.lock(); deferred = target; deferredLock.unlock()
                return false
            }
            guard checkRobots else { return true }
            let allowed = self.allowedByRobots(target)
            if !allowed && self.robotsTemporaryFailure(target) != nil {
                deferredLock.lock(); redirectRobotsUnavailable = true; deferredLock.unlock()
            }
            return allowed
        })
        deferredLock.lock()
        result.deferredURL = deferred
        if redirectRobotsUnavailable { result.retryable = true; result.error = "Redirect robots request timed out" }
        deferredLock.unlock()
        if gated {
            let delay = max(0.3, policy(for: url).delay, result.finalURL.map { policy(for: $0).delay } ?? 0)
            requestGate.release(owner, delay: delay)
        }
        return result
    }
    private func fetch(_ url: URL) -> Data? { let result = fetchResponse(url); return result.succeeded ? result.data : nil }
    private func policy(for url: URL) -> RobotsPolicy {
        guard var c = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return .denyAll }
        c.path = "/robots.txt"; c.query = nil; c.fragment = nil
        guard let robotsURL = c.url else { return .denyAll }
        let key = robotsURL.absoluteString
        policyLock.lock(); let cached = policies[key]; policyLock.unlock()
        if let value = cached { return value }
        let began = ProcessInfo.processInfo.systemUptime
        let result = fetchResponse(robotsURL)
        let elapsed = ProcessInfo.processInfo.systemUptime - began
        let value: RobotsPolicy
        if result.status == 404 || result.status == 410 { value = RobotsPolicy() }
        else if result.succeeded, let data = result.data, let text = String(data: data, encoding: .utf8) { value = RobotsPolicy(text) }
        else { value = .denyAll }
        policyLock.lock()
        policies[key] = value
        if !(result.status == 404 || result.status == 410 || result.succeeded) {
            let reason = result.error ?? result.status.map { "HTTP \($0)" } ?? "No usable response"
            transientRobots[key] = "Robots check failed after " + String(format: "%.1f", elapsed) + "s: " + reason
        }
        policyLock.unlock(); return value
    }
    private func robotsTemporaryFailure(_ url: URL) -> String? {
        guard var c = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return nil }
        c.path = "/robots.txt"; c.query = nil; c.fragment = nil
        guard let key = c.url?.absoluteString else { return nil }
        policyLock.lock(); defer { policyLock.unlock() }
        return transientRobots[key]
    }
    private func allowedByRobots(_ url: URL) -> Bool { policy(for: url).allows(url) }

    private static func links(_ html: String, base: URL) -> [URL] {
        guard let regex = try? NSRegularExpression(pattern: #"(?i)href\s*=\s*["']([^"']+)["']"#) else { return [] }
        let ns = NSRange(html.startIndex..<html.endIndex, in: html)
        return regex.matches(in: html, range: ns).compactMap { m in
            guard let r = Range(m.range(at: 1), in: html) else { return nil }
            let raw = String(html[r]).replacingOccurrences(of: "&amp;", with: "&")
            guard let url = URL(string: raw, relativeTo: base)?.absoluteURL else { return nil }
            return URLComponents(url: url, resolvingAgainstBaseURL: false).map { components -> URL? in
                var c = components; c.fragment = nil; return c.url
            } ?? nil
        }
    }

}
