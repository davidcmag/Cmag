import Foundation
#if os(macOS)
import WebKit
#endif
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

struct EmailLinkConflict: Codable, Hashable {
    var displayedAddress: String
    var destinationAddress: String
    var sourceURL: String
    var observedAt: Date
    var id: String { sourceURL + "\n" + displayedAddress.lowercased() + "\n" + destinationAddress.lowercased() }
    var summary: String { "Displayed email and link destination disagree: " + displayedAddress + " is displayed; mailto points to " + destinationAddress + "." }
}
struct EmailLinkDecision: Codable, Hashable {
    var approved: Bool
    var changedAt: Date
}
enum EmailLinkConflictPolicy {
    static func destinations(_ row: FoundEmail) -> [EmailLinkConflict] {
        (row.emailLinkConflicts ?? []).filter { $0.destinationAddress.lowercased() == row.address.lowercased() }
    }
    static func isHeld(_ row: FoundEmail) -> Bool {
        destinations(row).contains { row.emailLinkDecisions?[$0.id]?.approved != true }
    }
    static func warning(_ row: FoundEmail) -> String? {
        guard let conflicts = row.emailLinkConflicts, !conflicts.isEmpty else { return nil }
        return conflicts.map(\.summary).joined(separator: " ") + (isHeld(row) ? " Conflicting link destination held from contact exports until approved." : (destinations(row).isEmpty ? " Displayed contact retained with warning." : " Link destination approved for export; mismatch evidence retained."))
    }
    static func apply(_ conflicts: [EmailLinkConflict], to row: inout FoundEmail) {
        var values = Dictionary((row.emailLinkConflicts ?? []).map { ($0.id, $0) }, uniquingKeysWith: { a,b in a.observedAt >= b.observedAt ? a : b })
        for conflict in conflicts where [conflict.displayedAddress.lowercased(),conflict.destinationAddress.lowercased()].contains(row.address.lowercased()) {
            if values[conflict.id] == nil || conflict.observedAt >= values[conflict.id]!.observedAt { values[conflict.id] = conflict }
        }
        row.emailLinkConflicts = values.isEmpty ? nil : values.values.sorted { $0.id < $1.id }
    }
    static func decide(_ row: inout FoundEmail, approved: Bool, at date: Date = Date()) {
        var decisions = row.emailLinkDecisions ?? [:]
        for conflict in destinations(row) {
            if decisions[conflict.id] == nil || date >= decisions[conflict.id]!.changedAt { decisions[conflict.id] = EmailLinkDecision(approved: approved, changedAt: date) }
        }
        row.emailLinkDecisions = decisions.isEmpty ? nil : decisions
    }
    static func inheriting(_ rows: [FoundEmail], from known: [FoundEmail]) -> [FoundEmail] {
        var conflicts: [String: [String: EmailLinkConflict]] = [:]
        var decisions: [String: [String: EmailLinkDecision]] = [:]
        for row in rows + known {
            let key = row.address.lowercased() + "\n" + row.source
            for conflict in row.emailLinkConflicts ?? [] {
                if conflicts[key]?[conflict.id] == nil || conflict.observedAt >= conflicts[key]![conflict.id]!.observedAt { conflicts[key, default: [:]][conflict.id] = conflict }
            }
            for (id, decision) in row.emailLinkDecisions ?? [:] {
                if decisions[key]?[id] == nil || decision.changedAt > decisions[key]![id]!.changedAt { decisions[key, default: [:]][id] = decision }
            }
        }
        return rows.map { original in
            var row = original
            let key = row.address.lowercased() + "\n" + row.source
            apply(Array((conflicts[key] ?? [:]).values), to: &row)
            row.emailLinkDecisions = decisions[key]
            return row
        }
    }
}
enum EmailLinkConflictMatcher {
    private static let hidden = try! NSRegularExpression(pattern: #"<!--.*?(?:-->|$)|<(script|style|head|template|noscript)\b[^>]*>.*?(?:</\1\s*>|$)"#, options: [.caseInsensitive,.dotMatchesLineSeparators])
    private static let anchors = try! NSRegularExpression(pattern: #"<a\b((?:[^>"']|"[^"]*"|'[^']*')*)>(.*?)</a\s*>"#, options: [.caseInsensitive,.dotMatchesLineSeparators])
    private static let attrs = try! NSRegularExpression(pattern: #"(?:^|\s)([A-Z_:][A-Z0-9_:.-]*)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))"#, options: .caseInsensitive)
    private static let tags = try! NSRegularExpression(pattern: #"<(?:[^>"']|"[^"]*"|'[^']*')*>"#)
    private static let emails = try! NSRegularExpression(pattern: #"(?<![\p{L}\p{N}._%+@\-])[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}(?![\p{L}\p{N}.@\-])"#, options: .caseInsensitive)
    static func collect(_ input: String, source: String, at date: Date, cancelled: () -> Bool = { false }) -> [EmailLinkConflict] {
        guard input.utf8.count <= WebsiteConfirmer.maximumBytes, !cancelled() else { return [] }
        let clean = TextScan.replacing(hidden, in: input, with: " ", cancelled: cancelled)
        var results: [String: EmailLinkConflict] = [:]
        for anchor in TextScan.matches(anchors, in: clean, cancelled: cancelled) {
            if cancelled() { return [] }
            guard let ar = Range(anchor.range(at: 1), in: clean), let br = Range(anchor.range(at: 2), in: clean), anchor.range.length <= 16_384 else { continue }
            let attributes = String(clean[ar])
            var href: String?
            for attr in TextScan.matches(attrs, in: attributes, cancelled: cancelled) {
                guard let key = Range(attr.range(at: 1), in: attributes), attributes[key].lowercased() == "href" else { continue }
                for i in 2...4 where attr.range(at: i).location != NSNotFound {
                    if let range = Range(attr.range(at: i), in: attributes) { href = EmailPolicy.decodeHTML(String(attributes[range]), cancelled: cancelled) }
                }
            }
            guard let link = href?.trimmingCharacters(in: .whitespacesAndNewlines), link.lowercased().hasPrefix("mailto:"),
                  let to = String(link.dropFirst(7).prefix { $0 != "?" && $0 != "#" }).removingPercentEncoding else { continue }
            let recipients = Set(to.components(separatedBy: CharacterSet(charactersIn: ",;")).map { $0.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() }.filter(EmailPolicy.validSyntax))
            let label = EmailPolicy.decodeHTML(TextScan.replacing(tags, in: String(clean[br]), with: "", cancelled: cancelled), cancelled: cancelled)
            let displayed = Set(TextScan.matches(emails, in: label, cancelled: cancelled).compactMap { match -> String? in
                guard let range = Range(match.range, in: label) else { return nil }
                let address = label[range].lowercased(); return EmailPolicy.validSyntax(address) ? address : nil
            })
            guard !displayed.isEmpty else { continue }
            for destination in recipients.subtracting(displayed) {
                for shown in displayed {
                    let conflict = EmailLinkConflict(displayedAddress: shown, destinationAddress: destination, sourceURL: source, observedAt: date)
                    results[conflict.id] = conflict
                }
            }
        }
        return cancelled() ? [] : results.values.sorted { $0.id < $1.id }
    }
}

struct WebsitePageCheck: Codable, Hashable {
    var requestedURL: String
    var finalURL: String?
    var checkedAt: Date
    var httpStatus: Int?
    var outcome: String
    var browserRendered: Bool?
}

struct WebsiteConfirmation: Codable, Hashable {
    enum Outcome: String, Codable {
        case published = "Published"
        case notFound = "Not found on page"
        case unavailable = "Page unavailable"
        case noSource = "No website source"
        case cancelled = "Cancelled"
    }
    enum Match: String, Codable { case pageText = "Page text", mailto = "Email link" }
    var outcome: Outcome
    var reason: String
    var checkedAt = Date()
    var sourceURL: String
    var finalURL: String?
    var httpStatus: Int?
    var match: Match?
    var excerpt: String?
    var organizationDomain: Bool?
    var checkerVersion = "website-0.12.7"
    var pagesChecked: [WebsitePageCheck]?
    var browserRendered: Bool?
    var personAssociation: SourcePersonAssociation?
    var personNameCheckVersion: Int?
    var personNameAttemptAt: Date?
    var personNameCheckComplete: Bool?
    var emailLinkConflicts: [EmailLinkConflict]?
    var summary: String {
        let date = DateFormatter.localizedString(from: checkedAt, dateStyle: .medium, timeStyle: .short)
        return [reason, (emailLinkConflicts ?? []).map(\.summary).joined(separator: " "), "Checked: " + date, "URL: " + (finalURL ?? sourceURL)].joined(separator: "\n")
    }
    var label: String {
        if !(emailLinkConflicts?.isEmpty ?? true) { return "Email link mismatch" }
        if outcome == .notFound, (pagesChecked?.count ?? 0) > 1 { return "Not found in checked pages" }
        guard outcome == .published else { return outcome.rawValue }
        return organizationDomain == true ? "Published by organization" : "Published on source"
    }
}

struct WebsiteTarget: Hashable {
    var address: String
    var source: String
    var ids: [UUID]
    var knownPage: String?
    var knownPages: [String]? = nil
}

enum WebsiteConfirmationPolicy {
    static func targets(_ rows: [FoundEmail], selected: Set<UUID>? = nil,
                        rules: [SmartRule], removed: Set<String>, limit: Int = 100) -> [WebsiteTarget] {
        var result: [WebsiteTarget] = []; var indices: [String: Int] = [:]
        for row in rows {
            guard (selected == nil || selected!.contains(row.id)),
                  VerificationApplication.eligible(row, rules: rules, removed: removed) else { continue }
            let key = row.address.lowercased() + "\n" + row.source
            if let index = indices[key] { result[index].ids.append(row.id) }
            else if result.count < limit {
                indices[key] = result.count
                result.append(WebsiteTarget(address: row.address, source: row.source, ids: [row.id], knownPage: row.websiteConfirmation?.outcome == .published ? row.websiteConfirmation?.finalURL : row.websiteHistory?.reversed().first(where: { $0.outcome == .published })?.finalURL))
            }
        }
        let historyBySource = Dictionary(grouping: rows, by: { $0.address.lowercased() + "\n" + $0.source }).mapValues { records in
            records.flatMap { [$0.websiteConfirmation].compactMap { $0 } + ($0.websiteHistory ?? []) }
        }
        for index in result.indices {
            let sources = historyBySource[result[index].address.lowercased() + "\n" + result[index].source] ?? []
            result[index].knownPages = Array(Set(sources.filter { $0.outcome == .published }.map { $0.finalURL ?? $0.sourceURL })).sorted()
        }
        return result
    }
    static func apply(_ confirmation: WebsiteConfirmation, to row: inout FoundEmail) {
        if let previous = row.websiteConfirmation {
            var history = row.websiteHistory ?? []
            history.append(previous); row.websiteHistory = Array(history.suffix(3))
        }
        row.websiteConfirmation = confirmation
        EmailLinkConflictPolicy.apply(confirmation.emailLinkConflicts ?? [], to: &row)
        // Publication is independent evidence. Never change acceptance,
        // exclusions, removals, SMTP verdicts or provider conclusions here.
    }
    static func organization(_ host: String, email: String) -> Bool {
        guard let domain = email.split(separator: "@").last else { return false }
        let host = host.lowercased(), name = domain.lowercased()
        return host == name || host.hasSuffix("." + name)
    }
    static func sourceURL(_ source: String) -> URL? {
        guard source.utf8.count <= 8192, let url = URL(string: source),
              EmailPolicy.httpURL(url), let host = url.host,
              MailAddressSafety.hostname(host), url.port == nil || url.port == 80 || url.port == 443 else { return nil }
        return url
    }
    static func reflects(_ address: String, in url: URL) -> Bool {
        guard let query = URLComponents(url: url, resolvingAgainstBaseURL: false)?.query else { return false }
        return query.lowercased().contains(address.lowercased()) || (query.removingPercentEncoding?.lowercased().contains(address.lowercased()) == true)
    }
    static func permits(_ candidate: URL, from source: URL) -> Bool {
        guard sourceURL(candidate.absoluteString) != nil,
              let a = candidate.host, let b = source.host,
              EmailPolicy.canonicalHost(a) == EmailPolicy.canonicalHost(b),
              source.scheme?.lowercased() != "https" || candidate.scheme?.lowercased() == "https" else { return false }
        return true
    }
}

/// Serial, user-initiated batch. A fresh instance is created for every check.
/// Reuses a page only within that batch, with the actual fetch timestamp.
/// Exact page text/mailto matching; optional native rendering, never guessed addresses.
final class WebsiteConfirmer {
    typealias Fetch = (URLRequest, @escaping () -> Bool, @escaping (URL) -> Bool) -> HTTPResult
    private struct Page { var response: HTTPResult; var at: Date; var names: [String: SourcePersonAssociation]; var text: String?; var publications: [String: (WebsiteConfirmation.Match, String)]?; var conflicts: [EmailLinkConflict] }
    typealias Render = (URL, String, @escaping () -> Bool) -> HTTPResult
    private let render: Render?
    private var browserRequestCount = 0
    private var renderedPages: [String: Page] = [:]
    private var renderOrder: [String] = []
    private var nameCheckIncomplete = false
    private let fetch: Fetch
    private let now: () -> Date
    private var pages: [String: Page] = [:]
    private var pageOrder: [String] = []
    private var requestCount = 0
    private var conflictEvidence: [String: [String: EmailLinkConflict]] = [:]
    var pageLimitReached: Bool { requestCount >= 100 }
    static let maximumBytes = 3_000_000
    init(fetch: @escaping Fetch = { request, cancelled, redirect in
        HTTPTransport.perform(request, maxBytes: WebsiteConfirmer.maximumBytes, timeout: 12,
                              shouldCancel: cancelled, redirect: redirect)
    }, now: @escaping () -> Date = Date.init, render: Render? = nil) { self.fetch = fetch; self.now = now; self.render = render }

    func confirm(address: String, source: String, knownPage: String? = nil, knownPages: [String] = [], seekPersonName: Bool = false,
                 cancelled: @escaping () -> Bool = { false }) -> WebsiteConfirmation {
        nameCheckIncomplete = false
        let deadline = ProcessInfo.processInfo.systemUptime + 35
        defer { if seekPersonName && (ProcessInfo.processInfo.systemUptime >= deadline || pageLimitReached) { nameCheckIncomplete = true } }
        let bounded: () -> Bool = { cancelled() || ProcessInfo.processInfo.systemUptime >= deadline }
        var first = confirmPage(address: address, source: source, cancelled: bounded)
        var checks: [WebsitePageCheck] = []
        func record(_ requested: String, _ result: WebsiteConfirmation) {
            checks.append(.init(requestedURL: requested, finalURL: result.finalURL, checkedAt: result.checkedAt,
                                httpStatus: result.httpStatus, outcome: result.outcome.rawValue, browserRendered: result.browserRendered))
        }
        record(source, first)
        var bestPublication: WebsiteConfirmation? = first.outcome == .published ? first : nil
        if !(seekPersonName && first.outcome == .published && first.personAssociation == nil) && first.outcome != .notFound && !(render != nil && first.outcome == .unavailable && [200,403,429].contains(first.httpStatus ?? 0)) { first.pagesChecked = checks; return first }
        guard let original = WebsiteConfirmationPolicy.sourceURL(source), !WebsiteConfirmationPolicy.reflects(address, in: original) else { return first }
        var queue: [(URL, Int)] = []
        var visited: Set<String> = [WebsiteFollowup.key(original)]
        func enqueue(_ items: [(URL, Int)]) {
            for (url, score) in items where WebsiteConfirmationPolicy.permits(url, from: original) && !WebsiteConfirmationPolicy.reflects(address, in: url) && !visited.contains(WebsiteFollowup.key(url)) {
                if let i = queue.firstIndex(where: { WebsiteFollowup.key($0.0) == WebsiteFollowup.key(url) }) { queue[i].1 = max(queue[i].1, score) }
                else { queue.append((url, score)) }
            }
            queue.sort { $0.1 == $1.1 ? $0.0.absoluteString < $1.0.absoluteString : $0.1 > $1.1 }
            if queue.count > 40 { queue = Array(queue.prefix(40)) }
        }
        for page in knownPages { if let url = WebsiteConfirmationPolicy.sourceURL(page) { enqueue([(url, 210)]) } }
        if let knownPage = knownPage, let url = WebsiteConfirmationPolicy.sourceURL(knownPage) { enqueue([(url, 200)]) }
        if let cached = pages[WebsiteFollowup.key(original)], let text = cached.response.decodedText,
           let final = cached.response.finalURL {
            visited.insert(WebsiteFollowup.key(final))
            enqueue(WebsiteFollowup.links(address, html: text, base: final))
        }
        enqueue(WebsiteFollowup.seedPages(address, source: original))
        var incomplete = false
        while !queue.isEmpty && checks.count < 7 && !bounded() {
            let url = queue.removeFirst().0
            guard visited.insert(WebsiteFollowup.key(url)).inserted else { continue }
            var result = confirmPage(address: address, source: url.absoluteString, cancelled: bounded)
            record(url.absoluteString, result)
            if result.outcome == .published {
                result.sourceURL = source
                result.pagesChecked = checks
                result.reason += " Found on a same-site profile/contact follow-up page; original Source preserved."
                if !seekPersonName || result.personAssociation != nil { return result }
                bestPublication = result
            }
            if result.outcome == .cancelled { break }
            if result.outcome == .unavailable && ![404,410].contains(result.httpStatus ?? 0) { incomplete = true }
            if result.outcome == .notFound || (seekPersonName && result.outcome == .published), let cached = pages[WebsiteFollowup.key(url)],
               let text = cached.response.decodedText, let final = cached.response.finalURL {
                visited.insert(WebsiteFollowup.key(final))
                enqueue(WebsiteFollowup.links(address, html: text, base: final))
            }
        }
        // Retry the strongest actual profile URL before rendering the original index.
        // Each render is fresh, isolated from browser cookies and bounded by the batch deadline.
        var browserIncomplete = false
        if let render = render, !bounded() {
            let names = WebsiteFollowup.nameParts(address)
            var candidates = checks.compactMap { check -> URL? in
                guard let url = URL(string: check.finalURL ?? check.requestedURL),
                      WebsiteConfirmationPolicy.permits(url, from: original),
                      !WebsiteConfirmationPolicy.reflects(address, in: url),
                      ![404,410].contains(check.httpStatus ?? 0) else { return nil }
                return url
            }
            candidates.sort { a,b in
                if a == b { return false }
                let ap = names.allSatisfy { a.path.lowercased().contains($0) } && !names.isEmpty
                let bp = names.allSatisfy { b.path.lowercased().contains($0) } && !names.isEmpty
                if ap != bp { return ap }; if a == original { return true }; if b == original { return false }
                return a.absoluteString < b.absoluteString
            }
            var rendered = Set<String>()
            for url in candidates where rendered.count < 2 && !bounded() {
                guard rendered.insert(WebsiteFollowup.key(url)).inserted else { continue }
                guard var result = renderPage(address: address, url: url, originalSource: source, cancelled: bounded) else { nameCheckIncomplete = true; continue }
                for conflict in result.emailLinkConflicts ?? [] { conflictEvidence[address.lowercased(), default: [:]][conflict.id] = conflict }
                result.browserRendered = true
                record(url.absoluteString, result)
                if result.outcome == .published {
                    result.sourceURL = source; result.pagesChecked = checks
                    result.reason += " Confirmed in a freshly browser-rendered page. Original Source preserved."
                    if !seekPersonName || result.personAssociation != nil { return result }
                    bestPublication = result
                }
                if result.outcome == .unavailable { incomplete = true; browserIncomplete = true; nameCheckIncomplete = true }
            }
        }
        if seekPersonName, var published = bestPublication {
            published.pagesChecked = checks
            published.reason += " No explicit person association found in bounded source/profile checks."
            return published
        }
        first.pagesChecked = checks
        if cancelled() { first.outcome = .cancelled; first.reason = "Cancelled during profile/contact follow-up" }
        else if ProcessInfo.processInfo.systemUptime >= deadline { first.outcome = .unavailable; first.reason = "Website confirmation time budget reached; address remains unconfirmed" }
        else {
            first.reason += " Checked " + String(checks.count) + " source/profile/contact pages; this was a bounded check, not a search of the entire website."
            if incomplete { first.reason += " Some follow-up pages were unavailable." }
            if browserIncomplete { first.outcome = .unavailable; first.reason += " Browser confirmation was blocked or incomplete; publication remains unconfirmed." }
        }
        return first
    }

    func confirmPerson(address: String, source: String, knownPage: String? = nil, knownPages: [String] = [], cancelled: @escaping () -> Bool = { false }) -> WebsiteConfirmation {
        var answer = confirm(address: address, source: source, knownPage: knownPage, knownPages: knownPages, seekPersonName: true, cancelled: cancelled)
        var allConflicts = conflictEvidence[address.lowercased()] ?? [:]
        for conflict in answer.emailLinkConflicts ?? [] { allConflicts[conflict.id] = conflict }
        if !allConflicts.isEmpty {
            answer.emailLinkConflicts = allConflicts.values.sorted { $0.id < $1.id }
            if allConflicts.values.contains(where: { $0.destinationAddress.lowercased() == address.lowercased() }) { answer.personAssociation = nil }
            answer.reason += " " + allConflicts.values.sorted { $0.id < $1.id }.map(\.summary).joined(separator: " ")
        }
        if !cancelled() {
            answer.personNameAttemptAt = now()
            answer.personNameCheckComplete = answer.personAssociation != nil || (!nameCheckIncomplete && answer.outcome != .unavailable && answer.outcome != .cancelled)
            if answer.personNameCheckComplete == true { answer.personNameCheckVersion = SourcePersonMatcher.version }
        }
        return answer
    }
    private func renderPage(address: String, url: URL, originalSource: String, cancelled: @escaping () -> Bool) -> WebsiteConfirmation? {
        let key = WebsiteFollowup.key(url)
        let page: Page
        if let cached = renderedPages[key] { page = cached }
        else {
            guard let render = render, browserRequestCount < 10, !cancelled() else { return nil }
            browserRequestCount += 1
            let response = render(url, address, cancelled)
            let text = response.decodedText
            let usable = response.succeeded && !(text.map(Self.isChallenge) ?? true)
            let at = now()
            page = Page(response: response, at: at, names: usable ? text.map { SourcePersonMatcher.collect($0, cancelled: cancelled) } ?? [:] : [:], text: text,
                        publications: usable ? text.map { WebsitePublicationMatcher.collect(in: $0, html: response.mimeType?.lowercased() != "text/plain", cancelled: cancelled) } : nil,
                        conflicts: usable ? text.map { EmailLinkConflictMatcher.collect($0, source: url.absoluteString, at: at, cancelled: cancelled) } ?? [] : [])
            if !cancelled() {
                if renderOrder.count >= 8 { renderedPages.removeValue(forKey: renderOrder.removeFirst()) }
                renderedPages[key] = page; renderOrder.append(key)
            }
        }
        var result = Self.observe(address: address, source: url.absoluteString, response: page.response, checkedAt: page.at, decodedText: page.text, publications: page.publications, personAssociations: page.names, linkConflicts: page.conflicts, cancelled: cancelled)
        for conflict in result.emailLinkConflicts ?? [] { conflictEvidence[address.lowercased(), default: [:]][conflict.id] = conflict }
        result.browserRendered = true
        result.sourceURL = originalSource
        return result
    }
    /// Cheap first pass: actual source and already-fetched same-site evidence,
    /// before speculative profile follow-ups consume the batch budget.
    func confirmPersonOnSource(address: String, source: String, cancelled: @escaping () -> Bool = { false }) -> WebsiteConfirmation {
        var result = confirmPage(address: address, source: source, cancelled: cancelled)
        var checks = [WebsitePageCheck(requestedURL: source, finalURL: result.finalURL, checkedAt: result.checkedAt, httpStatus: result.httpStatus, outcome: result.outcome.rawValue, browserRendered: result.browserRendered)]
        guard !cancelled(), let original = WebsiteConfirmationPolicy.sourceURL(source) else { return result }
        if result.personAssociation == nil {
            for (key, page) in renderedPages.merging(pages, uniquingKeysWith: { rendered,_ in rendered }).sorted(by: { $0.key < $1.key }) {
                guard page.names[address.lowercased()] != nil, let url = URL(string: key), WebsiteConfirmationPolicy.permits(url, from: original), !WebsiteConfirmationPolicy.reflects(address, in: url) else { continue }
                var found = Self.observe(address: address, source: key, response: page.response, checkedAt: page.at, decodedText: page.text, publications: page.publications, personAssociations: page.names, linkConflicts: page.conflicts, cancelled: cancelled)
                if found.personAssociation != nil { checks.append(.init(requestedURL: key, finalURL: found.finalURL, checkedAt: found.checkedAt, httpStatus: found.httpStatus, outcome: found.outcome.rawValue, browserRendered: renderedPages[key] != nil)); found.sourceURL = source; found.browserRendered = renderedPages[key] != nil; found.reason += " Name found on a freshly checked same-site source page; original Source retained."; result = found; break }
            }
        }
        if result.personAssociation == nil, let url = WebsiteConfirmationPolicy.sourceURL(source), result.outcome == .published || result.outcome == .notFound || [200,403,429].contains(result.httpStatus ?? 0) {
            if let rendered = renderPage(address: address, url: url, originalSource: source, cancelled: cancelled) {
                checks.append(.init(requestedURL: source, finalURL: rendered.finalURL, checkedAt: rendered.checkedAt, httpStatus: rendered.httpStatus, outcome: rendered.outcome.rawValue, browserRendered: true))
                if rendered.outcome == .published { result = rendered }
                else { result.reason += " Browser source check: " + rendered.reason }
            }
        }
        if !cancelled(), !result.reason.contains("Batch page limit") {
            result.personNameAttemptAt = now()
            result.personNameCheckComplete = result.personAssociation != nil
            if result.personAssociation != nil { result.personNameCheckVersion = SourcePersonMatcher.version }
            result.reason += result.personAssociation == nil ? " Source-only name check; profile follow-up remains pending." : " Source-first name association."
            result.pagesChecked = checks
        }
        let conflicts = conflictEvidence[address.lowercased()] ?? [:]
        if !conflicts.isEmpty {
            result.emailLinkConflicts = conflicts.values.sorted { $0.id < $1.id }
            if conflicts.values.contains(where: { $0.destinationAddress.lowercased() == address.lowercased() }) { result.personAssociation = nil; result.personNameCheckVersion = nil; result.personNameCheckComplete = false }
        }
        return result
    }
    private func confirmPage(address: String, source: String, cancelled: @escaping () -> Bool = { false }) -> WebsiteConfirmation {
        var result = WebsiteConfirmation(outcome: .unavailable, reason: "", checkedAt: now(), sourceURL: source)
        guard !cancelled() else { result.outcome = .cancelled; result.reason = "Cancelled before website request"; return result }
        guard EmailPolicy.validSyntax(address) else { result.reason = "Unsupported address syntax"; return result }
        guard let url = WebsiteConfirmationPolicy.sourceURL(source) else {
            result.outcome = .noSource; result.reason = "Source is not a supported public HTTP/HTTPS website URL"; return result
        }
        guard !WebsiteConfirmationPolicy.reflects(address, in: url) else {
            result.reason = "Address is part of the source query; an echoed query is not independent publication evidence"; return result
        }
        guard var components = URLComponents(url: url, resolvingAgainstBaseURL: false) else { result.reason = "Could not normalize source URL"; return result }
        components.fragment = nil
        if components.path.isEmpty { components.path = "/" }
        guard let requestURL = components.url else { result.reason = "Could not normalize source URL"; return result }
        let key = requestURL.absoluteString
        let page: Page
        if let cached = pages[key] { page = cached }
        else {
            guard requestCount < 100 else { result.reason = "Batch page limit reached; check this source in a new batch"; return result }
            requestCount += 1
            var request = URLRequest(url: requestURL, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 10)
            request.httpShouldHandleCookies = false
            request.setValue("no-cache, no-store", forHTTPHeaderField: "Cache-Control")
            request.setValue("no-cache", forHTTPHeaderField: "Pragma")
            request.setValue("text/html, application/xhtml+xml, text/plain;q=0.9", forHTTPHeaderField: "Accept")
            request.setValue("EmailGrabber3/0.12.7 (user-requested source confirmation)", forHTTPHeaderField: "User-Agent")
            let response = fetch(request, cancelled, { WebsiteConfirmationPolicy.permits($0, from: url) })
            let text = response.decodedText
            let usable = response.succeeded && !(text.map(Self.isChallenge) ?? true)
            let names = usable ? text.map { SourcePersonMatcher.collect($0, cancelled: cancelled) } ?? [:] : [:]
            let publications = usable ? text.map { WebsitePublicationMatcher.collect(in: $0, html: response.mimeType?.lowercased() != "text/plain", cancelled: cancelled) } : nil
            let conflicts = usable && response.mimeType?.lowercased() != "text/plain" ? text.map { EmailLinkConflictMatcher.collect($0, source: source, at: now(), cancelled: cancelled) } ?? [] : []
            page = Page(response: response, at: now(), names: names, text: text, publications: publications, conflicts: conflicts)
            if !cancelled() {
                if pageOrder.count >= 8 { pages.removeValue(forKey: pageOrder.removeFirst()) }
                pages[key] = page; pageOrder.append(key)
            }
        }
        for conflict in page.conflicts where [conflict.displayedAddress.lowercased(), conflict.destinationAddress.lowercased()].contains(address.lowercased()) {
            conflictEvidence[address.lowercased(), default: [:]][conflict.id] = conflict
        }
        return Self.observe(address: address, source: source, response: page.response, checkedAt: page.at, decodedText: page.text, publications: page.publications, personAssociations: page.names, linkConflicts: page.conflicts, cancelled: cancelled)
    }

    static func isChallenge(_ text: String) -> Bool {
        let lower = text.lowercased()
        return lower.contains("cf-chl-") || lower.contains("<title>just a moment") || lower.contains("<title>access denied") || lower.contains("<title>verify you are human")
    }
    static func observe(address: String, source: String, response: HTTPResult, checkedAt: Date,
                        decodedText: String? = nil,
                        publications: [String: (WebsiteConfirmation.Match, String)]? = nil,
                        personAssociations: [String: SourcePersonAssociation]? = nil,
                        linkConflicts: [EmailLinkConflict]? = nil,
                        cancelled: () -> Bool = { false }) -> WebsiteConfirmation {
        var result = WebsiteConfirmation(outcome: .unavailable, reason: "", checkedAt: checkedAt, sourceURL: source)
        guard EmailPolicy.validSyntax(address), let url = WebsiteConfirmationPolicy.sourceURL(source), !WebsiteConfirmationPolicy.reflects(address, in: url) else {
            result.reason = "Unsupported source or address"; return result
        }
        result.checkedAt = checkedAt
        result.finalURL = response.finalURL?.absoluteString
        result.httpStatus = response.status
        guard !cancelled() else { result.outcome = .cancelled; result.reason = "Cancelled during website request"; return result }
        guard response.succeeded else {
            result.reason = response.status.map { "Website returned HTTP \($0); publication could not be checked" } ?? "Website request failed or timed out"
            if let error = response.error { result.reason += ": " + String(error.prefix(250)) }
            return result
        }
        guard let final = response.finalURL, WebsiteConfirmationPolicy.permits(final, from: url) else {
            result.reason = "Page redirected outside the source website or downgraded HTTPS; not confirmed"; return result
        }
        guard !WebsiteConfirmationPolicy.reflects(address, in: final) else {
            result.reason = "Address is part of the redirected query; an echoed query is not independent publication evidence"; return result
        }
        result.organizationDomain = WebsiteConfirmationPolicy.organization(final.host ?? "", email: address)
        guard let data = response.data, data.count <= Self.maximumBytes,
              let text = decodedText ?? response.decodedText else { result.reason = "Page was too large or could not be decoded"; return result }
        let mime = response.mimeType?.lowercased() ?? ""
        guard ["text/html", "application/xhtml+xml", "text/plain"].contains(mime) else {
            result.reason = "Unsupported page content type; HTML or plain text is required"; return result
        }
        if publications == nil && Self.isChallenge(text) {
            result.reason = "Website returned an access challenge; publication could not be checked"; return result
        }
        let conflicts = mime == "text/plain" ? [] : (linkConflicts ?? EmailLinkConflictMatcher.collect(text, source: source, at: checkedAt, cancelled: cancelled))
        result.emailLinkConflicts = conflicts.filter { [$0.displayedAddress.lowercased(), $0.destinationAddress.lowercased()].contains(address.lowercased()) }
        if let found = publications.map({ $0[address.lowercased()] }) ?? WebsitePublicationMatcher.find(address, in: text, html: mime != "text/plain") {
            result.outcome = .published; result.match = found.0; result.excerpt = found.1
            if mime != "text/plain" { result.personAssociation = (personAssociations ?? SourcePersonMatcher.collect(text))[address.lowercased()] }
            result.reason = "Exact address found in " + found.0.rawValue.lowercased() + " on " + (result.organizationDomain == true ? "the email domain's website" : "the recorded source website") + ". Publication does not prove mailbox delivery."
            if let mismatches = result.emailLinkConflicts, !mismatches.isEmpty {
                if mismatches.contains(where: { $0.destinationAddress.lowercased() == address.lowercased() }) { result.personAssociation = nil }
                result.reason = mismatches.map(\.summary).joined(separator: " ") + " This is conflicting page evidence, not verification of the correct contact."
            }
            if final.scheme?.lowercased() == "http" { result.reason += " Source uses unencrypted HTTP." }
        } else {
            result.outcome = .notFound
            result.reason = "Exact address not found in the retrieved page text or email links. This does not mean the mailbox is invalid; the page may have changed, hide contacts, or require JavaScript."
        }
        return result
    }
}

enum WebsitePublicationMatcher {
    private static let hidden = try! NSRegularExpression(pattern: #"<!--.*?(?:-->|$)|<(script|style|head|template|noscript)\b[^>]*>.*?(?:</\1\s*>|$)"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
    private static let anchors = try! NSRegularExpression(pattern: #"<a\b(?:[^>"']|"[^"]*"|'[^']*')*>"#, options: [.caseInsensitive])
    private static let href = try! NSRegularExpression(pattern: #"\s+([A-Z_:][A-Z0-9_:.-]*)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))"#, options: [.caseInsensitive])
    private static let tags = try! NSRegularExpression(pattern: #"<(?:[^>"']|"[^"]*"|'[^']*')*>"#)
    private static let blocks = try! NSRegularExpression(pattern: #"</?(?:p|div|br|li|ul|ol|section|article|header|footer|table|tr|td|th|h[1-6]|hr)\b(?:[^>"']|"[^"]*"|'[^']*')*>"#, options: [.caseInsensitive])
    private static let emails = try! NSRegularExpression(pattern: #"(?<![\p{L}\p{N}.!#$%&'*+/=?^_`{|}~-])[A-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9-]+(?:\.[A-Z0-9-]+)+(?![\p{L}\p{N}_-]|\.[\p{L}\p{N}_-])"#, options: [.caseInsensitive])
    private static let whitespace = try! NSRegularExpression(pattern: #"\s+"#)
    private static func replace(_ regex: NSRegularExpression, _ value: String, _ with: String) -> String {
        regex.stringByReplacingMatches(in: value, range: NSRange(value.startIndex..., in: value), withTemplate: with)
    }
    static func find(_ address: String, in input: String, html: Bool = true) -> (WebsiteConfirmation.Match, String)? {
        guard EmailPolicy.validSyntax(address) else { return nil }
        return collect(in: input, html: html)[address.lowercased()]
    }
    static func collect(in input: String, html: Bool = true, cancelled: () -> Bool = { false }) -> [String: (WebsiteConfirmation.Match, String)] {
        guard !cancelled(), input.utf8.count <= WebsiteConfirmer.maximumBytes else { return [:] }
        func replace(_ regex: NSRegularExpression, _ value: String, _ with: String) -> String {
            TextScan.replacing(regex, in: value, with: with, cancelled: cancelled)
        }
        var result: [String: (WebsiteConfirmation.Match, String)] = [:]
        var body = input
        var contextHTML = ""
        var contextAnchors: [(Range<String.Index>, [String], String)] = []
        if html {
            body = replace(hidden, body, " ")
            contextHTML = body
            for anchor in TextScan.matches(anchors, in: body, cancelled: cancelled) {
                if cancelled() { return [:] }
                guard let range = Range(anchor.range, in: body) else { continue }
                let tag = String(body[range])
                var recipients: [String] = []
                for attribute in TextScan.matches(href, in: tag, cancelled: cancelled) {
                    if cancelled() { return [:] }
                    guard let name = Range(attribute.range(at: 1), in: tag), tag[name].lowercased() == "href" else { continue }
                    for group in 2...4 where attribute.range(at: group).location != NSNotFound {
                        guard let r = Range(attribute.range(at: group), in: tag) else { continue }
                        let link = EmailPolicy.decodeHTML(String(tag[r]), cancelled: cancelled).trimmingCharacters(in: .whitespacesAndNewlines)
                        guard link.lowercased().hasPrefix("mailto:") else { continue }
                        // Header subject/body values are not recipient publication.
                        let to = String(link.dropFirst(7).prefix { $0 != "?" && $0 != "#" })
                        guard let decoded = to.removingPercentEncoding else { continue }
                        for recipient in decoded.components(separatedBy: CharacterSet(charactersIn: ",;")) {
                            let address = recipient.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
                            if EmailPolicy.validSyntax(address) { result[address] = (.mailto, "mailto:" + address); recipients.append(address) }
                        }
                    }
                }
                if !recipients.isEmpty { contextAnchors.append((range, recipients, replace(tags, tag, " "))) }
            }
            body = replace(blocks, body, "\n")
            body = replace(tags, body, "")
            body = EmailPolicy.decodeHTML(body, cancelled: cancelled)
        }
        for match in TextScan.matches(emails, in: body, cancelled: cancelled) {
            if cancelled() { return [:] }
            guard let range = Range(match.range, in: body) else { continue }
            let address = body[range].lowercased()
            guard EmailPolicy.validSyntax(address), result[address] == nil || result[address]?.1 == "mailto:" + address else { continue }
            let start = body.index(range.lowerBound, offsetBy: -80, limitedBy: body.startIndex) ?? body.startIndex
            let end = body.index(range.upperBound, offsetBy: 80, limitedBy: body.endIndex) ?? body.endIndex
            result[address] = (result[address]?.0 ?? .pageText, String(replace(whitespace, String(body[start..<end]), " ").prefix(240)))
        }
        // Link-only addresses previously kept only "mailto:...", discarding
        // the useful nearby page text. Build a separate marked text stream in
        // one pass; it never creates publication candidates or person evidence.
        if !contextAnchors.isEmpty {
            let prefix = "\u{1f}" + String(UInt64.random(in: 0...UInt64.max)) + ":"
            let marker = try! NSRegularExpression(pattern: NSRegularExpression.escapedPattern(for: prefix) + "([0-9]+)\u{1e}")
            var pieces: [String] = [], cursor = contextHTML.startIndex
            pieces.reserveCapacity(contextAnchors.count * 2 + 1)
            for (index, entry) in contextAnchors.enumerated() {
                if cancelled() { return [:] }
                pieces.append(String(contextHTML[cursor..<entry.0.lowerBound]))
                pieces.append(" " + prefix + String(index) + "\u{1e} " + entry.2 + " ")
                cursor = entry.0.upperBound
            }
            pieces.append(String(contextHTML[cursor...]))
            let marked = EmailPolicy.decodeHTML(replace(tags, replace(blocks, pieces.joined(), "\n"), " "), cancelled: cancelled)
            for match in TextScan.matches(marker, in: marked, cancelled: cancelled) {
                if cancelled() { return [:] }
                guard let range = Range(match.range, in: marked), let number = Range(match.range(at: 1), in: marked), let index = Int(marked[number]), contextAnchors.indices.contains(index) else { continue }
                let start = marked.index(range.lowerBound, offsetBy: -100, limitedBy: marked.startIndex) ?? marked.startIndex
                let end = marked.index(range.upperBound, offsetBy: 100, limitedBy: marked.endIndex) ?? marked.endIndex
                let window = String(marked[start..<end])
                let cleaned = TextScan.replacing(marker, in: window, with: " ", cancelled: cancelled)
                let context = replace(whitespace, String(cleaned.unicodeScalars.filter { !CharacterSet.controlCharacters.contains($0) }), " ").trimmingCharacters(in: .whitespacesAndNewlines)
                guard context.split(whereSeparator: \.isWhitespace).count >= 6 else { continue }
                for address in contextAnchors[index].1 where result[address]?.1 == "mailto:" + address {
                    result[address] = (.mailto, "mailto:" + address + " · Page context: " + String(context.prefix(300)))
                }
            }
        }
        return cancelled() ? [:] : result
    }
}


enum WebsiteFollowup {
    static func key(_ url: URL) -> String {
        var parts = URLComponents(url: url, resolvingAgainstBaseURL: false)
        parts?.fragment = nil
        if parts?.path.isEmpty == true { parts?.path = "/" }
        return parts?.url?.absoluteString ?? url.absoluteString
    }
    static func nameParts(_ address: String) -> [String] {
        let local = String(address.split(separator: "@").first ?? "").lowercased()
        let parts = local.components(separatedBy: CharacterSet(charactersIn: "._-"))
        guard (2...3).contains(parts.count), parts.allSatisfy({ $0.count >= 2 && $0.utf8.allSatisfy { (97...122).contains($0) } }) else { return [] }
        return parts
    }
    static func seedPages(_ address: String, source: URL) -> [(URL, Int)] {
        // Candidate URLs are hints, never evidence and never guessed addresses.
        // Exact publication must still be observed on the fetched page.
        guard WebsiteConfirmationPolicy.organization(source.host ?? "", email: address),
              var root = URLComponents(url: source, resolvingAgainstBaseURL: false) else { return [] }
        root.query = nil; root.fragment = nil; root.path = "/"
        guard let home = root.url else { return [] }
        var paths: [(String,Int)] = [("/",50),("/staff/",40),("/contact/",35),("/about/",30)]
        let parts = nameParts(address)
        if !parts.isEmpty {
            let slug = parts.joined(separator: "-")
            paths += [("/author/" + slug + "/",90),("/people/" + slug + "/",85),("/staff/" + slug + "/",80)]
        }
        return paths.compactMap { path,score in URL(string: path, relativeTo: home).map { ($0.absoluteURL,score) } }
    }
    static func links(_ address: String, html: String, base: URL) -> [(URL, Int)] {
        let hidden = try! NSRegularExpression(pattern: #"<!--.*?(?:-->|$)|<(script|style|template)\b[^>]*>.*?(?:</\1\s*>|$)"#, options: [.caseInsensitive,.dotMatchesLineSeparators])
        let clean = hidden.stringByReplacingMatches(in: html, range: NSRange(html.startIndex..., in: html), withTemplate: " ")
        let name = nameParts(address)
        return LinkRelevance.links(clean, base: base).compactMap { link in
            guard !link.nofollow, WebsiteConfirmationPolicy.permits(link.url, from: base) else { return nil }
            let words = LinkRelevance.tokens(link.url.path + " " + link.label)
            guard words.isDisjoint(with: ["login","logout","signin","unsubscribe","delete","checkout","privacy","legal"]) else { return nil }
            let nameWords = Set(name.flatMap { LinkRelevance.tokens($0) })
            let named = !nameWords.isEmpty && nameWords.isSubset(of: words)
            let useful = LinkRelevance.priority(link) > 0 || !words.isDisjoint(with: ["author","authors","contact","staff","team","people","profile","directory"])
            guard named || useful else { return nil }
            return (link.url, named ? 150 : 65)
        }
    }
}

/// Optional native browser fallback. No user browser session, cookies, downloads,
/// credential prompts or mailbox requests are used. Only a fixed DOM-read script runs.
enum BrowserDOMReadiness {
    static func shouldFinish(_ html: String, address: String, seekPersonName: Bool, reads: Int, cancelled: () -> Bool = { false }) -> Bool {
        if seekPersonName { return SourcePersonMatcher.collect(html, cancelled: cancelled)[address.lowercased()] != nil || reads >= 8 }
        return WebsitePublicationMatcher.find(address, in: html) != nil || reads >= 4
    }
}
enum WebsiteBrowserRenderer {
    static var defaultPersonRender: WebsiteConfirmer.Render? {
        #if os(macOS)
        return { url,address,cancelled in render(url, address, cancelled, seekPersonName: true) }
        #else
        return nil
        #endif
    }
    static var defaultRender: WebsiteConfirmer.Render? {
        #if os(macOS)
        return { url,address,cancelled in render(url, address, cancelled, seekPersonName: false) }
        #else
        return nil
        #endif
    }
    #if os(macOS)
    static func render(_ url: URL, _ address: String, _ cancelled: @escaping () -> Bool, seekPersonName: Bool = false) -> HTTPResult {
        guard !Thread.isMainThread else { return HTTPResult(error: "Browser check requires a background worker") }
        let state = BrowserRenderState()
        DispatchQueue.main.async { state.start(url: url, address: address, seekPersonName: seekPersonName) }
        let deadline = ProcessInfo.processInfo.systemUptime + 10
        while state.done.wait(timeout: .now() + 0.1) == .timedOut {
            if cancelled() || ProcessInfo.processInfo.systemUptime >= deadline {
                DispatchQueue.main.async { state.finish(HTTPResult(error: cancelled() ? "Browser check cancelled" : "Browser check timed out")) }
                state.done.wait()
                break
            }
        }
        return state.result
    }
    #endif
}

#if os(macOS)
private final class BrowserRenderState: NSObject, WKNavigationDelegate, WKUIDelegate {
    let done = DispatchSemaphore(value: 0)
    var result = HTTPResult(error: "Browser check did not complete")
    private var web: WKWebView?
    private var source: URL!
    private var address = ""
    private var status: Int?
    private var finished = false
    private var reads = 0
    private var seekPersonName = false
    private let inspectionControl = CrawlControl()
    func start(url: URL, address: String, seekPersonName: Bool = false) {
        guard !finished else { return }
        source = url; self.address = address; self.seekPersonName = seekPersonName
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .nonPersistent()
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = false
        let view = WKWebView(frame: CGRect(x: 0, y: 0, width: 1024, height: 768), configuration: configuration)
        web = view; view.navigationDelegate = self; view.uiDelegate = self
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 10)
        request.setValue("no-cache, no-store", forHTTPHeaderField: "Cache-Control")
        view.load(request)
    }
    func finish(_ response: HTTPResult) {
        guard !finished else { return }; finished = true
        inspectionControl.cancel()
        result = response; web?.stopLoading(); web?.navigationDelegate = nil; web?.uiDelegate = nil; web = nil
        done.signal()
    }
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url, action.targetFrame != nil else { decisionHandler(.cancel); return }
        if action.targetFrame?.isMainFrame == true && !WebsiteConfirmationPolicy.permits(url, from: source) {
            decisionHandler(.cancel); finish(HTTPResult(error: "Browser navigation left the source website")); return
        }
        decisionHandler(.allow)
    }
    func webView(_ webView: WKWebView, decidePolicyFor response: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        if response.isForMainFrame {
            status = (response.response as? HTTPURLResponse)?.statusCode
            guard let url = response.response.url, WebsiteConfirmationPolicy.permits(url, from: source),
                  response.canShowMIMEType, ["text/html", "application/xhtml+xml", "text/plain"].contains(response.response.mimeType ?? "") else {
                decisionHandler(.cancel); finish(HTTPResult(error: "Unsupported browser response")); return
            }
        }
        decisionHandler(.allow)
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { readDOM() }
    private func readDOM() {
        guard !finished, let view = web else { return }
        reads += 1
        view.evaluateJavaScript("(() => { const html = document.documentElement ? document.documentElement.outerHTML : ''; return html.length <= \(WebsiteConfirmer.maximumBytes) ? html : null; })()") { [weak self] value, error in
            guard let self = self, !self.finished else { return }
            guard error == nil, let html = value as? String, html.utf8.count <= WebsiteConfirmer.maximumBytes else {
                self.finish(HTTPResult(error: "Browser page too large or unreadable")); return
            }
            let response = HTTPResult(data: Data(html.utf8), status: self.status, finalURL: view.url, mimeType: "text/html")
            let reads = self.reads, address = self.address, seekName = self.seekPersonName, control = self.inspectionControl
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                let deadline = ProcessInfo.processInfo.systemUptime + 1.5
                let ready = BrowserDOMReadiness.shouldFinish(html, address: address, seekPersonName: seekName, reads: reads, cancelled: { control.wasCancelled || ProcessInfo.processInfo.systemUptime >= deadline })
                DispatchQueue.main.async { [weak self] in
                    guard let self = self, !self.finished else { return }
                    if ready { self.finish(response) }
                    else { DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in self?.readDOM() } }
                }
            }
        }
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { finish(HTTPResult(error: "Browser navigation failed: " + error.localizedDescription)) }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { finish(HTTPResult(error: "Browser request failed: " + error.localizedDescription)) }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) { finish(HTTPResult(error: "Browser content process stopped")) }
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) { completionHandler() }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) { completionHandler(false) }
    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) { completionHandler(nil) }
}
#endif


struct SourcePersonAssociation: Codable, Hashable {
    enum Method: String, Codable { case namedEmailLink = "named email link", schemaPerson = "Schema.org Person name/email fields", directoryRow = "same directory table row", contactCard = "same contact card with matching name/address", contactText = "bounded contact text with matching name/address" }
    var name: String
    var address: String
    var method: Method
    var sourceExcerpt: String
}
/// Associations use named email links, Schema.org Person name/email fields,
/// bounded table rows, or corroborated contact cards. Nearby headings, URL slugs and other staff members
/// are not evidence. Table rows require explicit
/// name/email columns or a corroborating name-shaped address in the same row.
enum SourcePersonMatcher {
    static let version = 6
    private static let comments = try! NSRegularExpression(pattern: #"<!--.*?(?:-->|$)|<(template|noscript)\b[^>]*>.*?(?:</\1\s*>|$)"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
    private static let hidden = try! NSRegularExpression(pattern: #"<(script|style|head)\b[^>]*>.*?(?:</\1\s*>|$)"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
    private static let anchors = try! NSRegularExpression(pattern: #"<a\b((?:[^>"']|"[^"]*"|'[^']*')*)>(.*?)</a\s*>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
    private static let scripts = try! NSRegularExpression(pattern: #"<script\b((?:[^>"']|"[^"]*"|'[^']*')*)>(.*?)</script\s*>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
    private static let attributes = try! NSRegularExpression(pattern: #"(?:^|\s)([A-Z_:][A-Z0-9_:.-]*)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))"#, options: [.caseInsensitive])
    private static let tags = try! NSRegularExpression(pattern: #"<[^>]*>"#)
    private static func replace(_ regex: NSRegularExpression, _ text: String) -> String { regex.stringByReplacingMatches(in: text, range: NSRange(text.startIndex..., in: text), withTemplate: " ") }
    private static func attribute(_ name: String, in text: String, cancelled: () -> Bool = { false }) -> String? {
        guard !cancelled(), text.utf8.count <= 16_384 else { return nil }
        for match in TextScan.matches(attributes, in: text, cancelled: cancelled) {
            guard let key = Range(match.range(at: 1), in: text), text[key].lowercased() == name else { continue }
            for i in 2...4 { if let value = Range(match.range(at: i), in: text) { return EmailPolicy.decodeHTML(String(text[value])) } }
        }
        return nil
    }
    private static func name(_ text: String) -> String? {
        guard text.utf8.count <= 8192 else { return nil }
        var words = EmailPolicy.decodeHTML(replace(tags, text)).split(whereSeparator: \.isWhitespace).map(String.init)
        if let first = words.first, ["email", "contact", "dr.", "mr.", "mrs.", "ms.", "prof."].contains(first.lowercased()) { words.removeFirst() }
        guard words.allSatisfy({ !["contacts", "details", "information"].contains($0.lowercased()) }) else { return nil }
        let value = words.joined(separator: " ")
        return value.count <= 120 && AddressClassification.plausiblePublishedName(value) ? value : nil
    }
    private static func email(_ text: String) -> String? {
        var value = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if value.lowercased().hasPrefix("mailto:") { value = String(value.dropFirst(7).prefix { $0 != "?" && $0 != "#" }) }
        guard let decoded = value.removingPercentEncoding else { return nil }
        return EmailPolicy.validSyntax(decoded) ? decoded.lowercased() : nil
    }
    private static let tables = try! NSRegularExpression(pattern: #"<table\b([^>]*)>(.*?)</table\s*>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
    private static let tableRows = try! NSRegularExpression(pattern: #"<tr\b([^>]*)>(.*?)</tr\s*>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
    private static let tableCells = try! NSRegularExpression(pattern: #"<(td|th)\b([^>]*)>(.*?)</\1\s*>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
    private static let exactEmails = try! NSRegularExpression(pattern: #"(?<![\p{L}\p{N}._%+@\-])[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}(?![\p{L}\p{N}.@\-])"#, options: [.caseInsensitive])
    private static let hiddenAttribute = try! NSRegularExpression(pattern: #"(?:^|\s)(?:hidden|inert)(?:\s|=|$)|aria-hidden\s*=\s*["']?true|(?:display\s*:\s*none|visibility\s*:\s*hidden)"#, options: [.caseInsensitive])
    private static let nestedStructure = try! NSRegularExpression(pattern: #"<(?:table|tr)\b"#, options: [.caseInsensitive])

    private static let markup = try! NSRegularExpression(pattern: #"<(/?)([A-Z][A-Z0-9:-]*)\b((?:[^>"']|"[^"]*"|'[^']*')*)>"#, options: [.caseInsensitive])
    private static func hiddenRanges(_ html: String, cancelled: () -> Bool) -> [NSRange] {
        let voids: Set<String> = ["area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"]
        var stack: [String] = [], ranges: [NSRange] = []
        var hiddenStart: (offset: Int, depth: Int)?
        for token in TextScan.matches(markup, in: html, cancelled: cancelled) {
            if cancelled() { return [NSRange(location: 0, length: (html as NSString).length)] }
            guard let closeRange = Range(token.range(at: 1), in: html), let nameRange = Range(token.range(at: 2), in: html), let attrsRange = Range(token.range(at: 3), in: html) else { continue }
            let tag = html[nameRange].lowercased(), attrs = String(html[attrsRange])
            if !html[closeRange].isEmpty {
                guard let index = stack.lastIndex(of: tag) else { continue }
                if let start = hiddenStart, index <= start.depth {
                    ranges.append(NSRange(location: start.offset, length: NSMaxRange(token.range) - start.offset)); hiddenStart = nil
                }
                stack.removeSubrange(index...)
            } else if !voids.contains(tag) && !attrs.trimmingCharacters(in: .whitespacesAndNewlines).hasSuffix("/") {
                if hiddenStart == nil && hiddenAttribute.firstMatch(in: attrs, range: NSRange(attrs.startIndex..., in: attrs)) != nil { hiddenStart = (token.range.location, stack.count) }
                stack.append(tag)
            }
        }
        if let start = hiddenStart { ranges.append(NSRange(location: start.offset, length: (html as NSString).length - start.offset)) }
        return ranges
    }
    private static func handleMatches(_ person: String, _ address: String) -> Bool {
        let words = person.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "en_US_POSIX")).split(whereSeparator: \.isWhitespace).map { $0.filter(\.isLetter) }
        guard let first = words.first, let last = words.last, first.count > 1, last.count > 1 else { return false }
        let local = String(address.split(separator: "@")[0]).split(separator: "+")[0].lowercased()
        let letters = local.filter(\.isLetter)
        guard local.allSatisfy({ $0.isLetter || $0.isNumber || ".-_".contains($0) }) else { return false }
        return words.dropFirst().filter { $0.count >= 3 || $0 == last }.contains { component in
            if letters == first + component || letters == component + first || letters == first + String(component.prefix(1)) { return true }
            guard letters.hasSuffix(component) else { return false }
            let initials = letters.dropLast(component.count)
            return (1...3).contains(initials.count) && initials.first == first.first
        }
    }
    private static func tableAssociations(_ html: String, cancelled: () -> Bool) -> [SourcePersonAssociation] {
        var associations: [SourcePersonAssociation] = []
        let invisible = hiddenRanges(html, cancelled: cancelled)
        func plain(_ value: String) -> String {
            EmailPolicy.decodeHTML(TextScan.replacing(tags, in: value, with: " ", cancelled: cancelled)).split(whereSeparator: \.isWhitespace).joined(separator: " ")
        }
        func addresses(_ value: String) -> Set<String> {
            Set(TextScan.matches(exactEmails, in: value, cancelled: cancelled).compactMap { match in
                Range(match.range, in: value).flatMap { email(String(value[$0])) }
            })
        }
        for table in TextScan.matches(tables, in: html, cancelled: cancelled) {
            if cancelled() { return [] }
            if invisible.contains(where: { NSLocationInRange(table.range.location, $0) }) { continue }
            guard let attrsRange = Range(table.range(at: 1), in: html), let bodyRange = Range(table.range(at: 2), in: html) else { continue }
            let tableAttrs = String(html[attrsRange])
            guard hiddenAttribute.firstMatch(in: tableAttrs, range: NSRange(tableAttrs.startIndex..., in: tableAttrs)) == nil else { continue }
            let body = String(html[bodyRange])
            // Nested/malformed tables cannot establish a single row boundary.
            if body.range(of: "<table", options: .caseInsensitive) != nil { continue }
            var columns: (name: Int, email: Int, count: Int)?
            for row in TextScan.matches(tableRows, in: body, cancelled: cancelled) {
                if cancelled() { return [] }
                guard let attributesRange = Range(row.range(at: 1), in: body), let contentRange = Range(row.range(at: 2), in: body) else { continue }
                let attrs = String(body[attributesRange]), content = String(body[contentRange])
                guard content.utf8.count <= 16_384,
                      hiddenAttribute.firstMatch(in: attrs, range: NSRange(attrs.startIndex..., in: attrs)) == nil,
                      nestedStructure.firstMatch(in: content, range: NSRange(content.startIndex..., in: content)) == nil else { continue }
                var values: [String] = [], hasHeader = false, invalid = false
                for cell in TextScan.matches(tableCells, in: content, cancelled: cancelled) {
                    if cancelled() { return [] }
                    guard let tagRange = Range(cell.range(at: 1), in: content), let attrRange = Range(cell.range(at: 2), in: content), let valueRange = Range(cell.range(at: 3), in: content) else { invalid = true; break }
                    let cellAttrs = String(content[attrRange]), raw = String(content[valueRange])
                    hasHeader = hasHeader || content[tagRange].lowercased() == "th"
                    if ["colspan", "rowspan"].contains(where: { field in attribute(field, in: cellAttrs, cancelled: cancelled).map { $0 != "1" } ?? false }) ||
                        hiddenAttribute.firstMatch(in: cellAttrs, range: NSRange(cellAttrs.startIndex..., in: cellAttrs)) != nil ||
                        hiddenAttribute.firstMatch(in: raw, range: NSRange(raw.startIndex..., in: raw)) != nil {
                        invalid = true; break
                    }
                    values.append(plain(raw))
                }
                guard !invalid, (2...12).contains(values.count) else { continue }
                let labels = values.map { $0.lowercased() }
                let nameColumns = labels.indices.filter { ["name", "full name", "person name", "contact name"].contains(labels[$0]) }
                let emailColumns = labels.indices.filter { ["email", "e-mail", "email address", "e-mail address"].contains(labels[$0]) }
                if nameColumns.count == 1, emailColumns.count == 1 {
                    columns = (nameColumns[0], emailColumns[0], values.count); continue
                }
                if hasHeader { columns = nil; continue }
                let rowAddresses = addresses(values.joined(separator: " "))
                guard rowAddresses.count == 1, let address = rowAddresses.first else { continue }
                let linkedAddresses = Set(TextScan.matches(anchors, in: content, cancelled: cancelled).compactMap { match -> String? in
                    guard let range = Range(match.range(at: 1), in: content), let href = attribute("href", in: String(content[range]), cancelled: cancelled), href.lowercased().hasPrefix("mailto:") else { return nil }
                    return email(href)
                })
                guard linkedAddresses.isEmpty || linkedAddresses == [address] else { continue }
                let person: String
                if let columns = columns {
                    guard values.count == columns.count, addresses(values[columns.email]) == [address], let found = name(values[columns.name]) else { continue }
                    person = found
                } else {
                    let names = values.compactMap { name($0) }.filter { handleMatches($0, address) }
                    guard Set(names).count == 1, let found = names.first else { continue }
                    person = found
                }
                associations.append(SourcePersonAssociation(name: person, address: address, method: .directoryRow, sourceExcerpt: String(values.joined(separator: " | ").prefix(500))))
            }
        }
        return cancelled() ? [] : associations
    }
    private static let contactBreaks = try! NSRegularExpression(pattern: #"</?(?:p|div|br|li|section|article|address|h[1-6])\b[^>]*>"#, options: .caseInsensitive)
    private static let nameWords = try! NSRegularExpression(pattern: #"[\p{L}]+(?:['’\-][\p{L}]+)*\.?"#)
    private static func contactTextNames(_ html: String, address: String, cancelled: () -> Bool) -> [String] {
        let broken = TextScan.replacing(contactBreaks, in: html, with: "\n", cancelled: cancelled)
        let text = EmailPolicy.decodeHTML(TextScan.replacing(tags, in: broken, with: " ", cancelled: cancelled), cancelled: cancelled)
        var found = Set<String>()
        var budget = 2000
        for line in text.split(whereSeparator: \.isNewline) {
            if cancelled() { return [] }
            // Punctuation separates name fields from job titles and labels.
            for part in line.split(whereSeparator: { ",;:&|".contains($0) }) {
                let segment = String(part)
                let tokens = TextScan.matches(nameWords, in: segment, cancelled: cancelled).compactMap { match in Range(match.range, in: segment).map { String(segment[$0]) } }
                guard tokens.count <= 128 else { continue }
                var spans: [(Int, Int, String)] = []
                for start in tokens.indices {
                    if cancelled() { return [] }
                    for count in 2...4 where start + count <= tokens.count {
                        budget -= 1
                        if budget <= 0 { return [] }
                        let words = Array(tokens[start..<(start + count)])
                        // Free-text windows need published capitalization; exact
                        // lowercase field labels continue through existing matchers.
                        guard words.allSatisfy({ $0.first?.isUppercase == true }),
                              let person = name(words.joined(separator: " ")), handleMatches(person, address) else { continue }
                        spans.append((start, start + count, person))
                    }
                }
                for span in spans where !spans.contains(where: { other in other.0 <= span.0 && other.1 >= span.1 && other.1 - other.0 > span.1 - span.0 }) {
                    found.insert(span.2)
                }
            }
        }
        return cancelled() ? [] : found.sorted()
    }
    private static let headings = try! NSRegularExpression(pattern: #"<h([1-6])\b[^>]*>(.*?)</h\1\s*>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
    private struct CardNode {
        var tag: String
        var attributes: String
        var start: Int
        var contentStart: Int
        var end: Int? = nil
        var contentEnd: Int? = nil
        var parent: Int?
        var children: [Int] = []
        var malformed = false
    }
    private static func cardAssociations(_ html: String, cancelled: () -> Bool) -> [SourcePersonAssociation] {
        let source = html as NSString
        let voids: Set<String> = ["area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"]
        var nodes: [CardNode] = [], stack: [Int] = []
        for token in TextScan.matches(markup, in: html, cancelled: cancelled) {
            if cancelled() { return [] }
            guard let close = Range(token.range(at: 1), in: html), let tagRange = Range(token.range(at: 2), in: html), let attrRange = Range(token.range(at: 3), in: html) else { continue }
            let tag = html[tagRange].lowercased(), attrs = String(html[attrRange])
            if !html[close].isEmpty {
                guard let last = stack.last else { continue }
                if nodes[last].tag == tag {
                    nodes[last].contentEnd = token.range.location; nodes[last].end = NSMaxRange(token.range); stack.removeLast()
                } else if let index = stack.lastIndex(where: { nodes[$0].tag == tag }) {
                    // Do not infer a card from unbalanced element boundaries.
                    for ancestor in stack { nodes[ancestor].malformed = true }
                    stack.removeSubrange(index...)
                }
            } else if !voids.contains(tag) && !attrs.trimmingCharacters(in: .whitespacesAndNewlines).hasSuffix("/") {
                guard stack.count < 512 else { return [] }
                let index = nodes.count
                nodes.append(CardNode(tag: tag, attributes: attrs, start: token.range.location, contentStart: NSMaxRange(token.range), parent: stack.last))
                if let parent = stack.last { nodes[parent].children.append(index) }
                stack.append(index)
            }
        }
        let invisible = hiddenRanges(html, cancelled: cancelled)
        func content(_ node: CardNode) -> String? {
            guard let end = node.contentEnd, end >= node.contentStart, end - node.contentStart <= 16_384 else { return nil }
            return source.substring(with: NSRange(location: node.contentStart, length: end - node.contentStart))
        }
        func plain(_ value: String) -> String {
            EmailPolicy.decodeHTML(TextScan.replacing(tags, in: value, with: " ", cancelled: cancelled)).split(whereSeparator: \.isWhitespace).joined(separator: " ")
        }
        func emails(_ value: String) -> Set<String> {
            Set(TextScan.matches(exactEmails, in: value, cancelled: cancelled).compactMap { match in
                Range(match.range, in: value).flatMap { email(String(value[$0])) }
            })
        }
        func names(_ value: String) -> [String] {
            TextScan.matches(headings, in: value, cancelled: cancelled).compactMap { match in
                Range(match.range(at: 2), in: value).flatMap { name(String(value[$0])) }
            }
        }
        var results: [SourcePersonAssociation] = []
        for (index, node) in nodes.enumerated() where ["div", "article", "li", "section", "p", "address"].contains(node.tag) {
            if cancelled() { return [] }
            guard !node.malformed, let end = node.end, let raw = content(node),
                  !invisible.contains(where: { NSLocationInRange(node.start, $0) }) else { continue }
            let text = plain(raw), recipients = emails(text)
            guard recipients.count == 1, let address = recipients.first else { continue }
            let headingsFound = names(raw)
            let textMode = headingsFound.isEmpty
            if textMode && raw.range(of: "<table", options: .caseInsensitive) != nil { continue }
            let persons = textMode ? contactTextNames(raw, address: address, cancelled: cancelled) : headingsFound
            guard persons.count == 1, let person = persons.first else { continue }
            let links = Set(TextScan.matches(anchors, in: raw, cancelled: cancelled).compactMap { match -> String? in
                guard let range = Range(match.range(at: 1), in: raw), let href = attribute("href", in: String(raw[range]), cancelled: cancelled), href.lowercased().hasPrefix("mailto:") else { return nil }
                return email(href)
            })
            guard links.isEmpty || links == [address] else { continue }
            var visibleEvidence = true
            for hiddenRange in invisible where hiddenRange.location >= node.contentStart && NSMaxRange(hiddenRange) <= end {
                if cancelled() { return [] }
                let hiddenHTML = source.substring(with: hiddenRange)
                // Decorative hidden icons do not supply either name or recipient.
                guard !emails(plain(hiddenHTML)).isEmpty || !names(hiddenHTML).isEmpty || !contactTextNames(hiddenHTML, address: address, cancelled: cancelled).isEmpty else { continue }
                let panels = node.children.filter { nodes[$0].start == hiddenRange.location }
                let buttons = node.children.filter { nodes[$0].tag == "button" && attribute("aria-expanded", in: nodes[$0].attributes, cancelled: cancelled) != nil }
                guard panels.count == 1, buttons.count == 1 else { visibleEvidence = false; break }
                let panel = nodes[panels[0]], button = nodes[buttons[0]]
                guard panel.parent == index, ["div", "section"].contains(panel.tag),
                      attribute("aria-hidden", in: panel.attributes, cancelled: cancelled)?.lowercased() == "true",
                      let buttonText = content(button), names(buttonText) == [person],
                      ["true", "false"].contains(attribute("aria-expanded", in: button.attributes, cancelled: cancelled)?.lowercased() ?? "") else { visibleEvidence = false; break }
                if let controls = attribute("aria-controls", in: button.attributes, cancelled: cancelled), controls != attribute("id", in: panel.attributes, cancelled: cancelled) { visibleEvidence = false; break }
                // Only a local disclosure panel may supply collapsed content.
                // Explicit hidden/inert content remains excluded.
                let explicitHidden = try! NSRegularExpression(pattern: #"(?:^|\s)(?:hidden|inert)(?:\s|=|$)"#, options: .caseInsensitive)
                if explicitHidden.firstMatch(in: panel.attributes, range: NSRange(panel.attributes.startIndex..., in: panel.attributes)) != nil { visibleEvidence = false; break }
            }
            guard visibleEvidence else { continue }
            results.append(SourcePersonAssociation(name: person, address: address, method: textMode ? .contactText : .contactCard, sourceExcerpt: String(text.prefix(500))))
        }
        let grouped = Dictionary(grouping: results, by: \.address)
        return cancelled() ? [] : results.filter { association in
            Set((grouped[association.address] ?? []).map { $0.name.lowercased() }).count == 1 && handleMatches(association.name, association.address)
        }
    }
    static func collect(_ input: String, cancelled: () -> Bool = { false }) -> [String: SourcePersonAssociation] {
        func replace(_ regex: NSRegularExpression, _ value: String) -> String {
            TextScan.replacing(regex, in: value, with: " ", cancelled: cancelled)
        }
        guard !cancelled(), input.utf8.count <= WebsiteConfirmer.maximumBytes else { return [:] }
        let clean = replace(comments, input)
        var candidates: [String: [SourcePersonAssociation]] = [:]
        var budget = 2000
        func walk(_ value: Any, depth: Int) {
            guard !cancelled(), budget > 0, depth < 20 else { return }; budget -= 1
            if let list = value as? [Any] { for item in list { walk(item, depth: depth + 1) }; return }
            guard let object = value as? [String: Any] else { return }
            let types = (object["@type"] as? [String]) ?? (object["@type"] as? String).map { [$0] } ?? []
            if types.contains(where: { ["person", "https://schema.org/person", "http://schema.org/person"].contains($0.lowercased()) }),
               let raw = object["name"] as? String, let person = name(raw) {
                let emails = (object["email"] as? [String]) ?? (object["email"] as? String).map { [$0] } ?? []
                for rawEmail in emails { if let address = email(rawEmail) {
                    candidates[address, default: []].append(SourcePersonAssociation(name: person, address: address, method: .schemaPerson, sourceExcerpt: "Person name field: " + raw + "; email field: " + rawEmail))
                } }
            }
            for item in object.values { walk(item, depth: depth + 1) }
        }
        for match in TextScan.matches(scripts, in: clean, cancelled: cancelled) {
            if cancelled() { return [:] }
            guard let a = Range(match.range(at: 1), in: clean), let b = Range(match.range(at: 2), in: clean), attribute("type", in: String(clean[a]), cancelled: cancelled)?.lowercased() == "application/ld+json",
                  let data = String(clean[b]).data(using: .utf8), let object = try? JSONSerialization.jsonObject(with: data) else { continue }
            walk(object, depth: 0)
        }
        let visible = replace(hidden, clean)
        for match in TextScan.matches(anchors, in: visible, cancelled: cancelled) {
            if cancelled() { return [:] }
            guard let a = Range(match.range(at: 1), in: visible), let b = Range(match.range(at: 2), in: visible), let whole = Range(match.range, in: visible),
                  let href = attribute("href", in: String(visible[a]), cancelled: cancelled), href.lowercased().hasPrefix("mailto:"), let address = email(href), let person = name(String(visible[b])) else { continue }
            candidates[address, default: []].append(SourcePersonAssociation(name: person, address: address, method: .namedEmailLink, sourceExcerpt: String(visible[whole].prefix(500))))
        }
        for association in tableAssociations(visible, cancelled: cancelled) {
            candidates[association.address, default: []].append(association)
        }
        for association in cardAssociations(visible, cancelled: cancelled) {
            candidates[association.address, default: []].append(association)
        }
        var result: [String: SourcePersonAssociation] = [:]
        for (address, values) in candidates {
            if Set(values.map { $0.name.lowercased() }).count == 1 { result[address] = values.first }
        }
        return cancelled() ? [:] : result
    }
}
