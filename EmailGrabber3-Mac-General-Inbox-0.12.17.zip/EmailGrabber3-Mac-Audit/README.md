0.12.17 broadens General inbox signals: shared functions (join, giving, visuals,
dev and related terms), collective/campaign roots and plurals, qualified dems handles,
collective phrases, and place-based accounts without supporting personal-name parts.
An opaque mailbox repeating its own non-free-provider domain label is treated as a
brand account, while recognized personal-name components and placeholder words are
protected. Domain-wide exclusions are never inferred. dev.patel remains a person
pattern even though standalone dev is a shared function. Ambiguous initials and
personal-looking handles are not blanket-classified General. Existing automatic
results update on display; saved corrections/learning retain priority.

0.12.16 fixes the Mac compiler error at the learning toggle: ResultsPane stores its
model as a plain reference, so it now uses an explicit getter/setter Binding instead
of the unavailable $model projection. This was the blocking error in the supplied
0.12.15 Terminal output; the preceding concurrency/deprecation messages were warnings.
Learning, source sorting, export cleanup and saved-data formats are unchanged.

0.12.15 adds local feedback-based learning and source-name sorting. Learning: ON
remembers new removals as not-a-person feedback unless you turn that option off;
explicit Person/General corrections also teach it. Exact addresses are remembered
immediately. Broader lexical patterns require at least three distinct handles and
no conflicting Person examples. Undo removal and Undo group decision unlearn their
feedback. The profile stays on this Mac across projects; Learning → Reset clears it.

Sort this list automatically checks unresolved source URLs, reusing pages and bounded
same-site follow-ups for explicit name/email associations (named mailto links or
Schema.org Person fields). It reports People / Shared inboxes / Needs review and
supports Stop. No SMTP probes or paid credits. Loose nearby capitalized words are
no longer treated as name proof; phrases, county and area accounts have safeguards.

A successful CSV export now removes only the exported addresses from current results
and suppresses later duplicates in that crawl. Undo removal restores them. Cancelled
or failed writes leave results unchanged. Exporting does not teach not-a-person
feedback. Originals remain saved. CSV format and exclusions remain unchanged.

0.12.14 adds Export person list directly in the main window. It exports included
Likely person results from the whole project in one action. Include Uncertain adds
unresolved possible people; the preference is remembered on this Mac. General inboxes,
exclusions and removals are omitted in both modes. All original records remain saved.
Current-list and other explicit export scopes remain available under Export CSV….

Review assistant now also has Remove group, using the same checked addresses and
unchecked exceptions, followed by count confirmation. Undo removal is in the
assistant header. Removal uses existing saved removal history, affects all copies
of the selected exact addresses, and creates no group/pattern removal rule.

0.12.13 adds Review assistant… beside Address type. It groups unresolved included
addresses from the current list, shows samples, and lets you expand groups to
uncheck exceptions before marking the group Person, General inbox or Uncertain.
Undo group decision is available in the assistant and main window. Remembering a
pattern for future matching addresses is optional; individual choices and exceptions
win. Decisions, optional rules and Undo history survive saving and reopening.

CSV export now offers Current list, All included results (all address types), and
All accepted / verified. Current list respects address type/search/status filters.
Every export omits crawler-excluded, rule-excluded and removed records. The former
Export all ignored current filters and did not suppress raw Excluded status; both
paths are fixed. CSV columns and evidence formatting are unchanged.

0.12.12 replaces the small given-name whitelist with pattern evidence and scoring.
Separated name words (either order, including middle initials) do not need to occur
in a name dictionary. Joined names, joined middle initials, and single-name handles
use bundled Census-derived components as optional positive evidence. Short numeric
suffixes do not disqualify otherwise supported full-name patterns. Roles and
organization signals take priority; ambiguous initials and unsupported handles
remain reviewable. No new requests or paid verification are needed.

Manual corrections still win. Existing rows reclassify on display without a recrawl.
See CLASSIFICATION.md for the mixed evaluation, evidence rules and limitations.

0.12.11 adds saved manual classification corrections. Select rows and use
Classify selected… → Mark as Likely person / General inbox / Uncertain, or right-click
an address. Use automatic classification resets a correction. Corrections apply to
all copies of that address in the current project and survive saving, reopening,
recrawling, live updates and older checkpoint merges. Classification reason is now
an explicit column. Organization terms and surname-first names are recognized;
initials still require matching recorded full-name evidence or your correction.
Filtering never deletes rows; verification and CSV behavior stay unchanged.

0.12.10 makes bulk selection explicit: Select all (count) selects every row in
the current list, including offscreen rows, respecting address type, search and
status filters. Deselect all clears the selection. With no filters, Select all
selects the entire list. Selection itself does not remove or change saved data.

0.12.9 fixes job-title mailboxes incorrectly shown as Likely person.
Executive Director, Deputy Director and Development Director addresses are General
inbox, even when those titles appear beside the address in website evidence.
Capitalized job titles and shared-inbox terms cannot serve as person-name evidence.
Actual matching staff names can still strengthen a person's classification.
Existing saved results are reclassified automatically; no recrawl or deletion is
needed. Filtering, verification, CSV, saved data and removal history are unchanged.

0.12.8 adds conservative address classification, reasons on the Address type
column, a Person addresses only filter, sortable classifications and reviewed
category removal using the existing removal history and Restore last removal.
Classification never changes verification or deletes filtered rows. Initials and
unusual single-word names remain Uncertain without recorded name evidence.
Existing role exclusions retain their previous behavior; newsroom is recognized
for classification without silently changing crawl exclusions. CSV stays unchanged.
Native macOS compilation and live WebKit behavior require macOS validation.

0.12.7 adds an in-app WebKit fallback to fresh website confirmation. A direct
HTML miss or access challenge can be retried in a fresh isolated browser view.
Only an exact visible-text/email-link match confirms publication; SMTP stays separate.
Native macOS build and live CPR rendering are not verified on the Linux builder.

0.12.6 adds a visible **Show evidence** button beside Copy selected. Select one
row using its checkbox, then click Show evidence and Copy evidence. This avoids
macOS text-selection menus intercepting the email cell's right-click menu.

0.12.5 also records publication evidence during discovery from the downloaded
page, without another HTTP request. Fresh checks that miss on the original
source perform bounded same-site profile/contact follow-up and retain the
actual matching page URL. Original Source values stay unchanged.

Fresh website confirmation is included in 0.12.5. Select an email and click
**Confirm selected on website**, or right-click it and choose **Confirm on
website**. No EHLO/sender setup is needed. Results appear in the Website column;
SMTP checks also collect this independent source evidence. Read
WEBSITE-CONFIRMATION.md for outcomes, limits and Mac validation status.

# Email Grabber 3 — SMTP development candidate 0.12.7

Read SMTP-CHECKER.md first. The optional direct SMTP checker has 240 passing
portable tests; macOS build, native TLS test and GUI checks are still required.
No public mailbox probes or paid provider calls were made during development.

On your Mac: `bash verify-mac.sh`, then `open EmailGrabber3.xcodeproj` and ⌘R
after tests pass. Keep your existing app and source as a fallback.

# Email Grabber 3 — audited Mac source candidate 0.11.13

Audited from the supplied `EmailGrabber3-v0.11.6-filter-scope.zip`. The uploaded original is unchanged. This is repaired source, not a compiled, notarized or fully Mac-validated release. Read AUDIT.md for findings and verification limits.

## With your existing Xcode

1. Quit the previous Email Grabber app; keep its app bundle and source as a fallback.
2. In Terminal, enter this extracted folder and run `bash verify-mac.sh`. It first makes a private backup of existing EmailGrabber3 application data, then asks Xcode to build the application and run the tests. No VPS commands, Python dependencies, API keys or paid services are needed.
3. If that succeeds, open `EmailGrabber3.xcodeproj`, choose the EmailGrabber3 scheme and My Mac, and press Command-R. Complete MAC-ACCEPTANCE.md before treating the candidate as your replacement.

The script stores the complete Xcode log and result bundle under `validation/`. It does not install over your existing app. Xcode uses local ad-hoc signing; no Apple Developer team or notarization is claimed. An alternative local application build remains available with `bash build-mac.sh`.

## What changed

0.11.13 addresses resource overhead seen during a 664-page crawl. Crawl display
events are combined and applied at most five times per second, with all email
deltas retained in order. The results subtree no longer observes unrelated
progress changes; cached filters process only appended records unless rules,
removals, status, search, field scope or existing records change. Sorting does
not rerun unchanged filtering. Pending URLs remain fully visible and uncapped.

Page processing uses a native autorelease pool per step on macOS. HTML decoding
skips unnecessary work, link regexes are reused, and each candidate is scored
once before sorting. A successful page's checkpoint is reused as the next
request's durable starting point, avoiding duplicate whole-state writes.
Every completed page is still saved, unfinished requests remain recoverable,
and the final display buffer is drained before the job is finalized. Streaming
row updates use crawl checkpoints instead of also scheduling repeated whole-
project autosaves; projects still save at start/end, explicit Save, on quit and
when reusable rules/manual removals change.

Relevance uses contact/profile path segments and explicit contact labels,
rather than treating ordinary prose containing "hosts" or "about" as contact
navigation. In a multiword query such as "podcast hosts", generic "host" alone
cannot carry the crawl onto an unrelated site. Topic selection remains a
heuristic, not a guarantee. Existing saved queues/results are preserved;
stricter link selection applies to newly considered links.

128 portable core tests pass, including the reported data sizes, coalesced
display delivery, cache invalidation, checkpoint continuity, relevance and
existing selection/filter/concurrency behavior. PERFORMANCE.md records a
synthetic Linux comparison against 0.11.12. Actual macOS CPU, memory plateau
and GUI behavior have not been measured in this cloud environment.


0.11.12 makes plain row clicks additive: click another row to add it, and click
a selected row to deselect it. Checkboxes use the same explicit selection set.
The native table no longer owns that set, so a native single-row selection or
refresh cannot replace earlier explicit selections. Selected cells are tinted.
Select visible, Copy selected, filtering and sorting remain available.
Changing the filter/status intentionally clears selection as before.

The exact reported 32-hex-character key at sentry.io is now rejected before
extraction acceptance or DNS checks. Regional Sentry ingest and Wix telemetry
hosts remain rejected. Ordinary mailboxes such as support@sentry.io and hex
mailboxes at unrelated domains remain eligible. On restoration/resume, existing
technical records are reclassified as Rejected without losing ID, source or
timestamp. Included view and accepted export reject them even if an old status
claimed Accepted or Verified. All/Rejected retain them for inspection.

117 portable core tests pass. The user's clarification narrowed the selection
repair to additive row/checkbox state; the existing SwiftUI grid is retained.
Actual Mac mouse/keyboard interaction still requires the acceptance checks.


0.11.11 defaults to Found order and offers Email A–Z / Email Z–A in the Order
control. Clicking sortable column headers remains available; choose Found order
to return to collection sequence. Incoming rows append rather than moving
existing rows alphabetically by default. Email text is selectable, row
checkboxes and Copy selected stay available during crawling, and the email cell
context menu supports Copy email and recoverable Remove email.

Results search, blocked input entries and a new Wildcard reusable rule support
case-insensitive * (zero or more characters) and ? (one character). Wildcards
match a whole email or selected field; use *word* for contains behavior.
Examples: info@*, *@example.org, *support*, sales?@example.org. Plain search
text and existing literal exclusion entries retain their substring behavior.
Wildcard rules have the same preview, undo, Included view and export behavior
as other rules. They apply to existing and newly collected addresses.
The matcher executes no regex and bounds patterns to 512 characters and field
values to 16,384 characters. Tests include an independent matching reference.

109 portable core tests pass. Native selection, copying and sort controls still
require the macOS build and GUI checks below.


0.11.10 adds a Simultaneous websites setting (1–8) and a right-hand activity panel.
Select 5 before starting a new crawl to permit up to five different sites at once.
New installations default to 5; existing projects and checkpoints retain their
saved setting, or 1 for older formats. The setting cannot change mid-crawl.
One coordinator owns the shared page frontier, deduplication, results and
checkpoints. Workers fetch individual pages, not private site queues. Relevant
links return to the shared queue. The panel lists active page URLs and every
pending page URL, including pages waiting for a busy site. It restores the
saved queue after restart. Recent history is a bounded display, not a crawl cap.
Each site receives at most one worker. Host leases protect native page requests
through redirects; a busy redirect target returns to the shared frontier.
Per-site delays, robots checks, optional page budgets and stop/resume remain
active. Search-provider discovery itself remains sequential.


Adaptive mode now starts from homepages and follows promising contact/staff/sales/profile links. Multiple explicitly supplied URLs on the same host are retained. Removed emails stay recoverable without becoming exclusion rules. All/Included/Excluded/Removed views and scoped search are consistent. Live updates send new rows in batches instead of repeatedly copying the entire result array.

Projects autosave privately; checkpoints preserve rules/removals and are written around every scanned page. Resuming merges newer saved validation results and retains unfinished requests. Native URLSession networking, cookies and shared connection reuse are retained; streamed response limits, cancellation and responsible provider-rate-limit handling are added.

CSV/TSV imports handle CRLF, quotes, multiline fields and BOMs. XLSX rich-text runs remain joined; resource limits and external-entity rejection protect workbook imports. CSV exports neutralize spreadsheet formulas. Syntax checks, null-MX handling, DNS fallback, telemetry rejection and optional ZeroBounce response handling are corrected.

## Existing scope and limits

This remains a native macOS 13+ app. It supports CSV export and text/CSV/TSV/XLSX import; XLSX export is not implemented. It supports ASCII email syntax, not full internationalized mailbox syntax. Disposable-domain detection is a starter list. Local syntax/MX/fallback checks never verify an individual mailbox. ZeroBounce is optional, requires explicit confirmation, and can consume credits. No audit tests contact it.

Discovery retains the existing free Bing RSS, DuckDuckGo and optional single-state OSM strategy. It processes the first five keyword lines, up to 3,000 candidate hosts, and bounded independent-source/directory queries. The original US geographic expansion is retained. Search providers may throttle or change their interfaces. No exhaustive coverage or comparative live-search performance is promised.

Zero page caps mean no numeric total/per-site cap, not unlimited memory or downloads. With relevant external-link following enabled, adaptive traversal has no fixed depth or per-page link-count cap. Legacy closed-site mode retains its 20-level/200-link limits. Text/CSV inputs are limited to 64 MB; workbook extracted text to 32 MB, each extracted entry to 8 MB, and workbooks to 100 worksheets. Crawler responses are capped while streaming. A crash can replay an unfinished page. JSON checkpoint costs on very large collections remain a scaling limitation.

The app is a local trusted-user application. It is not a hardened public service: private literal destinations and credentials in URLs are rejected, but full DNS-rebinding-resistant connection pinning is not implemented. Do not deploy this Mac core as an internet-facing server.
