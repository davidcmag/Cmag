import Foundation
#if os(macOS)
import WebKit
#endif
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

struct WebsitePageCheck: Codable, Hashable {
    var requestedURL: String
    var finalURL: String?
    var checkedAt: Date
    var httpStatus: Int?
    var outcome: String
    var browserRendered: Bool?
}

struct WebsiteConfirmation: Codable, Hashable {
    enum Outcome: String, Codable {
        case published = "Published"
        case notFound = "Not found on page"
        case unavailable = "Page unavailable"
        case noSource = "No website source"
        case cancelled = "Cancelled"
    }
    enum Match: String, Codable { case pageText = "Page text", mailto = "Email link" }
    var outcome: Outcome
    var reason: String
    var checkedAt = Date()
    var sourceURL: String
    var finalURL: String?
    var httpStatus: Int?
    var match: Match?
    var excerpt: String?
    var organizationDomain: Bool?
    var checkerVersion = "website-0.12.7"
    var pagesChecked: [WebsitePageCheck]?
    var browserRendered: Bool?
    var summary: String {
        let date = DateFormatter.localizedString(from: checkedAt, dateStyle: .medium, timeStyle: .short)
        return [reason, "Checked: " + date, "URL: " + (finalURL ?? sourceURL)].joined(separator: "\n")
    }
    var label: String {
        if outcome == .notFound, (pagesChecked?.count ?? 0) > 1 { return "Not found in checked pages" }
        guard outcome == .published else { return outcome.rawValue }
        return organizationDomain == true ? "Published by organization" : "Published on source"
    }
}

struct WebsiteTarget: Hashable {
    var address: String
    var source: String
    var ids: [UUID]
    var knownPage: String?
}

enum WebsiteConfirmationPolicy {
    static func targets(_ rows: [FoundEmail], selected: Set<UUID>? = nil,
                        rules: [SmartRule], removed: Set<String>, limit: Int = 100) -> [WebsiteTarget] {
        var result: [WebsiteTarget] = []; var indices: [String: Int] = [:]
        for row in rows {
            guard (selected == nil || selected!.contains(row.id)),
                  VerificationApplication.eligible(row, rules: rules, removed: removed) else { continue }
            let key = row.address.lowercased() + "\n" + row.source
            if let index = indices[key] { result[index].ids.append(row.id) }
            else if result.count < limit {
                indices[key] = result.count
                result.append(WebsiteTarget(address: row.address, source: row.source, ids: [row.id], knownPage: row.websiteConfirmation?.outcome == .published ? row.websiteConfirmation?.finalURL : row.websiteHistory?.reversed().first(where: { $0.outcome == .published })?.finalURL))
            }
        }
        return result
    }
    static func apply(_ confirmation: WebsiteConfirmation, to row: inout FoundEmail) {
        if let previous = row.websiteConfirmation {
            var history = row.websiteHistory ?? []
            history.append(previous); row.websiteHistory = Array(history.suffix(3))
        }
        row.websiteConfirmation = confirmation
        // Publication is independent evidence. Never change acceptance,
        // exclusions, removals, SMTP verdicts or provider conclusions here.
    }
    static func organization(_ host: String, email: String) -> Bool {
        guard let domain = email.split(separator: "@").last else { return false }
        let host = host.lowercased(), name = domain.lowercased()
        return host == name || host.hasSuffix("." + name)
    }
    static func sourceURL(_ source: String) -> URL? {
        guard source.utf8.count <= 8192, let url = URL(string: source),
              EmailPolicy.httpURL(url), let host = url.host,
              MailAddressSafety.hostname(host), url.port == nil || url.port == 80 || url.port == 443 else { return nil }
        return url
    }
    static func reflects(_ address: String, in url: URL) -> Bool {
        guard let query = URLComponents(url: url, resolvingAgainstBaseURL: false)?.query else { return false }
        return query.lowercased().contains(address.lowercased()) || (query.removingPercentEncoding?.lowercased().contains(address.lowercased()) == true)
    }
    static func permits(_ candidate: URL, from source: URL) -> Bool {
        guard sourceURL(candidate.absoluteString) != nil,
              let a = candidate.host, let b = source.host,
              EmailPolicy.canonicalHost(a) == EmailPolicy.canonicalHost(b),
              source.scheme?.lowercased() != "https" || candidate.scheme?.lowercased() == "https" else { return false }
        return true
    }
}

/// Serial, user-initiated batch. A fresh instance is created for every check.
/// Reuses a page only within that batch, with the actual fetch timestamp.
/// Exact page text/mailto matching; optional native rendering, never guessed addresses.
final class WebsiteConfirmer {
    typealias Fetch = (URLRequest, @escaping () -> Bool, @escaping (URL) -> Bool) -> HTTPResult
    private struct Page { var response: HTTPResult; var at: Date }
    typealias Render = (URL, String, @escaping () -> Bool) -> HTTPResult
    private let render: Render?
    private var browserRequestCount = 0
    private let fetch: Fetch
    private let now: () -> Date
    private var pages: [String: Page] = [:]
    private var pageOrder: [String] = []
    private var requestCount = 0
    static let maximumBytes = 1_000_000
    init(fetch: @escaping Fetch = { request, cancelled, redirect in
        HTTPTransport.perform(request, maxBytes: WebsiteConfirmer.maximumBytes, timeout: 12,
                              shouldCancel: cancelled, redirect: redirect)
    }, now: @escaping () -> Date = Date.init, render: Render? = nil) { self.fetch = fetch; self.now = now; self.render = render }

    func confirm(address: String, source: String, knownPage: String? = nil,
                 cancelled: @escaping () -> Bool = { false }) -> WebsiteConfirmation {
        let deadline = ProcessInfo.processInfo.systemUptime + 35
        let bounded: () -> Bool = { cancelled() || ProcessInfo.processInfo.systemUptime >= deadline }
        var first = confirmPage(address: address, source: source, cancelled: bounded)
        var checks: [WebsitePageCheck] = []
        func record(_ requested: String, _ result: WebsiteConfirmation) {
            checks.append(.init(requestedURL: requested, finalURL: result.finalURL, checkedAt: result.checkedAt,
                                httpStatus: result.httpStatus, outcome: result.outcome.rawValue, browserRendered: result.browserRendered))
        }
        record(source, first)
        if first.outcome != .notFound && !(render != nil && first.outcome == .unavailable && [200,403,429].contains(first.httpStatus ?? 0)) { first.pagesChecked = checks; return first }
        guard let original = WebsiteConfirmationPolicy.sourceURL(source), !WebsiteConfirmationPolicy.reflects(address, in: original) else { return first }
        var queue: [(URL, Int)] = []
        var visited: Set<String> = [WebsiteFollowup.key(original)]
        func enqueue(_ items: [(URL, Int)]) {
            for (url, score) in items where WebsiteConfirmationPolicy.permits(url, from: original) && !WebsiteConfirmationPolicy.reflects(address, in: url) && !visited.contains(WebsiteFollowup.key(url)) {
                if let i = queue.firstIndex(where: { WebsiteFollowup.key($0.0) == WebsiteFollowup.key(url) }) { queue[i].1 = max(queue[i].1, score) }
                else { queue.append((url, score)) }
            }
            queue.sort { $0.1 == $1.1 ? $0.0.absoluteString < $1.0.absoluteString : $0.1 > $1.1 }
            if queue.count > 40 { queue = Array(queue.prefix(40)) }
        }
        if let knownPage = knownPage, let url = WebsiteConfirmationPolicy.sourceURL(knownPage) { enqueue([(url, 200)]) }
        if let cached = pages[WebsiteFollowup.key(original)], let text = cached.response.decodedText,
           let final = cached.response.finalURL {
            visited.insert(WebsiteFollowup.key(final))
            enqueue(WebsiteFollowup.links(address, html: text, base: final))
        }
        enqueue(WebsiteFollowup.seedPages(address, source: original))
        var incomplete = false
        while !queue.isEmpty && checks.count < 7 && !bounded() {
            let url = queue.removeFirst().0
            guard visited.insert(WebsiteFollowup.key(url)).inserted else { continue }
            var result = confirmPage(address: address, source: url.absoluteString, cancelled: bounded)
            record(url.absoluteString, result)
            if result.outcome == .published {
                result.sourceURL = source
                result.pagesChecked = checks
                result.reason += " Found on a same-site profile/contact follow-up page; original Source preserved."
                return result
            }
            if result.outcome == .cancelled { break }
            if result.outcome == .unavailable && ![404,410].contains(result.httpStatus ?? 0) { incomplete = true }
            if result.outcome == .notFound, let cached = pages[WebsiteFollowup.key(url)],
               let text = cached.response.decodedText, let final = cached.response.finalURL {
                visited.insert(WebsiteFollowup.key(final))
                enqueue(WebsiteFollowup.links(address, html: text, base: final))
            }
        }
        // Retry the strongest actual profile URL before rendering the original index.
        // Each render is fresh, isolated from browser cookies and bounded by the batch deadline.
        var browserIncomplete = false
        if let render = render, !bounded() {
            let names = WebsiteFollowup.nameParts(address)
            var candidates = checks.compactMap { check -> URL? in
                guard let url = URL(string: check.finalURL ?? check.requestedURL),
                      WebsiteConfirmationPolicy.permits(url, from: original),
                      !WebsiteConfirmationPolicy.reflects(address, in: url),
                      ![404,410].contains(check.httpStatus ?? 0) else { return nil }
                return url
            }
            candidates.sort { a,b in
                if a == b { return false }
                let ap = names.allSatisfy { a.path.lowercased().contains($0) } && !names.isEmpty
                let bp = names.allSatisfy { b.path.lowercased().contains($0) } && !names.isEmpty
                if ap != bp { return ap }; if a == original { return true }; if b == original { return false }
                return a.absoluteString < b.absoluteString
            }
            var rendered = Set<String>()
            for url in candidates where rendered.count < 2 && browserRequestCount < 10 && !bounded() {
                guard rendered.insert(WebsiteFollowup.key(url)).inserted else { continue }
                browserRequestCount += 1
                let response = render(url, address, bounded)
                var result = Self.observe(address: address, source: url.absoluteString, response: response, checkedAt: now(), cancelled: bounded)
                result.browserRendered = true
                record(url.absoluteString, result)
                if result.outcome == .published {
                    result.sourceURL = source; result.pagesChecked = checks
                    result.reason += " Confirmed in a freshly browser-rendered page. Original Source preserved."
                    return result
                }
                if result.outcome == .unavailable { incomplete = true; browserIncomplete = true }
            }
        }
        first.pagesChecked = checks
        if cancelled() { first.outcome = .cancelled; first.reason = "Cancelled during profile/contact follow-up" }
        else if ProcessInfo.processInfo.systemUptime >= deadline { first.outcome = .unavailable; first.reason = "Website confirmation time budget reached; address remains unconfirmed" }
        else {
            first.reason += " Checked " + String(checks.count) + " source/profile/contact pages; this was a bounded check, not a search of the entire website."
            if incomplete { first.reason += " Some follow-up pages were unavailable." }
            if browserIncomplete { first.outcome = .unavailable; first.reason += " Browser confirmation was blocked or incomplete; publication remains unconfirmed." }
        }
        return first
    }

    private func confirmPage(address: String, source: String, cancelled: @escaping () -> Bool = { false }) -> WebsiteConfirmation {
        var result = WebsiteConfirmation(outcome: .unavailable, reason: "", checkedAt: now(), sourceURL: source)
        guard !cancelled() else { result.outcome = .cancelled; result.reason = "Cancelled before website request"; return result }
        guard EmailPolicy.validSyntax(address) else { result.reason = "Unsupported address syntax"; return result }
        guard let url = WebsiteConfirmationPolicy.sourceURL(source) else {
            result.outcome = .noSource; result.reason = "Source is not a supported public HTTP/HTTPS website URL"; return result
        }
        guard !WebsiteConfirmationPolicy.reflects(address, in: url) else {
            result.reason = "Address is part of the source query; an echoed query is not independent publication evidence"; return result
        }
        guard var components = URLComponents(url: url, resolvingAgainstBaseURL: false) else { result.reason = "Could not normalize source URL"; return result }
        components.fragment = nil
        if components.path.isEmpty { components.path = "/" }
        guard let requestURL = components.url else { result.reason = "Could not normalize source URL"; return result }
        let key = requestURL.absoluteString
        let page: Page
        if let cached = pages[key] { page = cached }
        else {
            guard requestCount < 100 else { result.reason = "Batch page limit reached; check this source in a new batch"; return result }
            requestCount += 1
            var request = URLRequest(url: requestURL, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 10)
            request.httpShouldHandleCookies = false
            request.setValue("no-cache, no-store", forHTTPHeaderField: "Cache-Control")
            request.setValue("no-cache", forHTTPHeaderField: "Pragma")
            request.setValue("text/html, application/xhtml+xml, text/plain;q=0.9", forHTTPHeaderField: "Accept")
            request.setValue("EmailGrabber3/0.12.7 (user-requested source confirmation)", forHTTPHeaderField: "User-Agent")
            let response = fetch(request, cancelled, { WebsiteConfirmationPolicy.permits($0, from: url) })
            page = Page(response: response, at: now())
            if !cancelled() {
                if pageOrder.count >= 8 { pages.removeValue(forKey: pageOrder.removeFirst()) }
                pages[key] = page; pageOrder.append(key)
            }
        }
        return Self.observe(address: address, source: source, response: page.response, checkedAt: page.at, cancelled: cancelled)
    }

    static func isChallenge(_ text: String) -> Bool {
        let lower = text.lowercased()
        return lower.contains("cf-chl-") || lower.contains("<title>just a moment") || lower.contains("<title>access denied") || lower.contains("<title>verify you are human")
    }
    static func observe(address: String, source: String, response: HTTPResult, checkedAt: Date,
                        decodedText: String? = nil,
                        publications: [String: (WebsiteConfirmation.Match, String)]? = nil,
                        cancelled: () -> Bool = { false }) -> WebsiteConfirmation {
        var result = WebsiteConfirmation(outcome: .unavailable, reason: "", checkedAt: checkedAt, sourceURL: source)
        guard EmailPolicy.validSyntax(address), let url = WebsiteConfirmationPolicy.sourceURL(source), !WebsiteConfirmationPolicy.reflects(address, in: url) else {
            result.reason = "Unsupported source or address"; return result
        }
        result.checkedAt = checkedAt
        result.finalURL = response.finalURL?.absoluteString
        result.httpStatus = response.status
        guard !cancelled() else { result.outcome = .cancelled; result.reason = "Cancelled during website request"; return result }
        guard response.succeeded else {
            result.reason = response.status.map { "Website returned HTTP \($0); publication could not be checked" } ?? "Website request failed or timed out"
            if let error = response.error { result.reason += ": " + String(error.prefix(250)) }
            return result
        }
        guard let final = response.finalURL, WebsiteConfirmationPolicy.permits(final, from: url) else {
            result.reason = "Page redirected outside the source website or downgraded HTTPS; not confirmed"; return result
        }
        guard !WebsiteConfirmationPolicy.reflects(address, in: final) else {
            result.reason = "Address is part of the redirected query; an echoed query is not independent publication evidence"; return result
        }
        result.organizationDomain = WebsiteConfirmationPolicy.organization(final.host ?? "", email: address)
        guard let data = response.data, data.count <= Self.maximumBytes,
              let text = decodedText ?? response.decodedText else { result.reason = "Page was too large or could not be decoded"; return result }
        let mime = response.mimeType?.lowercased() ?? ""
        guard ["text/html", "application/xhtml+xml", "text/plain"].contains(mime) else {
            result.reason = "Unsupported page content type; HTML or plain text is required"; return result
        }
        if publications == nil && Self.isChallenge(text) {
            result.reason = "Website returned an access challenge; publication could not be checked"; return result
        }
        if let found = publications.map({ $0[address.lowercased()] }) ?? WebsitePublicationMatcher.find(address, in: text, html: mime != "text/plain") {
            result.outcome = .published; result.match = found.0; result.excerpt = found.1
            result.reason = "Exact address found in " + found.0.rawValue.lowercased() + " on " + (result.organizationDomain == true ? "the email domain's website" : "the recorded source website") + ". Publication does not prove mailbox delivery."
            if final.scheme?.lowercased() == "http" { result.reason += " Source uses unencrypted HTTP." }
        } else {
            result.outcome = .notFound
            result.reason = "Exact address not found in the retrieved page text or email links. This does not mean the mailbox is invalid; the page may have changed, hide contacts, or require JavaScript."
        }
        return result
    }
}

enum WebsitePublicationMatcher {
    private static let hidden = try! NSRegularExpression(pattern: #"<!--.*?(?:-->|$)|<(script|style|head|template|noscript)\b[^>]*>.*?(?:</\1\s*>|$)"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
    private static let anchors = try! NSRegularExpression(pattern: #"<a\b(?:[^>"']|"[^"]*"|'[^']*')*>"#, options: [.caseInsensitive])
    private static let href = try! NSRegularExpression(pattern: #"\s+([A-Z_:][A-Z0-9_:.-]*)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))"#, options: [.caseInsensitive])
    private static let tags = try! NSRegularExpression(pattern: #"<(?:[^>"']|"[^"]*"|'[^']*')*>"#)
    private static let blocks = try! NSRegularExpression(pattern: #"</?(?:p|div|br|li|ul|ol|section|article|header|footer|table|tr|td|th|h[1-6]|hr)\b(?:[^>"']|"[^"]*"|'[^']*')*>"#, options: [.caseInsensitive])
    private static let emails = try! NSRegularExpression(pattern: #"(?<![\p{L}\p{N}.!#$%&'*+/=?^_`{|}~-])[A-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9-]+(?:\.[A-Z0-9-]+)+(?![\p{L}\p{N}_-]|\.[\p{L}\p{N}_-])"#, options: [.caseInsensitive])
    private static let whitespace = try! NSRegularExpression(pattern: #"\s+"#)
    private static func replace(_ regex: NSRegularExpression, _ value: String, _ with: String) -> String {
        regex.stringByReplacingMatches(in: value, range: NSRange(value.startIndex..., in: value), withTemplate: with)
    }
    static func find(_ address: String, in input: String, html: Bool = true) -> (WebsiteConfirmation.Match, String)? {
        guard EmailPolicy.validSyntax(address) else { return nil }
        return collect(in: input, html: html)[address.lowercased()]
    }
    static func collect(in input: String, html: Bool = true) -> [String: (WebsiteConfirmation.Match, String)] {
        guard input.utf8.count <= WebsiteConfirmer.maximumBytes else { return [:] }
        var result: [String: (WebsiteConfirmation.Match, String)] = [:]
        var body = input
        if html {
            body = replace(hidden, body, " ")
            for anchor in anchors.matches(in: body, range: NSRange(body.startIndex..., in: body)) {
                guard let range = Range(anchor.range, in: body) else { continue }
                let tag = String(body[range])
                for attribute in href.matches(in: tag, range: NSRange(tag.startIndex..., in: tag)) {
                    guard let name = Range(attribute.range(at: 1), in: tag), tag[name].lowercased() == "href" else { continue }
                    for group in 2...4 where attribute.range(at: group).location != NSNotFound {
                        guard let r = Range(attribute.range(at: group), in: tag) else { continue }
                        let link = EmailPolicy.decodeHTML(String(tag[r])).trimmingCharacters(in: .whitespacesAndNewlines)
                        guard link.lowercased().hasPrefix("mailto:") else { continue }
                        // Header subject/body values are not recipient publication.
                        let to = String(link.dropFirst(7).prefix { $0 != "?" && $0 != "#" })
                        guard let decoded = to.removingPercentEncoding else { continue }
                        for recipient in decoded.components(separatedBy: CharacterSet(charactersIn: ",;")) {
                            let address = recipient.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
                            if EmailPolicy.validSyntax(address) { result[address] = (.mailto, "mailto:" + address) }
                        }
                    }
                }
            }
            body = replace(blocks, body, "\n")
            body = replace(tags, body, "")
            body = EmailPolicy.decodeHTML(body)
        }
        for match in emails.matches(in: body, range: NSRange(body.startIndex..., in: body)) {
            guard let range = Range(match.range, in: body) else { continue }
            let address = body[range].lowercased()
            guard EmailPolicy.validSyntax(address), result[address] == nil else { continue }
            let start = body.index(range.lowerBound, offsetBy: -80, limitedBy: body.startIndex) ?? body.startIndex
            let end = body.index(range.upperBound, offsetBy: 80, limitedBy: body.endIndex) ?? body.endIndex
            result[address] = (.pageText, String(replace(whitespace, String(body[start..<end]), " ").prefix(240)))
        }
        return result
    }
}


enum WebsiteFollowup {
    static func key(_ url: URL) -> String {
        var parts = URLComponents(url: url, resolvingAgainstBaseURL: false)
        parts?.fragment = nil
        if parts?.path.isEmpty == true { parts?.path = "/" }
        return parts?.url?.absoluteString ?? url.absoluteString
    }
    static func nameParts(_ address: String) -> [String] {
        let local = String(address.split(separator: "@").first ?? "").lowercased()
        let parts = local.components(separatedBy: CharacterSet(charactersIn: "._-"))
        guard (2...3).contains(parts.count), parts.allSatisfy({ $0.count >= 2 && $0.utf8.allSatisfy { (97...122).contains($0) } }) else { return [] }
        return parts
    }
    static func seedPages(_ address: String, source: URL) -> [(URL, Int)] {
        // Candidate URLs are hints, never evidence and never guessed addresses.
        // Exact publication must still be observed on the fetched page.
        guard WebsiteConfirmationPolicy.organization(source.host ?? "", email: address),
              var root = URLComponents(url: source, resolvingAgainstBaseURL: false) else { return [] }
        root.query = nil; root.fragment = nil; root.path = "/"
        guard let home = root.url else { return [] }
        var paths: [(String,Int)] = [("/",50),("/staff/",40),("/contact/",35),("/about/",30)]
        let parts = nameParts(address)
        if !parts.isEmpty {
            let slug = parts.joined(separator: "-")
            paths += [("/author/" + slug + "/",90),("/people/" + slug + "/",85),("/staff/" + slug + "/",80)]
        }
        return paths.compactMap { path,score in URL(string: path, relativeTo: home).map { ($0.absoluteURL,score) } }
    }
    static func links(_ address: String, html: String, base: URL) -> [(URL, Int)] {
        let hidden = try! NSRegularExpression(pattern: #"<!--.*?(?:-->|$)|<(script|style|template)\b[^>]*>.*?(?:</\1\s*>|$)"#, options: [.caseInsensitive,.dotMatchesLineSeparators])
        let clean = hidden.stringByReplacingMatches(in: html, range: NSRange(html.startIndex..., in: html), withTemplate: " ")
        let name = nameParts(address)
        return LinkRelevance.links(clean, base: base).compactMap { link in
            guard !link.nofollow, WebsiteConfirmationPolicy.permits(link.url, from: base) else { return nil }
            let words = LinkRelevance.tokens(link.url.path + " " + link.label)
            guard words.isDisjoint(with: ["login","logout","signin","unsubscribe","delete","checkout","privacy","legal"]) else { return nil }
            let nameWords = Set(name.flatMap { LinkRelevance.tokens($0) })
            let named = !nameWords.isEmpty && nameWords.isSubset(of: words)
            let useful = LinkRelevance.priority(link) > 0 || !words.isDisjoint(with: ["author","authors","contact","staff","team","people","profile","directory"])
            guard named || useful else { return nil }
            return (link.url, named ? 150 : 65)
        }
    }
}

/// Optional native browser fallback. No user browser session, cookies, downloads,
/// credential prompts or mailbox requests are used. Only a fixed DOM-read script runs.
enum WebsiteBrowserRenderer {
    static var defaultRender: WebsiteConfirmer.Render? {
        #if os(macOS)
        return render
        #else
        return nil
        #endif
    }
    #if os(macOS)
    static func render(_ url: URL, _ address: String, _ cancelled: @escaping () -> Bool) -> HTTPResult {
        guard !Thread.isMainThread else { return HTTPResult(error: "Browser check requires a background worker") }
        let state = BrowserRenderState()
        DispatchQueue.main.async { state.start(url: url, address: address) }
        let deadline = ProcessInfo.processInfo.systemUptime + 10
        while state.done.wait(timeout: .now() + 0.1) == .timedOut {
            if cancelled() || ProcessInfo.processInfo.systemUptime >= deadline {
                DispatchQueue.main.async { state.finish(HTTPResult(error: cancelled() ? "Browser check cancelled" : "Browser check timed out")) }
                state.done.wait()
                break
            }
        }
        return state.result
    }
    #endif
}

#if os(macOS)
private final class BrowserRenderState: NSObject, WKNavigationDelegate, WKUIDelegate {
    let done = DispatchSemaphore(value: 0)
    var result = HTTPResult(error: "Browser check did not complete")
    private var web: WKWebView?
    private var source: URL!
    private var address = ""
    private var status: Int?
    private var finished = false
    private var reads = 0
    func start(url: URL, address: String) {
        guard !finished else { return }
        source = url; self.address = address
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .nonPersistent()
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = false
        let view = WKWebView(frame: CGRect(x: 0, y: 0, width: 1024, height: 768), configuration: configuration)
        web = view; view.navigationDelegate = self; view.uiDelegate = self
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 10)
        request.setValue("no-cache, no-store", forHTTPHeaderField: "Cache-Control")
        view.load(request)
    }
    func finish(_ response: HTTPResult) {
        guard !finished else { return }; finished = true
        result = response; web?.stopLoading(); web?.navigationDelegate = nil; web?.uiDelegate = nil; web = nil
        done.signal()
    }
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url, action.targetFrame != nil else { decisionHandler(.cancel); return }
        if action.targetFrame?.isMainFrame == true && !WebsiteConfirmationPolicy.permits(url, from: source) {
            decisionHandler(.cancel); finish(HTTPResult(error: "Browser navigation left the source website")); return
        }
        decisionHandler(.allow)
    }
    func webView(_ webView: WKWebView, decidePolicyFor response: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        if response.isForMainFrame {
            status = (response.response as? HTTPURLResponse)?.statusCode
            guard let url = response.response.url, WebsiteConfirmationPolicy.permits(url, from: source),
                  response.canShowMIMEType, ["text/html", "application/xhtml+xml", "text/plain"].contains(response.response.mimeType ?? "") else {
                decisionHandler(.cancel); finish(HTTPResult(error: "Unsupported browser response")); return
            }
        }
        decisionHandler(.allow)
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { readDOM() }
    private func readDOM() {
        guard !finished, let view = web else { return }
        reads += 1
        view.evaluateJavaScript("(() => { const html = document.documentElement ? document.documentElement.outerHTML : ''; return html.length <= 1000000 ? html : null; })()") { [weak self] value, error in
            guard let self = self, !self.finished else { return }
            guard error == nil, let html = value as? String, html.utf8.count <= WebsiteConfirmer.maximumBytes else {
                self.finish(HTTPResult(error: "Browser page too large or unreadable")); return
            }
            let response = HTTPResult(data: Data(html.utf8), status: self.status, finalURL: view.url, mimeType: "text/html")
            if WebsitePublicationMatcher.find(self.address, in: html) != nil || self.reads >= 4 {
                self.finish(response)
            } else {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in self?.readDOM() }
            }
        }
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { finish(HTTPResult(error: "Browser navigation failed: " + error.localizedDescription)) }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { finish(HTTPResult(error: "Browser request failed: " + error.localizedDescription)) }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) { finish(HTTPResult(error: "Browser content process stopped")) }
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) { completionHandler() }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) { completionHandler(false) }
    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) { completionHandler(nil) }
}
#endif
