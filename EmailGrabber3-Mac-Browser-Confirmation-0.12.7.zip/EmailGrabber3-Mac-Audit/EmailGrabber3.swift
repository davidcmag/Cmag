import SwiftUI
import AppKit
import Foundation
import UniformTypeIdentifiers

@MainActor final class GrabberModel: ObservableObject {
    @Published var mode: SourceMode = .website { didSet { scheduleAutosave() } }
    @Published var input = "" { didSet { scheduleAutosave() } }
    @Published var excluded = "noreply@\nno-reply@" { didSet { scheduleAutosave() } }
    @Published var depth = 0 { didSet { scheduleAutosave() } }
    @Published var maxPages = 0 { didSet { scheduleAutosave() } }
    @Published var maxPagesPerDomain = 0 { didSet { scheduleAutosave() } }
    @Published var stripDuplicates = true { didSet { scheduleAutosave() } }
    @Published var excludeRole = false { didSet { scheduleAutosave() } }
    @Published var excludeFree = false { didSet { scheduleAutosave() } }
    @Published var excludeDisposable = true { didSet { scheduleAutosave() } }
    @Published var followExternalLinks = true { didSet { scheduleAutosave() } }
    @Published var concurrentSites = 5 { didSet { scheduleAutosave() } }
    @Published var topicContext = "" { didSet { scheduleAutosave() } }
    @Published var checkDNS = true { didSet { scheduleAutosave() } }
    private(set) var resultsRevision = 0
    @Published var rows: [FoundEmail] = [] { didSet {
        resultsRevision += 1
        if !running { scheduleAutosave() }
    } }
    @Published var smartRules: [SmartRule] = [] { didSet { presentationChanged() } }
    @Published var removal = RemovalState() { didSet { presentationChanged() } }
    func isHiddenByRule(_ address: String) -> Bool { smartRules.contains { $0.matches(address) } }
    func addRule(kind: String, pattern: String) {
        let token = pattern.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !token.isEmpty else { return }
        guard kind != "Wildcard" || token.count <= SafeWildcard.maximumPatternLength else { progress = "Wildcard rules support up to 512 characters"; return }
        if !smartRules.contains(where: { $0.kind == kind && $0.pattern == token }) {
            smartRules.append(SmartRule(kind: kind, pattern: token))
        }
        progress = "Rule applied immediately; original results retained"
    }
    func undoRule() {
        guard !smartRules.isEmpty else { return }
        smartRules.removeLast()
        progress = "Last rule undone; matching results restored"
    }
    func countMatching(kind: String, pattern: String) -> Int {
        let rule = SmartRule(kind: kind, pattern: pattern)
        return rows.filter { rule.matches($0.address) && !isHiddenByRule($0.address) && !isRemoved($0.address) && $0.status != "Excluded" && $0.status != "Rejected" }.count
    }
    // Addresses removed from the grid are suppressed on subsequent live refreshes.
    private var projectID = UUID()
    private var restoring = true
    private var autosaveWork: DispatchWorkItem?
    func isRemoved(_ address: String) -> Bool { removal.addresses.contains(address.lowercased()) }
    func displayStatus(_ row: FoundEmail) -> String { ResultPolicy.displayedStatus(row, rules: smartRules, removed: removal.addresses) }
    private func presentationChanged() {
        resultsRevision += 1
        guard !restoring else { return }
        CrawlDisk.updatePresentation(rules: smartRules, removal: removal, projectID: projectID)
        let checkpointError = CrawlDisk.lastError
        flushAutosave()
        if let checkpointError = checkpointError { persistenceError = "Checkpoint: " + checkpointError }
    }
    private func makeSession() -> GrabSession {
        GrabSession(mode: mode, input: input, excluded: excluded, depth: depth, maxPages: maxPages, maxPagesPerDomain: maxPagesPerDomain, stripDuplicates: stripDuplicates, excludeRole: excludeRole, excludeFree: excludeFree, excludeDisposable: excludeDisposable, checkDNS: checkDNS, rows: rows, discoveredSites: discoveredSites, directoryDiscovery: directoryDiscovery, osmStateCode: osmStateCode, smartRules: smartRules, removedAddresses: removal.addresses, removalHistory: removal.history, projectID: projectID, followExternalLinks: followExternalLinks, topicContext: topicContext, concurrentSites: concurrentSites, smtpOptions: smtpOptions)
    }
    private func scheduleAutosave() {
        guard !restoring else { return }
        autosaveWork?.cancel()
        let item = DispatchWorkItem { [weak self] in DispatchQueue.main.async { [weak self] in self?.flushAutosave() } }
        autosaveWork = item
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: item)
    }
    func flushAutosave() {
        guard !restoring else { return }
        autosaveWork?.cancel(); autosaveWork = nil
        if !CrawlDisk.saveProject(makeSession()) { persistenceError = "Could not autosave: " + (CrawlDisk.lastError ?? "unknown error") }
        else { persistenceError = nil }
    }
    private func apply(_ session: GrabSession) {
        currentActivity = nil; recentActivity.removeAll(); activePages.removeAll(); queuedPageURLs.removeAll(); pendingPageCount = 0
        smtpOptions = session.smtpOptions ?? SMTPOptions()
        projectID = session.projectID ?? UUID()
        concurrentSites = min(8, max(1, session.concurrentSites ?? 1))
        followExternalLinks = session.followExternalLinks ?? true; topicContext = session.topicContext ?? ""
        mode = session.mode; input = session.input; excluded = session.excluded
        depth = min(20, max(0, session.depth)); maxPages = max(0, session.maxPages); maxPagesPerDomain = max(0, session.maxPagesPerDomain ?? 0)
        stripDuplicates = session.stripDuplicates; excludeRole = session.excludeRole; excludeFree = session.excludeFree
        excludeDisposable = session.excludeDisposable; checkDNS = session.checkDNS; rows = TechnicalAddressPolicy.reclassify(session.rows)
        smartRules = session.smartRules ?? []; removal = RemovalState(addresses: session.removedAddresses ?? [], history: session.removalHistory ?? [])
        discoveredSites = session.discoveredSites ?? []; directoryDiscovery = session.directoryDiscovery ?? true; osmStateCode = session.osmStateCode ?? ""
        discoverySignature = currentDiscoverySignature
    }
    init() {
        if let session = CrawlDisk.loadProject() {
            apply(session)
            if let checkpoint = CrawlDisk.load(), checkpoint.projectID == session.projectID, session.projectID != nil {
                rows = TechnicalAddressPolicy.reclassify(ResultMerge.combine(checkpoint.rows, rows))
                scanned = checkpoint.scanned; domainsScanned = checkpoint.domainPageCount.count; domainsDiscovered = checkpoint.discoveredCount
                showSavedQueue(checkpoint)
            }
            progress = "Restored autosaved project with \(rows.count) original records"
        } else if let snapshot = CrawlDisk.load() {
            applyCheckpoint(snapshot); progress = "Recovered \(rows.count) records from the crawl checkpoint"
        } else if let error = CrawlDisk.lastError { progress = "Could not restore saved data: " + error }
        restoring = false
        CrawlDisk.updatePresentation(rules: smartRules, removal: removal, projectID: projectID)
    }
    private func showSavedQueue(_ snapshot: CrawlProgress) {
        let pending = snapshot.queue.filter { !snapshot.visited.contains($0.url) }.map { $0.url }
        reportActivity(CrawlActivity(url: "", phase: "Idle", pending: pending.count, message: pending.isEmpty ? "No eligible links remain" : "Saved pages ready to resume", activeSites: [], queuedPages: pending))
    }
    private func applyCheckpoint(_ snapshot: CrawlProgress) {
        showSavedQueue(snapshot)
        projectID = snapshot.projectID ?? projectID
        let o = snapshot.settings
        concurrentSites = min(8, max(1, o.concurrentSites ?? 1))
        followExternalLinks = o.followExternalLinks ?? false; topicContext = o.topic ?? ""
        depth = min(20, max(0, o.depth)); maxPages = max(0, o.maxPages); maxPagesPerDomain = max(0, o.maxPagesPerDomain)
        excluded = o.excluded; stripDuplicates = o.stripDuplicates; excludeRole = o.excludeRole; excludeFree = o.excludeFree
        excludeDisposable = o.excludeDisposable; checkDNS = o.checkDNS
        mode = .website; input = snapshot.input; rows = TechnicalAddressPolicy.reclassify(snapshot.rows)
        smartRules = snapshot.smartRules ?? smartRules
        removal = RemovalState(addresses: snapshot.removedAddresses ?? removal.addresses, history: snapshot.removalHistory ?? removal.history)
        scanned = snapshot.scanned; domainsScanned = snapshot.domainPageCount.count; domainsDiscovered = snapshot.discoveredCount
    }
    func restoreLastRemoval() { removal.undo(); progress = "Last removal restored; filtering rules unchanged" }
    func restoreAllRemoved() { removal.restoreAll(); progress = "Manually removed records restored; filtering rules unchanged" }

    func removeSelectedResults(_ identifiers: Set<UUID>) {
        let addresses = Set(rows.filter { identifiers.contains($0.id) }.map { $0.address.lowercased() })
        suppress(addresses)
    }

    func excludeMatchingResults(_ term: String) {
        let needle = term.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !needle.isEmpty else { progress = "Enter an address or domain filter first"; return }
        let wildcard = SafeWildcard.containsWildcard(needle) ? SafeWildcard(needle) : nil
        let addresses = Set(rows.filter { wildcard?.matches($0.address) ?? $0.address.lowercased().contains(needle) }.map { $0.address.lowercased() })
        suppress(addresses)
    }

    private func suppress(_ addresses: Set<String>) {
        let fresh = addresses.filter { !isRemoved($0) }
        guard !fresh.isEmpty else { progress = "No new matching addresses to remove"; return }
        removal.remove(fresh)
        progress = "Removed \(fresh.count) addresses; no filtering rule added. Use Restore last removal to undo."

    }

    @Published var discoveredSites: [DiscoveredSite] = [] { didSet { scheduleAutosave() } }
    @Published var discovering = false
    @Published var discoveryWarning: String?
    @Published var directoryDiscovery = true { didSet { scheduleAutosave() } }
    @Published var osmStateCode = "" { didSet { scheduleAutosave() } }
    @Published var running = false
    @Published var paused = false
    @Published var activePages: [String] = []
    @Published var queuedPageURLs: [String] = []
    @Published var pendingPageCount = 0
    @Published var currentActivity: CrawlActivity?
    @Published var recentActivity: [CrawlActivity] = []
    func reportActivity(_ event: CrawlActivity) {
        if let active = event.activeSites { activePages = active }
        if let waiting = event.queuedPages { queuedPageURLs = waiting }
        if event.phase == "Queue" || event.phase == "Idle" { pendingPageCount = event.pending }
        if event.phase == "Queue" { return }
        currentActivity = event
        if event.phase == "Completed" || event.phase == "Skipped" {
            recentActivity.insert(event, at: 0)
            if recentActivity.count > 100 { recentActivity.removeLast(recentActivity.count - 100) }
        }
    }
    private var crawlDisplayTimer: DispatchSourceTimer?
    private var crawlDisplayBuffer: CrawlDisplayBuffer?
    private func applyDisplayBatch(_ batch: CrawlDisplayBatch) {
        guard !batch.isEmpty else { return }
        if !batch.rows.isEmpty { rows.append(contentsOf: batch.rows) }
        if let counters = batch.counters {
            if scanned != counters.pages { scanned = counters.pages }
            if domainsDiscovered != counters.discovered { domainsDiscovered = counters.discovered }
            if domainsScanned != counters.scannedSites { domainsScanned = counters.scannedSites }
            if progress != counters.message { progress = counters.message }
        }
        if !batch.recent.isEmpty {
            recentActivity = Array((Array(batch.recent.reversed()) + recentActivity).prefix(100))
        }
        func applyQueue(_ event: CrawlActivity) {
            if let active = event.activeSites, activePages != active { activePages = active }
            if let waiting = event.queuedPages, queuedPageURLs != waiting { queuedPageURLs = waiting }
            if (event.phase == "Queue" || event.phase == "Idle") && pendingPageCount != event.pending { pendingPageCount = event.pending }
        }
        if let queue = batch.queue { applyQueue(queue) }
        if let event = batch.current {
            applyQueue(event)
            if currentActivity?.url != event.url || currentActivity?.phase != event.phase || currentActivity?.message != event.message {
                currentActivity = event
            }
        }
    }
    private func startDisplayUpdates(_ buffer: CrawlDisplayBuffer) {
        crawlDisplayTimer?.cancel(); crawlDisplayBuffer = buffer
        let timer = DispatchSource.makeTimerSource(queue: .main)
        timer.schedule(deadline: .now(), repeating: .milliseconds(200), leeway: .milliseconds(30))
        timer.setEventHandler { [weak self] in
            guard let self = self, self.crawlDisplayBuffer === buffer else { return }
            self.applyDisplayBatch(buffer.drain())
        }
        crawlDisplayTimer = timer; timer.resume()
    }
    private func finishDisplayUpdates(_ buffer: CrawlDisplayBuffer) {
        guard crawlDisplayBuffer === buffer else { return }
        crawlDisplayTimer?.cancel(); crawlDisplayTimer = nil; crawlDisplayBuffer = nil
        applyDisplayBatch(buffer.drain())
    }
    @Published var progress = "Ready"
    @Published var persistenceError: String?
    @Published var scanned = 0
    @Published var domainsScanned = 0
    @Published var domainsDiscovered = 0
    @Published var smtpOptions = SMTPOptions() { didSet { scheduleAutosave() } }
    @Published var verifierKey = ""
    @Published var verifying = false
    private var worker: Thread?
    private var crawlControl: CrawlControl?
    private var continuationEngine: GrabEngine?
    private var continuationContext: CrawlInputContext?
    @Published var canContinue = false
    private var verifierWorker: Thread?
    private var discoveryControl: CrawlControl?
    private var discoverySignature = ""
    private var startAfterDiscovery = false
    private var currentDiscoverySignature: String { "\(osmStateCode)|\(directoryDiscovery)|\(input)" }

    func discover() {
        guard !running && !verifying && !discovering && mode == .keywords else { return }
        let query = input
        let terms = query.split(whereSeparator: \.isNewline).map(String.init).filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
        guard !terms.isEmpty else { progress = "Enter search keywords first"; return }
        discovering = true; discoveryWarning = nil
        discoveredSites = []
        progress = "Discovering websites…"
        let control = CrawlControl()
        discoveryControl = control
        let settings = GrabSettings(depth: depth, maxPages: maxPages, maxPagesPerDomain: maxPagesPerDomain, exclude: excluded, duplicates: stripDuplicates, role: excludeRole, free: excludeFree, disposable: excludeDisposable, dns: checkDNS, followExternalLinks: followExternalLinks, topic: mode == .keywords ? input : topicContext, concurrentSites: concurrentSites)
        let scanDirectories = directoryDiscovery
        let stateCode = osmStateCode
        let category = OSMBusinessCategories.match(keyword: terms.joined(separator: " "))
        let location = USStates.all.first(where: { $0.code == stateCode })?.name
        let searchTerms = location.map { place in terms.map { "\($0) \(place)" } } ?? terms
        let signature = currentDiscoverySignature
        Thread { [weak self] in
            let report: (String) -> Void = { message in DispatchQueue.main.async { [weak self] in self?.progress = message } }
            let discoveryEngine = GrabEngine(settings: settings)
            var result = discoveryEngine.discoverSites(terms: searchTerms, exploreDirectories: scanDirectories, nationwide: stateCode.isEmpty, shouldStop: { control.checkpoint() }, progress: report)
            if let category = category, !stateCode.isEmpty, !control.wasCancelled {
                let regional = OpenStreetMapDiscovery.discoverBusinesses(stateCode: stateCode, category: category, shouldStop: { control.checkpoint() }, progress: report)
                var known = Set(result.map { $0.host.lowercased().replacingOccurrences(of: "www.", with: "", options: .anchored) })
                for site in regional {
                    let host = site.host.lowercased().replacingOccurrences(of: "www.", with: "", options: .anchored)
                    if known.insert(host).inserted { result.append(site) }
                }
            }
            DispatchQueue.main.async { [weak self] in
                if control.wasCancelled {
                    self?.startAfterDiscovery = false
                    self?.progress = "Discovery stopped"
                    self?.discovering = false
                    self?.discoveryControl = nil
                    return
                }
                self?.discoveryWarning = discoveryEngine.discoveryWarning
                self?.discoveredSites = result
                self?.discoverySignature = signature
                self?.discovering = false
                self?.discoveryControl = nil
                if self?.startAfterDiscovery == true {
                    self?.startAfterDiscovery = false
                    if result.isEmpty { self?.progress = "No candidate websites discovered. Try a narrower location or import a website list." }
                    else { self?.start() }
                } else {
                    self?.progress = "Discovered \(result.count) website candidates. Review selections, then Start."
                }
            }
        }.start()
    }

    func setAllSites(_ selected: Bool) {
        for i in discoveredSites.indices { discoveredSites[i].selected = selected }
    }
    func cancelDiscovery() { startAfterDiscovery = false; discoveryControl?.cancel(); progress = "Stopping discovery…" }
    func clearDiscoveredSites() { guard !running && !discovering else { return }; discoveredSites = []; discoverySignature = "" }
    func exportDiscoveredSites() {
        guard !discoveredSites.isEmpty else { return }
        let panel = NSSavePanel()
        panel.allowedContentTypes = [.commaSeparatedText]
        panel.nameFieldStringValue = "discovered-websites.csv"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        func escaped(_ value: String) -> String { EmailPolicy.csvField(value) }
        let lines = discoveredSites.map { "\(escaped($0.url)),\(escaped($0.origin)),\($0.selected)" }
        do {
            try (["website,source,selected"] + lines).joined(separator: "\r\n").appending("\r\n").write(to: url, atomically: true, encoding: .utf8)
            progress = "Exported \(discoveredSites.count) discovered website candidates"
        } catch { progress = "Could not export website list: \(error.localizedDescription)" }
    }

    func start() { beginCrawl(resume: false) }
    func continueCrawl() { beginCrawl(resume: true) }
    private func beginCrawl(resume: Bool) {
        guard !running && !verifying && !discovering else { return }
        if resume && (continuationEngine == nil || !canContinue) { progress = "No remaining pages to continue"; return }
        let terms = input.split(whereSeparator: \.isNewline).map { String($0).trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
        let useReviewedSites = mode == .keywords && discoverySignature == currentDiscoverySignature && !discoveredSites.isEmpty
        if !resume && mode == .keywords && !useReviewedSites {
            guard !terms.isEmpty else { progress = "Enter at least one keyword"; return }
            startAfterDiscovery = true
            discover()
            return
        }
        guard !terms.isEmpty || useReviewedSites else { progress = "Enter at least one input or discover websites first."; return }
        let settings = GrabSettings(depth: depth, maxPages: maxPages, maxPagesPerDomain: maxPagesPerDomain, exclude: excluded, duplicates: stripDuplicates, role: excludeRole, free: excludeFree, disposable: excludeDisposable, dns: checkDNS, followExternalLinks: followExternalLinks, topic: mode == .keywords ? input : topicContext, concurrentSites: concurrentSites)
        if resume, let engine = continuationEngine, engine.settings != settings { progress = "Settings changed; start a new crawl or restore the previous settings before continuing"; return }
        let selectedURLs = discoveredSites.filter(\.selected).map(\.url)
        if useReviewedSites && selectedURLs.isEmpty { progress = "Select at least one discovered website"; return }
        let context = CrawlInputContext(mode: mode, input: input, reviewedSites: useReviewedSites ? selectedURLs : [])
        if resume && continuationContext != context { progress = "Inputs changed; use Resume saved crawl to restore the old job, or Start a new search"; return }
        if !resume { continuationContext = context }
        let sourceMode: SourceMode = useReviewedSites ? .website : mode
        let inputs = useReviewedSites ? selectedURLs : terms
        running = true
        paused = false
        let control = CrawlControl()
        crawlControl = control
        if !resume {
            scanned = 0; domainsScanned = 0; domainsDiscovered = 0
            currentActivity = nil; recentActivity.removeAll(); activePages.removeAll(); queuedPageURLs.removeAll(); pendingPageCount = 0
            continuationEngine = GrabEngine(settings: settings)
        }
        canContinue = false
        progress = resume ? "Continuing next batch…" : "Starting…"
        let initial = rows
        guard let engine = continuationEngine else { return }
        flushAutosave()
        let display = CrawlDisplayBuffer()
        startDisplayUpdates(display)
        let thread = Thread { [weak self] in
            let result = engine.run(mode: sourceMode, terms: inputs, existing: initial, liveRows: { display.append($0) }, update: { count, foundDomains, visitedDomains, message in
                display.report(CrawlCounters(pages: count, discovered: foundDomains, scannedSites: visitedDomains, message: message))
            }, shouldStop: { control.checkpoint() }, activity: { display.report($0) })
            let wasStopped = control.wasCancelled
            let failure = engine.lastFailure
            DispatchQueue.main.async { [weak self] in
                self?.finishDisplayUpdates(display)
                self?.rows = result
                self?.canContinue = engine.hasRemainingPages
                self?.running = false
                self?.paused = false
                self?.crawlControl = nil
                self?.progress = failure ?? (wasStopped ? "Stopped; remaining pages saved and available to continue" : (engine.hasRemainingPages ? "Batch complete: \(result.count) addresses. Continue to scan more pages." : "Finished: \(result.count) addresses; \(result.filter { $0.status == "Accepted" }.count) locally checked"))
                self?.flushAutosave()
            }
        }
        worker = thread
        thread.start()
    }

    func resumeSavedCrawl() {
        guard !running && !discovering && !verifying else { return }
        guard let snapshot = CrawlDisk.load() else { progress = "No readable saved crawl checkpoint"; return }
        let currentRows = rows
        restoring = true; applyCheckpoint(snapshot)
        rows = TechnicalAddressPolicy.reclassify(ResultMerge.combine(snapshot.rows, currentRows))
        restoring = false; CrawlDisk.updatePresentation(rules: smartRules, removal: removal, projectID: projectID); flushAutosave()
        guard !snapshot.queue.isEmpty else { progress = "Restored \(rows.count) records; no unscanned links remain"; return }
        let settings = GrabSettings(depth: depth, maxPages: maxPages, maxPagesPerDomain: maxPagesPerDomain, exclude: excluded, duplicates: stripDuplicates, role: excludeRole, free: excludeFree, disposable: excludeDisposable, dns: checkDNS, followExternalLinks: followExternalLinks, topic: mode == .keywords ? input : topicContext, concurrentSites: concurrentSites)
        let engine = GrabEngine(settings: settings); engine.restore(snapshot)
        continuationEngine = engine; continuationContext = CrawlInputContext(mode: mode, input: input, reviewedSites: []); canContinue = true
        beginCrawl(resume: true)
    }
    func pause() { guard running && !paused else { return }; crawlControl?.pause(); paused = true; progress = "Pausing after current request…" }
    func resume() { guard running && paused else { return }; paused = false; crawlControl?.resume(); progress = "Resumed" }
    func stop() { startAfterDiscovery = false; crawlControl?.cancel(); discoveryControl?.cancel(); worker?.cancel(); paused = false; progress = "Stopping after current request…" }
    func storeVerificationKey() {
        let key = verifierKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { progress = "Enter your ZeroBounce API key first"; return }
        progress = AdvancedVerifier.saveAPIKey(key) ? "Verification key stored in Mac Keychain" : "Could not store API key"
        verifierKey = ""
    }

    func verifyWithZeroBounce(selected: Set<UUID>? = nil) {
        guard !running && !verifying && !discovering else { return }
        guard let key = AdvancedVerifier.loadAPIKey(), !key.isEmpty else {
            progress = "Store a ZeroBounce API key to enable optional checks"
            return
        }
        let targets = VerificationApplication.targets(rows, selected: selected, rules: smartRules, removed: removal.addresses)
        guard !targets.isEmpty else { progress = "No eligible addresses to verify"; return }
        let confirmation = NSAlert()
        confirmation.messageText = "Send \(targets.count) addresses to ZeroBounce?"
        confirmation.informativeText = "This transmits the selected addresses to ZeroBounce and may use up to \(targets.count) verification credits. It cannot guarantee delivery. No requests run automatically."
        confirmation.alertStyle = .warning
        confirmation.addButton(withTitle: "Verify \(targets.count) addresses")
        confirmation.addButton(withTitle: "Cancel")
        guard confirmation.runModal() == .alertFirstButtonReturn else { return }
        verifying = true
        progress = "Verifying 0 / \(targets.count)"
        let thread = Thread { [weak self] in
            for (position, address) in targets.enumerated() {
                if Thread.current.isCancelled { break }
                let eligible = DispatchQueue.main.sync { [weak self] in
                    guard let self = self else { return false }
                    return self.rows.contains { $0.address.lowercased() == address.lowercased() && VerificationApplication.eligible($0, rules: self.smartRules, removed: self.removal.addresses) }
                }
                if !eligible { continue }
                let answer = AdvancedVerifier.validate(email: address, apiKey: key)
                DispatchQueue.main.sync { [weak self] in
                    guard let self = self else { return }
                    let record = ProviderVerification(status: answer.status, reason: answer.reason, requestFailed: answer.requestFailed)
                    for index in self.rows.indices where self.rows[index].address.lowercased() == address.lowercased() {
                        VerificationApplication.provider(record, to: &self.rows[index])
                    }
                    self.flushAutosave()
                    self.progress = "Processed \(position + 1) / \(targets.count) verification checks"
                }
                if answer.stopBatch {
                    DispatchQueue.main.async { [weak self] in self?.progress = "Verification stopped: " + answer.reason }
                    break
                }
            }
            DispatchQueue.main.async { [weak self] in self?.verifying = false; self?.flushAutosave() }
        }
        verifierWorker = thread
        thread.start()
    }
    func verifySMTP(selected: Set<UUID>? = nil, retryInconclusive: Bool = false) {
        guard !running && !verifying && !discovering else { return }
        let options = smtpOptions
        guard options.valid else { progress = "Enter your EHLO hostname and sender email before SMTP checks"; return }
        let targets = VerificationApplication.targets(rows, selected: selected, rules: smartRules, removed: removal.addresses, uncheckedOnly: selected == nil && !retryInconclusive, retryDueOnly: retryInconclusive)
        guard !targets.isEmpty else { progress = retryInconclusive ? "No inconclusive checks are due yet; Show evidence lists retry timing" : "No eligible unchecked addresses; select rows to recheck"; return }
        let targetAddresses = Set(targets.map { $0.lowercased() })
        let sourceTargets = WebsiteConfirmationPolicy.targets(rows.filter { targetAddresses.contains($0.address.lowercased()) }, selected: selected, rules: smartRules, removed: removal.addresses)
        let sourcesByAddress = Dictionary(grouping: sourceTargets, by: { $0.address.lowercased() })
        let confirmation = NSAlert()
        confirmation.messageText = "Check \(targets.count) addresses via SMTP?"
        confirmation.informativeText = "This contacts recipient mail servers on port 25 using your sender identity. Each accepted target is compared with two random recipients. No message is sent. This also revisits the saved source websites to look for the exact addresses. Publication and SMTP acceptance cannot guarantee delivery. " + (options.requireTLS ? "Verified TLS is required." : "Plaintext is permitted only when STARTTLS is not offered; failed TLS never downgrades.")
        confirmation.addButton(withTitle: "Check via SMTP")
        confirmation.addButton(withTitle: "Cancel")
        guard confirmation.runModal() == .alertFirstButtonReturn else { return }
        verifying = true
        progress = "Starting SMTP verification"
        let thread = Thread { [weak self] in
            let verifier = MailboxVerifier()
            let website = WebsiteConfirmer(render: WebsiteBrowserRenderer.defaultRender)
            var failedDomains = Set<String>()
            for (position, address) in targets.enumerated() {
                if Thread.current.isCancelled { break }
                let eligible = DispatchQueue.main.sync { [weak self] in
                    guard let self = self else { return false }
                    return self.rows.contains { $0.address.lowercased() == address.lowercased() && VerificationApplication.eligible($0, rules: self.smartRules, removed: self.removal.addresses) }
                }
                if !eligible { continue }
                let answer = verifier.verify(address, options: options, cancelled: { Thread.current.isCancelled })
                var publications: [(WebsiteTarget, WebsiteConfirmation)] = []
                for target in sourcesByAddress[address.lowercased()] ?? [] {
                    if Thread.current.isCancelled { break }
                    publications.append((target, website.confirm(address: address, source: target.source, knownPage: target.knownPage, cancelled: { Thread.current.isCancelled })))
                }
                let completedPublications = publications
                DispatchQueue.main.sync { [weak self] in
                    guard let self = self else { return }
                    for index in self.rows.indices where self.rows[index].address.lowercased() == address.lowercased() {
                        VerificationApplication.smtp(answer, to: &self.rows[index])
                    }
                    for (target, publication) in completedPublications {
                        self.applyWebsiteConfirmation(publication, target: target)
                    }
                    self.progress = "SMTP + website \(position + 1) / \(targets.count): " + answer.verdict.rawValue
                    self.flushAutosave()
                }
                if answer.connectionFailed { failedDomains.insert(String(address.split(separator: "@").last ?? "").lowercased()) }
                if failedDomains.count >= 3 {
                    DispatchQueue.main.async { [weak self] in self?.progress = "SMTP batch stopped: three domains unreachable; outbound port 25 may be restricted" }
                    break
                }
            }
            DispatchQueue.main.async { [weak self] in self?.verifying = false; self?.flushAutosave() }
        }
        verifierWorker = thread
        thread.start()
    }
    private func applyWebsiteConfirmation(_ confirmation: WebsiteConfirmation, target: WebsiteTarget) {
        let ids = Set(target.ids)
        for index in rows.indices where ids.contains(rows[index].id) && rows[index].source == target.source && rows[index].address.lowercased() == target.address.lowercased() {
            WebsiteConfirmationPolicy.apply(confirmation, to: &rows[index])
        }
    }
    func confirmWebsite(selected: Set<UUID>? = nil) {
        guard !running && !verifying && !discovering else { return }
        let candidates = selected == nil ? rows.filter { $0.websiteConfirmation == nil } : rows
        let targets = WebsiteConfirmationPolicy.targets(candidates, selected: selected, rules: smartRules, removed: removal.addresses)
        guard !targets.isEmpty else { progress = selected == nil ? "No unchecked website sources; select rows to recheck fresh" : "No eligible addresses selected for website confirmation"; return }
        verifying = true
        progress = "Checking fresh website sources"
        let thread = Thread { [weak self] in
            let website = WebsiteConfirmer(render: WebsiteBrowserRenderer.defaultRender)
            for (position, target) in targets.enumerated() {
                if Thread.current.isCancelled { break }
                let eligible = DispatchQueue.main.sync { [weak self] in
                    guard let self = self else { return false }
                    return self.rows.contains { target.ids.contains($0.id) && $0.source == target.source && VerificationApplication.eligible($0, rules: self.smartRules, removed: self.removal.addresses) }
                }
                if !eligible { continue }
                let answer = website.confirm(address: target.address, source: target.source, knownPage: target.knownPage, cancelled: { Thread.current.isCancelled })
                DispatchQueue.main.sync { [weak self] in
                    guard let self = self else { return }
                    self.applyWebsiteConfirmation(answer, target: target)
                    self.progress = "Website \(position + 1) / \(targets.count): " + answer.label
                    self.flushAutosave()
                }
            }
            DispatchQueue.main.async { [weak self] in self?.verifying = false; self?.flushAutosave() }
        }
        verifierWorker = thread
        thread.start()
    }
    func showVerificationEvidence(_ id: UUID) {
        guard let row = rows.first(where: { $0.id == id }) else { return }
        let details = VerificationEvidence.text(row)
        let alert = NSAlert()
        alert.messageText = "Verification evidence: " + row.address
        alert.informativeText = "Server responses, retry timing, and earlier checks. Acceptance is not a delivery guarantee."
        let scroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: 640, height: 320))
        scroll.hasVerticalScroller = true
        let text = NSTextView(frame: scroll.bounds)
        text.isEditable = false
        text.isSelectable = true
        text.isVerticallyResizable = true
        text.isHorizontallyResizable = false
        text.autoresizingMask = [.width]
        text.textContainer?.widthTracksTextView = true
        text.font = NSFont.monospacedSystemFont(ofSize: 11, weight: .regular)
        text.string = details
        scroll.documentView = text
        alert.accessoryView = scroll
        alert.addButton(withTitle: "Close")
        alert.addButton(withTitle: "Copy evidence")
        if alert.runModal() == .alertSecondButtonReturn {
            NSPasteboard.general.clearContents()
            NSPasteboard.general.setString(details, forType: .string)
        }
    }
    func stopVerification() { verifierWorker?.cancel(); progress = "Stopping verification after current check…" }
    func clear() { guard !running && !verifying && !discovering else { return }; rows.removeAll(); removal.restoreAll(); currentActivity = nil; recentActivity.removeAll(); activePages.removeAll(); queuedPageURLs.removeAll(); pendingPageCount = 0; projectID = UUID(); continuationEngine = nil; canContinue = false; CrawlDisk.clear(); CrawlDisk.updatePresentation(rules: smartRules, removal: removal, projectID: projectID); flushAutosave(); progress = "Results cleared; reusable rules retained" }

    func importFile() {
        guard !running && !verifying && !discovering else { return }
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.plainText, .commaSeparatedText, .html] + ["xlsx", "tsv"].compactMap { UTType(filenameExtension: $0) }
        panel.allowsMultipleSelection = true
        guard panel.runModal() == .OK else { return }
        var imports: [String] = []
        var failures: [String] = []
        for url in panel.urls {
            do { imports.append(try FileImport.text(from: url)) }
            catch { failures.append("\(url.lastPathComponent): \(error.localizedDescription)") }
        }
        let content = imports.joined(separator: "\n")
        mode = .pasted
        input = content
        progress = failures.isEmpty ? "Imported \(imports.count) file(s). Run to extract addresses." : "Imported \(imports.count); failed: \(failures.joined(separator: "; "))"
    }

    func importWebsiteList() {
        guard !running && !verifying && !discovering else { return }
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.plainText, .commaSeparatedText] + ["xlsx", "tsv"].compactMap { UTType(filenameExtension: $0) }
        panel.allowsMultipleSelection = true
        guard panel.runModal() == .OK else { return }
        var websiteURLs = Set<String>()
        var addresses: [String] = []
        for file in panel.urls {
            guard let content = try? FileImport.text(from: file) else { continue }
            for line in content.split(whereSeparator: \.isNewline) {
                let value = String(line).trimmingCharacters(in: .whitespacesAndNewlines)
                if value.isEmpty || value.contains("@") || value.contains(" ") { continue }
                guard let url = GrabEngine.normalizedURL(value), let host = url.host?.lowercased(), host.contains(".") else { continue }
                if websiteURLs.insert(url.absoluteString).inserted { addresses.append(url.absoluteString) }
            }
        }
        mode = .website
        input = addresses.joined(separator: "\n")
        progress = "Imported \(addresses.count) distinct website URLs; set page limits and Start"
    }

    func exportCSV(onlyAccepted: Bool) {
        let panel = NSSavePanel()
        panel.nameFieldStringValue = onlyAccepted ? "email-grabber-accepted.csv" : "email-grabber-all.csv"
        panel.allowedContentTypes = [.commaSeparatedText]
        guard panel.runModal() == .OK, let url = panel.url else { return }
        let target = ResultPolicy.exportRows(rows, rules: smartRules, removed: removal.addresses, onlyAccepted: onlyAccepted)
        func q(_ s: String) -> String { EmailPolicy.csvField(s) }
        let header = VerificationCSV.header
        let lines = target.map(VerificationCSV.line)
        do { try ([header] + lines).joined(separator: "\r\n").appending("\r\n").write(to: url, atomically: true, encoding: .utf8); progress = "Exported \(target.count) rows" }
        catch { progress = "Export failed: \(error.localizedDescription)" }
    }

    func saveSession() {
        let panel = NSSavePanel()
        panel.nameFieldStringValue = "email-grabber-session.json"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        let session = makeSession()
        do { try JSONEncoder().encode(session).write(to: url, options: .atomic); progress = "Saved complete project" }
        catch { progress = "Could not save session: \(error.localizedDescription)" }
    }

    func openSession() {
        guard !running && !verifying && !discovering else { return }
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.json]
        guard panel.runModal() == .OK, let url = panel.url else { return }
        do {
            guard (try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0) <= 64_000_000 else { progress = "Project exceeds the 64 MB import limit"; return }
            let data = try Data(contentsOf: url)
            if let session = try? JSONDecoder().decode(GrabSession.self, from: data) {
                guard session.version <= 3 else { progress = "This project requires a newer application version"; return }
                restoring = true; CrawlDisk.clear(); apply(session)
                continuationEngine = nil; canContinue = false; restoring = false
                CrawlDisk.updatePresentation(rules: smartRules, removal: removal, projectID: projectID); flushAutosave()
                progress = "Opened project with \(rows.count) records"
            } else {
                let imported = try JSONDecoder().decode([FoundEmail].self, from: data)
                restoring = true; CrawlDisk.clear(); projectID = UUID(); rows = TechnicalAddressPolicy.reclassify(imported); removal = RemovalState(); smartRules = []
                continuationEngine = nil; canContinue = false; restoring = false; CrawlDisk.updatePresentation(rules: smartRules, removal: removal, projectID: projectID); flushAutosave()
                progress = "Opened older results file with \(rows.count) records"
            }
        }
        catch { progress = "Could not open session: \(error.localizedDescription)" }
    }
}

@MainActor struct ResultsPane: View, Equatable {
    let model: GrabberModel
    let revision: Int
    let running: Bool
    let discovering: Bool
    let verifying: Bool
    let canContinue: Bool
    nonisolated static func == (lhs: ResultsPane, rhs: ResultsPane) -> Bool {
        lhs.model === rhs.model && lhs.revision == rhs.revision && lhs.running == rhs.running &&
        lhs.discovering == rhs.discovering && lhs.verifying == rhs.verifying && lhs.canContinue == rhs.canContinue
    }
    @State private var selectedStatus = "Included"
    @State private var selectedResultIDs = Set<UUID>()
    @State private var resultSearch = ""
    @State private var resultSearchScope = "Email"
    @State private var sortOrder: [KeyPathComparator<FoundEmail>] = []
    @State private var showingRuleSheet = false
    @State private var ruleKind = "Prefix"
    @State private var rulePattern = ""
    private var suggestedAddress: String? { model.rows.first { selectedResultIDs.contains($0.id) }?.address }
    private func makeSuggestion() {
        guard let email = suggestedAddress else {
            ruleKind = SafeWildcard.containsWildcard(resultSearch) ? "Wildcard" : "Contains"; rulePattern = resultSearch; return
        }
        ruleKind = "Prefix"
        rulePattern = String(email.split(separator: "@").first ?? "")
    }

    @State private var visible: [FoundEmail] = []
    @State private var filterCache = ResultsFilterCache()
    private func rebuildVisible() {
        let next = filterCache.update(model.rows, rules: model.smartRules, removed: model.removal.addresses, status: selectedStatus, search: resultSearch, scope: resultSearchScope, sort: sortOrder)
        if next != visible { visible = next }
    }
    private var resultOrder: Binding<String> {
        Binding(get: { ResultOrdering.label(sortOrder) }, set: { choice in
            if let comparators = ResultOrdering.comparators(choice) { sortOrder = comparators }
        })
    }

    private func toggleResultSelection(_ id: UUID) {
        selectedResultIDs = ResultSelection.updated(selectedResultIDs, id: id)
    }
    private func resultCell(_ row: FoundEmail, text: String) -> some View {
        Text(text).textSelection(.enabled)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
            .background(selectedResultIDs.contains(row.id) ? Color.accentColor.opacity(0.18) : Color.clear)
            .contentShape(Rectangle())
            .simultaneousGesture(TapGesture().onEnded { toggleResultSelection(row.id) })
    }

    private func copyEmails(_ addresses: [String]) {
        guard !addresses.isEmpty else { return }
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(addresses.joined(separator: "\n"), forType: .string)
    }

    var body: some View {
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text("Results (\(visible.count)) · Accepted = local checks only, mailbox not verified").font(.headline)
                        Spacer()
                        Picker("Status", selection: $selectedStatus) {
                            ForEach(["Included", "All", "Accepted", "Verified", "Uncertain", "Rejected", "Excluded", "Removed"], id: \.self) { Text($0) }
                        }.frame(width: 150)
                    }
                    HStack {
                        Picker("Filter field", selection: $resultSearchScope) {
                            ForEach(["Email", "Domain", "Source", "All fields"], id: \.self) { Text($0) }
                        }
                        .labelsHidden()
                        .frame(width: 115)
                        TextField("Filter \(resultSearchScope.lowercased()) (* or ?)", text: $resultSearch)
                            .textFieldStyle(.roundedBorder)
                            .help("Plain text finds a substring. Wildcards match the whole field: * means any text; ? means one character. Example: *@example.org")
                        Button("Remove / Filter…") {
                            makeSuggestion()
                            showingRuleSheet = true
                        }.disabled(selectedResultIDs.isEmpty && resultSearch.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                        Button("Undo last rule") { model.undoRule() }.disabled(model.smartRules.isEmpty)
                        Text("Rules: \(model.smartRules.count)").font(.caption).foregroundStyle(.secondary)
                        Button("Reset filter") { resultSearch = "" }.disabled(resultSearch.isEmpty)
                    }
                    .help("Preview a reusable exclusion rule. Originals are preserved and rules can be undone.")
                    HStack {
                        Picker("Order", selection: resultOrder) {
                            Text("Found order").tag("Found order")
                            Text("Email A–Z").tag("Email A–Z")
                            Text("Email Z–A").tag("Email Z–A")
                            Text("Column sort").tag("Column sort").disabled(true)
                        }.frame(width: 165)
                        Button("Copy selected") { copyEmails(visible.filter { selectedResultIDs.contains($0.id) }.map(\.address)) }.disabled(selectedResultIDs.isEmpty)
                        Button("Show evidence") {
                            if let row = model.rows.first(where: { selectedResultIDs.contains($0.id) }) {
                                model.showVerificationEvidence(row.id)
                            }
                        }.disabled(selectedResultIDs.count != 1)
                        .help("Select one row using its checkbox, then view or copy its SMTP and website evidence.")
                        Text("\(selectedResultIDs.count) selected").font(.caption).foregroundStyle(.secondary)
                        Spacer()
                    }
                    HStack {
                        Button("Confirm selected on website") { model.confirmWebsite(selected: selectedResultIDs) }.disabled(selectedResultIDs.isEmpty || model.running || model.verifying || model.discovering)
                        Button("Verify selected (SMTP)") { model.verifySMTP(selected: selectedResultIDs) }.disabled(selectedResultIDs.isEmpty || model.running || model.verifying || model.discovering)
                        Button("Compare selected (ZeroBounce)") { model.verifyWithZeroBounce(selected: selectedResultIDs) }.disabled(selectedResultIDs.isEmpty || model.running || model.verifying || model.discovering)
                    }
                    HStack {
                        Button("Select visible") { selectedResultIDs = Set(visible.map(\.id)) }
                        Button("Remove selected") { model.removeSelectedResults(selectedResultIDs); selectedResultIDs.removeAll() }.disabled(selectedResultIDs.isEmpty)
                        Button("Remove all matching") { model.removeSelectedResults(Set(visible.map(\.id))); selectedResultIDs.removeAll() }.disabled(resultSearch.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || visible.isEmpty)
                        Button("Restore last removal") { model.restoreLastRemoval() }.disabled(model.removal.history.isEmpty)
                        Button("Restore all removed") { model.restoreAllRemoved() }.disabled(model.removal.addresses.isEmpty)
                    }
                    .help("Manual removal is recoverable and does not add an exclusion rule.")
                    Table(visible, sortOrder: $sortOrder) {
                        TableColumn("") { row in
                            Toggle("Select " + row.address, isOn: Binding(get: {
                                selectedResultIDs.contains(row.id)
                            }, set: { selected in
                                selectedResultIDs = ResultSelection.updated(selectedResultIDs, id: row.id, selected: selected)
                            }))
                            .toggleStyle(.checkbox).labelsHidden()
                        }.width(24)
                        TableColumn("Email", value: \.address) { row in
                            resultCell(row, text: row.address)
                                .contextMenu {
                                    Button("Copy email") { copyEmails([row.address]) }
                                    Button("Show verification evidence") { model.showVerificationEvidence(row.id) }
                                    Button("Confirm on website") { model.confirmWebsite(selected: [row.id]) }.disabled(model.running || model.verifying || model.discovering)
                                    Button("Remove email") { model.removeSelectedResults([row.id]); selectedResultIDs.remove(row.id) }
                                }
                        }.width(min: 160)
                        TableColumn("Status", value: \.status) { row in resultCell(row, text: model.displayStatus(row)) }.width(min: 75)
                        TableColumn("SMTP") { row in resultCell(row, text: row.smtpVerification?.verdict.rawValue ?? "Unchecked").help(row.smtpVerification?.reason ?? "No SMTP check") }.width(min: 100)
                        TableColumn("Website") { row in
                            resultCell(row, text: row.websiteConfirmation?.label ?? "Unchecked")
                                .help(row.websiteConfirmation?.summary ?? "No fresh source check")
                        }.width(min: 150)
                        TableColumn("ZeroBounce") { row in resultCell(row, text: row.providerVerification?.status ?? "Unchecked").help(row.providerVerification?.reason ?? "No provider check") }.width(min: 90)
                        TableColumn("Reason", value: \.reason) { row in resultCell(row, text: ResultPolicy.displayedReason(row)) }.width(min: 170)
                        TableColumn("Source", value: \.source) { row in resultCell(row, text: row.source) }.width(min: 180)
                    }
                    .help("Click rows or use checkboxes to add/remove selections. Earlier selections remain selected while extraction continues.")
                    HStack {
                        Button("Continue next batch") { model.continueCrawl() }.disabled(!model.canContinue || model.running)
                        Button("Resume saved crawl") { model.resumeSavedCrawl() }.disabled(model.running || model.discovering)
                        Button("Export all CSV") { model.exportCSV(onlyAccepted: false) }
                        Button("Export accepted") { model.exportCSV(onlyAccepted: true) }
                        Button("Save session") { model.saveSession() }
                        Button("Open session") { model.openSession() }.disabled(model.running || model.discovering || model.verifying)
                        Spacer()
                        Button("Clear") { model.clear() }.disabled(model.running || model.verifying || model.discovering)
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        .sheet(isPresented: $showingRuleSheet) {
            VStack(alignment: .leading, spacing: 14) {
                Text("Remove / Filter results").font(.headline)
                Text("Choose what to exclude. Your original collected results remain saved.")
                    .foregroundStyle(.secondary)
                Picker("Rule", selection: $ruleKind) {
                    ForEach(["Address", "Prefix", "Domain", "Contains", "Wildcard"], id: \.self) { Text($0) }
                }
                TextField(ruleKind == "Wildcard" ? "e.g. info@* or *@example.org" : "Address, prefix, domain, or text", text: $rulePattern)
                    .textFieldStyle(.roundedBorder)
                if ruleKind == "Wildcard" {
                    Text("* matches any text; ? matches one character. Matches the whole email, ignoring case. Up to 512 characters.").font(.caption).foregroundStyle(.secondary)
                }
                HStack {
                    Button("Use selected address") {
                        if let address = suggestedAddress { ruleKind = "Address"; rulePattern = address }
                    }.disabled(suggestedAddress == nil)
                    Button("Use selected domain") {
                        if let address = suggestedAddress, let domain = address.split(separator: "@").last {
                            ruleKind = "Domain"; rulePattern = String(domain)
                        }
                    }.disabled(suggestedAddress == nil)
                }
                Text("Would exclude \(model.countMatching(kind: ruleKind, pattern: rulePattern)) Included records. Applies to future results too.")
                    .font(.subheadline).bold()
                HStack {
                    Spacer()
                    Button("Cancel") { showingRuleSheet = false }
                    Button("Apply rule") {
                        model.addRule(kind: ruleKind, pattern: rulePattern)
                        selectedResultIDs.removeAll()
                        showingRuleSheet = false
                    }.disabled(rulePattern.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || (ruleKind == "Wildcard" && rulePattern.count > SafeWildcard.maximumPatternLength))
                }
            }
            .padding(20)
            .frame(width: 440)
        }
        .onChange(of: resultSearch) { _ in selectedResultIDs.removeAll(); rebuildVisible() }
        .onChange(of: resultSearchScope) { _ in selectedResultIDs.removeAll(); rebuildVisible() }
        .onChange(of: selectedStatus) { _ in selectedResultIDs.removeAll(); rebuildVisible() }
        .onChange(of: revision) { _ in rebuildVisible() }
        .onChange(of: sortOrder) { _ in rebuildVisible() }
        .onAppear { rebuildVisible() }
    }
}

@MainActor struct ContentView: View {
    @ObservedObject var model: GrabberModel
    @State private var showDiscoveredSites = true

    private var activityPanel: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Website activity").font(.headline)
            Text("Active: \(model.activePages.count) / \(model.concurrentSites) websites").font(.caption).foregroundStyle(.secondary)
            Text("One worker per website").font(.caption2).foregroundStyle(.secondary)
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 8) {
                    ForEach(model.activePages, id: \.self) { url in
                        Text(url).font(.caption).textSelection(.enabled)
                    }
                }
            }.frame(maxHeight: 150)
            Text("Queued pages (\(model.queuedPageURLs.count))").font(.subheadline).bold()
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 6) {
                    ForEach(model.queuedPageURLs, id: \.self) { url in
                        Text(url).font(.caption).lineLimit(3).textSelection(.enabled)
                    }
                }
            }.frame(maxHeight: 180)
            if let event = model.currentActivity {
                Text(model.paused ? "Pausing / paused" : event.phase).font(.subheadline).bold()
                if !event.url.isEmpty {
                    Text(event.url).font(.caption).textSelection(.enabled).lineLimit(5)
                }
                Text(event.message).font(.caption).foregroundStyle(.secondary)
                Text("Pending pages: \(model.pendingPageCount)").font(.caption)
            } else {
                Text("Start or resume a crawl to see activity.").font(.caption).foregroundStyle(.secondary)
            }
            Divider()
            Text("Recent pages").font(.subheadline).bold()
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 12) {
                    ForEach(model.recentActivity) { event in
                        VStack(alignment: .leading, spacing: 3) {
                            HStack {
                                Text(event.phase).bold()
                                Spacer()
                                Text(event.time, style: .time).foregroundStyle(.secondary)
                            }
                            Text(event.url).lineLimit(3).textSelection(.enabled)
                            Text(event.message).foregroundStyle(.secondary)
                        }
                        .font(.caption)
                        Divider()
                    }
                }
            }
            Text("Shows the latest 100 completed or skipped pages.").font(.caption2).foregroundStyle(.secondary)
        }
        .frame(width: 260, alignment: .topLeading)
        .frame(maxHeight: .infinity, alignment: .top)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "envelope.badge.shield.half.filled").font(.title2)
                Text("Email Grabber 3").font(.title2).bold()
                Spacer()
                Text("Local Mac Edition").foregroundStyle(.secondary)
            }
            HStack(alignment: .top, spacing: 14) {
                ScrollView(.vertical) {
                VStack(alignment: .leading, spacing: 10) {
                    Picker("Input method", selection: $model.mode) { ForEach(SourceMode.allCases) { Text($0.rawValue).tag($0) } }.disabled(model.running || model.discovering || model.verifying)
                    Text(model.mode == .website ? "Enter one website or domain per line" : model.mode == .keywords ? "Enter one search phrase per line" : "Paste addresses, text or import CSV/TXT")
                        .font(.caption).foregroundStyle(.secondary)
                    TextEditor(text: $model.input).font(.system(.body, design: .monospaced)).frame(height: 135).overlay(RoundedRectangle(cornerRadius: 5).stroke(.gray.opacity(0.25))).disabled(model.running || model.discovering || model.verifying)
                    Button("Import CSV / TXT / Excel") { model.importFile() }.disabled(model.running || model.discovering || model.verifying)
                    Button("Import website list (CSV / Excel)") { model.importWebsiteList() }.disabled(model.running || model.discovering || model.verifying)
                    if model.mode == .keywords {
                        Divider()
                        Picker("Location (optional)", selection: $model.osmStateCode) {
                            Text("Any location").tag("")
                            ForEach(USStates.all) { item in Text(item.name).tag(item.code) }
                        }
                        HStack {
                            Button("Discover Websites") { model.discover() }.disabled(model.running || model.discovering)
                            Button("Cancel") { model.cancelDiscovery() }.disabled(!model.discovering)
                        }
                        if !model.discoveredSites.isEmpty {
                            DisclosureGroup(isExpanded: $showDiscoveredSites) {
                                HStack {
                                    Button("All") { model.setAllSites(true) }
                                    Button("None") { model.setAllSites(false) }
                                    Button("Export") { model.exportDiscoveredSites() }
                                    Button("Clear") { model.clearDiscoveredSites() }
                                    Spacer()
                                }
                                ScrollView {
                                    LazyVStack(alignment: .leading, spacing: 4) {
                                        ForEach($model.discoveredSites) { site in
                                            Toggle(isOn: site.selected) {
                                                VStack(alignment: .leading, spacing: 1) {
                                                    Text(site.wrappedValue.host).lineLimit(1)
                                                    Text(site.wrappedValue.origin).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                                                }
                                            }
                                            .toggleStyle(.checkbox)
                                        }
                                    }
                                }
                                .frame(height: 160)
                                Text("Review directory-derived links; some may not be relevant businesses.")
                                    .font(.caption2).foregroundStyle(.secondary)
                            } label: {
                                Text("Discovered websites (\(model.discoveredSites.filter(\.selected).count)/\(model.discoveredSites.count) selected)")
                            }
                        }
                    }
                    HStack {
                        Button("Start") { model.start() }.disabled(model.running || model.discovering || model.verifying)
                            .keyboardShortcut(.return, modifiers: .command)
                        Button(model.paused ? "Resume" : "Pause") {
                            if model.paused { model.resume() } else { model.pause() }
                        }.disabled(!model.running)
                        Button("Stop") { model.stop() }.disabled(!model.running)
                        Spacer()
                    }
                    Divider()
                    Text("Crawling").font(.headline)
                    Stepper("Simultaneous websites: \(model.concurrentSites)", value: $model.concurrentSites, in: 1...8)
                        .disabled(model.running || model.discovering || model.verifying)
                    Text("At most one worker per website. Change before starting a new crawl.").font(.caption2).foregroundStyle(.secondary)
                    Toggle("Follow relevant links to other websites", isOn: $model.followExternalLinks).disabled(model.running || model.discovering || model.verifying)
                    if model.mode == .website { TextField("Optional topic for relevant external links", text: $model.topicContext).disabled(model.running || model.discovering || model.verifying) }
                    Text("With unlimited pages, follows relevant links until stopped or no eligible links remain.").font(.caption2).foregroundStyle(.secondary)
                    Stepper("Link depth: \(model.depth == 0 ? "Adaptive" : String(model.depth))", value: $model.depth, in: 0...20).disabled(model.running || model.discovering || model.verifying)
                    Toggle("Unlimited total pages", isOn: Binding(get: { model.maxPages == 0 }, set: { model.maxPages = $0 ? 0 : 500 })).disabled(model.running || model.discovering || model.verifying)
                    if model.maxPages != 0 { Stepper("Maximum pages: \(model.maxPages)", value: $model.maxPages, in: 10...1000000, step: 100) }
                    Toggle("Adaptive pages per website (no fixed cap)", isOn: Binding(get: { model.maxPagesPerDomain == 0 }, set: { model.maxPagesPerDomain = $0 ? 0 : 10 })).disabled(model.running || model.discovering || model.verifying)
                    if model.maxPagesPerDomain != 0 { Stepper("Pages per website: \(model.maxPagesPerDomain)", value: $model.maxPagesPerDomain, in: 1...100000) }
                    Divider()
                    Text("Filtering & validation").font(.headline)
                    Toggle("Remove duplicates", isOn: $model.stripDuplicates).disabled(model.running || model.discovering || model.verifying)
                    Toggle("Exclude generic role accounts", isOn: $model.excludeRole).disabled(model.running || model.discovering || model.verifying)
                    Text("Includes info@, care@, support@, office@, and other generic addresses. Applies to new searches; rerun a search after changing filters.").font(.caption2).foregroundStyle(.secondary)
                    Toggle("Exclude free mail providers", isOn: $model.excludeFree).disabled(model.running || model.discovering || model.verifying)
                    Toggle("Exclude known disposable domains", isOn: $model.excludeDisposable).disabled(model.running || model.discovering || model.verifying)
                    Toggle("Check DNS MX records", isOn: $model.checkDNS).disabled(model.running || model.discovering || model.verifying)
                    Divider()
                    Text("Fresh website confirmation").font(.headline)
                    Button("Confirm next 100 on website") { model.confirmWebsite() }.disabled(model.running || model.verifying || model.discovering)
                    Text("Revisits each saved Source URL. Records exact page-text/email-link matches separately from SMTP. No sender setup or API credits needed. SMTP checks also perform this source confirmation.").font(.caption).foregroundStyle(.secondary)
                    Button("Stop verification") { model.stopVerification() }.disabled(!model.verifying)
                    Divider()
                    Text("Optional SMTP mailbox check").font(.headline)
                    TextField("Your EHLO hostname", text: $model.smtpOptions.ehlo)
                    TextField("Your sender email", text: $model.smtpOptions.sender)
                    Toggle("Require verified TLS", isOn: $model.smtpOptions.requireTLS)
                    Button("Check next 100 via SMTP") { model.verifySMTP() }.disabled(model.running || model.verifying || model.discovering)
                    Button("Retry inconclusive (SMTP)") { model.verifySMTP(retryInconclusive: true) }.disabled(model.running || model.verifying || model.discovering)
                    Text(model.running ? "Stop the crawl before SMTP verification." : model.discovering ? "Wait for discovery to finish before SMTP verification." : model.verifying ? "Verification is running. Use Stop verification to cancel." : "Select one row → Show evidence for server replies, website pages and retry timing.").font(.caption).foregroundStyle(.secondary)
                    Text("Contacts recipient servers; no message body is sent. Catch-all, blocks and temporary failures cannot prove mailbox existence. Use a sender identity you control.").font(.caption).foregroundStyle(.secondary)
                    Divider()
                    Text("Optional ZeroBounce").font(.headline)
                    SecureField("ZeroBounce API key", text: $model.verifierKey)
                    Button("Save API key in Keychain") { model.storeVerificationKey() }
                    HStack {
                        Button("Verify up to 100") { model.verifyWithZeroBounce() }.disabled(model.running || model.verifying || model.discovering)
                        Button("Stop verification") { model.stopVerification() }.disabled(!model.verifying)
                    }
                    Text("Only the explicitly confirmed batch is sent to ZeroBounce. Provider credits may be charged.")
                        .font(.caption).foregroundStyle(.secondary)
                    Text("Blocked terms / addresses (one per line; * and ? supported)").font(.caption)
                    TextEditor(text: $model.excluded).frame(height: 75).overlay(RoundedRectangle(cornerRadius: 5).stroke(.gray.opacity(0.25)))
                    Text("MX checks do not establish mailbox existence. Provider 'catch-all' and 'unknown' remain uncertain.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                .padding(.trailing, 6)
                }
                .frame(width: 310)
                .frame(maxHeight: .infinity)
                Divider()
                ResultsPane(model: model, revision: model.resultsRevision, running: model.running, discovering: model.discovering, verifying: model.verifying, canContinue: model.canContinue).equatable()
                Divider()
                activityPanel
            }
            .frame(maxHeight: .infinity)
            Divider()
            if let warning = model.discoveryWarning { Text(warning).foregroundStyle(.orange).font(.caption) }
            if let error = model.persistenceError { Text(error).foregroundStyle(.red).font(.caption) }
            HStack {
                if model.running { ProgressView().controlSize(.small) }
                Text(model.progress).font(.caption)
                Spacer()
                Text("Websites discovered: \(model.domainsDiscovered) | scanned: \(model.domainsScanned) | pages: \(model.scanned)").font(.caption).foregroundStyle(.secondary)
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: NSApplication.willTerminateNotification)) { _ in model.flushAutosave() }
        .padding(16)
        .frame(minWidth: 1340, minHeight: 580)
    }
}

@main @MainActor struct EmailGrabberApp: App {
    @StateObject private var model = GrabberModel()
    var body: some Scene { WindowGroup { ContentView(model: model) } }
}
