import XCTest
import Foundation
@testable import EmailGrabberCore

final class AddressClassificationTests: XCTestCase {
    func testAuditDiscoveredCivicEditorialAndBroadcastFunctions() {
        for handle in ["chairman", "elections", "legals", "obits", "advertise", "cityclerk", "electionboard", "voterregistration", "publicfile", "closedcaption", "closed.captioning", "rights", "mediarights", "rightsrepro", "giftplanning", "journalpermissions", "viewermail", "republish", "newstips", "readerservice", "elections.voterregistration", "programming9", "speakerservices", "public.health", "town-clerk"] {
            XCTAssertEqual(row(handle + "@example.org").addressClassification.category, .general, handle)
        }
    }
    func testOrganizationAndDepartmentCompositionUsesEvidence() {
        for address in ["rivergroupmemberservices@rivergroup.org", "cityjournalpermissions@example.org", "wxyzclosedcaptions@example.org", "journalpermissions@example.org", "stationclosedcaptioning@example.org", "examplecitysales@example.org", "examplewebteam@example.org"] {
            XCTAssertEqual(row(address).addressClassification.category, .general, address)
        }
        for address in ["janesales@example.org", "jane.press@example.org", "john.staff@example.org", "citynews@example.org", "mary.online@example.org"] {
            // Existing exact role-token rules may classify staff/press; verify
            // the new organization-prefix rule independently through reasons.
            XCTAssertFalse(row(address).addressClassification.reason.contains("Organization-branded function"), address)
        }
    }
    func testCollectiveChapterNamesKeepUserAndExplicitNameOverrides() {
        for handle in ["indivisiblerivercity", "northcoastindivisible", "indivisible.county12", "riverindivisibles"] {
            XCTAssertEqual(row(handle + "@example.org").addressClassification.category, .general, handle)
        }
        var value = row("indivisible.jane@example.org")
        value.websiteConfirmation = namedEvidence(value.address, "Jane Smith")
        XCTAssertEqual(value.addressClassification.category, .person)
        value.websiteConfirmation = nil
        let manuallyCorrected = ClassificationEdits.set([value], selected: [value.id], category: .person)[0]
        XCTAssertEqual(manuallyCorrected.addressClassification.category, .person)
    }
    func testOrganizationAffiliationDoesNotMakeANamedContactASharedInbox() {
        for handle in ["mike.indivisiblefl13", "joe.indivisible.hifi", "jane.indivisible"] {
            var value = row(handle + "@example.org")
            XCTAssertEqual(value.addressClassification.category, .uncertain, handle)
            value.websiteConfirmation = namedEvidence(value.address, "Jane Smith")
            XCTAssertEqual(value.addressClassification.category, .person, handle)
        }
    }
    func testReportedEditorialAndFinancialAidMailboxesAreGeneral() {
        for address in ["corrections@forbes.com", "readers@forbes.com", "accolades@forbes.com", "financialaid@charlotte.edu", "frbcustserv@cdsfulfillment.com"] {
            XCTAssertEqual(row(address).addressClassification.category, .general, address)
        }
    }
    func testServiceFamiliesComposeWithoutSubstringMatching() {
        let handles = ["financial.aid", "financial-aid-office", "financial_aid_dept", "finaid", "corrections.desk", "readerservices", "reader-services-uk", "us.customercare", "customer-service", "customer_services", "custsvc", "custserv", "frbcustserv", "subscriber-services", "subscriberservicesintl", "scholarships", "registrar", "transcripts", "bursar", "counseling", "counselling", "student-support", "studyabroad", "internationalstudents", "library", "career-services", "accountspayable", "accounts.receivable", "payroll", "reprints", "permissions", "syndication", "circulation", "classifieds", "obituaries", "nominations", "award-nominations", "ad.sales", "benefits", "humanresources", "publicrecords", "communityrelations", "mediainquiries", "ombudsperson", "interlibraryloan", "donor-services", "membership-services", "customer-service-team"]
        for handle in handles {
            XCTAssertEqual(row(handle + "@example.org").addressClassification.category, .general, handle)
        }
    }
    func testServiceNamesDoNotConsumePersonalNamesOrInitialHandles() {
        for address in ["jane.reader@example.org", "john.read@example.org", "sharon.dean@example.org", "jane.cleveland@example.org", "dev.patel@example.org", "john.crew@example.org", "arun.volam@gmail.com", "tbowser1@charlotte.edu", "rlambe12@charlotte.edu", "nvlincen4@charlotte.edu"] {
            XCTAssertNotEqual(row(address).addressClassification.category, .general, address)
        }
        for handle in ["readerson", "accoladesmith", "finaidson", "jane.correctionsmith", "correctionsmith", "custservsmith", "myreaders"] {
            XCTAssertNotEqual(row(handle + "@example.org").addressClassification.category, .general, handle)
        }
    }
    func testDepartmentDecisionsPreserveSavedCorrectionsAndCrawlOptions() {
        let original = row("financialaid@example.edu")
        var value = original
        value.websiteConfirmation = namedEvidence(value.address, "Jane Smith")
        XCTAssertEqual(value.addressClassification.category, .general)
        let corrected = ClassificationEdits.set([value], selected: [value.id], category: .person)[0]
        XCTAssertEqual(corrected.addressClassification.category, .person)
        XCTAssertFalse(AddressClassification.roleNames.contains("financialaid"))
        XCTAssertEqual(original.status, "Accepted")
    }
    func testFullReportedScreenshotSharedAccounts() {
        for address in ["sandusky@ohiolegal.org", "columbus@ohiolegal.org", "cleveland@ohiolegal.org", "online@charlotte.edu", "studenthealth@charlotte.edu", "wstudent@uark.edu", "mailto@uark.edu", "admissions@jcsu.edu", "helpdesk@alaska.edu", "zerowastecrew@charlotte.edu", "data@lsd.law", "spreadsheets@forbes.com"] {
            XCTAssertEqual(row(address).addressClassification.category, .general, address)
        }
    }
    func testRegionalOfficeInferenceRequiresMatchingOrganizationContext() {
        for address in ["columbus@ohiolegal.org", "cleveland@ohio-legal.org", "austin@texashealth.org", "madison@wisconsinlibrary.org", "columbus@georgialegalaid.org"] {
            XCTAssertEqual(row(address).addressClassification.category, .general, address)
        }
        for address in ["cleveland@gmail.com", "columbus@texaslegal.org", "cleveland@ohio.org", "cleveland@myohiolegal.org", "austin@texassmith.org", "cleveland@ohiolegal.org.evil.com", "columbus@ohiolegal.com"] {
            XCTAssertNotEqual(row(address).addressClassification.category, .general, address)
        }
        var person = row("austin@texashealth.org")
        person.websiteConfirmation = namedEvidence(person.address, "Austin Smith")
        XCTAssertEqual(person.addressClassification.category, .person)
    }
    func testStudentPatternPreservesExplicitNamesAndNumericPersonalHandles() {
        for address in ["lmitch45@charlotte.edu", "koconn36@charlotte.edu", "rchew@charlotte.edu", "arun.volam@gmail.com", "jane.student@example.org"] {
            XCTAssertNotEqual(row(address).addressClassification.category, .general, address)
        }
        var person = row("wstudent@uark.edu")
        person.websiteConfirmation = namedEvidence(person.address, "William Smith")
        XCTAssertEqual(person.addressClassification.category, .person)
        XCTAssertNotEqual(row("wstudent@gmail.com").addressClassification.category, .general)
    }
    func testBugReportingIdentifierIsRejectedWithoutRejectingRealHexMailboxes() {
        let address = "325506e3332d487999567a7bc91d151d@bug-reporting-xalgha6.m-w.com"
        let original = row(address)
        XCTAssertNotNil(TechnicalAddressPolicy.rejectionReason(address))
        XCTAssertEqual(TechnicalAddressPolicy.reclassified(original).status, "Rejected")
        XCTAssertTrue(ResultPolicy.filtered([original], rules: [], removed: [], status: "Included", search: "", scope: "Email").isEmpty)
        XCTAssertEqual(ResultPolicy.filtered([original], rules: [], removed: [], status: "All", search: "", scope: "Email").count, 1, "Keep the saved original")
        XCTAssertNil(TechnicalAddressPolicy.rejectionReason("325506e3332d487999567a7bc91d151d@example.org"))
        XCTAssertNil(TechnicalAddressPolicy.rejectionReason("jane@bug-reporting-xalgha6.m-w.com"))
    }
    func testDepartmentInboxWinsOverPublishedStaffAssociation() {
        for address in ["admissions@jcsu.edu", "helpdesk@alaska.edu", "data@lsd.law", "spreadsheets@forbes.com", "admissions.office@example.org"] {
            var value = row(address)
            value.websiteConfirmation = namedEvidence(address, "Jane Smith")
            XCTAssertEqual(value.addressClassification.category, .general, address)
            XCTAssertFalse(AddressClassification.roleNames.contains(address.split(separator: "@")[0].description), "Classification must not expand crawl exclusions")
        }
    }
    func testCollectiveHandlesDoNotNeedExactAddressExceptions() {
        for address in ["zerowastecrew@charlotte.edu", "recyclingcrew@example.org", "discoverarkansas@example.org", "discovermaine@example.org"] {
            XCTAssertEqual(row(address).addressClassification.category, .general, address)
        }
    }
    func testPlaceNameCollisionNeedsContextAndPreservesPeople() {
        for local in ["sandusky", "columbus", "cleveland", "austin", "madison"] {
            var value = row(local + "@example.org")
            XCTAssertEqual(value.addressClassification.category, .uncertain, "A name vocabulary hit cannot settle a place/person collision")
            value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact address", sourceURL: value.source, excerpt: local.capitalized + " Office: " + value.address)
            XCTAssertEqual(value.addressClassification.category, .general)
            value.websiteConfirmation = namedEvidence(value.address, "Austin Smith")
            XCTAssertEqual(value.addressClassification.category, .person, "Explicit full name remains usable")
        }
        for address in ["austin.smith@example.org", "jane.cleveland@example.org", "madison.jones@example.org", "john.smith@example.org", "dev.patel@example.org", "john.crew@example.org"] {
            XCTAssertEqual(row(address).addressClassification.category, .person, address)
        }
    }
    func testLocationEvidenceRequiresPublishedProofAndSpecificAssociation() {
        var value = row("cleveland@example.org")
        value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact address", sourceURL: "https://example.org/offices/cleveland", excerpt: value.address)
        XCTAssertEqual(value.addressClassification.category, .general)
        value.websiteConfirmation?.outcome = .unavailable
        XCTAssertEqual(value.addressClassification.category, .uncertain)
        value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact address", sourceURL: value.source, excerpt: "Our office includes Jane Cleveland and Austin Smith")
        XCTAssertEqual(value.addressClassification.category, .uncertain, "Unrelated office wording must not turn a surname into location evidence")
    }
    func testManualPersonCorrectionStillWinsForSharedInbox() {
        var value = row("admissions@jcsu.edu")
        value = ClassificationEdits.set([value], selected: [value.id], category: .person)[0]
        XCTAssertEqual(value.addressClassification.category, .person)
    }
    func row(_ address: String) -> FoundEmail {
        FoundEmail(address: address, source: "https://example.org/staff", status: "Accepted", reason: "Local checks")
    }
    func namedEvidence(_ address: String, _ name: String) -> WebsiteConfirmation {
        let html = "<a href='mailto:" + address + "'>" + name + "</a>"
        let url = URL(string: "https://example.org/staff")!
        return WebsiteConfirmer.observe(address: address, source: url.absoluteString, response: HTTPResult(data: Data(html.utf8), status: 200, finalURL: url, mimeType: "text/html"), checkedAt: Date())
    }
    func testPublishedJobTitlesAreGeneralInboxesNotPeople() {
        for (local, title) in [("executivedirector", "Executive Director"), ("deputydirector", "Deputy Director"), ("developmentdirector", "Development Director"), ("program.director", "Program Director"), ("executive-director+contact", "Executive Director"), ("chiefdevelopmentofficer", "Chief Development Officer")] {
            var value = row(local + "@example.org")
            XCTAssertEqual(value.addressClassification.category, .general, local)
            value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact text", sourceURL: value.source, excerpt: title + " — " + value.address)
            XCTAssertEqual(value.addressClassification.category, .general, local)
            XCTAssertFalse(value.addressClassification.reason.contains("excerpt names"))
            XCTAssertFalse(AddressClassification.roleNames.contains(local), "Do not change crawl exclusions")
        }
    }
    func testCapitalizedTitleCannotBecomeNameEvidenceForUnknownMailbox() {
        for (local, title) in [("eofficer", "Executive Officer"), ("specialprojects", "Special Projects"), ("developmentmanager", "Development Manager"), ("jdirector", "Junior Director"), ("salesoffice", "Sales Office")] {
            var value = row(local + "@example.org")
            value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact text", sourceURL: value.source, excerpt: title + " — " + value.address)
            // Unknown titles may remain uncertain; capitalization alone is insufficient.
            XCTAssertNotEqual(value.addressClassification.category, .person, local)
        }
    }
    func testPersonFilterAndCategoryReviewExcludePublishedDirectors() {
        var director = row("executivedirector@example.org")
        director.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact text", sourceURL: director.source, excerpt: "Executive Director — executivedirector@example.org")
        let rows = [director, row("dan.boyce@example.org")]
        XCTAssertEqual(AddressClassification.review(rows, category: .person, removed: []).map(\.address), ["dan.boyce@example.org"])
        XCTAssertEqual(AddressClassification.review(rows, category: .general, removed: []).map(\.address), [director.address])
    }
    func testActualStaffNameBesideTitleStillSupportsPerson() {
        var value = row("mbrown@example.org")
        value.websiteConfirmation = namedEvidence(value.address, "Michael Brown")
        XCTAssertEqual(value.addressClassification.category, .person)
        XCTAssertTrue(value.addressClassification.reason.contains("Michael Brown"))
        value.websiteConfirmation?.personAssociation?.address = "mbrown@example.org.evil"
        XCTAssertEqual(value.addressClassification.category, .uncertain)
    }
    func testScreenshotOrganizationPatternsAndSurnameFirst() {
        for address in ["connect@bridge2blue.org", "massbayallianceunited@gmail.com", "bvccommunitycoalition@gmail.com", "borregovoices@gmail.com", "beaconfordemocracychapter@gmail.com", "bienvenidos@gmail.com"] {
            XCTAssertEqual(row(address).addressClassification.category, .general, address)
        }
        XCTAssertEqual(row("palumbo.dana@gmail.com").addressClassification.category, .person)
        XCTAssertEqual(row("dana.palumbo@gmail.com").addressClassification.category, .person)
        XCTAssertEqual(row("bwfro01223@gmail.com").addressClassification.category, .uncertain)
        XCTAssertEqual(row("r.lambertson@gmail.com").addressClassification.category, .uncertain)
        XCTAssertNotEqual(row("jane@example-alliance.org").addressClassification.category, .general, "Domain alone does not identify a shared mailbox")
    }
    func testInitialsAndTrailingInitialRequireActualFullNameEvidence() {
        for (address, name) in [("r.lambertson@example.org", "Richard Lambertson"), ("glennp@example.org", "Glenn Palmer")] {
            var value = row(address)
            XCTAssertEqual(value.addressClassification.category, .uncertain)
            value.websiteConfirmation = namedEvidence(address, name)
            XCTAssertEqual(value.addressClassification.category, .person)
            value.websiteConfirmation?.personAssociation = nil
            value.websiteConfirmation?.excerpt = "Executive Director — " + address
            XCTAssertEqual(value.addressClassification.category, .uncertain)
        }
    }
    func testManualCorrectionWinsAndResetRestoresAutomaticClassification() {
        let value = row("executivedirector@example.org")
        let edited = ClassificationEdits.set([value], selected: [value.id], category: .person, at: Date(timeIntervalSince1970: 1))[0]
        XCTAssertEqual(edited.addressClassification.category, .person)
        XCTAssertTrue(edited.addressClassification.reason.contains("Your saved correction"))
        XCTAssertEqual(AddressClassification.automatic(edited).category, .general)
        let reset = ClassificationEdits.set([edited], selected: [edited.id], category: nil, at: Date(timeIntervalSince1970: 2))[0]
        XCTAssertEqual(reset.addressClassification.category, .general)
        XCTAssertNotNil(reset.classificationDecision, "A dated reset must survive stale checkpoints")
        XCTAssertNil(reset.classificationDecision?.category)
        let uncertain = ClassificationEdits.set([value], selected: [value.id], category: .uncertain)[0]
        XCTAssertEqual(uncertain.addressClassification.category, .uncertain)
    }
    func testCorrectionsRoundTripAndOlderFilesStillDecode() throws {
        let original = row("info@example.org")
        let legacy = try JSONEncoder().encode(original)
        let decodedLegacy = try JSONDecoder().decode(FoundEmail.self, from: legacy)
        XCTAssertNil(decodedLegacy.classificationDecision)
        let changed = ClassificationEdits.set([original], selected: [original.id], category: .person)[0]
        let restored = try JSONDecoder().decode(FoundEmail.self, from: JSONEncoder().encode(changed))
        XCTAssertEqual(restored, changed)
        XCTAssertEqual(restored.addressClassification.category, .person)
    }
    func testDuplicateAddressCorrectionsAndLateCrawlRows() {
        let first = row("INFO@example.org"), duplicate = row("info@example.org"), other = row("dan.boyce@example.org")
        let changed = ClassificationEdits.set([first, duplicate, other], selected: [first.id], category: .person)
        XCTAssertEqual(changed[0].classificationDecision, changed[1].classificationDecision)
        XCTAssertNil(changed[2].classificationDecision)
        let later = row("info@example.org")
        XCTAssertEqual(ClassificationEdits.inheriting([later], from: changed)[0].addressClassification.category, .person)
    }
    func testOldCheckpointCannotResurrectResetDespiteNewerVerificationTimestamp() {
        let original = row("info@example.org")
        var stale = ClassificationEdits.set([original], selected: [original.id], category: .person, at: Date(timeIntervalSince1970: 1))[0]
        let reset = ClassificationEdits.set([stale], selected: [stale.id], category: nil, at: Date(timeIntervalSince1970: 2))[0]
        stale.checkedAt = Date(timeIntervalSince1970: 9999999999)
        let restored = ResultMerge.combine([stale], [reset])[0]
        XCTAssertEqual(restored.addressClassification.category, .general)
        XCTAssertEqual(restored.classificationDecision, reset.classificationDecision)
        XCTAssertEqual(restored.checkedAt, stale.checkedAt, "Independent verification remains unchanged")
    }
    func testEditsDoNotChangeRemovalVerificationCSVOrOriginalValues() {
        let original = row("info@example.org")
        let changed = ClassificationEdits.set([original], selected: [original.id], category: .person)[0]
        XCTAssertEqual(changed.status, original.status)
        XCTAssertEqual(changed.reason, original.reason)
        XCTAssertEqual(changed.id, original.id)
        XCTAssertEqual(VerificationCSV.line(changed), VerificationCSV.line(original))
        XCTAssertTrue(ResultPolicy.exportRows([changed], rules: [], removed: [changed.address], onlyAccepted: false).isEmpty)
        XCTAssertTrue(ResultPolicy.filtered([changed], rules: [SmartRule(kind: "Address", pattern: changed.address)], removed: [], status: "Included", search: "", scope: "Email").isEmpty)
        XCTAssertEqual(original.addressClassification.category, .general)
    }
    func testBundledNameVocabularyAndReviewedMixedEvaluation() throws {
        XCTAssertEqual(PersonNameVocabulary.given.count, 5130)
        XCTAssertEqual(PersonNameVocabulary.surnames.count, 88698)
        #if SWIFT_PACKAGE
        let url = try XCTUnwrap(Bundle.module.url(forResource: "classification-evaluation", withExtension: "tsv", subdirectory: "Fixtures"))
        #else
        let url = try XCTUnwrap(Bundle(for: type(of: self)).url(forResource: "classification-evaluation", withExtension: "tsv", subdirectory: "Fixtures"))
        #endif
        let text = try String(contentsOf: url, encoding: .utf8)
        var counts: [String: Int] = [:]
        var mismatches: [String] = []
        for line in text.split(whereSeparator: \.isNewline) where !line.hasPrefix("#") {
            let fields = line.split(separator: "\t").map(String.init)
            XCTAssertEqual(fields.count, 3)
            guard fields.count == 3 else { continue }
            counts[fields[1], default: 0] += 1
            let actual = row(fields[0] + "@example.org").addressClassification
            if actual.category.rawValue != fields[1] { mismatches.append(fields[0] + ": expected " + fields[1] + ", got " + actual.category.rawValue + " — " + actual.reason) }
        }
        XCTAssertGreaterThanOrEqual(counts["Likely person", default: 0], 40)
        XCTAssertGreaterThanOrEqual(counts["General inbox", default: 0], 40)
        XCTAssertGreaterThanOrEqual(counts["Uncertain", default: 0], 20)
        XCTAssertTrue(mismatches.isEmpty, mismatches.joined(separator: "\n"))
    }
    func testPositiveNameEvidenceAndDigitsAreNeutral() {
        for local in ["li.wei", "ng.ann", "sharon.dean2025", "susanne.g.hinkle", "clarkdavid01", "margueritechandler", "terryewhitaker"] {
            XCTAssertEqual(row(local + "@example.org").addressClassification.category, .person, local)
        }
        XCTAssertEqual(row("qylthar.zorvek@example.org").addressClassification.category, .uncertain, "Dots alone are not person evidence")
        var explicit = row("qylthar.zorvek@example.org")
        explicit.websiteConfirmation = namedEvidence(explicit.address, "Qylthar Zorvek")
        XCTAssertEqual(explicit.addressClassification.category, .person, "Explicit name/email associations do not require vocabulary membership")
        XCTAssertFalse(PersonNameVocabulary.given.contains("qylthar"))
        XCTAssertFalse(PersonNameVocabulary.surnames.contains("zorvek"))
        for local in ["k.jones", "dksmiley5551", "jkb1099", "123456", "abc123xyz", "support2025", "executive.director42"] {
            XCTAssertNotEqual(row(local + "@example.org").addressClassification.category, .person, local)
        }
    }
    func testMailboxAndPublicationEvidenceDoNotManufactureNameEvidence() {
        var value = row("jkb1099@example.org")
        value.status = "Verified"
        value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Published on staff site", sourceURL: value.source, excerpt: "Contact jkb1099@example.org")
        XCTAssertEqual(value.addressClassification.category, .uncertain)
        value.websiteConfirmation?.excerpt = "Executive Director jkb1099@example.org"
        XCTAssertEqual(value.addressClassification.category, .uncertain)
    }
    func testGeneralInboxAndAliases() {
        for address in ["INFO@example.org", "sales+press@example.org", "support@example.org", "newsroom@example.org", "press.office@example.org"] {
            XCTAssertEqual(row(address).addressClassification.category, .general, address)
            XCTAssertFalse(row(address).addressClassification.reason.isEmpty)
        }
        XCTAssertFalse(AddressClassification.roleNames.contains("newsroom"), "Existing crawl exclusions must not expand")
    }
    func testConservativeNamesAndInitials() {
        XCTAssertEqual(row("dan.boyce@example.org").addressClassification.category, .person)
        XCTAssertEqual(row("cher@example.org").addressClassification.category, .person, "Single recognized name is now positive evidence, not an automatic uncertain outcome")
        for local in ["db", "dboyce", "d.boyce", "x", "maria99", "a_b", "weird-name-xyz", "unusual.name", "custom.address"] {
            XCTAssertEqual(row(local + "@example.org").addressClassification.category, .uncertain, local)
        }
    }
    func testExplicitAssociationStrengthensInitialButLooseExcerptDoesNot() {
        var value = row("dboyce@example.org")
        value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact text", sourceURL: value.source, match: .pageText, excerpt: "Dan Boyce — dboyce@example.org")
        XCTAssertEqual(value.addressClassification.category, .uncertain, "Loose nearby capitalized words are not explicit association")
        value.websiteConfirmation = namedEvidence(value.address, "Dan Boyce")
        XCTAssertEqual(value.addressClassification.category, .person)
        value.websiteConfirmation?.outcome = .notFound
        XCTAssertEqual(value.addressClassification.category, .uncertain)
        value.websiteConfirmation?.outcome = .published
        value.websiteConfirmation?.personAssociation?.address = "another@example.org"
        XCTAssertEqual(value.addressClassification.category, .uncertain)
    }
    func testDuplicateAddressBulkRemovalUsesExistingAddressHistory() {
        let rows = [row("info@example.org"), row("INFO@example.org"), row("db@example.org")]
        var state = RemovalState()
        state.remove(Set(AddressClassification.review(rows, category: .general, removed: []).map(\.address)))
        XCTAssertEqual(state.addresses.count, 1)
        XCTAssertEqual(state.history.count, 1)
        XCTAssertEqual(ResultPolicy.filtered(rows, rules: [], removed: state.addresses, status: "Included", search: "", scope: "Email").map(\.address), ["db@example.org"])
        state.undo()
        XCTAssertEqual(ResultPolicy.filtered(rows, rules: [], removed: state.addresses, status: "Included", search: "", scope: "Email"), rows)
    }
    func testRoleEvidenceNeverOverridesSharedInbox() {
        var value = row("info@example.org")
        value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact text", sourceURL: value.source, excerpt: "Dan Boyce info@example.org")
        XCTAssertEqual(value.addressClassification.category, .general)
    }
    func testBulkRemovalUndoPersistenceAndExport() throws {
        let rows = [row("info@example.org"), row("newsroom@example.org"), row("dan.boyce@example.org"), row("db@example.org")]
        var state = RemovalState(addresses: ["old@example.org"], history: [["old@example.org"]])
        let original = rows
        let reviewed = AddressClassification.review(rows, category: .general, removed: state.addresses)
        XCTAssertEqual(reviewed.count, 2)
        state.remove(Set(reviewed.map(\.address)))
        XCTAssertEqual(state.history.count, 2)
        XCTAssertEqual(ResultPolicy.exportRows(rows, rules: [], removed: state.addresses, onlyAccepted: false).map(\.address), ["dan.boyce@example.org", "db@example.org"])
        XCTAssertEqual(rows, original)
        var restored = try JSONDecoder().decode(RemovalState.self, from: JSONEncoder().encode(state))
        restored.undo()
        XCTAssertEqual(restored.addresses, ["old@example.org"])
        XCTAssertEqual(ResultPolicy.exportRows(rows, rules: [], removed: restored.addresses, onlyAccepted: false), original)
    }
    func testSortAndFilterPreserveOriginalRecordsAndRules() {
        let rows = [row("info@example.org"), row("dan.boyce@example.org"), row("db@example.org")]
        let sorted = ResultOrdering.apply(rows, order: [KeyPathComparator(\FoundEmail.classificationLabel)])
        XCTAssertEqual(sorted.map(\.classificationLabel), ["General inbox", "Likely person", "Uncertain"])
        let filtered = rows.filter { $0.addressClassification.category == .person }
        XCTAssertEqual(filtered.map(\.address), ["dan.boyce@example.org"])
        XCTAssertEqual(rows.count, 3)
        let rule = SmartRule(kind: "Address", pattern: "dan.boyce@example.org")
        XCTAssertEqual(ResultPolicy.filtered(rows, rules: [rule], removed: [], status: "Included", search: "", scope: "Email").count, 2)
    }
}

final class GroupReviewAndExportTests: DiskTests {
    func row(_ address: String, status: String = "Accepted") -> FoundEmail {
        FoundEmail(address: address, source: "https://example.org/staff", status: status, reason: "Fixture")
    }
    func testGroupingUsesStructuredPatternsIncludedScopeAndUniqueAddresses() {
        let initial = row("r.lambertson@example.org"), numeric = row("jkb1099@example.org"), unknown = row("qylthar@example.org"), possible = row("john.officer@example.org")
        var manual = row("manualxyz@example.org")
        manual.classificationDecision = ClassificationDecision(category: .uncertain, changedAt: Date())
        let rows = [initial, row(initial.address.uppercased()), numeric, unknown, possible, row("dan.boyce@example.org"), row("info@example.org"), row("excludedxxx@example.org", status: "Excluded"), manual]
        let groups = GroupReview.groups(rows, rules: [], removed: [])
        XCTAssertEqual(groups.map(\.pattern), [.initials, .numeric, .unrecognized, .possibleOrganization])
        XCTAssertEqual(groups.map { $0.rows.count }, [1,1,1,1])
        let hidden = GroupReview.groups(rows, rules: [SmartRule(kind: "Address", pattern: initial.address)], removed: [numeric.address])
        XCTAssertEqual(hidden.flatMap(\.rows).map(\.address), [unknown.address, possible.address])
    }
    func testBatchScopeExceptionsNoDeletionAndUndo() {
        let a = row("jkb1099@example.org"), b = row("bwfro01223@example.org"), later = row("mocajh91@example.org")
        let original = [a, b, later]
        var state = ReviewState()
        let changed = state.approve(original, selected: [a.id,b.id], pattern: .numeric, category: .person, remember: false, exceptions: [b.address])
        XCTAssertEqual(changed.count, original.count)
        XCTAssertEqual(changed[0].addressClassification.category, .person)
        XCTAssertEqual(changed[1], b)
        XCTAssertEqual(changed[2], later)
        XCTAssertTrue(state.rules.isEmpty)
        XCTAssertEqual(state.history.count, 1)
        let restored = state.undo(changed)
        XCTAssertEqual(restored.map { $0.addressClassification.category }, original.map { $0.addressClassification.category })
        XCTAssertEqual(restored.map(\.id), original.map(\.id))
        XCTAssertEqual(restored.map(\.status), original.map(\.status))
        XCTAssertTrue(state.history.isEmpty)
    }
    func testRememberedRuleFutureMatchesExceptionsAndUnreviewedExistingRows() {
        let a = row("jkb1099@example.org"), exception = row("bwfro01223@example.org"), outside = row("mocajh91@example.org")
        var state = ReviewState()
        _ = state.approve([a, exception, outside], selected: [a.id], pattern: .numeric, category: .person, remember: true, exceptions: [exception.address])
        let fresh = row("ssmith5391@example.org")
        let initial = row("r.lambertson@example.org")
        let result = state.applyingRules(to: [fresh, exception, outside, initial, row("info42@example.org")])
        XCTAssertEqual(result[0].addressClassification.category, .person)
        XCTAssertEqual(result[1], exception)
        XCTAssertEqual(result[2], outside)
        XCTAssertEqual(result[3], initial)
        XCTAssertEqual(result[4].addressClassification.category, .general)
    }
    func testUndoRemovesRuleAndLaterMatchesButPreservesLaterManualCorrection() {
        let a = row("jkb1099@example.org"), b = row("bwfro01223@example.org"), future = row("mocajh91@example.org")
        var state = ReviewState()
        let changed = state.approve([a,b], selected: [a.id,b.id], pattern: .numeric, category: .person, remember: true, at: Date(timeIntervalSince1970: 1))
        let later = state.applyingRules(to: changed + [future])
        let individuallyEdited = ClassificationEdits.set(later, selected: [b.id], category: .general, at: Date(timeIntervalSince1970: 2))
        let undone = state.undo(individuallyEdited, at: Date(timeIntervalSince1970: 3))
        XCTAssertEqual(undone[0].addressClassification.category, .uncertain)
        XCTAssertEqual(undone[1].addressClassification.category, .general)
        XCTAssertEqual(undone[2].addressClassification.category, .uncertain)
        XCTAssertTrue(state.rules.isEmpty)
        XCTAssertTrue(state.history.isEmpty)
        let recovered = ResultMerge.combine(later, undone)
        XCTAssertEqual(recovered.map { $0.addressClassification.category }, undone.map { $0.addressClassification.category })
    }
    func testAutomaticResetAndManualChoiceOverrideRememberedRule() {
        let a = row("jkb1099@example.org"), b = row("bwfro01223@example.org")
        var state = ReviewState()
        _ = state.approve([a], selected: [a.id], pattern: .numeric, category: .person, remember: true)
        let manual = ClassificationEdits.set([b], selected: [b.id], category: .general)
        XCTAssertEqual(state.applyingRules(to: manual), manual)
        let reset = ClassificationEdits.set([b], selected: [b.id], category: nil)
        XCTAssertEqual(state.applyingRules(to: reset), reset)
    }
    func testKeepUncertainIsAnExplicitReviewDecision() {
        let a = row("jkb1099@example.org")
        var state = ReviewState()
        let kept = state.approve([a], selected: [a.id], pattern: .numeric, category: .uncertain, remember: false)
        XCTAssertEqual(kept[0].addressClassification.category, .uncertain)
        XCTAssertTrue(GroupReview.groups(kept, rules: [], removed: []).isEmpty)
        XCTAssertEqual(state.undo(kept)[0].addressClassification.category, .uncertain)
    }
    func testGroupStateRoundTripAndCheckpointProtectsUndoFromWorkerWrites() throws {
        let a = row("jkb1099@example.org")
        var state = ReviewState()
        let changed = state.approve([a], selected: [a.id], pattern: .numeric, category: .person, remember: true)
        let restored = try JSONDecoder().decode(ReviewState.self, from: JSONEncoder().encode(state))
        XCTAssertEqual(restored, state)
        var snapshot = CrawlProgress(queue: [], visited: [], queued: [], robotRules: [:], domainPageCount: [:], discoveredCount: 0, scanned: 0, rows: changed, selectedSites: [], settings: CrawlOptions(depth: 0, maxPages: 0, maxPagesPerDomain: 0, excluded: "", stripDuplicates: true, excludeRole: false, excludeFree: false, excludeDisposable: false, checkDNS: false), input: "")
        CrawlDisk.updatePresentation(rules: [], removal: RemovalState(), classifications: changed, reviewState: state)
        XCTAssertTrue(CrawlDisk.save(snapshot))
        XCTAssertEqual(CrawlDisk.load()?.reviewState, state)
        let undone = state.undo(changed)
        CrawlDisk.updatePresentation(rules: [], removal: RemovalState(), classifications: undone, reviewState: state)
        snapshot.rows = changed // stale worker
        XCTAssertTrue(CrawlDisk.save(snapshot))
        XCTAssertEqual(CrawlDisk.load()?.rows[0].addressClassification.category, .uncertain)
        XCTAssertTrue(CrawlDisk.load()?.reviewState?.rules.isEmpty == true)
    }
    func testEveryExportDropsRawExcludedRulesAndRemoved() {
        let accepted = row("dan.boyce@example.org"), role = row("info@example.org", status: "Excluded"), provider = row("excluded@example.org", status: " excluded "), rule = row("hide@example.org"), removed = row("removed@example.org")
        let rows = [accepted, role, provider, rule, removed, row("logo@2x.png", status: "Excluded")]
        let rules = [SmartRule(kind: "Address", pattern: rule.address)]
        for onlyAccepted in [true, false] {
            XCTAssertEqual(ResultPolicy.exportRows(rows, rules: rules, removed: [removed.address], onlyAccepted: onlyAccepted).map(\.address), [accepted.address])
            XCTAssertEqual(ResultPolicy.exportSelection(rows, currentList: rows, rules: rules, removed: [removed.address], onlyAccepted: onlyAccepted).map(\.address), [accepted.address])
        }
    }
    func testCurrentListExportRespectsCategorySearchStatusAndOrder() {
        let person = row("sharon.dean@example.org"), second = row("rebecca.dolber@example.org"), role = row("info@example.org"), rejected = row("bad@example.org", status: "Rejected"), excluded = row("off@example.org", status: "Excluded")
        let rows = [role, second, rejected, excluded, person]
        let visible = ResultPolicy.filtered(rows, rules: [], removed: [], status: "Included", search: "sharon", scope: "Email").filter { $0.addressClassification.category == .person }
        XCTAssertEqual(ResultPolicy.exportSelection(rows, currentList: visible, rules: [], removed: [], onlyAccepted: false).map(\.id), [person.id])
        XCTAssertEqual(ResultPolicy.exportSelection(rows, currentList: [person,second], rules: [], removed: [], onlyAccepted: false).map(\.id), [person.id,second.id])
        XCTAssertEqual(ResultPolicy.exportSelection(rows, rules: [], removed: [], onlyAccepted: false).map(\.id), [role.id,second.id,person.id])
        XCTAssertTrue(ResultPolicy.exportSelection(rows, currentList: [excluded], rules: [], removed: [], onlyAccepted: false).isEmpty)
    }
    func testGroupEditsLeaveCSVSchemaEvidenceAndExclusionsUnchanged() {
        let a = row("jkb1099@example.org")
        var state = ReviewState()
        let result = state.approve([a], selected: [a.id], pattern: .numeric, category: .person, remember: true)
        XCTAssertEqual(VerificationCSV.line(result[0]), VerificationCSV.line(a))
        XCTAssertEqual(result[0].websiteConfirmation, a.websiteConfirmation)
        XCTAssertEqual(result[0].smtpVerification, a.smtpVerification)
        XCTAssertTrue(ResultPolicy.exportSelection(result, rules: [], removed: [a.address], onlyAccepted: false).isEmpty)
    }
}

extension GroupReviewAndExportTests {
    func testWholeSessionRoundTripAndLegacyMissingReviewState() throws {
        let a = row("jkb1099@example.org")
        var state = ReviewState()
        let changed = state.approve([a], selected: [a.id], pattern: .numeric, category: .person, remember: true)
        let session = GrabSession(mode: .pasted, input: "", excluded: "", depth: 0, maxPages: 0, stripDuplicates: true, excludeRole: false, excludeFree: false, excludeDisposable: false, checkDNS: false, rows: changed, reviewState: state)
        XCTAssertTrue(CrawlDisk.saveProject(session))
        let loaded = try XCTUnwrap(CrawlDisk.loadProject())
        XCTAssertEqual(loaded.reviewState, state)
        XCTAssertEqual(loaded.rows[0].classificationDecision, changed[0].classificationDecision)
        let future = row("ssmith5391@example.org")
        XCTAssertEqual(loaded.reviewState?.applyingRules(to: [future])[0].addressClassification.category, .person)
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(session)) as? [String:Any])
        object.removeValue(forKey: "reviewState")
        let legacy = try JSONDecoder().decode(GrabSession.self, from: JSONSerialization.data(withJSONObject: object))
        XCTAssertNil(legacy.reviewState)
        XCTAssertEqual(legacy.rows.count, session.rows.count)
    }
    func testConfirmingStaleGroupCannotChangeExcludedOrIndividuallyReviewedRows() {
        let a = row("jkb1099@example.org"), excluded = row("bwfro01223@example.org", status: "Excluded"), hidden = row("mocajh91@example.org"), removed = row("ssmith5391@example.org")
        var manual = row("rossis555@example.org")
        manual.classificationDecision = ClassificationDecision(category: .general, changedAt: Date())
        let rows = [a,excluded,hidden,removed,manual]
        var state = ReviewState()
        let result = state.approve(rows, selected: Set(rows.map(\.id)), pattern: .numeric, category: .person, remember: false, rules: [SmartRule(kind: "Address", pattern: hidden.address)], removed: [removed.address])
        XCTAssertEqual(result[0].addressClassification.category, .person)
        XCTAssertEqual(Array(result.dropFirst()), Array(rows.dropFirst()))
    }
    func testLatestRememberedRuleExceptionDoesNotFallThroughToOlderRule() {
        let a = row("jkb1099@example.org"), b = row("bwfro01223@example.org"), exception = row("mocajh91@example.org")
        var state = ReviewState()
        let first = state.approve([a], selected: [a.id], pattern: .numeric, category: .person, remember: true)
        _ = state.approve(first + [b,exception], selected: [b.id], pattern: .numeric, category: .general, remember: true, exceptions: [exception.address])
        XCTAssertEqual(state.applyingRules(to: [exception])[0], exception)
        let next = row("ssmith5391@example.org")
        XCTAssertEqual(state.applyingRules(to: [next])[0].addressClassification.category, .general)
    }
}

extension GroupReviewAndExportTests {
    func testReviewRemovalHonorsSelectedScopeExceptionsAndDuplicates() {
        let a = row("jkb1099@example.org"), duplicate = row("JKB1099@example.org"), exception = row("bwfro01223@example.org"), outside = row("mocajh91@example.org"), initial = row("r.lambertson@example.org")
        let rows = [a, duplicate, exception, outside, initial]
        let addresses = GroupReview.removalAddresses(rows, selected: [a.id,initial.id], pattern: .numeric, rules: [], removed: [])
        XCTAssertEqual(addresses, [a.address])
        var removal = RemovalState()
        removal.remove(addresses)
        XCTAssertEqual(removal.history.count, 1)
        XCTAssertEqual(ResultPolicy.exportSelection(rows, rules: [], removed: removal.addresses, onlyAccepted: false).map(\.id), [exception.id,outside.id,initial.id])
        removal.undo()
        XCTAssertEqual(ResultPolicy.exportSelection(rows, rules: [], removed: removal.addresses, onlyAccepted: false), rows)
        XCTAssertNil(rows[0].classificationDecision)
    }
    func testReviewRemovalRevalidatesExclusionsAndLaterClassification() {
        let a = row("jkb1099@example.org"), excluded = row("bwfro01223@example.org", status: "Excluded"), hidden = row("mocajh91@example.org"), removed = row("ssmith5391@example.org")
        var manual = row("rossis555@example.org")
        manual.classificationDecision = ClassificationDecision(category: .person, changedAt: Date())
        let rows = [a,excluded,hidden,removed,manual]
        let addresses = GroupReview.removalAddresses(rows, selected: Set(rows.map(\.id)), pattern: .numeric, rules: [SmartRule(kind: "Address", pattern: hidden.address)], removed: [removed.address])
        XCTAssertEqual(addresses, [a.address])
        XCTAssertTrue(GroupReview.removalAddresses(rows, selected: [], pattern: .numeric, rules: [], removed: []).isEmpty)
    }
    func testReviewRemovalUndoHistoryRoundTripPreservesEarlierRemovals() throws {
        let a = row("jkb1099@example.org")
        var removal = RemovalState(addresses: ["older@example.org"], history: [["older@example.org"]])
        removal.remove(GroupReview.removalAddresses([a], selected: [a.id], pattern: .numeric, rules: [], removed: removal.addresses))
        var restored = try JSONDecoder().decode(RemovalState.self, from: JSONEncoder().encode(removal))
        restored.undo()
        XCTAssertEqual(restored.addresses, ["older@example.org"])
        XCTAssertEqual(restored.history, [["older@example.org"]])
        XCTAssertTrue(ReviewState().rules.isEmpty)
    }
}

extension GroupReviewAndExportTests {
    func testOneStepPersonExportDoesNotRequireReviewOrDeleteUnknowns() {
        let person = row("sharon.dean@example.org"), uncertain = row("jkb1099@example.org"), shared = row("support@example.org")
        let rows = [person, uncertain, shared]
        XCTAssertEqual(ResultPolicy.personExportRows(rows, includeUncertain: false, rules: [], removed: []).map(\.id), [person.id])
        XCTAssertEqual(ResultPolicy.personExportRows(rows, includeUncertain: true, rules: [], removed: []).map(\.id), [person.id,uncertain.id])
        XCTAssertEqual(rows.count, 3)
        XCTAssertEqual(uncertain.addressClassification.category, .uncertain)
        XCTAssertNil(uncertain.classificationDecision)
    }
    func testPersonExportHonorsEveryExclusionAndSavedCorrection() {
        let person = row("sharon.dean@example.org"), excluded = row("rebecca.dolber@example.org", status: "Excluded"), rejected = row("debra.fyock@example.org", status: "Rejected"), removed = row("sheri.coln@example.org")
        var corrected = row("info@example.org")
        corrected.classificationDecision = ClassificationDecision(category: .person, changedAt: Date())
        let rows = [person,excluded,rejected,removed,corrected]
        let rules = [SmartRule(kind: "Address", pattern: person.address)]
        for includeUncertain in [true,false] {
            XCTAssertEqual(ResultPolicy.personExportRows(rows, includeUncertain: includeUncertain, rules: rules, removed: [removed.address]).map(\.id), [corrected.id])
        }
    }
}

final class ExplicitPersonEvidenceTests: DiskTests {
    func page(_ html: String, _ url: String = "https://example.org/staff", status: Int = 200) -> HTTPResult {
        HTTPResult(data: Data(html.utf8), status: status, finalURL: URL(string: url), mimeType: "text/html")
    }
    func row(_ address: String) -> FoundEmail { FoundEmail(address: address, source: "https://example.org/staff", status: "Accepted", reason: "Local checks") }
    func testReportedPhrasesCountyAndAreaAccountsAreNotPeopleEvenWithLegacyExcerpt() {
        for local in ["mission.of.zelma", "progressive.yamhill", "we.can.ct", "mississippicounty", "whitecounty", "conwaycounty", "popecounty", "johnsoncounty", "faulknercounty", "sharpcounty", "deltaarea", "northdelta", "columbiacounty", "carrollcounty", "clarkcounty", "phillipscounty", "crosscounty", "leecounty", "monroecounty", "cleburnecounty", "greenecounty"] {
            var value = row(local + "@acrf.org")
            value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact address", sourceURL: value.source, excerpt: "Mississippi County White County " + value.address)
            XCTAssertEqual(value.addressClassification.category, .general, local)
        }
        XCTAssertEqual(row("ofa.nws@gmail.com").addressClassification.category, .uncertain)
    }
    func testNamedMailtoAndStructuredPersonResolveOpaqueHandle() throws {
        let address = "jkb1099@example.org"
        let link = "<a href='mailto:jkb1099@example.org'><span>Jane Smith</span></a>"
        let association = try XCTUnwrap(SourcePersonMatcher.collect(link)[address])
        XCTAssertEqual(association.name, "Jane Smith")
        var value = row(address)
        value.websiteConfirmation = WebsiteConfirmer.observe(address: address, source: value.source, response: page(link), checkedAt: Date())
        XCTAssertEqual(value.addressClassification.category, .person)
        XCTAssertEqual(value.status, "Accepted")
        XCTAssertNil(value.smtpVerification)
        let schema = #"<script type="application/ld+json">{"@type":"Person","name":"Jane Smith","email":"jkb1099@example.org"}</script><a href="mailto:jkb1099@example.org">Email</a>"#
        XCTAssertEqual(SourcePersonMatcher.collect(schema)[address]?.method, .schemaPerson)
    }
    func testNearbyNamesTitlesWrongEmailsHiddenMarkupAndConflictsDoNotResolve() {
        let address = "jkb1099@example.org"
        for html in [
            "<h2>Jane Smith</h2><a href='mailto:jkb1099@example.org'>Email</a>",
            "<a href='mailto:jkb1099@example.org'>Executive Director</a>",
            "<a href='mailto:jkb1099@example.org'>Mississippi County</a>",
            "<a href='mailto:other@example.org?subject=jkb1099@example.org'>Jane Smith</a><p>jkb1099@example.org</p>",
            "<!-- <a href='mailto:jkb1099@example.org'>Jane Smith</a> --><p>jkb1099@example.org</p>",
            "<template><a href='mailto:jkb1099@example.org'>Jane Smith</a></template><p>jkb1099@example.org</p>",
            "<a href='mailto:jkb1099@example.org'>Jane Smith</a><a href='mailto:jkb1099@example.org'>John Jones</a>",
            #"<script type="application/ld+json">{"@type":"Organization","name":"Jane Smith","email":"jkb1099@example.org"}</script>"#
        ] { XCTAssertNil(SourcePersonMatcher.collect(html)[address], html) }
    }
    func testUnsafeResponseNeverCreatesPersonAssociationAndEvidenceRoundTrips() throws {
        let html = "<a href='mailto:jkb1099@example.org'>Jane Smith</a>"
        let forbidden = WebsiteConfirmer.observe(address: "jkb1099@example.org", source: "https://example.org/staff", response: page(html, status: 403), checkedAt: Date())
        XCTAssertNil(forbidden.personAssociation)
        let outside = WebsiteConfirmer.observe(address: "jkb1099@example.org", source: "https://example.org/staff", response: page(html, "https://other.org/staff"), checkedAt: Date())
        XCTAssertNil(outside.personAssociation)
        let good = WebsiteConfirmer.observe(address: "jkb1099@example.org", source: "https://example.org/staff", response: page(html), checkedAt: Date())
        XCTAssertEqual(try JSONDecoder().decode(WebsiteConfirmation.self, from: JSONEncoder().encode(good)), good)
    }
    func testNameSeekingFollowupContinuesAfterPublicationWithoutName() {
        var requests: [String] = []
        let checker = WebsiteConfirmer(fetch: { request,_,_ in
            requests.append(request.url!.path)
            if request.url!.path == "/staff/jane" { return self.page("<a href='mailto:jkb1099@example.org'>Jane Smith</a>", request.url!.absoluteString) }
            return self.page("<a href='mailto:jkb1099@example.org'>Email</a><a href='/staff/jane'>Staff profile</a>", request.url!.absoluteString)
        })
        let result = checker.confirmPerson(address: "jkb1099@example.org", source: "https://example.org/staff")
        XCTAssertEqual(result.personAssociation?.name, "Jane Smith")
        XCTAssertEqual(result.sourceURL, "https://example.org/staff")
        XCTAssertEqual(result.personNameCheckVersion, 1)
        XCTAssertTrue(requests.contains("/staff/jane"))
    }
    func testSourceCacheReusesPageForSeveralNamesAndOrdinaryConfirmationStaysDirect() {
        var count = 0
        let checker = WebsiteConfirmer(fetch: { request,_,_ in
            count += 1
            return self.page("<a href='mailto:jkb1099@example.org'>Jane Smith</a><a href='mailto:xyz123@example.org'>Qylthar Zorvek</a>", request.url!.absoluteString)
        })
        XCTAssertNotNil(checker.confirmPerson(address: "jkb1099@example.org", source: "https://example.org/staff").personAssociation)
        XCTAssertNotNil(checker.confirmPerson(address: "xyz123@example.org", source: "https://example.org/staff").personAssociation)
        XCTAssertEqual(count, 1)
        let plainChecker = WebsiteConfirmer(fetch: { request,_,_ in
            var response = self.page("<a href='mailto:jkb1099@example.org'>Jane Smith</a>", request.url!.absoluteString)
            response.mimeType = "TEXT/PLAIN"
            return response
        })
        let plain = plainChecker.confirm(address: "jkb1099@example.org", source: "https://example.org/staff")
        XCTAssertEqual(plain.match, .pageText)
        XCTAssertNil(plain.personAssociation)
    }
    func testAutomaticTargetsRespectScopeChoicesRecentAttemptsAndExclusions() {
        let a = row("jkb1099@example.org"), b = row("xyz123@example.org")
        var manual = row("mocajh91@example.org")
        manual.classificationDecision = ClassificationDecision(category: .uncertain, changedAt: Date())
        var recent = row("ssmith5391@example.org")
        recent.websiteConfirmation = WebsiteConfirmation(outcome: .notFound, reason: "Checked", checkedAt: Date(), sourceURL: recent.source, personNameCheckVersion: 1)
        let rows = [a,b,manual,recent,row("info@example.org")]
        XCTAssertEqual(AutomaticPersonSort.targets(rows, selected: Set(rows.map(\.id)), rules: [], removed: []).map(\.address), [a.address,b.address])
        XCTAssertTrue(AutomaticPersonSort.targets(rows, selected: [a.id], rules: [SmartRule(kind: "Address", pattern: a.address)], removed: []).isEmpty)
        XCTAssertTrue(AutomaticPersonSort.targets(rows, selected: [b.id], rules: [], removed: [b.address]).isEmpty)
        XCTAssertEqual(AutomaticPersonSort.counts(rows, rules: [], removed: []).shared, 1)
    }
}

final class LocalLearningAndExportTests: DiskTests {
    func row(_ address: String) -> FoundEmail { FoundEmail(address: address, source: "https://example.org/staff", status: "Accepted", reason: "Fixture") }
    func testThreeDistinctExamplesLearnPatternAndPersonCorrectionVetoesIt() {
        let rows = ["civicdesk.east@example.org", "civicdesk.west@example.org", "civicdesk.north@example.org"].map(row)
        let id = UUID()
        var profile = LearningProfile(), removal = RemovalState()
        removal.remove(Set(rows.prefix(2).map(\.address)), learn: true)
        profile.synchronize(projectID: id, rows: rows, removal: removal, review: ReviewState())
        XCTAssertNil(LocalLearningModel(profile: profile).evidence("civicdesk.south@example.org"))
        removal.remove([rows[2].address], learn: true)
        profile.synchronize(projectID: id, rows: rows, removal: removal, review: ReviewState())
        XCTAssertEqual(LocalLearningModel(profile: profile).evidence("civicdesk.south@example.org")?.category, .general)
        var positive = row("civicdesk.jane@example.org")
        positive.classificationDecision = ClassificationDecision(category: .person, changedAt: Date())
        profile.synchronize(projectID: id, rows: rows + [positive], removal: removal, review: ReviewState())
        XCTAssertNil(LocalLearningModel(profile: profile).evidence("civicdesk.south@example.org"))
    }
    func testUndoRemovalUnlearnsAndOtherProjectLessonsRemain() {
        let rows = ["civicdesk.east@example.org", "civicdesk.west@example.org", "civicdesk.north@example.org"].map(row)
        let id = UUID(), otherID = UUID()
        var profile = LearningProfile(), removal = RemovalState()
        var other = row("personalxyz@example.org")
        other.classificationDecision = ClassificationDecision(category: .person, changedAt: Date())
        profile.synchronize(projectID: otherID, rows: [other], removal: RemovalState(), review: ReviewState())
        for value in rows { removal.remove([value.address], learn: true) }
        profile.synchronize(projectID: id, rows: rows, removal: removal, review: ReviewState())
        XCTAssertNotNil(LocalLearningModel(profile: profile).evidence("civicdesk.south@example.org"))
        removal.undo()
        profile.synchronize(projectID: id, rows: rows, removal: removal, review: ReviewState())
        XCTAssertNil(LocalLearningModel(profile: profile).evidence("civicdesk.south@example.org"))
        XCTAssertNil(LocalLearningModel(profile: profile).evidence(rows[2].address))
        XCTAssertEqual(LocalLearningModel(profile: profile).evidence(other.address)?.category, .person)
    }
    func testNoDomainLearningOrRepeatedAddressAmplification() {
        var profile = LearningProfile()
        let value = row("civicdesk.east@example.org")
        for _ in 0..<5 {
            var removal = RemovalState(); removal.remove([value.address], learn: true)
            profile.synchronize(projectID: UUID(), rows: [value], removal: removal, review: ReviewState())
        }
        let model = LocalLearningModel(profile: profile)
        XCTAssertTrue(model.patterns.isEmpty)
        XCTAssertNil(model.evidence("civicdesk.west@example.org"))
        XCTAssertNil(model.evidence("sharon.dean@example.org"))
    }
    func testPredictionsNeverTrainThemselvesAndSourceAssociationBeatsPattern() {
        let rows = ["civicdesk.east@example.org", "civicdesk.west@example.org", "civicdesk.north@example.org"].map(row)
        var profile = LearningProfile(), removal = RemovalState()
        removal.remove(Set(rows.map(\.address)), learn: true)
        profile.synchronize(projectID: UUID(), rows: rows, removal: removal, review: ReviewState())
        let model = LocalLearningModel(profile: profile)
        var predicted = model.applying(to: [row("civicdesk.south@example.org")])[0]
        XCTAssertEqual(predicted.addressClassification.category, .general)
        let before = profile.exampleCount
        profile.synchronize(projectID: UUID(), rows: [predicted], removal: RemovalState(), review: ReviewState())
        XCTAssertEqual(profile.exampleCount, before)
        predicted.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact link", sourceURL: predicted.source, personAssociation: SourcePersonAssociation(name: "Jane Smith", address: predicted.address, method: .namedEmailLink, sourceExcerpt: "Named email link"))
        XCTAssertEqual(predicted.addressClassification.category, .person)
        predicted.classificationDecision = ClassificationDecision(category: .uncertain, changedAt: Date())
        XCTAssertEqual(predicted.addressClassification.category, .uncertain)
    }
    func testLearningProfileAndRemovalDatesPersistAndLegacyStateDecodes() throws {
        let value = row("jkb1099@example.org")
        var profile = LearningProfile(), removal = RemovalState()
        removal.remove([value.address], learn: true)
        profile.synchronize(projectID: UUID(), rows: [value], removal: removal, review: ReviewState())
        XCTAssertTrue(CrawlDisk.saveLearningProfile(profile))
        XCTAssertEqual(CrawlDisk.loadLearningProfile(), profile)
        let restored = try JSONDecoder().decode(RemovalState.self, from: JSONEncoder().encode(removal))
        XCTAssertEqual(restored.learningDates, removal.learningDates)
        let legacy = try JSONDecoder().decode(RemovalState.self, from: Data(#"{"addresses":[],"history":[]}"#.utf8))
        XCTAssertNil(legacy.learningDates)
    }
    func testResetCutoffDoesNotRelearnOldChoicesAndNewFeedbackWorks() {
        let value = row("jkb1099@example.org"), new = row("ssmith5391@example.org")
        var removal = RemovalState()
        removal.remove([value.address], learn: true, at: Date(timeIntervalSince1970: 10))
        var profile = LearningProfile(resetAt: Date(timeIntervalSince1970: 20))
        profile.synchronize(projectID: UUID(), rows: [value], removal: removal, review: ReviewState())
        XCTAssertEqual(profile.exampleCount, 0)
        removal.remove([new.address], learn: true, at: Date(timeIntervalSince1970: 30))
        profile.synchronize(projectID: UUID(), rows: [value,new], removal: removal, review: ReviewState())
        XCTAssertEqual(profile.exampleCount, 1)
    }
    func testSuccessfulExportRemovesOnlyWrittenAddressesWithoutNegativeLearning() throws {
        let a = row("sharon.dean@example.org"), b = row("jkb1099@example.org")
        let original = RemovalState(addresses: ["old@example.org"], history: [["old@example.org"]])
        let file = directory.appendingPathComponent("people.csv")
        var committed = try CSVExportTransaction.write([a], to: file, removal: original)
        XCTAssertTrue(try String(contentsOf: file).contains(a.address))
        XCTAssertFalse(try String(contentsOf: file).contains(b.address))
        XCTAssertEqual(committed.addresses, ["old@example.org",a.address])
        XCTAssertNil(committed.learningDates)
        XCTAssertEqual(ResultPolicy.exportSelection([a,b], rules: [], removed: committed.addresses, onlyAccepted: false).map(\.address), [b.address])
        var profile = LearningProfile()
        profile.synchronize(projectID: UUID(), rows: [a,b], removal: committed, review: ReviewState())
        XCTAssertEqual(profile.exampleCount, 0)
        committed.undo()
        XCTAssertEqual(committed, original)
    }
    func testFailedExportLeavesOriginalRemovalStateUnchanged() {
        let original = RemovalState(addresses: ["old@example.org"], history: [["old@example.org"]])
        let missing = directory.appendingPathComponent("missing/people.csv")
        XCTAssertThrowsError(try CSVExportTransaction.write([row("sharon.dean@example.org")], to: missing, removal: original))
        XCTAssertEqual(original.addresses, ["old@example.org"])
        XCTAssertEqual(original.history.count, 1)
        XCTAssertFalse(FileManager.default.fileExists(atPath: missing.path))
    }
}

extension LocalLearningAndExportTests {
    func testRememberedPredictionsDoNotBecomeFeedbackAndUndoUnlearnsGroup() {
        let rows = ["civicdesk.east@example.org", "civicdesk.west@example.org", "civicdesk.north@example.org"].map(row)
        var review = ReviewState(), profile = LearningProfile()
        let id = UUID()
        let edited = review.approve(rows, selected: Set(rows.map(\.id)), pattern: .unrecognized, category: .general, remember: true)
        profile.synchronize(projectID: id, rows: edited, removal: RemovalState(), review: review)
        XCTAssertEqual(profile.exampleCount, 3)
        let future = review.applyingRules(to: [row("civicdesk.south@example.org")])
        profile.synchronize(projectID: id, rows: edited + future, removal: RemovalState(), review: review)
        XCTAssertEqual(profile.exampleCount, 3)
        let undone = review.undo(edited + future)
        profile.synchronize(projectID: id, rows: undone, removal: RemovalState(), review: review)
        XCTAssertEqual(profile.exampleCount, 0)
    }
    func testExportNeverReusesStaleNotPersonLessonFromImportedState() throws {
        let a = row("sharon.dean@example.org")
        let raw = #"{"addresses":[],"history":[],"learningDates":{"sharon.dean@example.org":100}}"#
        let stale = try JSONDecoder().decode(RemovalState.self, from: Data(raw.utf8))
        let committed = try CSVExportTransaction.write([a], to: directory.appendingPathComponent("people.csv"), removal: stale)
        XCTAssertNil(committed.learningDates)
        var profile = LearningProfile()
        profile.synchronize(projectID: UUID(), rows: [a], removal: committed, review: ReviewState())
        XCTAssertEqual(profile.exampleCount, 0)
    }
}

extension ExplicitPersonEvidenceTests {
    func testNameSortBudgetAndCancellationDoNotMarkUnfinishedChecksComplete() {
        var requests = 0
        let checker = WebsiteConfirmer(fetch: { request,_,_ in
            requests += 1
            return self.page("<p>No contact address here</p>", request.url!.absoluteString)
        })
        var last: WebsiteConfirmation?
        for i in 0..<100 { last = checker.confirmPerson(address: "jkb1099@other.org", source: "https://example.org/page/" + String(i)) }
        XCTAssertEqual(requests, 100)
        XCTAssertTrue(checker.pageLimitReached)
        XCTAssertNil(last?.personNameCheckVersion)
        XCTAssertNil(checker.confirmPerson(address: "jkb1099@other.org", source: "https://example.org/unchecked").personNameCheckVersion)
        XCTAssertNil(checker.confirmPerson(address: "jkb1099@other.org", source: "https://example.org/cancelled", cancelled: { true }).personNameCheckVersion)
        XCTAssertEqual(requests, 100)
    }
}

extension ExplicitPersonEvidenceTests {
    func testReportedSharedFunctionsAndCollectiveHandlesAreGeneral() {
        for address in ["join@civicalliance.com", "giving@commoncause.org", "visuals@calmatters.org", "dev@tealmedia.com", "votingmatters@calmatters.org", "igcadvocates@gmail.com", "demsinbrandon@aol.com", "northpinellasdems@gmail.com", "eldoradoprogressives@gmail.com", "progressivewatertown@gmail.com", "progressiveroxroz@gmail.com", "districtoneneighbors@gmail.com", "downtownnastywomen@gmail.com", "occupynhseacoast@gmail.com", "wewillpersistc@gmail.com", "comoforprogress@gmail.com", "greylocktogether@gmail.com", "manhattanbeach@gmail.com", "arcf@arcf.org"] {
            XCTAssertEqual(row(address).addressClassification.category, .general, address)
        }
        for local in ["join+volunteers", "giving2027", "southcoastprogressives", "townshipadvocates", "newtownneighbors", "demsinnewtown", "newtowndems", "district.people"] {
            XCTAssertEqual(row(local + "@example.org").addressClassification.category, .general, local)
        }
    }
    func testAmbiguousPeopleAndShortAbbreviationsAreNotBlanketGeneral() {
        for address in ["jodya@mydacil.org", "stromf@hcfl.gov", "dhu@calmatters.org", "aco@arkansascomm.org", "icccr@tc.columbia.edu", "donnis33@hotmail.com", "amthanos@mac.com", "lenagonio@verizon.net", "hope@hillsboroughhope.org"] {
            XCTAssertNotEqual(row(address).addressClassification.category, .general, address)
        }
        for address in ["sharon.dean@gmail.com", "johnbeach@gmail.com", "jane@janeconsulting.com", "sharon@sharon.org", "john.smith@advocates.org", "dev.patel@example.org"] {
            XCTAssertEqual(row(address).addressClassification.category, .person, address)
        }
        XCTAssertNotEqual(row("arcf@gmail.com").addressClassification.category, .general, "Free-provider names do not make an organization")
        XCTAssertFalse(AddressClassification.roleNames.contains("join"), "Presentation changes must not change crawler exclusions")
    }
}

extension LocalLearningAndExportTests {
    func testPersonExportEmptiesOnlyPersonViewAndPreservesOtherCategories() throws {
        let person = row("sharon.dean@example.org"), shared = row("support@example.org"), uncertain = row("jkb1099@example.org")
        let rows = [person,shared,uncertain]
        let target = ResultPolicy.personExportRows(rows, includeUncertain: false, rules: [], removed: [])
        let committed = try CSVExportTransaction.write(target, to: directory.appendingPathComponent("people.csv"), removal: RemovalState())
        let remaining = ResultPolicy.filtered(rows, rules: [], removed: committed.addresses, status: "Included", search: "", scope: "Email")
        XCTAssertEqual(remaining.map(\.id), [shared.id,uncertain.id])
        XCTAssertTrue(remaining.filter { $0.addressClassification.category == .person }.isEmpty, "An empty person-only view is not deletion of remaining categories")
        XCTAssertEqual(rows.count, 3)
    }
    func testFilteredPersonExportCannotIncludeHiddenPeopleOrUncertain() throws {
        let a = row("sharon.dean@example.org"), hiddenPerson = row("rebecca.dolber@example.org"), hiddenUncertain = row("jkb1099@example.org")
        let rows = [a,hiddenPerson,hiddenUncertain]
        let visible = ResultPolicy.filtered(rows, rules: [], removed: [], status: "Included", search: "sharon", scope: "Email")
        let target = ResultPolicy.personExportRows(visible, includeUncertain: true, rules: [], removed: [])
        XCTAssertEqual(target.map(\.id), [a.id])
        let committed = try CSVExportTransaction.write(target, to: directory.appendingPathComponent("filtered.csv"), removal: RemovalState())
        XCTAssertEqual(ResultPolicy.filtered(rows, rules: [], removed: committed.addresses, status: "Included", search: "", scope: "Email").map(\.id), [hiddenPerson.id,hiddenUncertain.id])
    }
    func testIncludingUncertainRemovesExactlyWrittenCandidatesNotGeneral() throws {
        let person = row("sharon.dean@example.org"), shared = row("support@example.org"), uncertain = row("jkb1099@example.org")
        let rows = [person,shared,uncertain]
        let target = ResultPolicy.personExportRows(rows, includeUncertain: true, rules: [], removed: [])
        XCTAssertEqual(target.map(\.id), [person.id,uncertain.id])
        var committed = try CSVExportTransaction.write(target, to: directory.appendingPathComponent("candidates.csv"), removal: RemovalState())
        XCTAssertEqual(committed.addresses, [person.address,uncertain.address])
        XCTAssertEqual(ResultPolicy.filtered(rows, rules: [], removed: committed.addresses, status: "Included", search: "", scope: "Email").map(\.id), [shared.id])
        committed.undo()
        XCTAssertTrue(committed.addresses.isEmpty)
        XCTAssertNil(committed.learningDates)
    }
}
