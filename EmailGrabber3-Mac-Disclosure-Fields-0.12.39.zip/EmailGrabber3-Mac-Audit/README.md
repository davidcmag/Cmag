## 0.12.39: contact fields inside group disclosures

Names and addresses in separate labeled fields of the same disclosure entry can now be associated even when the entry title is an organization/group rather than a person. Heading labels do not compete with corroborated body names. Standard ARIA disclosures and native details/summary entries are supported. Multiple contacts are accepted only when every address has a unique, distinct matching name; ambiguous, incomplete, hidden or mismatched evidence remains unresolved. No website, person, industry or CSS-class hardcoding was added. Existing unresolved records can be retried with **Sort this list automatically** under name-check version 7. See DISCLOSURE-FIELDS-0.12.39.md. Native Mac build/GUI remains unverified.

## 0.12.38: names in ordinary contact text

Name matching now supports bounded paragraph/address blocks without heading tags, honorifics before names, a named contact within a larger narrative section, and full given-name plus surname-initial handles. The match must corroborate the exact address and remain unambiguous within the contact block. Heading/table/card safeguards, shared-inbox rules, saved choices, mismatch holds and source-first sorting remain. Existing unresolved records can be rechecked with **Sort this list automatically**; older attempts are eligible under name-check version 6. No Clear, learning reset or full recrawl is required. See CONTACT-TEXT-0.12.38.md. Native Mac build/GUI remains unverified.

## 0.12.37: source-first automatic sorting

Automatic person sorting now checks source pages across the current list before spending the batch budget on deeper follow-ups. A rendered directory is parsed and reused for its other addresses, and historical publication URLs are retained as leads for fresh checks. Browser name sorting waits for name evidence rather than stopping when only the email appears; DOM inspection runs off the UI thread. Partial attempts no longer start a false 24-hour cooldown, and reruns prioritize unattempted sources. Existing page/time limits, saved choices, learning/removal recovery, mismatch holds and pending crawl work remain. Use **Sort this list automatically** again after installing. See SOURCE-FIRST-SORTING-0.12.37.md. Native Mac build/GUI remains unverified.

## 0.12.36: conflicting email links and multi-part names

When an email link displays one address but points to another, both records retain a mismatch warning. The displayed contact stays eligible; the conflicting destination is held from CSV exports and normal copying until explicitly approved. Right-click the held row to inspect evidence, approve it, or restore its hold. Classification does not approve an export hold. Existing records gain the check through **Confirm selected on website**. Source-page rechecks, partial crawls, checkpoints and project saves preserve mismatch evidence and dated approval/revocation decisions.

Contact cards now support a handle matching an earlier component of a multi-part published name, while retaining short-surname support. Use **Sort this list automatically** to refresh existing unresolved name classifications. No Clear or learning reset is required. See EMAIL-LINK-MISMATCH-0.12.36.md. Native Mac build/GUI remains unverified.

## 0.12.35: names in contact cards and disclosure panels

Contact-card headings can now associate a person with the matching email inside the same bounded card, including plain email text in an expanded or locally controlled collapsed panel. Matching requires a corroborating name/address pattern; neighboring cards, multiple recipients, conflicting names and unrelated hidden content are rejected. Table-row matching and continuous crawling remain. Use **Sort this list automatically** to recheck existing unresolved records; checks by older versions can be retried immediately. Saved manual choices, learning and removal recovery remain unchanged. See CONTACT-CARDS-0.12.35.md. Native Mac build/GUI remains unverified.

## 0.12.34: names in directory table rows

Names and email addresses in separate cells of the same directory row can now establish a Person association, including email text linked back to the directory rather than mailto. Labeled Name/Email columns support opaque handles; headerless rows require name/address corroboration. Ambiguous rows and neighboring people remain separate, shared-inbox and saved-correction safeguards remain. Name/publication checks now accept the crawler's same bounded 3 MB page size. Existing unresolved records can be rechecked with **Sort this list automatically**, including records checked by older versions in the last 24 hours. No Clear or learning reset is needed. See DIRECTORY-NAMES-0.12.34.md. Native Mac build/GUI remains unverified.

## 0.12.33: continue crawling after slow pages

Address/link extraction timeouts and temporary network/robots/host-wait failures retain pending pages and continue healthy work. Automatic retries wait 30 seconds, then back off to at most five minutes per attempt. When only deferred work remains, the app shows Waiting to retry until Stop, a selected page limit, or true frontier exhaustion. Stop cancels the wait; pending pages and partial rows survive Resume/restart. Existing limits, general directory traversal, learning and removal recovery remain. See CONTINUOUS-CRAWL-0.12.33.md. Native Mac build/GUI remains unverified.

## 0.12.32: general Adaptive directory traversal

Directory → organization profile → official website traversal now uses general directory structure and repeated entry links, with profile context preserved across Resume. It is no longer limited to college/institution routes. Existing external-link controls and exclusions remain. See GENERAL-DIRECTORIES-0.12.32.md for tests, limits and Mac use. Native Mac build/GUI and live directory behavior remain unverified.

## 0.12.31: Adaptive directory-to-college traversal

Adaptive now recognizes intermediate institution-directory links and explicit official-website links from college profiles. External crawling remains opt-in and existing exclusions remain active. Completed pages report link/queue counts. See DIRECTORY-BRIDGES-0.12.31.md for verification and steps to re-examine an exhausted starting page without Clear. Native Mac build/GUI and live BigFuture behavior remain unverified.

## 0.12.30: responsive extraction, truthful failures, people discovery

Stop can interrupt slow regex matching and DNS child processes; interrupted pages remain queued. The UI stays Stopping during cancellation. Robots failures show the actual error and elapsed time. University/college keyword searches prioritize faculty/staff directories, keep better same-host seeds and follow academic gateways and named directory profiles. Shared inbox classifications and existing learning remain intact. See EXTRACTION-DISCOVERY-0.12.30.md for findings, limits and Mac acceptance. Native Mac build/GUI and live WHED/search yield remain unverified.

## 0.12.29: bounded crawl waits and retained timeouts

Website throttling now has a bounded, cancellable wait and a separate elapsed status. Downloads report their total timeout budget. Timed-out pages remain pending for the next resume while other sites continue. The Learning-menu checkmarks observe preference changes directly. See CRAWL-WAITS-0.12.29.md for findings, limits and Mac acceptance. The exact reported GAO stall has not been reproduced; native Mac build and GUI remain unverified.

## 0.12.28: broader local feedback learning

Explicit Person/General corrections now teach recurring published-page phrases as well as existing address patterns. Learning → Teach useful examples prioritizes conflicts and partially supported wording. Ordinary removal hides addresses without teaching a class; an explicit General-inbox removal lesson is opt-in. Earlier feedback and the 0.12.27 removal recovery are preserved. See FEEDBACK-LEARNING-0.12.28.md.

## 0.12.27: removal recovery

Removed addresses are recovered from the newest state for this project when reopening or resuming an older saved crawl. Undo and Restore create newer state too. See REMOVAL-RECOVERY-0.12.27.md. Native Mac build and GUI acceptance still required.

0.12.26 adds singular/plural function normalization, department-title composition and scoped government election aliases. See ROLE-FORMS-0.12.26.md. Existing automatic records update without clearing data.
0.12.25 added an opt-in local trained context-model preview. It is off by default: see CONTEXT-MODEL-0.12.25.md for limited evaluation, training provenance and how to enable it.
0.12.24 fixed runaway contact-crawl queues, bounded the displayed queue preview, batched huge checkpoint writes and separated new records from duplicate matches. See CRAWL-0.12.24.md before resuming an oversized queue.
0.12.23 improved local learning: corrected handles can transfer across independent domains, and explicit Person feedback can teach organization-specific address formats with source context and conflict safeguards. See LEARNING-0.12.23.md.
0.12.22 expanded organization-qualified services, civic offices, editorial aliases and collective handles based on an audit of the uploaded session.
See CLASSIFICATION-0.12.22.md for audit counts and limitations. It includes all prior fixes.
0.12.21 expanded editorial, reader-service, academic and business department recognition.
See CLASSIFICATION-0.12.21.md for coverage, compositional rules and limitations.
0.12.20 added regional office context, campus service accounts, and technical bug-report rejection.
See CLASSIFICATION-0.12.20.md for this update. It retains the 0.12.19 department/shared inbox fixes.
See CLASSIFICATION-0.12.19.md for behavior, limitations, and validation. This is source;
native macOS compilation and GUI acceptance still require a Mac. Earlier export fixes remain.
Export people in this list (count) now uses only the current filtered list; Include
Uncertain cannot add hidden addresses. Whole-project exports are explicit menu choices.
The save dialog shows exact category counts. After a successful save/removal, filters
reset to All classifications / Included so remaining results appear automatically.
The heading distinguishes shown from saved rows; empty views offer saved-record and
Undo access. Cancelled/failed exports do not reset the view or remove any records.

0.12.17 broadens General inbox signals: shared functions (join, giving, visuals,
dev and related terms), collective/campaign roots and plurals, qualified dems handles,
collective phrases, and place-based accounts without supporting personal-name parts.
An opaque mailbox repeating its own non-free-provider domain label is treated as a
brand account, while recognized personal-name components and placeholder words are
protected. Domain-wide exclusions are never inferred. dev.patel remains a person
pattern even though standalone dev is a shared function. Ambiguous initials and
personal-looking handles are not blanket-classified General. Existing automatic
results update on display; saved corrections/learning retain priority.

0.12.16 fixes the Mac compiler error at the learning toggle: ResultsPane stores its
model as a plain reference, so it now uses an explicit getter/setter Binding instead
of the unavailable $model projection. This was the blocking error in the supplied
0.12.15 Terminal output; the preceding concurrency/deprecation messages were warnings.
Learning, source sorting, export cleanup and saved-data formats are unchanged.

0.12.15 adds local feedback-based learning and source-name sorting. Learning: ON
remembers new removals as not-a-person feedback unless you turn that option off;
explicit Person/General corrections also teach it. Exact addresses are remembered
immediately. Broader lexical patterns require at least three distinct handles and
no conflicting Person examples. Undo removal and Undo group decision unlearn their
feedback. The profile stays on this Mac across projects; Learning → Reset clears it.

Sort this list automatically checks unresolved source URLs, reusing pages and bounded
same-site follow-ups for explicit name/email associations (named mailto links or
Schema.org Person fields). It reports People / Shared inboxes / Needs review and
supports Stop. No SMTP probes or paid credits. Loose nearby capitalized words are
no longer treated as name proof; phrases, county and area accounts have safeguards.

A successful CSV export now removes only the exported addresses from current results
and suppresses later duplicates in that crawl. Undo removal restores them. Cancelled
or failed writes leave results unchanged. Exporting does not teach not-a-person
feedback. Originals remain saved. CSV format and exclusions remain unchanged.

0.12.14 adds Export person list directly in the main window. It exports included
Likely person results from the whole project in one action. Include Uncertain adds
unresolved possible people; the preference is remembered on this Mac. General inboxes,
exclusions and removals are omitted in both modes. All original records remain saved.
Current-list and other explicit export scopes remain available under Export CSV….

Review assistant now also has Remove group, using the same checked addresses and
unchecked exceptions, followed by count confirmation. Undo removal is in the
assistant header. Removal uses existing saved removal history, affects all copies
of the selected exact addresses, and creates no group/pattern removal rule.

0.12.13 adds Review assistant… beside Address type. It groups unresolved included
addresses from the current list, shows samples, and lets you expand groups to
uncheck exceptions before marking the group Person, General inbox or Uncertain.
Undo group decision is available in the assistant and main window. Remembering a
pattern for future matching addresses is optional; individual choices and exceptions
win. Decisions, optional rules and Undo history survive saving and reopening.

CSV export now offers Current list, All included results (all address types), and
All accepted / verified. Current list respects address type/search/status filters.
Every export omits crawler-excluded, rule-excluded and removed records. The former
Export all ignored current filters and did not suppress raw Excluded status; both
paths are fixed. CSV columns and evidence formatting are unchanged.

0.12.12 replaces the small given-name whitelist with pattern evidence and scoring.
Separated name words (either order, including middle initials) do not need to occur
in a name dictionary. Joined names, joined middle initials, and single-name handles
use bundled Census-derived components as optional positive evidence. Short numeric
suffixes do not disqualify otherwise supported full-name patterns. Roles and
organization signals take priority; ambiguous initials and unsupported handles
remain reviewable. No new requests or paid verification are needed.

Manual corrections still win. Existing rows reclassify on display without a recrawl.
See CLASSIFICATION.md for the mixed evaluation, evidence rules and limitations.

0.12.11 adds saved manual classification corrections. Select rows and use
Classify selected… → Mark as Likely person / General inbox / Uncertain, or right-click
an address. Use automatic classification resets a correction. Corrections apply to
all copies of that address in the current project and survive saving, reopening,
recrawling, live updates and older checkpoint merges. Classification reason is now
an explicit column. Organization terms and surname-first names are recognized;
initials still require matching recorded full-name evidence or your correction.
Filtering never deletes rows; verification and CSV behavior stay unchanged.

0.12.10 makes bulk selection explicit: Select all (count) selects every row in
the current list, including offscreen rows, respecting address type, search and
status filters. Deselect all clears the selection. With no filters, Select all
selects the entire list. Selection itself does not remove or change saved data.

0.12.9 fixes job-title mailboxes incorrectly shown as Likely person.
Executive Director, Deputy Director and Development Director addresses are General
inbox, even when those titles appear beside the address in website evidence.
Capitalized job titles and shared-inbox terms cannot serve as person-name evidence.
Actual matching staff names can still strengthen a person's classification.
Existing saved results are reclassified automatically; no recrawl or deletion is
needed. Filtering, verification, CSV, saved data and removal history are unchanged.

0.12.8 adds conservative address classification, reasons on the Address type
column, a Person addresses only filter, sortable classifications and reviewed
category removal using the existing removal history and Restore last removal.
Classification never changes verification or deletes filtered rows. Initials and
unusual single-word names remain Uncertain without recorded name evidence.
Existing role exclusions retain their previous behavior; newsroom is recognized
for classification without silently changing crawl exclusions. CSV stays unchanged.
Native macOS compilation and live WebKit behavior require macOS validation.

0.12.7 adds an in-app WebKit fallback to fresh website confirmation. A direct
HTML miss or access challenge can be retried in a fresh isolated browser view.
Only an exact visible-text/email-link match confirms publication; SMTP stays separate.
Native macOS build and live CPR rendering are not verified on the Linux builder.

0.12.6 adds a visible **Show evidence** button beside Copy selected. Select one
row using its checkbox, then click Show evidence and Copy evidence. This avoids
macOS text-selection menus intercepting the email cell's right-click menu.

0.12.5 also records publication evidence during discovery from the downloaded
page, without another HTTP request. Fresh checks that miss on the original
source perform bounded same-site profile/contact follow-up and retain the
actual matching page URL. Original Source values stay unchanged.

Fresh website confirmation is included in 0.12.5. Select an email and click
**Confirm selected on website**, or right-click it and choose **Confirm on
website**. No EHLO/sender setup is needed. Results appear in the Website column;
SMTP checks also collect this independent source evidence. Read
WEBSITE-CONFIRMATION.md for outcomes, limits and Mac validation status.

# Email Grabber 3 — SMTP development candidate 0.12.7

Read SMTP-CHECKER.md first. The optional direct SMTP checker has 240 passing
portable tests; macOS build, native TLS test and GUI checks are still required.
No public mailbox probes or paid provider calls were made during development.

On your Mac: `bash verify-mac.sh`, then `open EmailGrabber3.xcodeproj` and ⌘R
after tests pass. Keep your existing app and source as a fallback.

# Email Grabber 3 — audited Mac source candidate 0.11.13

Audited from the supplied `EmailGrabber3-v0.11.6-filter-scope.zip`. The uploaded original is unchanged. This is repaired source, not a compiled, notarized or fully Mac-validated release. Read AUDIT.md for findings and verification limits.

## With your existing Xcode

1. Quit the previous Email Grabber app; keep its app bundle and source as a fallback.
2. In Terminal, enter this extracted folder and run `bash verify-mac.sh`. It first makes a private backup of existing EmailGrabber3 application data, then asks Xcode to build the application and run the tests. No VPS commands, Python dependencies, API keys or paid services are needed.
3. If that succeeds, open `EmailGrabber3.xcodeproj`, choose the EmailGrabber3 scheme and My Mac, and press Command-R. Complete MAC-ACCEPTANCE.md before treating the candidate as your replacement.

The script stores the complete Xcode log and result bundle under `validation/`. It does not install over your existing app. Xcode uses local ad-hoc signing; no Apple Developer team or notarization is claimed. An alternative local application build remains available with `bash build-mac.sh`.

## What changed

0.11.13 addresses resource overhead seen during a 664-page crawl. Crawl display
events are combined and applied at most five times per second, with all email
deltas retained in order. The results subtree no longer observes unrelated
progress changes; cached filters process only appended records unless rules,
removals, status, search, field scope or existing records change. Sorting does
not rerun unchanged filtering. Pending URLs remain fully visible and uncapped.

Page processing uses a native autorelease pool per step on macOS. HTML decoding
skips unnecessary work, link regexes are reused, and each candidate is scored
once before sorting. A successful page's checkpoint is reused as the next
request's durable starting point, avoiding duplicate whole-state writes.
Every completed page is still saved, unfinished requests remain recoverable,
and the final display buffer is drained before the job is finalized. Streaming
row updates use crawl checkpoints instead of also scheduling repeated whole-
project autosaves; projects still save at start/end, explicit Save, on quit and
when reusable rules/manual removals change.

Relevance uses contact/profile path segments and explicit contact labels,
rather than treating ordinary prose containing "hosts" or "about" as contact
navigation. In a multiword query such as "podcast hosts", generic "host" alone
cannot carry the crawl onto an unrelated site. Topic selection remains a
heuristic, not a guarantee. Existing saved queues/results are preserved;
stricter link selection applies to newly considered links.

128 portable core tests pass, including the reported data sizes, coalesced
display delivery, cache invalidation, checkpoint continuity, relevance and
existing selection/filter/concurrency behavior. PERFORMANCE.md records a
synthetic Linux comparison against 0.11.12. Actual macOS CPU, memory plateau
and GUI behavior have not been measured in this cloud environment.


0.11.12 makes plain row clicks additive: click another row to add it, and click
a selected row to deselect it. Checkboxes use the same explicit selection set.
The native table no longer owns that set, so a native single-row selection or
refresh cannot replace earlier explicit selections. Selected cells are tinted.
Select visible, Copy selected, filtering and sorting remain available.
Changing the filter/status intentionally clears selection as before.

The exact reported 32-hex-character key at sentry.io is now rejected before
extraction acceptance or DNS checks. Regional Sentry ingest and Wix telemetry
hosts remain rejected. Ordinary mailboxes such as support@sentry.io and hex
mailboxes at unrelated domains remain eligible. On restoration/resume, existing
technical records are reclassified as Rejected without losing ID, source or
timestamp. Included view and accepted export reject them even if an old status
claimed Accepted or Verified. All/Rejected retain them for inspection.

117 portable core tests pass. The user's clarification narrowed the selection
repair to additive row/checkbox state; the existing SwiftUI grid is retained.
Actual Mac mouse/keyboard interaction still requires the acceptance checks.


0.11.11 defaults to Found order and offers Email A–Z / Email Z–A in the Order
control. Clicking sortable column headers remains available; choose Found order
to return to collection sequence. Incoming rows append rather than moving
existing rows alphabetically by default. Email text is selectable, row
checkboxes and Copy selected stay available during crawling, and the email cell
context menu supports Copy email and recoverable Remove email.

Results search, blocked input entries and a new Wildcard reusable rule support
case-insensitive * (zero or more characters) and ? (one character). Wildcards
match a whole email or selected field; use *word* for contains behavior.
Examples: info@*, *@example.org, *support*, sales?@example.org. Plain search
text and existing literal exclusion entries retain their substring behavior.
Wildcard rules have the same preview, undo, Included view and export behavior
as other rules. They apply to existing and newly collected addresses.
The matcher executes no regex and bounds patterns to 512 characters and field
values to 16,384 characters. Tests include an independent matching reference.

109 portable core tests pass. Native selection, copying and sort controls still
require the macOS build and GUI checks below.


0.11.10 adds a Simultaneous websites setting (1–8) and a right-hand activity panel.
Select 5 before starting a new crawl to permit up to five different sites at once.
New installations default to 5; existing projects and checkpoints retain their
saved setting, or 1 for older formats. The setting cannot change mid-crawl.
One coordinator owns the shared page frontier, deduplication, results and
checkpoints. Workers fetch individual pages, not private site queues. Relevant
links return to the shared queue. The panel lists active page URLs and every
pending page URL, including pages waiting for a busy site. It restores the
saved queue after restart. Recent history is a bounded display, not a crawl cap.
Each site receives at most one worker. Host leases protect native page requests
through redirects; a busy redirect target returns to the shared frontier.
Per-site delays, robots checks, optional page budgets and stop/resume remain
active. Search-provider discovery itself remains sequential.


Adaptive mode now starts from homepages and follows promising contact/staff/sales/profile links. Multiple explicitly supplied URLs on the same host are retained. Removed emails stay recoverable without becoming exclusion rules. All/Included/Excluded/Removed views and scoped search are consistent. Live updates send new rows in batches instead of repeatedly copying the entire result array.

Projects autosave privately; checkpoints preserve rules/removals and are written around every scanned page. Resuming merges newer saved validation results and retains unfinished requests. Native URLSession networking, cookies and shared connection reuse are retained; streamed response limits, cancellation and responsible provider-rate-limit handling are added.

CSV/TSV imports handle CRLF, quotes, multiline fields and BOMs. XLSX rich-text runs remain joined; resource limits and external-entity rejection protect workbook imports. CSV exports neutralize spreadsheet formulas. Syntax checks, null-MX handling, DNS fallback, telemetry rejection and optional ZeroBounce response handling are corrected.

## Existing scope and limits

This remains a native macOS 13+ app. It supports CSV export and text/CSV/TSV/XLSX import; XLSX export is not implemented. It supports ASCII email syntax, not full internationalized mailbox syntax. Disposable-domain detection is a starter list. Local syntax/MX/fallback checks never verify an individual mailbox. ZeroBounce is optional, requires explicit confirmation, and can consume credits. No audit tests contact it.

Discovery retains the existing free Bing RSS, DuckDuckGo and optional single-state OSM strategy. It processes the first five keyword lines, up to 3,000 candidate hosts, and bounded independent-source/directory queries. The original US geographic expansion is retained. Search providers may throttle or change their interfaces. No exhaustive coverage or comparative live-search performance is promised.

Zero page caps mean no numeric total/per-site cap, not unlimited memory or downloads. With relevant external-link following enabled, adaptive traversal has no fixed depth or per-page link-count cap. Legacy closed-site mode retains its 20-level/200-link limits. Text/CSV inputs are limited to 64 MB; workbook extracted text to 32 MB, each extracted entry to 8 MB, and workbooks to 100 worksheets. Crawler responses are capped while streaming. A crash can replay an unfinished page. JSON checkpoint costs on very large collections remain a scaling limitation.

The app is a local trusted-user application. It is not a hardened public service: private literal destinations and credentials in URLs are rejected, but full DNS-rebinding-resistant connection pinning is not implemented. Do not deploy this Mac core as an internet-facing server.
