# Names in ordinary contact text — 0.12.38, bundle 59

## Change

Source-person matching now supports bounded paragraph and address blocks as well as headings, tables and contact cards. A published full name in ordinary text can corroborate an exact email in the same structural contact block. Honorifics are removed from the stored name, job-title/narrative punctuation is separated, and repeated mentions of the same full name are deduplicated. A title/mailing-address/contact column can supply one unambiguous matching name even when a larger section mentions other people.

Email corroboration now also accepts a full given name followed by a family-name initial, alongside the existing initial-plus-family-name and multi-part-name patterns. This does not depend on adding the reported people to a name dictionary. It does not guess new addresses or force unsupported handles into Person.

Free-text name windows require published capitalization, a plausible full name and matching address components. Longer name spans take priority over their matching subparts, preserving complete multi-part names. Competing matching names, multiple recipient addresses, mismatched mailto destinations, unrelated hidden text and unsafe element boundaries still abstain. Table markup keeps its separate structural safeguards instead of being reinterpreted as free text. Generic contact labels such as Contacts, Details and Information cannot act as person names.

Contact containers remain bounded to 16,384 UTF-16 code units, free-text windows have a finite processing budget, full pages retain the 3 MB bound, and cancellation/deadline checks remain active. Existing named-mailto, Schema.org, table-row and disclosure-card behavior remains. Shared inboxes remain General; exact saved feedback and manual choices retain priority. Email-link destination holds are not approved by classification. Automatic predictions still do not self-train.

Name-check version is 6, so prior-version unresolved records may be checked immediately with Sort this list automatically. The source-first coordinator, shared rendered-page cache, historical fresh-source leads, attempt/completion metadata, budget continuation and Stop behavior from 0.12.37 remain. No record IDs, learning, removal journals, review decisions, pending crawl pages or settings are cleared or reset.

## Verification

439 portable XCTest tests passed with zero failures using the signature-verified official Swift 6.0.3 toolchain, Swift 5 language mode and four jobs. CORE-TESTS.log and CORE-TESTS-EXTERNAL.log contain the current public run; Swift Testing's separate zero-tests line is not its XCTest count.

New synthetic public coverage includes full given-name/surname-initial handles absent from the reference vocabulary, honorifics and line-break contact paragraphs, a narrative/mailing-address column alongside other contacts, same-initial/surname ambiguity, wrong/opaque handles, hidden names, mismatch protection, nested name markup, multi-part names, saved manual choices, shared inboxes, cancellation and Codable evidence. Existing source-first sorting, table/card, mismatch approvals/exports, learning/removal recovery, continuous-crawl and large-frontier regressions remain passing.

A separate private diagnostic runs the three newly supplied complete HTML files through the matcher and the same sorting coordinator used by the UI. All three records resolve to their own named Person associations in three source fetches, with original IDs preserved and no speculative profile follow-ups required. Earlier uploaded-page diagnostics also pass. This is actual uploaded-HTML validation with injected responses, not live website retrieval or a Mac GUI run. The earlier source-history diagnostic still distinguishes its uploaded full-name page from an excerpt-derived synthetic response for another source.

Uploaded HTML, actual identifying data, screenshots, private diagnostics and learned profiles are excluded from the public ZIP. Public fixtures use synthetic records. Core build, Linux SwiftUI/website-checker syntax parse and Xcode project references pass. Native Mac compilation/GUI and live website behavior remain unverified. Different HTML, unsupported structures, lowercase free-text names, ambiguous contacts or inaccessible sources can remain unresolved. Organization-site crawl scheduling remains outstanding.

## Existing records and Mac acceptance

Save, Stop and quit the previous app without Clear. Download and verify the release ZIP, extract into a fresh directory, run `bash build-mac.sh`, then `open dist/EmailGrabber3.app`. Confirm version 0.12.38.

Leave the unresolved list selected and run **Sort this list automatically** again. Existing records can gain these associations without restarting the crawl or resetting learning. Verify the fresh name and actual Source/final evidence page in Show verification evidence. A limited pass prioritizes untouched sources on the next pass. Manual choices remain respected; a record deliberately assigned a category is not silently reset. Existing email-link mismatch destinations remain held from normal exports until explicitly approved.
