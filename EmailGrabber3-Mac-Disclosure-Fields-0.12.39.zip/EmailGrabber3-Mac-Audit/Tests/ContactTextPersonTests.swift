import XCTest
import Foundation
@testable import EmailGrabberCore

final class ContactTextPersonTests: XCTestCase {
    let source = "https://public.org/staff"
    func proof(_ html: String, address: String) -> WebsiteConfirmation {
        WebsiteConfirmer.observe(address: address, source: source, response: HTTPResult(data: Data(html.utf8), status: 200, finalURL: URL(string: source), mimeType: "text/html"), checkedAt: Date())
    }
    func testGivenNamePlusSurnameInitialWithinOneCardDoesNotNeedNameVocabulary() {
        let html = "<article><img src='portrait.jpg'><h3>Qylthar Zorvek</h3><p>Director of Outreach</p><a href='mailto:qyltharz@public.org'>qyltharz@public.org</a></article>"
        XCTAssertEqual(SourcePersonMatcher.collect(html)["qyltharz@public.org"]?.name, "Qylthar Zorvek")
        var row = FoundEmail(address: "qyltharz@public.org", source: source, status: "Accepted", reason: "Local checks")
        row.websiteConfirmation = proof(html, address: row.address)
        XCTAssertEqual(row.addressClassification.category, .person)
    }
    func testHonorificAndNameInParagraphWithLineBreakEmail() {
        let html = "<p><strong>North Campus:</strong><br>Dr. Jane Smith<br><a href='mailto:jsmith@public.org'>jsmith@public.org</a><br>555-0100</p>"
        let found = SourcePersonMatcher.collect(html)["jsmith@public.org"]
        XCTAssertEqual(found?.name, "Jane Smith")
        XCTAssertEqual(found?.method, .contactText)
    }
    func testNamedNarrativeContactColumnKeepsOtherPeopleSeparate() {
        let html = "<section><div><p>The coordinator is Richard Smith, Director of Human Resources.</p><h3>Mailing Address</h3><address>Organization<br>Attention: Richard Smith<br>100 Main Street</address><h3>Phone/Email</h3><p>555-0100<br><a href='mailto:rsmith@public.org'>rsmith@public.org</a></p></div><div><h3>Key Contacts</h3><p>Ms. Alice Brown, Deputy Coordinator<br>555-0101</p><p>Mr. John Jones, Deputy Coordinator<br>555-0102</p></div></section>"
        XCTAssertEqual(SourcePersonMatcher.collect(html)["rsmith@public.org"]?.name, "Richard Smith")
        var row = FoundEmail(address: "rsmith@public.org", source: source, status: "Accepted", reason: "Local checks")
        row.websiteConfirmation = proof(html, address: row.address)
        XCTAssertEqual(row.addressClassification.category, .person)
    }
    func testSameInitialSurnameAmbiguityAndWrongHandleAbstain() {
        for html in [
            "<div><p>Richard Smith and Robert Smith</p><p>rsmith@public.org</p></div>",
            "<p>Dr. Jane Smith<br>jdoe@public.org</p>",
            "<div><p>Jane Smith</p><p>opaque391@public.org</p></div>",
            "<p>Jane Smith<br>jsmith@public.org johnj@public.org</p>"
        ] { XCTAssertTrue(SourcePersonMatcher.collect(html).isEmpty, html) }
    }
    func testHiddenTextCannotSupplyNameAndMismatchedLinkCannotBorrowIt() {
        let hidden = "<p><span hidden>Jane Smith</span><br>jsmith@public.org</p>"
        XCTAssertNil(SourcePersonMatcher.collect(hidden)["jsmith@public.org"])
        let mismatch = "<p>Jane Smith<br><a href='mailto:old@public.org'>jsmith@public.org</a></p>"
        XCTAssertNil(proof(mismatch, address: "old@public.org").personAssociation)
    }
    func testNestedNameMarkupAndMultiplePartsPreserveFullName() {
        let html = "<div><p><strong>Dr. <span>Jane Smith Brown</span></strong></p><p>jsmith@public.org</p></div>"
        XCTAssertEqual(SourcePersonMatcher.collect(html)["jsmith@public.org"]?.name, "Jane Smith Brown")
    }
    func testGenericTitlesSharedInboxesAndManualDecisionsKeepSafeguards() {
        let html = "<p>Executive Director<br>director@public.org</p>"
        XCTAssertTrue(SourcePersonMatcher.collect(html).isEmpty)
        var row = FoundEmail(address: "jsmith@public.org", source: source, status: "Accepted", reason: "Local checks")
        row.websiteConfirmation = proof("<p>Dr. Jane Smith<br>jsmith@public.org</p>", address: row.address)
        row.classificationDecision = ClassificationDecision(category: .general, changedAt: Date())
        XCTAssertEqual(row.addressClassification.category, .general)
        var shared = FoundEmail(address: "info@public.org", source: source, status: "Accepted", reason: "Local checks")
        shared.websiteConfirmation = proof("<p>Jane Smith<br>info@public.org</p>", address: shared.address)
        XCTAssertEqual(shared.addressClassification.category, .general)
    }
    func testContactTextMatchingCancelsAndEvidenceRoundTrips() throws {
        let html = "<p>Dr. Jane Smith<br>jsmith@public.org</p>"
        var checks = 0
        XCTAssertTrue(SourcePersonMatcher.collect(String(repeating: html, count: 2000), cancelled: { checks += 1; return checks > 50 }).isEmpty)
        let found = try XCTUnwrap(SourcePersonMatcher.collect(html)["jsmith@public.org"])
        XCTAssertEqual(try JSONDecoder().decode(SourcePersonAssociation.self, from: JSONEncoder().encode(found)), found)
    }
}
