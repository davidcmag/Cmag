import XCTest
import Foundation
@testable import EmailGrabberCore

final class DisclosureEntryPersonTests: DiskTests {
    func entry(_ title: String = "Garden Alliance", person: String = "Jane Smith", address: String = "jsmith@public.org", collapsed: Bool = true) -> String {
        "<div><button aria-expanded='\(!collapsed)'><h3>\(title)</h3><span aria-hidden='true'></span></button><div aria-hidden='\(collapsed)' style='display:\(collapsed ? "none" : "block")'><p>Membership activities and events.</p><h3>Meeting Information</h3><ul><li>Tuesday</li></ul><h3>Contact Information</h3><ul><li><a href='mailto:\(address)'>\(address)</a></li></ul><h3>Representatives</h3><ul><li>\(person)</li></ul></div></div>"
    }
    func testCollapsedExpandedGroupEntriesAcrossIndustriesResolveTheirOwnNames() {
        for title in ["Garden Alliance", "Manufacturing Circle", "Community Association"] {
            for collapsed in [true,false] {
                let html = "<section>" + entry(title, collapsed: collapsed) + entry("Other Group", person: "John Jones", address: "jjones@public.org", collapsed: collapsed) + "</section>"
                let found = SourcePersonMatcher.collect(html)
                XCTAssertEqual(found["jsmith@public.org"]?.name, "Jane Smith")
                XCTAssertEqual(found["jjones@public.org"]?.name, "John Jones")
                XCTAssertEqual(found["jsmith@public.org"]?.method, .disclosureEntry)
            }
        }
    }
    func testSectionLabelsDoNotCompeteWithCorroboratedFieldValues() {
        let html = "<section>" + entry().replacingOccurrences(of: "Representatives", with: "Faculty Advisors") + "</section>"
        XCTAssertEqual(SourcePersonMatcher.collect(html)["jsmith@public.org"]?.name, "Jane Smith")
        let repeatedCase = entry().replacingOccurrences(of: "Jane Smith</li>", with: "Jane Smith</li><li>JANE SMITH</li>")
        XCTAssertEqual(SourcePersonMatcher.collect(repeatedCase)["jsmith@public.org"]?.name.lowercased(), "jane smith")
        let differentLabel = entry().replacingOccurrences(of: "Representatives", with: "Responsible Persons")
        XCTAssertEqual(SourcePersonMatcher.collect(differentLabel)["jsmith@public.org"]?.name, "Jane Smith")
    }
    func testMultiContactEntryRequiresCompleteUnambiguousOneToOnePairing() {
        let html = entry().replacingOccurrences(of: "Jane Smith</li>", with: "Jane Smith</li><li>John Jones</li>").replacingOccurrences(of: "<h3>Representatives", with: "<p>jjones@public.org</p><h3>Representatives")
        let found = SourcePersonMatcher.collect(html)
        XCTAssertEqual(found["jsmith@public.org"]?.name, "Jane Smith")
        XCTAssertEqual(found["jjones@public.org"]?.name, "John Jones")
        let onePersonTwoAliases = html.replacingOccurrences(of: "John Jones</li>", with: "Jane Smith</li>").replacingOccurrences(of: "jjones@public.org", with: "jane.smith@public.org")
        XCTAssertNil(SourcePersonMatcher.collect(onePersonTwoAliases)["jsmith@public.org"])
    }
    func testExplicitControlsAndNativeDetailsUseEntryBoundaries() {
        let controlled = entry().replacingOccurrences(of: "<button aria-expanded", with: "<button aria-controls='details' aria-expanded").replacingOccurrences(of: "<div aria-hidden", with: "<div id='details' aria-hidden")
        XCTAssertEqual(SourcePersonMatcher.collect(controlled)["jsmith@public.org"]?.name, "Jane Smith")
        let native = "<details><summary>Garden Alliance</summary><h3>Contact Information</h3><ul><li>jsmith@public.org</li></ul><h3>Representatives</h3><ul><li>Jane Smith</li></ul></details>"
        XCTAssertEqual(SourcePersonMatcher.collect("<section>" + native + "</section>")["jsmith@public.org"]?.name, "Jane Smith")
    }
    func testWrongControlsMultipleRecipientsAndMultipleMatchingNamesAbstain() {
        for html in [
            entry().replacingOccurrences(of: "<button aria-expanded", with: "<button aria-controls='wrong' aria-expanded"),
            entry().replacingOccurrences(of: "Jane Smith</li>", with: "Jane Smith</li><li>John Smith</li>"),
            entry().replacingOccurrences(of: "<h3>Representatives", with: "<p>other@public.org</p><h3>Representatives"),
            entry().replacingOccurrences(of: "<div aria-hidden", with: "<div hidden aria-hidden"),
            "<div hidden>" + entry() + "</div>",
            entry().replacingOccurrences(of: "Jane Smith</li>", with: "<span hidden>Jane Smith</span></li>")
        ] { XCTAssertNil(SourcePersonMatcher.collect(html)["jsmith@public.org"], html) }
    }
    func testMismatchedDestinationCannotBorrowGroupContactName() {
        let html = entry().replacingOccurrences(of: "mailto:jsmith@public.org", with: "mailto:old@public.org")
        let source = "https://public.org/groups"
        let response = HTTPResult(data: Data(html.utf8), status: 200, finalURL: URL(string: source), mimeType: "text/html")
        let proof = WebsiteConfirmer.observe(address: "old@public.org", source: source, response: response, checkedAt: Date())
        XCTAssertNil(proof.personAssociation)
        var row = FoundEmail(address: "old@public.org", source: source, status: "Accepted", reason: "Local checks")
        WebsiteConfirmationPolicy.apply(proof, to: &row)
        XCTAssertTrue(EmailLinkConflictPolicy.isHeld(row))
    }
    func testExistingRowsResolveThroughSourceFirstCoordinatorWithoutLosingIDsOrLearning() {
        let source = "https://public.org/groups"
        var records = [FoundEmail(address: "jsmith@public.org", source: source, status: "Accepted", reason: "Local checks")]
        records[0].learningEvidence = LearningEvidence(category: .uncertain, exact: false, reason: "Earlier wording disagrees")
        records[0].websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Old check", sourceURL: source, personNameCheckVersion: 6)
        let id = records[0].id, learning = records[0].learningEvidence
        let html = entry()
        let checker = WebsiteConfirmer(fetch: { request,_,_ in HTTPResult(data: Data(html.utf8), status: 200, finalURL: request.url, mimeType: "text/html") })
        let targets = AutomaticPersonSort.targets(records, selected: [id], rules: [], removed: [])
        XCTAssertEqual(targets.count, 1)
        let summary = PersonSortCoordinator.run(targets, checker: checker, shouldStop: { false }, eligible: { _ in true }, apply: { _,proof in WebsiteConfirmationPolicy.apply(proof, to: &records[0]); return records[0].addressClassification.category == .person ? 1 : 0 }, progress: { _,_,_,_ in })
        XCTAssertEqual(summary.linked, 1)
        XCTAssertEqual(records[0].id, id)
        XCTAssertEqual(records[0].learningEvidence, learning)
    }
    func testUnrelatedHiddenTextAndAdjacentEntriesCannotSupplyAName() {
        let noName = entry(person: "No published person")
        let unrelated = noName + "<p>Jane Smith</p>"
        XCTAssertNil(SourcePersonMatcher.collect(unrelated)["jsmith@public.org"])
        let across = entry(person: "John Jones") + entry("Other Group", person: "Jane Smith", address: "other@public.org")
        XCTAssertNil(SourcePersonMatcher.collect(across)["jsmith@public.org"])
    }
    func testDisclosureEvidenceRoundTripsAndMatchingCancels() throws {
        let html = entry()
        let found = try XCTUnwrap(SourcePersonMatcher.collect(html)["jsmith@public.org"])
        XCTAssertEqual(try JSONDecoder().decode(SourcePersonAssociation.self, from: JSONEncoder().encode(found)), found)
        var checks = 0
        XCTAssertTrue(SourcePersonMatcher.collect(String(repeating: html, count: 1500), cancelled: { checks += 1; return checks > 100 }).isEmpty)
    }
}
