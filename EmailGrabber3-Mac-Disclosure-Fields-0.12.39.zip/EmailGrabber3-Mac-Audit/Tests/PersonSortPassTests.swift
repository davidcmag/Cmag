import XCTest
import Foundation
@testable import EmailGrabberCore

final class PersonSortPassTests: XCTestCase {
    func row(_ index: Int, source: String = "https://public.org/directory") -> FoundEmail {
        FoundEmail(address: "zxv\(index)391@public.org", source: source, status: "Accepted", reason: "Local checks")
    }
    func table(_ records: [FoundEmail]) -> String {
        "<table><tr><th>Name</th><th>Email</th></tr>" + records.map { "<tr><td>Jane Smith</td><td>\($0.address)</td></tr>" }.joined() + "</table>"
    }
    func response(_ html: String, _ url: URL, status: Int = 200) -> HTTPResult {
        HTTPResult(data: Data(html.utf8), status: status, finalURL: url, mimeType: "text/html")
    }
    func apply(_ target: WebsiteTarget, _ proof: WebsiteConfirmation, _ records: inout [FoundEmail]) -> Int {
        var linked = 0
        for index in records.indices where target.ids.contains(records[index].id) {
            let before = records[index].addressClassification.category
            WebsiteConfirmationPolicy.apply(proof, to: &records[index])
            if before != .person && records[index].addressClassification.category == .person { linked += 1 }
        }
        return linked
    }
    func testRenderedDirectoryResolvesFiftyExistingRecordsWithOneFetchAndOneRender() {
        var records = (0..<50).map { row($0) }
        let html = table(records)
        let raw = records.map { "<p>\($0.address)</p>" }.joined()
        var fetches = 0, renders = 0
        let checker = WebsiteConfirmer(fetch: { request,_,_ in fetches += 1; return self.response(raw, request.url!) }, render: { url,_,_ in renders += 1; return self.response(html, url) })
        let targets = AutomaticPersonSort.targets(records, selected: Set(records.map(\.id)), rules: [], removed: [])
        let summary = PersonSortCoordinator.run(targets, checker: checker, shouldStop: { false }, eligible: { _ in true }, apply: { self.apply($0,$1,&records) }, progress: { _,_,_,_ in })
        XCTAssertEqual(summary.linked, 50)
        XCTAssertTrue(records.allSatisfy { $0.addressClassification.category == .person })
        XCTAssertEqual(fetches, 1); XCTAssertEqual(renders, 1)
        XCTAssertEqual(summary.checked, 50); XCTAssertFalse(summary.limited)
    }
    func testHealthySourceIsCheckedBeforeDifficultRecordUsesProfileFollowups() {
        var records = [row(1, source: "https://public.org/a-directory"), row(2, source: "https://public.org/z-directory")]
        var paths: [String] = []
        let healthy = table([records[1]])
        let checker = WebsiteConfirmer(fetch: { request,_,_ in
            paths.append(request.url!.path)
            return self.response(request.url!.path == "/z-directory" ? healthy : "<p>No name here</p><a href='/staff/profile'>Staff profile</a>", request.url!)
        })
        let targets = AutomaticPersonSort.targets(records, selected: Set(records.map(\.id)), rules: [], removed: [])
        _ = PersonSortCoordinator.run(targets, checker: checker, shouldStop: { false }, eligible: { target in records.contains { target.ids.contains($0.id) && $0.addressClassification.category == .uncertain } }, apply: { self.apply($0,$1,&records) }, progress: { _,_,_,_ in })
        XCTAssertEqual(Array(paths.prefix(2)), ["/a-directory","/z-directory"])
        XCTAssertEqual(records[1].addressClassification.category, .person)
    }
    func testHistoricalPublicationURLsAreFreshLeadsAndRetainOriginalSource() {
        var record = row(9, source: "https://public.org/greek-life")
        record.websiteHistory = [WebsiteConfirmation(outcome: .published, reason: "Earlier publication", checkedAt: .distantPast, sourceURL: "https://public.org/admissions", finalURL: "https://public.org/admissions")]
        let target = AutomaticPersonSort.targets([record], selected: [record.id], rules: [], removed: [])[0]
        XCTAssertTrue(target.knownPages?.contains("https://public.org/admissions") == true)
        var paths: [String] = []
        let html = table([record])
        let checker = WebsiteConfirmer(fetch: { request,_,_ in paths.append(request.url!.path); return self.response(request.url!.path == "/admissions" ? html : "<p>Contact information</p>", request.url!) })
        let proof = checker.confirmPerson(address: target.address, source: target.source, knownPage: target.knownPage, knownPages: target.knownPages ?? [])
        WebsiteConfirmationPolicy.apply(proof, to: &record)
        XCTAssertEqual(record.addressClassification.category, .person)
        XCTAssertTrue(paths.contains("/admissions"))
        XCTAssertEqual(record.websiteConfirmation?.sourceURL, "https://public.org/greek-life")
        XCTAssertEqual(record.websiteConfirmation?.finalURL, "https://public.org/admissions")
        XCTAssertGreaterThan(record.websiteConfirmation!.checkedAt, Date(timeIntervalSince1970: 1))
    }
    func testSourcePassReusesFreshSameSiteNameEvidenceRatherThanOldExcerpt() {
        let name = row(1, source: "https://public.org/admissions")
        let checker = WebsiteConfirmer(fetch: { request,_,_ in self.response(request.url!.path == "/admissions" ? self.table([name]) : "<p>No full name</p>", request.url!) })
        XCTAssertNotNil(checker.confirmPersonOnSource(address: name.address, source: name.source).personAssociation)
        let proof = checker.confirmPersonOnSource(address: name.address, source: "https://public.org/clubs")
        XCTAssertEqual(proof.personAssociation?.name, "Jane Smith")
        XCTAssertEqual(proof.sourceURL, "https://public.org/clubs")
        XCTAssertEqual(proof.finalURL, "https://public.org/admissions")
    }
    func testBudgetLimitedPassLeavesUnattemptedRecordsEligibleAndPrioritizesThemNext() {
        var records = (0..<105).map { row($0, source: String(format: "https://public.org/source-%03d", $0)) }
        let checker = WebsiteConfirmer(fetch: { request,_,_ in self.response("<p>No name available</p>", request.url!, status: 404) })
        let targets = AutomaticPersonSort.targets(records, selected: Set(records.map(\.id)), rules: [], removed: [])
        let summary = PersonSortCoordinator.run(targets, checker: checker, shouldStop: { false }, eligible: { _ in true }, apply: { self.apply($0,$1,&records) }, progress: { _,_,_,_ in })
        XCTAssertTrue(summary.limited)
        XCTAssertEqual(summary.checked, 100)
        XCTAssertNil(records[104].websiteConfirmation?.personNameAttemptAt)
        XCTAssertTrue(records.allSatisfy { $0.websiteConfirmation?.personNameCheckVersion == nil })
        let next = AutomaticPersonSort.targets(records, selected: Set(records.map(\.id)), rules: [], removed: [])
        XCTAssertEqual(next.first?.source, "https://public.org/source-100")
    }
    func testPersonDOMReadinessDoesNotFinishOnAddressBeforeNameAppears() {
        let record = row(1)
        let raw = "<p>\(record.address)</p>"
        XCTAssertTrue(BrowserDOMReadiness.shouldFinish(raw, address: record.address, seekPersonName: false, reads: 1))
        XCTAssertFalse(BrowserDOMReadiness.shouldFinish(raw, address: record.address, seekPersonName: true, reads: 1))
        XCTAssertTrue(BrowserDOMReadiness.shouldFinish(table([record]), address: record.address, seekPersonName: true, reads: 2))
        XCTAssertTrue(BrowserDOMReadiness.shouldFinish(raw, address: record.address, seekPersonName: true, reads: 8))
    }
    func testStopDuringSourcePassDoesNotLaunchRemainingSourcesOrFollowups() {
        var records = [row(1, source: "https://public.org/a"),row(2, source: "https://public.org/b")]
        let html = table(records)
        let control = CrawlControl()
        var paths: [String] = []
        let checker = WebsiteConfirmer(fetch: { request,_,_ in paths.append(request.url!.path); return self.response(html, request.url!) })
        let targets = AutomaticPersonSort.targets(records, selected: Set(records.map(\.id)), rules: [], removed: [])
        let summary = PersonSortCoordinator.run(targets, checker: checker, shouldStop: { control.wasCancelled }, eligible: { _ in true }, apply: { target, proof in let linked = self.apply(target,proof,&records); control.cancel(); return linked }, progress: { _,_,_,_ in })
        XCTAssertEqual(paths.count, 1); XCTAssertTrue(summary.limited)
        XCTAssertEqual(summary.linked, 1)
    }
    func testSourceOnlyUnresolvedCheckDoesNotStartTwentyFourHourCooldown() {
        var record = row(1)
        let checker = WebsiteConfirmer(fetch: { request,_,_ in self.response("<p>\(record.address)</p>", request.url!) })
        let proof = checker.confirmPersonOnSource(address: record.address, source: record.source)
        WebsiteConfirmationPolicy.apply(proof, to: &record)
        XCTAssertEqual(proof.personNameCheckComplete, false)
        XCTAssertNil(proof.personNameCheckVersion)
        XCTAssertNotNil(proof.personNameAttemptAt)
        XCTAssertEqual(AutomaticPersonSort.targets([record], selected: [record.id], rules: [], removed: []).count, 1)
    }
}
