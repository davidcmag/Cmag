# Contact fields inside disclosure entries — 0.12.39, bundle 60

## Change

A disclosure entry may be titled with an organization, group or activity while its body contains separate labeled email and person-name fields. The matcher now uses the owning entry boundary and corroborated body values instead of requiring a person-name trigger or allowing section labels to compete as candidate people. It does not depend on a particular club, site, person, industry, CSS class or heading-label string.

Standard ARIA entries require one local disclosure button and one following direct-child panel, valid aria-expanded/aria-hidden states, and a matching panel ID when aria-controls is supplied. Native details/summary entry fields are also supported. Collapsed and expanded entries use the same ownership boundaries. Repeated case variants of the same name are deduplicated. Corroborated person headings inside the body are allowed, while other headings act as section labels.

An entry with multiple recipients is accepted only if every displayed address can be paired uniquely with a different matching full name. This does not pair by list order or proximity. Missing or ambiguous pairs, multiple addresses for the same name, mismatched mailto labels, mismatched controls, explicit hidden/inert panels, hidden ancestors, relevant hidden descendants, malformed boundaries and table reinterpretation abstain. Once an entry supplies candidate field evidence, weaker overlapping container/heading fallbacks cannot defeat its ambiguity rejection.

Entries keep the 16,384 UTF-16 code-unit bound and at most 20 distinct recipients; page, free-text and cancellation/deadline bounds remain. Existing named links, Schema.org, tables, personal cards, ordinary contact paragraphs, source-first batch sorting and shared-inbox classification remain. Name-check version 7 lets old unresolved attempts be retried immediately. Manual/exact choices, learning/removal state, email-link export holds, record IDs, pending crawl work and user settings are preserved. Automatic predictions do not self-train.

## Validation

448 portable XCTest tests passed with zero failures using the signature-verified official Swift 6.0.3 toolchain, Swift 5 mode and four jobs. CORE-TESTS.log and CORE-TESTS-EXTERNAL.log contain the complete current public run; Swift Testing's separate zero-test line is not the XCTest count.

New synthetic public tests cover group entries across several industries, collapsed/expanded panels, arbitrary section labels, explicit control IDs, native details/summary, complete multi-contact one-to-one pairing, ambiguity/incomplete pairing, case variants, hidden content, mismatched links, adjacent-entry isolation, in-place source-first upgrades, preserved learning/IDs, cancellation and Codable evidence. Earlier table/card/contact-text, sorting, mismatch export/approval, feedback/removal recovery, continuous-crawl and frontier regressions remain passing.

Private diagnostics against the exact newly supplied page and its extracted entry resolve the reported person/address association in collapsed and expanded states. The same source-first sorting coordinator used by the UI upgrades the existing record in one source fetch without replacing its ID. Earlier uploaded-page checks also pass. A private bulk coverage audit now exercises every published address/page encounter across the uploaded corpus, and an independent field parser checks the directory's explicit name/email columns. This is broader uploaded-corpus testing, not a representative accuracy benchmark for arbitrary websites or a live Mac session. Detailed private audit output and identifiers are excluded from this distribution.

Core build, Linux SwiftUI/website-checker syntax parse and Xcode project references pass. Native Mac compilation/GUI, live retrieval and browser timing remain unverified. Aliases, unsupported structures, unavailable pages, conflicting or ambiguous evidence can still remain Uncertain. Some addresses can be classified by existing handle rules without an explicit source-person association; those are distinct forms of evidence. No thresholds were weakened to force all results into Person. Organization-site crawl scheduling remains separate outstanding work.

Uploaded files, private diagnostic code/logs, corpus/field-analysis outputs, actual identifying data, learned profiles and sessions are excluded from the public source ZIP. Public fixtures use synthetic records and injected responses; no public SMTP or paid verification probes were added.

## Existing results and Mac acceptance

Save, Stop and quit the previous app without Clear. Download and verify the release ZIP, extract into a fresh directory, run `bash build-mac.sh`, then `open dist/EmailGrabber3.app`. Confirm version 0.12.39.

Run **Sort this list automatically** on the unresolved list again. Old name-check attempts may be retried under version 7; no Clear, learning reset or full recrawl is required. Inspect the fresh association name, method and source in Show verification evidence. A limited pass prioritizes untouched sources on the next pass. Manual choices remain unchanged, and conflicting link destinations remain held until separately approved. Pending crawl work remains available to Resume.
