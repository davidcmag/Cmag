# Source-first automatic person sorting — 0.12.37, bundle 58

## Confirmed coordinator problems

The old automatic pass could spend up to seven source/profile requests for one unresolved address before reaching other records, render the same directory separately for each address, then run out of its browser/page/time budget. A known example's supplied evidence still contained its original discovery check, without a completed sorting result. Its current source also differed from the full-name page in its historical website evidence. Historical source URLs were not retained as fresh-check leads.

The native browser's DOM read returned as soon as an email appeared, even if the corresponding name/card was still loading. Name-check completion also did not reliably distinguish incomplete budget-limited checks from a completed unresolved check. These are code/coordinator defects; the exact live Mac response and full runtime cause of the user's pass were not captured.

## Change

The UI now uses a portable PersonSortCoordinator. It performs a source-first pass across selected list records before profile follow-ups. Source pages and parsed rendered pages are reused within the bounded sorting pass, so multiple addresses on one rendered directory do not each consume a new browser attempt. Freshly checked same-site pages may supply an exact address/name association for another record while retaining that record's original Source and recording the actual evidence page. Previous publication URLs are candidate leads for fresh retrieval, never fresh proof by themselves. Historical lookup is grouped by address/source instead of rescanning every record for every target.

For person sorting, the browser now waits for an actual supported name association, or a bounded sequence of DOM reads, instead of stopping on email publication alone. Regex/name readiness inspection runs off the UI thread with cancellation and an inspection budget. Ordinary publication-only checks keep their own readiness behavior. Browser requests remain nonpersistent and same-site; no existing challenges or access rules are bypassed. Native WebKit behavior still needs Mac acceptance.

Optional attempt/completion metadata distinguishes source-only, interrupted and completed checks. Name-check version 5 lets prior-version unresolved records be retried. A source-only or budget-incomplete attempt does not trigger the completed-check 24-hour cooldown. Subsequent passes prioritize source groups with no attempts, then older attempts, so untouched records can advance. Current-version completed checks retain the cooldown. The existing 300-second sorting-pass, 100 HTTP-page and 10 browser-attempt budgets remain; limits were not silently increased or removed. Summaries explicitly identify limited/incomplete passes instead of implying the whole list was finished.

Saved manual/exact decisions, removals, exclusions, optional classification model safeguards and email-link export holds remain. New associations apply in place to existing IDs. Sorting does not reset learning, clear results, change crawl settings, mark pending crawl pages visited, or discard the crawl frontier. The separate organization-site crawl-scheduling improvement remains outstanding.

## Validation

431 portable XCTest tests passed with zero failures using the signature-verified official Swift 6.0.3 toolchain, Swift 5 mode and four jobs. CORE-TESTS.log and CORE-TESTS-EXTERNAL.log contain the current complete public run; Swift Testing's separate zero-test line is not the XCTest count.

New tests execute the same coordinator used by the UI: fifty existing records resolve from one HTTP fetch and one rendered-directory fetch; healthy sources are checked before speculative follow-ups; historical source URLs are fetched fresh; same-site fresh name evidence is reused while retaining Source; a page-limited pass leaves untouched records eligible and prioritizes them on rerun; browser name readiness waits past email-only DOM snapshots; Stop prevents further sources/follow-ups; and source-only checks do not start the 24-hour cooldown. Existing classification, general table/card, mismatch approvals/exports, learning/removal recovery, continuous-crawl and large-frontier regressions pass.

Private local diagnostics against the supplied uploaded pages also pass. A coordinator diagnostic uses the actual uploaded full-name source HTML together with an excerpt-derived synthetic response for the other source and the historical source URL supplied by the user; it resolves the two relevant records with two source fetches. This is not a capture/reproduction of the live Greek/other-source response or the complete Mac sorting run. Uploaded HTML, actual identifying data, private diagnostics and screenshots are excluded from this source distribution. Public fixtures are synthetic.

Core build, Linux SwiftUI/website-checker syntax parse and Xcode project references pass. The new test file is registered in the Xcode test target. Native Mac compilation/GUI, real browser timing and live source retrieval remain unverified. Unsupported structures, unavailable sources and names that cannot be associated safely remain Uncertain; the update does not force all unresolved addresses into Person.

## Mac acceptance and existing records

Save, Stop and quit the prior app without Clear. Download and verify the release ZIP, extract into a fresh directory, run `bash build-mac.sh`, then `open dist/EmailGrabber3.app`. Confirm version 0.12.37.

Open the unresolved list and click **Sort this list automatically** again. It rechecks prior-version attempts with the new source-first pass; no full crawl restart, Clear or learning reset is needed. Check that the summary reports records checked, new Person associations and any incomplete/pending work. If a pass is limited, rerun to prioritize untouched sources. Stop must retain completed updates and prevent further work. Evidence for a resolved record should show the fresh name, actual source/final page, browser-use flag where applicable, and the original record Source. Existing mismatch destinations remain held until explicitly approved. Preserve existing manual choices and the pending crawl queue.
