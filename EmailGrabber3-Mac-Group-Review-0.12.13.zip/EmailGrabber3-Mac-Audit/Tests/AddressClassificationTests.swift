import XCTest
import Foundation
@testable import EmailGrabberCore

final class AddressClassificationTests: XCTestCase {
    func row(_ address: String) -> FoundEmail {
        FoundEmail(address: address, source: "https://example.org/staff", status: "Accepted", reason: "Local checks")
    }
    func testPublishedJobTitlesAreGeneralInboxesNotPeople() {
        for (local, title) in [("executivedirector", "Executive Director"), ("deputydirector", "Deputy Director"), ("developmentdirector", "Development Director"), ("program.director", "Program Director"), ("executive-director+contact", "Executive Director"), ("chiefdevelopmentofficer", "Chief Development Officer")] {
            var value = row(local + "@example.org")
            XCTAssertEqual(value.addressClassification.category, .general, local)
            value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact text", sourceURL: value.source, excerpt: title + " — " + value.address)
            XCTAssertEqual(value.addressClassification.category, .general, local)
            XCTAssertFalse(value.addressClassification.reason.contains("excerpt names"))
            XCTAssertFalse(AddressClassification.roleNames.contains(local), "Do not change crawl exclusions")
        }
    }
    func testCapitalizedTitleCannotBecomeNameEvidenceForUnknownMailbox() {
        for (local, title) in [("eofficer", "Executive Officer"), ("specialprojects", "Special Projects"), ("developmentmanager", "Development Manager"), ("jdirector", "Junior Director"), ("salesoffice", "Sales Office")] {
            var value = row(local + "@example.org")
            value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact text", sourceURL: value.source, excerpt: title + " — " + value.address)
            // Unknown titles may remain uncertain; capitalization alone is insufficient.
            XCTAssertNotEqual(value.addressClassification.category, .person, local)
        }
    }
    func testPersonFilterAndCategoryReviewExcludePublishedDirectors() {
        var director = row("executivedirector@example.org")
        director.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact text", sourceURL: director.source, excerpt: "Executive Director — executivedirector@example.org")
        let rows = [director, row("dan.boyce@example.org")]
        XCTAssertEqual(AddressClassification.review(rows, category: .person, removed: []).map(\.address), ["dan.boyce@example.org"])
        XCTAssertEqual(AddressClassification.review(rows, category: .general, removed: []).map(\.address), [director.address])
    }
    func testActualStaffNameBesideTitleStillSupportsPerson() {
        var value = row("mbrown@example.org")
        value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact text", sourceURL: value.source, excerpt: "Executive Director: Michael Brown — mbrown@example.org")
        XCTAssertEqual(value.addressClassification.category, .person)
        XCTAssertTrue(value.addressClassification.reason.contains("Michael Brown"))
        value.websiteConfirmation?.excerpt = "Michael Brown — mbrown@example.org.evil"
        XCTAssertEqual(value.addressClassification.category, .uncertain)
    }
    func testScreenshotOrganizationPatternsAndSurnameFirst() {
        for address in ["connect@bridge2blue.org", "massbayallianceunited@gmail.com", "bvccommunitycoalition@gmail.com", "borregovoices@gmail.com", "beaconfordemocracychapter@gmail.com", "bienvenidos@gmail.com"] {
            XCTAssertEqual(row(address).addressClassification.category, .general, address)
        }
        XCTAssertEqual(row("palumbo.dana@gmail.com").addressClassification.category, .person)
        XCTAssertEqual(row("dana.palumbo@gmail.com").addressClassification.category, .person)
        XCTAssertEqual(row("bwfro01223@gmail.com").addressClassification.category, .uncertain)
        XCTAssertEqual(row("r.lambertson@gmail.com").addressClassification.category, .uncertain)
        XCTAssertNotEqual(row("jane@example-alliance.org").addressClassification.category, .general, "Domain alone does not identify a shared mailbox")
    }
    func testInitialsAndTrailingInitialRequireActualFullNameEvidence() {
        for (address, name) in [("r.lambertson@example.org", "Richard Lambertson"), ("glennp@example.org", "Glenn Palmer")] {
            var value = row(address)
            XCTAssertEqual(value.addressClassification.category, .uncertain)
            value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact text", sourceURL: value.source, excerpt: name + " — " + address)
            XCTAssertEqual(value.addressClassification.category, .person)
            value.websiteConfirmation?.excerpt = "Executive Director — " + address
            XCTAssertEqual(value.addressClassification.category, .uncertain)
        }
    }
    func testManualCorrectionWinsAndResetRestoresAutomaticClassification() {
        let value = row("executivedirector@example.org")
        let edited = ClassificationEdits.set([value], selected: [value.id], category: .person, at: Date(timeIntervalSince1970: 1))[0]
        XCTAssertEqual(edited.addressClassification.category, .person)
        XCTAssertTrue(edited.addressClassification.reason.contains("Your saved correction"))
        XCTAssertEqual(AddressClassification.automatic(edited).category, .general)
        let reset = ClassificationEdits.set([edited], selected: [edited.id], category: nil, at: Date(timeIntervalSince1970: 2))[0]
        XCTAssertEqual(reset.addressClassification.category, .general)
        XCTAssertNotNil(reset.classificationDecision, "A dated reset must survive stale checkpoints")
        XCTAssertNil(reset.classificationDecision?.category)
        let uncertain = ClassificationEdits.set([value], selected: [value.id], category: .uncertain)[0]
        XCTAssertEqual(uncertain.addressClassification.category, .uncertain)
    }
    func testCorrectionsRoundTripAndOlderFilesStillDecode() throws {
        let original = row("info@example.org")
        let legacy = try JSONEncoder().encode(original)
        let decodedLegacy = try JSONDecoder().decode(FoundEmail.self, from: legacy)
        XCTAssertNil(decodedLegacy.classificationDecision)
        let changed = ClassificationEdits.set([original], selected: [original.id], category: .person)[0]
        let restored = try JSONDecoder().decode(FoundEmail.self, from: JSONEncoder().encode(changed))
        XCTAssertEqual(restored, changed)
        XCTAssertEqual(restored.addressClassification.category, .person)
    }
    func testDuplicateAddressCorrectionsAndLateCrawlRows() {
        let first = row("INFO@example.org"), duplicate = row("info@example.org"), other = row("dan.boyce@example.org")
        let changed = ClassificationEdits.set([first, duplicate, other], selected: [first.id], category: .person)
        XCTAssertEqual(changed[0].classificationDecision, changed[1].classificationDecision)
        XCTAssertNil(changed[2].classificationDecision)
        let later = row("info@example.org")
        XCTAssertEqual(ClassificationEdits.inheriting([later], from: changed)[0].addressClassification.category, .person)
    }
    func testOldCheckpointCannotResurrectResetDespiteNewerVerificationTimestamp() {
        let original = row("info@example.org")
        var stale = ClassificationEdits.set([original], selected: [original.id], category: .person, at: Date(timeIntervalSince1970: 1))[0]
        let reset = ClassificationEdits.set([stale], selected: [stale.id], category: nil, at: Date(timeIntervalSince1970: 2))[0]
        stale.checkedAt = Date(timeIntervalSince1970: 9999999999)
        let restored = ResultMerge.combine([stale], [reset])[0]
        XCTAssertEqual(restored.addressClassification.category, .general)
        XCTAssertEqual(restored.classificationDecision, reset.classificationDecision)
        XCTAssertEqual(restored.checkedAt, stale.checkedAt, "Independent verification remains unchanged")
    }
    func testEditsDoNotChangeRemovalVerificationCSVOrOriginalValues() {
        let original = row("info@example.org")
        let changed = ClassificationEdits.set([original], selected: [original.id], category: .person)[0]
        XCTAssertEqual(changed.status, original.status)
        XCTAssertEqual(changed.reason, original.reason)
        XCTAssertEqual(changed.id, original.id)
        XCTAssertEqual(VerificationCSV.line(changed), VerificationCSV.line(original))
        XCTAssertTrue(ResultPolicy.exportRows([changed], rules: [], removed: [changed.address], onlyAccepted: false).isEmpty)
        XCTAssertTrue(ResultPolicy.filtered([changed], rules: [SmartRule(kind: "Address", pattern: changed.address)], removed: [], status: "Included", search: "", scope: "Email").isEmpty)
        XCTAssertEqual(original.addressClassification.category, .general)
    }
    func testBundledNameVocabularyAndReviewedMixedEvaluation() throws {
        XCTAssertEqual(PersonNameVocabulary.given.count, 5130)
        XCTAssertEqual(PersonNameVocabulary.surnames.count, 88698)
        #if SWIFT_PACKAGE
        let url = try XCTUnwrap(Bundle.module.url(forResource: "classification-evaluation", withExtension: "tsv", subdirectory: "Fixtures"))
        #else
        let url = try XCTUnwrap(Bundle(for: type(of: self)).url(forResource: "classification-evaluation", withExtension: "tsv", subdirectory: "Fixtures"))
        #endif
        let text = try String(contentsOf: url, encoding: .utf8)
        var counts: [String: Int] = [:]
        var mismatches: [String] = []
        for line in text.split(whereSeparator: \.isNewline) where !line.hasPrefix("#") {
            let fields = line.split(separator: "\t").map(String.init)
            XCTAssertEqual(fields.count, 3)
            guard fields.count == 3 else { continue }
            counts[fields[1], default: 0] += 1
            let actual = row(fields[0] + "@example.org").addressClassification
            if actual.category.rawValue != fields[1] { mismatches.append(fields[0] + ": expected " + fields[1] + ", got " + actual.category.rawValue + " — " + actual.reason) }
        }
        XCTAssertGreaterThanOrEqual(counts["Likely person", default: 0], 40)
        XCTAssertGreaterThanOrEqual(counts["General inbox", default: 0], 40)
        XCTAssertGreaterThanOrEqual(counts["Uncertain", default: 0], 20)
        XCTAssertTrue(mismatches.isEmpty, mismatches.joined(separator: "\n"))
    }
    func testStructureDoesNotRequireKnownNameAndDigitsAreNeutral() {
        for local in ["qylthar.zorvek", "zorvek.q.qylthar", "li.wei", "ng.ann", "sharon.dean2025", "susanne.g.hinkle", "clarkdavid01", "margueritechandler", "terryewhitaker"] {
            XCTAssertEqual(row(local + "@example.org").addressClassification.category, .person, local)
        }
        XCTAssertFalse(PersonNameVocabulary.given.contains("qylthar"))
        XCTAssertFalse(PersonNameVocabulary.surnames.contains("zorvek"))
        for local in ["k.jones", "dksmiley5551", "jkb1099", "123456", "abc123xyz", "support2025", "executive.director42"] {
            XCTAssertNotEqual(row(local + "@example.org").addressClassification.category, .person, local)
        }
    }
    func testMailboxAndPublicationEvidenceDoNotManufactureNameEvidence() {
        var value = row("jkb1099@example.org")
        value.status = "Verified"
        value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Published on staff site", sourceURL: value.source, excerpt: "Contact jkb1099@example.org")
        XCTAssertEqual(value.addressClassification.category, .uncertain)
        value.websiteConfirmation?.excerpt = "Executive Director jkb1099@example.org"
        XCTAssertEqual(value.addressClassification.category, .uncertain)
    }
    func testGeneralInboxAndAliases() {
        for address in ["INFO@example.org", "sales+press@example.org", "support@example.org", "newsroom@example.org", "press.office@example.org"] {
            XCTAssertEqual(row(address).addressClassification.category, .general, address)
            XCTAssertFalse(row(address).addressClassification.reason.isEmpty)
        }
        XCTAssertFalse(AddressClassification.roleNames.contains("newsroom"), "Existing crawl exclusions must not expand")
    }
    func testConservativeNamesAndInitials() {
        XCTAssertEqual(row("dan.boyce@example.org").addressClassification.category, .person)
        XCTAssertEqual(row("cher@example.org").addressClassification.category, .person, "Single recognized name is now positive evidence, not an automatic uncertain outcome")
        for local in ["db", "dboyce", "d.boyce", "x", "maria99", "a_b", "weird-name-xyz", "unusual.name", "custom.address"] {
            XCTAssertEqual(row(local + "@example.org").addressClassification.category, .uncertain, local)
        }
    }
    func testRecordedExactPublicationNameStrengthensInitial() {
        var value = row("dboyce@example.org")
        value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact text", sourceURL: value.source, match: .pageText, excerpt: "Dan Boyce — dboyce@example.org")
        XCTAssertEqual(value.addressClassification.category, .person)
        XCTAssertTrue(value.addressClassification.reason.contains("Dan Boyce"))
        value.websiteConfirmation?.outcome = .notFound
        XCTAssertEqual(value.addressClassification.category, .uncertain)
        value.websiteConfirmation?.outcome = .published
        value.websiteConfirmation?.excerpt = "Dan Boyce — another@example.org"
        XCTAssertEqual(value.addressClassification.category, .uncertain)
        value.websiteConfirmation?.excerpt = "Jane Smith — dboyce@example.org"
        XCTAssertEqual(value.addressClassification.category, .uncertain)
    }
    func testDuplicateAddressBulkRemovalUsesExistingAddressHistory() {
        let rows = [row("info@example.org"), row("INFO@example.org"), row("db@example.org")]
        var state = RemovalState()
        state.remove(Set(AddressClassification.review(rows, category: .general, removed: []).map(\.address)))
        XCTAssertEqual(state.addresses.count, 1)
        XCTAssertEqual(state.history.count, 1)
        XCTAssertEqual(ResultPolicy.filtered(rows, rules: [], removed: state.addresses, status: "Included", search: "", scope: "Email").map(\.address), ["db@example.org"])
        state.undo()
        XCTAssertEqual(ResultPolicy.filtered(rows, rules: [], removed: state.addresses, status: "Included", search: "", scope: "Email"), rows)
    }
    func testRoleEvidenceNeverOverridesSharedInbox() {
        var value = row("info@example.org")
        value.websiteConfirmation = WebsiteConfirmation(outcome: .published, reason: "Exact text", sourceURL: value.source, excerpt: "Dan Boyce info@example.org")
        XCTAssertEqual(value.addressClassification.category, .general)
    }
    func testBulkRemovalUndoPersistenceAndExport() throws {
        let rows = [row("info@example.org"), row("newsroom@example.org"), row("dan.boyce@example.org"), row("db@example.org")]
        var state = RemovalState(addresses: ["old@example.org"], history: [["old@example.org"]])
        let original = rows
        let reviewed = AddressClassification.review(rows, category: .general, removed: state.addresses)
        XCTAssertEqual(reviewed.count, 2)
        state.remove(Set(reviewed.map(\.address)))
        XCTAssertEqual(state.history.count, 2)
        XCTAssertEqual(ResultPolicy.exportRows(rows, rules: [], removed: state.addresses, onlyAccepted: false).map(\.address), ["dan.boyce@example.org", "db@example.org"])
        XCTAssertEqual(rows, original)
        var restored = try JSONDecoder().decode(RemovalState.self, from: JSONEncoder().encode(state))
        restored.undo()
        XCTAssertEqual(restored.addresses, ["old@example.org"])
        XCTAssertEqual(ResultPolicy.exportRows(rows, rules: [], removed: restored.addresses, onlyAccepted: false), original)
    }
    func testSortAndFilterPreserveOriginalRecordsAndRules() {
        let rows = [row("info@example.org"), row("dan.boyce@example.org"), row("db@example.org")]
        let sorted = ResultOrdering.apply(rows, order: [KeyPathComparator(\FoundEmail.classificationLabel)])
        XCTAssertEqual(sorted.map(\.classificationLabel), ["General inbox", "Likely person", "Uncertain"])
        let filtered = rows.filter { $0.addressClassification.category == .person }
        XCTAssertEqual(filtered.map(\.address), ["dan.boyce@example.org"])
        XCTAssertEqual(rows.count, 3)
        let rule = SmartRule(kind: "Address", pattern: "dan.boyce@example.org")
        XCTAssertEqual(ResultPolicy.filtered(rows, rules: [rule], removed: [], status: "Included", search: "", scope: "Email").count, 2)
    }
}

final class GroupReviewAndExportTests: DiskTests {
    func row(_ address: String, status: String = "Accepted") -> FoundEmail {
        FoundEmail(address: address, source: "https://example.org/staff", status: status, reason: "Fixture")
    }
    func testGroupingUsesStructuredPatternsIncludedScopeAndUniqueAddresses() {
        let initial = row("r.lambertson@example.org"), numeric = row("jkb1099@example.org"), unknown = row("qylthar@example.org"), possible = row("john.officer@example.org")
        var manual = row("manualxyz@example.org")
        manual.classificationDecision = ClassificationDecision(category: .uncertain, changedAt: Date())
        let rows = [initial, row(initial.address.uppercased()), numeric, unknown, possible, row("dan.boyce@example.org"), row("info@example.org"), row("excludedxxx@example.org", status: "Excluded"), manual]
        let groups = GroupReview.groups(rows, rules: [], removed: [])
        XCTAssertEqual(groups.map(\.pattern), [.initials, .numeric, .unrecognized, .possibleOrganization])
        XCTAssertEqual(groups.map { $0.rows.count }, [1,1,1,1])
        let hidden = GroupReview.groups(rows, rules: [SmartRule(kind: "Address", pattern: initial.address)], removed: [numeric.address])
        XCTAssertEqual(hidden.flatMap(\.rows).map(\.address), [unknown.address, possible.address])
    }
    func testBatchScopeExceptionsNoDeletionAndUndo() {
        let a = row("jkb1099@example.org"), b = row("bwfro01223@example.org"), later = row("mocajh91@example.org")
        let original = [a, b, later]
        var state = ReviewState()
        let changed = state.approve(original, selected: [a.id,b.id], pattern: .numeric, category: .person, remember: false, exceptions: [b.address])
        XCTAssertEqual(changed.count, original.count)
        XCTAssertEqual(changed[0].addressClassification.category, .person)
        XCTAssertEqual(changed[1], b)
        XCTAssertEqual(changed[2], later)
        XCTAssertTrue(state.rules.isEmpty)
        XCTAssertEqual(state.history.count, 1)
        let restored = state.undo(changed)
        XCTAssertEqual(restored.map { $0.addressClassification.category }, original.map { $0.addressClassification.category })
        XCTAssertEqual(restored.map(\.id), original.map(\.id))
        XCTAssertEqual(restored.map(\.status), original.map(\.status))
        XCTAssertTrue(state.history.isEmpty)
    }
    func testRememberedRuleFutureMatchesExceptionsAndUnreviewedExistingRows() {
        let a = row("jkb1099@example.org"), exception = row("bwfro01223@example.org"), outside = row("mocajh91@example.org")
        var state = ReviewState()
        _ = state.approve([a, exception, outside], selected: [a.id], pattern: .numeric, category: .person, remember: true, exceptions: [exception.address])
        let fresh = row("ssmith5391@example.org")
        let initial = row("r.lambertson@example.org")
        let result = state.applyingRules(to: [fresh, exception, outside, initial, row("info42@example.org")])
        XCTAssertEqual(result[0].addressClassification.category, .person)
        XCTAssertEqual(result[1], exception)
        XCTAssertEqual(result[2], outside)
        XCTAssertEqual(result[3], initial)
        XCTAssertEqual(result[4].addressClassification.category, .general)
    }
    func testUndoRemovesRuleAndLaterMatchesButPreservesLaterManualCorrection() {
        let a = row("jkb1099@example.org"), b = row("bwfro01223@example.org"), future = row("mocajh91@example.org")
        var state = ReviewState()
        let changed = state.approve([a,b], selected: [a.id,b.id], pattern: .numeric, category: .person, remember: true, at: Date(timeIntervalSince1970: 1))
        let later = state.applyingRules(to: changed + [future])
        let individuallyEdited = ClassificationEdits.set(later, selected: [b.id], category: .general, at: Date(timeIntervalSince1970: 2))
        let undone = state.undo(individuallyEdited, at: Date(timeIntervalSince1970: 3))
        XCTAssertEqual(undone[0].addressClassification.category, .uncertain)
        XCTAssertEqual(undone[1].addressClassification.category, .general)
        XCTAssertEqual(undone[2].addressClassification.category, .uncertain)
        XCTAssertTrue(state.rules.isEmpty)
        XCTAssertTrue(state.history.isEmpty)
        let recovered = ResultMerge.combine(later, undone)
        XCTAssertEqual(recovered.map { $0.addressClassification.category }, undone.map { $0.addressClassification.category })
    }
    func testAutomaticResetAndManualChoiceOverrideRememberedRule() {
        let a = row("jkb1099@example.org"), b = row("bwfro01223@example.org")
        var state = ReviewState()
        _ = state.approve([a], selected: [a.id], pattern: .numeric, category: .person, remember: true)
        let manual = ClassificationEdits.set([b], selected: [b.id], category: .general)
        XCTAssertEqual(state.applyingRules(to: manual), manual)
        let reset = ClassificationEdits.set([b], selected: [b.id], category: nil)
        XCTAssertEqual(state.applyingRules(to: reset), reset)
    }
    func testKeepUncertainIsAnExplicitReviewDecision() {
        let a = row("jkb1099@example.org")
        var state = ReviewState()
        let kept = state.approve([a], selected: [a.id], pattern: .numeric, category: .uncertain, remember: false)
        XCTAssertEqual(kept[0].addressClassification.category, .uncertain)
        XCTAssertTrue(GroupReview.groups(kept, rules: [], removed: []).isEmpty)
        XCTAssertEqual(state.undo(kept)[0].addressClassification.category, .uncertain)
    }
    func testGroupStateRoundTripAndCheckpointProtectsUndoFromWorkerWrites() throws {
        let a = row("jkb1099@example.org")
        var state = ReviewState()
        let changed = state.approve([a], selected: [a.id], pattern: .numeric, category: .person, remember: true)
        let restored = try JSONDecoder().decode(ReviewState.self, from: JSONEncoder().encode(state))
        XCTAssertEqual(restored, state)
        var snapshot = CrawlProgress(queue: [], visited: [], queued: [], robotRules: [:], domainPageCount: [:], discoveredCount: 0, scanned: 0, rows: changed, selectedSites: [], settings: CrawlOptions(depth: 0, maxPages: 0, maxPagesPerDomain: 0, excluded: "", stripDuplicates: true, excludeRole: false, excludeFree: false, excludeDisposable: false, checkDNS: false), input: "")
        CrawlDisk.updatePresentation(rules: [], removal: RemovalState(), classifications: changed, reviewState: state)
        XCTAssertTrue(CrawlDisk.save(snapshot))
        XCTAssertEqual(CrawlDisk.load()?.reviewState, state)
        let undone = state.undo(changed)
        CrawlDisk.updatePresentation(rules: [], removal: RemovalState(), classifications: undone, reviewState: state)
        snapshot.rows = changed // stale worker
        XCTAssertTrue(CrawlDisk.save(snapshot))
        XCTAssertEqual(CrawlDisk.load()?.rows[0].addressClassification.category, .uncertain)
        XCTAssertTrue(CrawlDisk.load()?.reviewState?.rules.isEmpty == true)
    }
    func testEveryExportDropsRawExcludedRulesAndRemoved() {
        let accepted = row("dan.boyce@example.org"), role = row("info@example.org", status: "Excluded"), provider = row("excluded@example.org", status: " excluded "), rule = row("hide@example.org"), removed = row("removed@example.org")
        let rows = [accepted, role, provider, rule, removed, row("logo@2x.png", status: "Excluded")]
        let rules = [SmartRule(kind: "Address", pattern: rule.address)]
        for onlyAccepted in [true, false] {
            XCTAssertEqual(ResultPolicy.exportRows(rows, rules: rules, removed: [removed.address], onlyAccepted: onlyAccepted).map(\.address), [accepted.address])
            XCTAssertEqual(ResultPolicy.exportSelection(rows, currentList: rows, rules: rules, removed: [removed.address], onlyAccepted: onlyAccepted).map(\.address), [accepted.address])
        }
    }
    func testCurrentListExportRespectsCategorySearchStatusAndOrder() {
        let person = row("sharon.dean@example.org"), second = row("rebecca.dolber@example.org"), role = row("info@example.org"), rejected = row("bad@example.org", status: "Rejected"), excluded = row("off@example.org", status: "Excluded")
        let rows = [role, second, rejected, excluded, person]
        let visible = ResultPolicy.filtered(rows, rules: [], removed: [], status: "Included", search: "sharon", scope: "Email").filter { $0.addressClassification.category == .person }
        XCTAssertEqual(ResultPolicy.exportSelection(rows, currentList: visible, rules: [], removed: [], onlyAccepted: false).map(\.id), [person.id])
        XCTAssertEqual(ResultPolicy.exportSelection(rows, currentList: [person,second], rules: [], removed: [], onlyAccepted: false).map(\.id), [person.id,second.id])
        XCTAssertEqual(ResultPolicy.exportSelection(rows, rules: [], removed: [], onlyAccepted: false).map(\.id), [role.id,second.id,person.id])
        XCTAssertTrue(ResultPolicy.exportSelection(rows, currentList: [excluded], rules: [], removed: [], onlyAccepted: false).isEmpty)
    }
    func testGroupEditsLeaveCSVSchemaEvidenceAndExclusionsUnchanged() {
        let a = row("jkb1099@example.org")
        var state = ReviewState()
        let result = state.approve([a], selected: [a.id], pattern: .numeric, category: .person, remember: true)
        XCTAssertEqual(VerificationCSV.line(result[0]), VerificationCSV.line(a))
        XCTAssertEqual(result[0].websiteConfirmation, a.websiteConfirmation)
        XCTAssertEqual(result[0].smtpVerification, a.smtpVerification)
        XCTAssertTrue(ResultPolicy.exportSelection(result, rules: [], removed: [a.address], onlyAccepted: false).isEmpty)
    }
}

extension GroupReviewAndExportTests {
    func testWholeSessionRoundTripAndLegacyMissingReviewState() throws {
        let a = row("jkb1099@example.org")
        var state = ReviewState()
        let changed = state.approve([a], selected: [a.id], pattern: .numeric, category: .person, remember: true)
        let session = GrabSession(mode: .pasted, input: "", excluded: "", depth: 0, maxPages: 0, stripDuplicates: true, excludeRole: false, excludeFree: false, excludeDisposable: false, checkDNS: false, rows: changed, reviewState: state)
        XCTAssertTrue(CrawlDisk.saveProject(session))
        let loaded = try XCTUnwrap(CrawlDisk.loadProject())
        XCTAssertEqual(loaded.reviewState, state)
        XCTAssertEqual(loaded.rows[0].classificationDecision, changed[0].classificationDecision)
        let future = row("ssmith5391@example.org")
        XCTAssertEqual(loaded.reviewState?.applyingRules(to: [future])[0].addressClassification.category, .person)
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(session)) as? [String:Any])
        object.removeValue(forKey: "reviewState")
        let legacy = try JSONDecoder().decode(GrabSession.self, from: JSONSerialization.data(withJSONObject: object))
        XCTAssertNil(legacy.reviewState)
        XCTAssertEqual(legacy.rows.count, session.rows.count)
    }
    func testConfirmingStaleGroupCannotChangeExcludedOrIndividuallyReviewedRows() {
        let a = row("jkb1099@example.org"), excluded = row("bwfro01223@example.org", status: "Excluded"), hidden = row("mocajh91@example.org"), removed = row("ssmith5391@example.org")
        var manual = row("rossis555@example.org")
        manual.classificationDecision = ClassificationDecision(category: .general, changedAt: Date())
        let rows = [a,excluded,hidden,removed,manual]
        var state = ReviewState()
        let result = state.approve(rows, selected: Set(rows.map(\.id)), pattern: .numeric, category: .person, remember: false, rules: [SmartRule(kind: "Address", pattern: hidden.address)], removed: [removed.address])
        XCTAssertEqual(result[0].addressClassification.category, .person)
        XCTAssertEqual(Array(result.dropFirst()), Array(rows.dropFirst()))
    }
    func testLatestRememberedRuleExceptionDoesNotFallThroughToOlderRule() {
        let a = row("jkb1099@example.org"), b = row("bwfro01223@example.org"), exception = row("mocajh91@example.org")
        var state = ReviewState()
        let first = state.approve([a], selected: [a.id], pattern: .numeric, category: .person, remember: true)
        _ = state.approve(first + [b,exception], selected: [b.id], pattern: .numeric, category: .general, remember: true, exceptions: [exception.address])
        XCTAssertEqual(state.applyingRules(to: [exception])[0], exception)
        let next = row("ssmith5391@example.org")
        XCTAssertEqual(state.applyingRules(to: [next])[0].addressClassification.category, .general)
    }
}
