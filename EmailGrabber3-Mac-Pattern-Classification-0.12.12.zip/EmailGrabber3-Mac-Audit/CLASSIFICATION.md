# Pattern-based classification — 0.12.12

The old familiar-given-name whitelist is removed. This version evaluates independent
signals, keeping the following precedence:

1. Your saved correction wins, including an explicit Uncertain correction.
2. Explicit shared-inbox, job-title and organization signals route to General inbox.
3. A recorded exact-address excerpt with a matching name supports Likely person.
4. Name-shaped address patterns supply heuristic evidence for Likely person.
5. Insufficient or ambiguous evidence remains Uncertain, never automatically deleted.

Separated name patterns accept two to four alphabetic components with at least two
full words, allowing middle initials and either order. They are not gated by a list
of known names. This fixes sharon.dean, rebecca.dolber, debra.fyock, sheri.coln,
susanne.g.hinkle, and unfamiliar names absent from the reference vocabulary.

Joined given/surname components (either order), optionally including a middle
initial, use a bundled vocabulary derived from 1990 US Census distributions. It has
5,130 given names and 88,698 surnames, is not exhaustive or internationally complete,
and is only positive evidence. The data and package provenance, hashes, public-domain
origin and MIT package license are recorded in Resources/person-names-provenance.json
and PERSON-NAMES-LICENSE.txt. No runtime download is needed. Native app and core
resource phases include the data, and missing vocabulary fails the resource test.

Examples supported by segmentation include margueritechandler, terryewhitaker,
debiferrer and ernestinagarcia. Full-name patterns can retain up to four trailing
digits, e.g. clarkdavid01 or susanstreett24. Numeric IDs, digits inside a handle,
initial-only patterns and initial+surname forms without additional name evidence
remain cautious. Numbers alone do not establish or exclude a person. Recognized
single-name handles can contribute evidence, with ambiguous word/name terms such
as hope and faith kept for review. No inference is proof of identity.

Explicit role and organization evidence overrides address-shape evidence, including
when a role has numeric suffixes. Existing crawl role-exclusion membership is not
changed. Publication alone, SMTP results and the email's domain never prove that
the address belongs to a person. Pattern reasons state the basis and identity limit.

Evaluation: Tests/Fixtures/classification-evaluation.tsv contains 139 curated routing
examples: 45 likely-person, 63 general-inbox and 31 uncertain cases. These combine
reported examples with synthetic cases across the supported patterns, unknown names,
titles, role aliases, organizations and numeric/initial handles. All 139 passed.
They are expected routing labels, not verified real identities or a measurement of
accuracy on the user's full dataset. The full portable suite passed 264 tests,
including saved corrections/reset, recrawl/checkpoint recovery and unchanged CSV.
SwiftUI syntax, project references/resources and shell syntax passed. Native Mac
compilation, GUI/WebKit execution and live CPR confirmation remain unverified.

Existing saved rows use the new automatic rules on display; no recrawl or data
migration is required. Saved manual corrections retain priority. Use automatic
classification to reset one explicitly. No mailbox probes or paid verification
were run. Selection, filtering, removal/Undo and saved evidence remain unchanged.

# Classification tuning — 0.12.11

Select one or more rows, then Classify selected… → Mark as Likely person,
General inbox or Uncertain. The same choices appear in an address's context menu.
Corrections take priority over automatic rules for all copies of that exact address
(case insensitive, within this project). They do not change acceptance, verification,
exclusions, removal history or CSV output. Use automatic classification resets them;
a dated reset prevents older checkpoints from restoring an obsolete correction.
A correction to one address never creates a pattern rule for other addresses.

Corrections persist in the optional classificationDecision field on saved rows.
Older projects without it still load without migration. Session/autosave/checkpoint
recovery, recrawls and later duplicate discoveries preserve the latest decision.
Clear starts a new project and clears its result-bound corrections. Corrections are
not a global address book shared across unrelated projects.

The Classification reason column explains the effective choice; Show evidence also
includes it. Automated improvements recognize connect/outreach/membership and other
shared terms, coalition/alliance/democracy and organization endings such as voices
and united in the local part. These are heuristics, not proof; domains alone are not
used to infer a shared inbox. Existing crawl role-exclusion membership is unchanged.

Separated familiar-given-name / surname patterns work in either order, including
palumbo.dana. This small name list is deliberately incomplete. Initials and unusual
names remain Uncertain unless recorded exact-address publication text supplies a
matching full name. Initial+surname (including separators) and given-name+initial
forms can then be strengthened. Capitalized job titles remain barred as names.
Your saved choice always wins and can also explicitly preserve Uncertain.

261 portable tests passed, including 9 new regressions covering screenshot examples,
name patterns, manual correction/reset, duplicates, backward-compatible decoding,
CSV invariance, session/autosave reopening, recrawls and late checkpoint writes.
SwiftUI syntax, Xcode project references and shell syntax passed. Native macOS
compilation, GUI/WebKit execution and live CPR confirmation remain unverified.
No paid verification or public mailbox probes were run.

# 0.12.9 correction

Validation: 252 portable tests passed. SwiftUI syntax, Xcode project references
and shell syntax passed. Native macOS compilation and GUI/WebKit execution were
not run in this Linux environment.

0.12.8 could mistake capitalized job titles for names in publication excerpts.
0.12.9 recognizes title inboxes before interpreting name evidence, rejects job-title
and shared-inbox terms as names, and requires an exact address match in excerpts.
Existing rows are reclassified on display without changing saved data or removals.
New regressions cover the reported three director inboxes, separator/alias forms,
unknown titles, person/category filtering, genuine staff names beside titles and
false address suffix matches. This changes presentation only, not role exclusions.

# Address classification — 0.12.8

Address type is independent of acceptance, SMTP, ZeroBounce and website publication.
General inbox recognizes shared mailbox terms, including newsroom and role aliases.
Likely person requires a familiar given name and separated name-like surname, or
recorded exact-address publication text with a matching full name. These are hints,
not proof of a person's identity. Unfamiliar names, initials, numeric handles and
single-word addresses stay Uncertain without matching recorded name evidence.
No new network requests are made for classification. Existing excerpts may have
only a mailto address; those do not imply name evidence. New visible mailto text
can retain the surrounding name while preserving the Email link match type.

Choose Address type → Person addresses only to hide other rows, or select General
inbox / Uncertain for review. Click Address type's column header to sort. Hover
its cells or use Show evidence to read the classification reason.
Review category removal captures visible rows under the current status/search
filters. Confirming uses existing address-based removal: all copies of those
addresses are suppressed, including future duplicate discoveries. Restore last
removal undoes the batch. Existing removals and rules remain intact. Review and
Cancel do not remove anything. Clearing the address-type filter restores hidden
rows. CSV export behavior and saved-data schema remain unchanged.

Validation: 248 portable tests passed on Linux using signature-verified Swift
6.0.3, including 8 new classification/publication and removal regressions.
SwiftUI syntax, Xcode object/source references and shell syntax passed.
Native macOS compilation, GUI interactions, native WebKit execution and live CPR
confirmation were not run. No paid verification or public mailbox probes were run.
