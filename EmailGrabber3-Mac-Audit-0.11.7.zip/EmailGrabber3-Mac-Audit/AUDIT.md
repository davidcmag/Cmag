# Mac source audit and repairs

Scope: all five Swift files, Info.plist, build script and setup documentation in the uploaded v0.11.6 Mac archive. Findings apply to that source; the currently installed Mac binary may differ. Original files are preserved outside the audit working copy. The VPS was not modified during this work.

## Findings repaired

| Finding | Original behavior | Repair and evidence |
|---|---|---|
| Adaptive traversal | Default depth zero did not follow links from an ordinary homepage | Always inspect seed links; follow promising contact/staff/sales/profile paths. Fixture verifies contact/fragment and sales traversal while skipping news. |
| URL aliases/fragments | Root URL aliases were distinct; links containing fragments could be missed | Normalize the empty root path and strip fragments after resolving links. Regression tests verify traversal and no repeated seed fetch during resume. |
| Explicit URL lists | Only the first four URLs per host were seeded | Retain all unique explicit URLs, respecting the user's page cap. Ten-URL and 300-page fixtures verify committed results/checkpoint counts. |
| Manual removal | Removed rows were deleted and appended to blocked terms, with no recovery path | Retain original rows, persist separate removal state, provide removal/restore controls, and keep reusable rules separate. |
| Filtering | All still hid rule matches; prefixes and preview labels were misleading | Centralize status/scope filtering, support Removed, correct prefix semantics, count Included rule impact, and add column sorting. |
| Checkpoint reliability | Errors were swallowed; up to nine pages and all smart-rule/removal metadata could be lost | Atomic checkpoints before requests/after pages; report failures and stop before unsafe progress; retain canceled pages and metadata. |
| Recovery | Completed checkpoints could not restore rows; loading checkpoint rows could overwrite newer verification | Restore results without pending links, autosave whole projects, merge stable identities using newer timestamps, and preserve unreadable/future-format files as recovery copies. |
| Concurrent windows/state changes | Separate window models shared a checkpoint file; opening/importing could change rows during verification | Share one application model; prevent conflicting import/open operations; reject changed-input continuation; use stable row IDs for verification updates. |
| Request limits | URLSession buffered entire responses before checking size; timed-out tasks could continue | Stream through bounded transfers, cancel timeouts, maintain shared native sessions/cookies/connection reuse, and validate redirects. Fixture concurrency/cancellation/limit tests exercise the transport. |
| Robots/rate handling | Wildcards, Allow precedence and named agents were ignored; unavailable robots could mean allow-all | Apply named-agent/longest-match rules, bounded wildcard matching, encoded-path normalization and crawl delays; fail closed on unavailable policy. Stop a restricted search provider rather than hammering its remaining queries. |
| DNS/syntax | Nonempty dig errors and null MX could appear valid; fallback absent; invalid dot/hyphen syntax passed | Parse MX/null-MX responses, distinguish failures, use A/AAAA fallback and stricter ASCII syntax. Never label local checks mailbox-verified. |
| False positives | Unicode addresses could be truncated into ASCII suffixes; some ingest endpoints slipped through; real providers were blanket placeholders | Protect Unicode boundaries and double-@ cases, decode mailto URIs deliberately, reject known telemetry, preserve valid hex locals and legitimate domain.com/email.com addresses. |
| Delimited imports | Swift treats CRLF as one Character; original parser could merge rows and accept malformed quoting | Parse CRLF, multiline fields, escaped quotes and BOMs correctly; reject malformed CSV. |
| Workbooks/subprocesses | Unbounded unzip output, unread stderr pipes, split rich-text addresses and no XML entity defense | Bound time/output/aggregate text, avoid unread stderr pipes, join text runs and reject DTD/external-entity inputs. |
| Exports | Quoting alone did not prevent spreadsheet formulas | Neutralize formula prefixes before CSV quoting. |
| Optional provider | HTTP status ignored; replacing a key deleted the prior key first; errors could continue a batch | Require successful HTTP/JSON; preserve uncertain/catch-all results; stop unavailable/rate-limited batches; update Keychain in place and retain existing keys on failure. Tests send no real addresses or keys. |
| Build metadata | Bundle version lagged the source, no Xcode test project | Versioned source candidate 0.11.7/build 14; added an Xcode app/core/test project and a backup-first verification script. |

## Verification boundaries

The final XCTest run executed 78 tests with zero failures, no skips and no compiler warnings. CORE-TESTS.log records the executed suite. Tests exercise actual portable Swift code with deterministic network/provider fixtures, native URLSession protocol fixtures, temporary files, real bounded unzip/process operations, and a 300-page fixture crawl. No live search coverage or Mac UI performance is inferred from fixture counts. Swift 6 may print a separate unused SwiftTesting zero-test summary after XCTest; the XCTest 'Executed ... tests' result is the relevant runner outcome.

The Swift compiler/toolchain was obtained from the official Swift download service and its detached signature verified with signing keys from the Swift project's official website-source repository. See TOOLCHAIN.md.

The macOS-only UI and Security branches were syntax parsed. The Xcode project property list, target/source references and scheme were checked. AppKit/SwiftUI type checking, Xcode build/test, actual Keychain behavior, UI actions and comparative live discovery have not been executed in this Linux environment. The Xcode project compiles the application as part of its test action so native compiler failures will be captured by verify-mac.sh before GUI acceptance.

## Remaining risks and limits

- No claim of perfection, signing/notarization, complete macOS acceptance or demonstrated live-search improvement is made. Follow MAC-ACCEPTANCE.md.
- The local crawler rejects credential-bearing and common private literal URLs but does not pin native URLSession connections to prevalidated DNS addresses. DNS rebinding/private-address aliases remain a hardening gap; this is not an internet-facing service implementation.
- Search sources, OSM coverage, US geographic expansion, ASCII email support and disposable lists retain the documented scope limits in README.md.
- Large-scale JSON autosaves/checkpoints can be costly; the 300-page fixture is not a days-long or million-record performance claim.
- CSV export and flattened-text XLSX import remain the native feature set; structured XLSX export and full column mapping were not added.
- The working original app must be retained until native acceptance succeeds. The source candidate does not replace it automatically.
