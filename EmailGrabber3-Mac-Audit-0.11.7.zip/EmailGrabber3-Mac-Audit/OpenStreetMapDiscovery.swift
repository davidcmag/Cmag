import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

struct USStateOption: Identifiable {
    let code: String
    let name: String
    var id: String { code }
}

enum USStates {
    static let all: [USStateOption] = [
        ("AL","Alabama"),("AK","Alaska"),("AZ","Arizona"),("AR","Arkansas"),("CA","California"),
        ("CO","Colorado"),("CT","Connecticut"),("DE","Delaware"),("FL","Florida"),("GA","Georgia"),
        ("HI","Hawaii"),("ID","Idaho"),("IL","Illinois"),("IN","Indiana"),("IA","Iowa"),
        ("KS","Kansas"),("KY","Kentucky"),("LA","Louisiana"),("ME","Maine"),("MD","Maryland"),
        ("MA","Massachusetts"),("MI","Michigan"),("MN","Minnesota"),("MS","Mississippi"),("MO","Missouri"),
        ("MT","Montana"),("NE","Nebraska"),("NV","Nevada"),("NH","New Hampshire"),("NJ","New Jersey"),
        ("NM","New Mexico"),("NY","New York"),("NC","North Carolina"),("ND","North Dakota"),("OH","Ohio"),
        ("OK","Oklahoma"),("OR","Oregon"),("PA","Pennsylvania"),("RI","Rhode Island"),("SC","South Carolina"),
        ("SD","South Dakota"),("TN","Tennessee"),("TX","Texas"),("UT","Utah"),("VT","Vermont"),
        ("VA","Virginia"),("WA","Washington"),("WV","West Virginia"),("WI","Wisconsin"),("WY","Wyoming")
    ].map { USStateOption(code: $0.0, name: $0.1) }
}

struct OSMBusinessCategory: Identifiable {
    let id: String
    let label: String
    let tagKey: String
    let tagValue: String
}

enum OSMBusinessCategories {
    // Explicit, reviewed OSM tag mappings. Free-form keywords use web search.
    static let all: [OSMBusinessCategory] = [
        .init(id: "funeral", label: "Funeral homes", tagKey: "amenity", tagValue: "funeral_home"),
        .init(id: "restaurant", label: "Restaurants", tagKey: "amenity", tagValue: "restaurant"),
        .init(id: "cafe", label: "Cafés", tagKey: "amenity", tagValue: "cafe"),
        .init(id: "dentist", label: "Dentists", tagKey: "amenity", tagValue: "dentist"),
        .init(id: "doctors", label: "Physicians' offices", tagKey: "amenity", tagValue: "doctors"),
        .init(id: "clinic", label: "Medical clinics", tagKey: "amenity", tagValue: "clinic"),
        .init(id: "pharmacy", label: "Pharmacies", tagKey: "amenity", tagValue: "pharmacy"),
        .init(id: "bank", label: "Banks", tagKey: "amenity", tagValue: "bank"),
        .init(id: "hotel", label: "Hotels", tagKey: "tourism", tagValue: "hotel"),
        .init(id: "supermarket", label: "Supermarkets", tagKey: "shop", tagValue: "supermarket"),
        .init(id: "hairdresser", label: "Hair salons", tagKey: "shop", tagValue: "hairdresser"),
        .init(id: "car_repair", label: "Auto repair shops", tagKey: "shop", tagValue: "car_repair"),
        .init(id: "insurance", label: "Insurance offices", tagKey: "office", tagValue: "insurance"),
        .init(id: "lawyer", label: "Law offices", tagKey: "office", tagValue: "lawyer"),
        .init(id: "accountant", label: "Accounting offices", tagKey: "office", tagValue: "accountant"),
        .init(id: "estate_agent", label: "Real estate offices", tagKey: "office", tagValue: "estate_agent")
    ]

    static func match(keyword: String) -> OSMBusinessCategory? {
        let input = keyword.lowercased()
        let aliases: [(String, [String])] = [
            ("funeral", ["funeral", "mortuary"]),
            ("restaurant", ["restaurant"]),
            ("cafe", ["cafe", "coffee shop"]),
            ("dentist", ["dentist", "dental"]),
            ("doctors", ["physician", "doctor office", "doctors office"]),
            ("clinic", ["medical clinic", "health clinic"]),
            ("pharmacy", ["pharmacy", "pharmacies"]),
            ("bank", ["banks", "bank branch"]),
            ("hotel", ["hotel", "lodging"]),
            ("supermarket", ["supermarket", "grocery store"]),
            ("hairdresser", ["hair salon", "hairdresser", "barbershop"]),
            ("car_repair", ["auto repair", "car repair", "mechanic"]),
            ("insurance", ["insurance agency", "insurance office"]),
            ("lawyer", ["law firm", "law office", "attorney", "lawyer"]),
            ("accountant", ["accountant", "accounting firm"]),
            ("estate_agent", ["real estate agency", "realtor"])
        ]
        for (id, words) in aliases where words.contains(where: input.contains) {
            return all.first(where: { $0.id == id })
        }
        return nil
    }
}

/// An explicitly user-initiated single-state query. Never loops across states
/// or retries rate-limit responses on a public Overpass instance.
enum OpenStreetMapDiscovery {
    static func discoverBusinesses(stateCode: String, category: OSMBusinessCategory, shouldStop: () -> Bool, progress: (String) -> Void) -> [DiscoveredSite] {
        guard USStates.all.contains(where: { $0.code == stateCode }), !shouldStop() else { return [] }
        progress("Requesting \(category.label.lowercased()) records for \(stateCode)…")
        let query = """
        [out:json][timeout:40];
        area["ISO3166-2"="US-\(stateCode)"]["boundary"="administrative"]->.region;
        nwr["\(category.tagKey)"="\(category.tagValue)"](area.region);
        out tags center;
        """
        guard let url = URL(string: "https://overpass-api.de/api/interpreter") else { return [] }
        var request = URLRequest(url: url, timeoutInterval: 65)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.setValue("EmailGrabber3/0.7 (manual regional business discovery)", forHTTPHeaderField: "User-Agent")
        let encoded = query.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? ""
        request.httpBody = "data=\(encoded)".data(using: .utf8)
        let result = HTTPTransport.perform(request, maxBytes: 15_000_000, timeout: 70, shouldCancel: shouldStop,
            redirect: { $0.scheme == "https" && $0.host == "overpass-api.de" })
        let httpCode = result.status ?? 0
        let returnedData = result.data
        if shouldStop() { return [] }
        guard result.succeeded, httpCode == 200, let data = returnedData,
              let root = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let records = root["elements"] as? [[String: Any]] else {
            progress(httpCode == 429 || httpCode == 504 ? "OpenStreetMap server is busy or rate-limiting; try another time" : "Regional lookup failed (HTTP \(httpCode))")
            return []
        }
        var candidates: [DiscoveredSite] = []
        var uniqueHosts = Set<String>()
        for item in records {
            if shouldStop() { break }
            guard let tags = item["tags"] as? [String: String] else { continue }
            let possible = [tags["website"], tags["contact:website"]].compactMap { $0 }
            guard let first = possible.first(where: { !$0.trimmingCharacters(in: .whitespaces).isEmpty }) else { continue }
            let candidate = first.trimmingCharacters(in: .whitespacesAndNewlines)
            let withScheme = candidate.contains("://") ? candidate : "https://" + candidate
            guard let target = URL(string: withScheme),
                  EmailPolicy.httpURL(target),
                  let host = target.host?.lowercased() else { continue }
            let normalized = host.hasPrefix("www.") ? String(host.dropFirst(4)) : host
            guard uniqueHosts.insert(normalized).inserted else { continue }
            let businessName = tags["name"] ?? "Unnamed \(category.label.lowercased()) listing"
            candidates.append(DiscoveredSite(url: target.absoluteString, origin: "OSM \(stateCode): \(businessName)"))
        }
        progress("OSM \(stateCode): \(records.count) mapped \(category.label.lowercased()) records; \(candidates.count) distinct websites")
        return candidates
    }
}
