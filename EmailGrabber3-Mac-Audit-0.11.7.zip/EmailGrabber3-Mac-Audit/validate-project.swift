import Foundation
let root = URL(fileURLWithPath: CommandLine.arguments[1])
let data = try Data(contentsOf: root.appendingPathComponent("EmailGrabber3.xcodeproj/project.pbxproj"))
var format = PropertyListSerialization.PropertyListFormat.openStep
let project = try PropertyListSerialization.propertyList(from: data, options: [], format: &format) as! [String: Any]
let objects = project["objects"] as! [String: Any]
guard let rootID = project["rootObject"] as? String, objects[rootID] != nil else { fatalError("Invalid project root") }
let targets = objects.values.compactMap { $0 as? [String: Any] }.filter { $0["isa"] as? String == "PBXNativeTarget" }
precondition(targets.count == 3)
for (_, value) in objects {
    guard let object = value as? [String: Any] else { continue }
    for key in ["fileRef","target","targetProxy","containerPortal","buildConfigurationList","productReference","mainGroup","productRefGroup"] {
        if let id = object[key] as? String { precondition(objects[id] != nil, "Dangling object: \(key)") }
    }
    for key in ["children","buildPhases","files","buildConfigurations","dependencies","targets"] {
        if let ids = object[key] as? [String] { for id in ids { precondition(objects[id] != nil, "Dangling collection: \(key)") } }
    }
    if object["isa"] as? String == "PBXFileReference", object["sourceTree"] as? String == "SOURCE_ROOT", let path = object["path"] as? String { precondition(FileManager.default.fileExists(atPath: root.appendingPathComponent(path).path), "Missing source: \(path)") }
}
print("Project property list parsed; three targets and all object/source references validated. Xcode build still requires macOS.")
