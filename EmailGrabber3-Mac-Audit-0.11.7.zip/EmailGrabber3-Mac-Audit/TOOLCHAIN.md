# Audit toolchain evidence

Portable code was compiled and tested using Swift 6.0.3 for x86_64 Linux in Swift 5 language mode, matching the macOS 13+ compatibility setting used by the build scripts/project. This does not provide Apple's SDKs.

Official archive: https://download.swift.org/swift-6.0.3-release/ubuntu2204/swift-6.0.3-RELEASE/swift-6.0.3-RELEASE-ubuntu22.04.tar.gz

Detached signature: the same URL plus .sig.

Signing-key source: https://raw.githubusercontent.com/swiftlang/swift-org-website/main/keys/all-keys.asc

GPG verified the archive with Swift 6.x Release Signing Key fingerprint:
52BB 7E3D E28A 71BE 22EC 05FF EF80 A866 B47A 981F

The key was authenticated through its official HTTPS project source; no personal GPG web-of-trust certification is claimed. TLS, signature verification and package integrity checks were not disabled. No system Python or original application source was changed.
