import Foundation
#if canImport(FoundationXML)
import FoundationXML
#endif

/// Imports text, CSV and XLSX data without a third-party dependency.
/// XLSX is an OOXML ZIP: we read the shared strings and worksheet XML with macOS unzip.
enum FileImport {
    static func text(from url: URL) throws -> String {
        let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
        guard size <= 64_000_000 else { throw ImportError.tooLarge }
        let ext = url.pathExtension.lowercased()
        switch ext {
        case "csv", "tsv":
            let raw = try String(contentsOf: url, encoding: .utf8)
            let delimiter: Character = ext == "tsv" ? "\t" : ","
            return try parseDelimited(raw, separator: delimiter)
                .map { $0.joined(separator: "\n") }.joined(separator: "\n")
        case "xlsx":
            return try extractXLSX(url)
        case "txt", "html", "htm":
            return try String(contentsOf: url, encoding: .utf8)
        default:
            throw ImportError.unsupported
        }
    }

    static func parseDelimited(_ input: String, separator: Character) throws -> [[String]] {
        let chars = Array(input.hasPrefix("\u{FEFF}") ? String(input.dropFirst()) : input)
        var rows: [[String]] = []; var row: [String] = []; var field = ""
        var quoted = false; var closed = false; var i = 0
        func finishField() { row.append(field); field = ""; closed = false }
        func finishRow() { finishField(); if row.contains(where: { !$0.isEmpty }) { rows.append(row) }; row = [] }
        while i < chars.count {
            let ch = chars[i]
            if quoted {
                if ch == "\"" {
                    if i + 1 < chars.count && chars[i + 1] == "\"" { field.append("\""); i += 1 }
                    else { quoted = false; closed = true }
                } else { field.append(ch) }
            } else if ch == separator { finishField() }
            else if ch == "\n" || ch == "\r" || ch == "\r\n" { finishRow() }
            else if closed {
                if ch != " " && ch != "\t" { throw ImportError.invalidDelimited }
            } else if ch == "\"" {
                guard field.isEmpty else { throw ImportError.invalidDelimited }; quoted = true
            } else { field.append(ch) }
            i += 1
        }
        guard !quoted else { throw ImportError.invalidDelimited }
        finishRow(); return rows
    }

    private static func extractXLSX(_ url: URL) throws -> String {
        let archiveEntries = try unzipList(url)
        guard archiveEntries.count <= 10_000 else { throw ImportError.invalidWorkbook }
        guard archiveEntries.contains("xl/workbook.xml") else { throw ImportError.invalidWorkbook }
        var text: [String] = []; var totalBytes = 0
        func append(_ value: String) throws {
            totalBytes += value.utf8.count
            guard totalBytes <= 32_000_000 else { throw ImportError.tooLarge }
            text.append(value)
        }
        if archiveEntries.contains("xl/sharedStrings.xml") {
            try append(extractTextNodes(unzip(url, entry: "xl/sharedStrings.xml")))
        }
        let worksheets = archiveEntries.filter { $0.hasPrefix("xl/worksheets/sheet") && $0.hasSuffix(".xml") }.sorted()
        guard worksheets.count <= 100 else { throw ImportError.tooLarge }
        for entry in worksheets {
            try append(extractTextNodes(unzip(url, entry: entry)))
        }
        guard text.reduce(0, { $0 + $1.utf8.count }) <= 32_000_000 else { throw ImportError.tooLarge }
        return text.joined(separator: "\n")
    }

    private static func extractTextNodes(_ data: Data) throws -> String {
        for encoding in [String.Encoding.utf8, .utf16LittleEndian, .utf16BigEndian] {
            if String(data: data, encoding: encoding)?.range(of: "<!DOCTYPE", options: .caseInsensitive) != nil { throw ImportError.invalidWorkbook }
        }
        let delegate = TextNodeCollector()
        let parser = XMLParser(data: data)
        parser.delegate = delegate
        parser.shouldResolveExternalEntities = false
        guard parser.parse() else { throw ImportError.invalidWorkbook }
        return delegate.values.joined(separator: "\n")
    }

    private static func unzipList(_ url: URL) throws -> [String] {
        let data = try runUnzip(["-Z1", url.path])
        return (String(data: data, encoding: .utf8) ?? "").split(whereSeparator: \.isNewline).map(String.init)
    }

    private static func unzip(_ url: URL, entry: String) throws -> Data {
        // Paths are fixed by inspected archive entry names; no shell interpolation.
        try runUnzip(["-p", url.path, entry])
    }

    private static func runUnzip(_ arguments: [String]) throws -> Data {
        do { return try SafeProcess.run("/usr/bin/unzip", arguments, maxBytes: 8_000_000, timeout: 10) }
        catch { throw ImportError.invalidWorkbook }
    }

    enum ImportError: LocalizedError {
        case unsupported, invalidWorkbook, invalidDelimited, tooLarge
        var errorDescription: String? {
            switch self {
            case .invalidDelimited: return "Malformed quoted CSV/TSV file"
            case .tooLarge: return "Imported workbook text exceeds the 32 MB limit"
            case .unsupported: return "Unsupported file format"
            case .invalidWorkbook: return "Could not read Excel workbook"
            }
        }
    }
}

private final class TextNodeCollector: NSObject, XMLParserDelegate {
    var values: [String] = []
    private var recording = false
    private var buffer = ""
    private var group: String?
    private var bytes = 0
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String: String] = [:]) {
        if elementName == "si" || elementName == "is" { group = "" }
        if elementName == "t" || elementName == "v" { recording = true; buffer = "" }
    }
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        guard recording else { return }
        bytes += string.utf8.count
        guard bytes <= 8_000_000 else { parser.abortParsing(); return }
        buffer += string
    }
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "t" || elementName == "v" {
            if group != nil && elementName == "t" { group! += buffer }
            else if !buffer.isEmpty { values.append(buffer) }
            recording = false; buffer = ""
        }
        if elementName == "si" || elementName == "is" {
            if let value = group, !value.isEmpty { values.append(value) }; group = nil
        }
    }
}
