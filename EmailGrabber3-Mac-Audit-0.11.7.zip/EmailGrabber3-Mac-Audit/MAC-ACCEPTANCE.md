# Remaining macOS acceptance

The cloud environment cannot run AppKit/SwiftUI or the Mac Keychain. Passing portable Swift tests does not replace these checks.

Run `bash verify-mac.sh` once from this folder. It backs up the existing local application-data directory, builds the native app, and runs the same XCTest suite against the Mac SDK. Keep the original app/source and the printed backup directory. Quit the original app before launching the new build.

After a successful build, open the Xcode project and press Command-R:

1. Crawl the same accessible URLs used by your existing Mac copy with the same limits. Include a homepage whose contact link uses a fragment, plus several pages on one host. Confirm adaptive crawling reaches contact/sales/staff pages and records retain actual source URLs.
2. Select an email, choose Remove selected, and confirm no reusable rule is added. Restore last removal. Check Included, All, Excluded and Removed views, scoped search and column sorting. Excluded/removed records must stay out of accepted CSV exports.
3. Pause an unfinished crawl, stop it, quit normally and relaunch. Resume saved crawl; confirm original results, rules, removals and progress remain. A completed checkpoint must also restore its results without requiring remaining links.
4. Reimport a CSV exported by the original app and the included rich-text XLSX fixture. Export CSV and inspect the dataset against the grid.
5. Run the same keyword phrases/location on the old and new app separately. Record actual relevant sites, pages, genuine addresses, false positives and elapsed time. Provider restrictions must be reported; do not bypass website security. No result-count target substitutes for this comparison.

Keep ZeroBounce off for acceptance unless you intentionally authorize a paid batch. Keychain save/update/unlock behavior requires a separate Mac check if that optional integration is used. Do not send an API key or passwords in chat.

If a build or required check fails, retain the original app. Share the compiler/check output rather than repeatedly testing an incomplete release. Do not call this candidate finished until these checks pass.
