import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

/// Independent, best-effort public HTML search source. Requests are deliberately
/// bounded; a public website may change its markup or block automated clients.
enum AdditionalSearchDiscovery {
    static func extractResultURLs(from html: String) -> [URL] {
        let pattern = #"<a\b[^>]*class\s*=\s*["'][^"']*result__a[^"']*["'][^>]*href\s*=\s*["']([^"']+)["']|<a\b[^>]*href\s*=\s*["']([^"']+)["'][^>]*class\s*=\s*["'][^"']*result__a[^"']*["']"#
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return [] }
        let range = NSRange(html.startIndex..<html.endIndex, in: html)
        var urls: [URL] = []
        for match in regex.matches(in: html, range: range) {
            let capture = [1, 2].compactMap { Range(match.range(at: $0), in: html) }.first
            guard let capture = capture else { continue }
            var link = String(html[capture]).replacingOccurrences(of: "&amp;", with: "&")
            if let components = URLComponents(string: link),
                let destination = components.queryItems?.first(where: { $0.name == "uddg" })?.value {
                link = destination
            } else if link.hasPrefix("//") {
                link = "https:" + link
            }
            guard let url = URL(string: link), ["https", "http"].contains(url.scheme?.lowercased() ?? ""), EmailPolicy.httpURL(url), !(url.host?.lowercased().hasSuffix("duckduckgo.com") ?? true) else { continue }
            urls.append(url)
        }
        return urls
    }

    struct SearchResult { var urls: [URL]; var status: Int? }
    static func search(_ query: String, shouldStop: () -> Bool = { false }) -> [URL] { searchResult(query, shouldStop: shouldStop).urls }
    static func searchResult(_ query: String, shouldStop: () -> Bool = { false }) -> SearchResult {
        guard var components = URLComponents(string: "https://html.duckduckgo.com/html/") else { return SearchResult(urls: [], status: nil) }
        components.queryItems = [URLQueryItem(name: "q", value: query), URLQueryItem(name: "kl", value: "us-en")]
        components.percentEncodedQuery = components.percentEncodedQuery?.replacingOccurrences(of: "+", with: "%2B")
        guard let url = components.url else { return SearchResult(urls: [], status: nil) }
        var request = URLRequest(url: url, timeoutInterval: 12)
        request.setValue("Mozilla/5.0 (compatible; EmailGrabber3/0.9; local personal search)", forHTTPHeaderField: "User-Agent")
        let result = HTTPTransport.perform(request, maxBytes: 2_000_000, timeout: 14, shouldCancel: shouldStop)
        guard result.succeeded, let data = result.data, let html = String(data: data, encoding: .utf8) else { return SearchResult(urls: [], status: result.status) }
        return SearchResult(urls: extractResultURLs(from: html), status: result.status)
    }
}
