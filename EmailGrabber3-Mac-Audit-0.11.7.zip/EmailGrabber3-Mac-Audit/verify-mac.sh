#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ "$(uname -s)" != Darwin ]]; then echo "This application verification requires macOS." >&2; exit 1; fi
umask 077
auditDataDirectory="$HOME/Library/Application Support/EmailGrabber3"
if [[ -d "$auditDataDirectory" ]]; then
  auditBackupRoot="$HOME/Library/Application Support/EmailGrabber3-backups"
  mkdir -p "$auditBackupRoot"
  auditBackupDirectory=$(mktemp -d "$auditBackupRoot/audit-XXXXXXXX")
  ditto "$auditDataDirectory" "$auditBackupDirectory"
  chmod 700 "$auditBackupDirectory"
  echo "Existing local app data backed up to: $auditBackupDirectory"
fi
mkdir -p validation
auditRunTag="$(date -u +%Y%m%dT%H%M%SZ)-$$"
auditLog="validation/xcode-$auditRunTag.log"
auditResults="validation/tests-$auditRunTag.xcresult"
xcodebuild -project EmailGrabber3.xcodeproj -scheme EmailGrabber3 -configuration Debug -destination 'platform=macOS' -derivedDataPath validation/DerivedData -resultBundlePath "$auditResults" test > "$auditLog" 2>&1 || { tail -n 80 "$auditLog"; exit 1; }
echo "Xcode build and tests passed. Log: $auditLog"
echo "Quit the previous app, then open EmailGrabber3.xcodeproj and Run to complete the GUI/live-site checks."
