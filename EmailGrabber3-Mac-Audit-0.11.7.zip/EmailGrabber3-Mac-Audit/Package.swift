// swift-tools-version: 5.9
import PackageDescription
let package = Package(
    name: "EmailGrabberCore",
    platforms: [.macOS(.v13)],
    products: [.library(name: "EmailGrabberCore", targets: ["EmailGrabberCore"])],
    targets: [
        .target(name: "EmailGrabberCore", path: ".", exclude: ["EmailGrabber3.swift", "Tests", "Info.plist", "README.md", "AUDIT.md", "MAC-ACCEPTANCE.md", "TOOLCHAIN.md", "build-mac.sh", "verify-mac.sh", "validate-project.swift", "EmailGrabber3.xcodeproj", "CORE-BUILD.log", "CORE-TESTS.log", "UI-PARSE.log", "PROJECT-VALIDATION.log", "SHA256SUMS", "BASELINE-ORIGINAL.json"], sources: ["AdvancedVerifier.swift", "DomainModels.swift", "GrabEngine.swift", "AdditionalSearchDiscovery.swift", "OpenStreetMapDiscovery.swift", "FileImport.swift", "AuditSupport.swift", "HTTPTransport.swift", "SafeProcess.swift"]),
        .testTarget(name: "EmailGrabberCoreTests", dependencies: ["EmailGrabberCore"], path: "Tests", resources: [.copy("Fixtures")])
    ],
    swiftLanguageVersions: [.v5]
)
