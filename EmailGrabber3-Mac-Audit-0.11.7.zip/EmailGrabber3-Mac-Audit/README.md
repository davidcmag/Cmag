# Email Grabber 3 — audited Mac source candidate 0.11.7

Audited from the supplied `EmailGrabber3-v0.11.6-filter-scope.zip`. The uploaded original is unchanged. This is repaired source, not a compiled, notarized or fully Mac-validated release. Read AUDIT.md for findings and verification limits.

## With your existing Xcode

1. Quit the previous Email Grabber app; keep its app bundle and source as a fallback.
2. In Terminal, enter this extracted folder and run `bash verify-mac.sh`. It first makes a private backup of existing EmailGrabber3 application data, then asks Xcode to build the application and run the tests. No VPS commands, Python dependencies, API keys or paid services are needed.
3. If that succeeds, open `EmailGrabber3.xcodeproj`, choose the EmailGrabber3 scheme and My Mac, and press Command-R. Complete MAC-ACCEPTANCE.md before treating the candidate as your replacement.

The script stores the complete Xcode log and result bundle under `validation/`. It does not install over your existing app. Xcode uses local ad-hoc signing; no Apple Developer team or notarization is claimed. An alternative local application build remains available with `bash build-mac.sh`.

## What changed

Adaptive mode now starts from homepages and follows promising contact/staff/sales/profile links. Multiple explicitly supplied URLs on the same host are retained. Removed emails stay recoverable without becoming exclusion rules. All/Included/Excluded/Removed views and scoped search are consistent. Live updates send new rows in batches instead of repeatedly copying the entire result array.

Projects autosave privately; checkpoints preserve rules/removals and are written around every scanned page. Resuming merges newer saved validation results and retains unfinished requests. Native URLSession networking, cookies and shared connection reuse are retained; streamed response limits, cancellation and responsible provider-rate-limit handling are added.

CSV/TSV imports handle CRLF, quotes, multiline fields and BOMs. XLSX rich-text runs remain joined; resource limits and external-entity rejection protect workbook imports. CSV exports neutralize spreadsheet formulas. Syntax checks, null-MX handling, DNS fallback, telemetry rejection and optional ZeroBounce response handling are corrected.

## Existing scope and limits

This remains a native macOS 13+ app. It supports CSV export and text/CSV/TSV/XLSX import; XLSX export is not implemented. It supports ASCII email syntax, not full internationalized mailbox syntax. Disposable-domain detection is a starter list. Local syntax/MX/fallback checks never verify an individual mailbox. ZeroBounce is optional, requires explicit confirmation, and can consume credits. No audit tests contact it.

Discovery retains the existing free Bing RSS, DuckDuckGo and optional single-state OSM strategy. It processes the first five keyword lines, up to 3,000 candidate hosts, and bounded independent-source/directory queries. The original US geographic expansion is retained. Search providers may throttle or change their interfaces. No exhaustive coverage or comparative live-search performance is promised.

Zero page caps mean no numeric total/per-site cap, not unlimited memory or downloads. Adaptive traversal is bounded to 20 levels; each page contributes up to 200 eligible links. Text/CSV inputs are limited to 64 MB; workbook extracted text to 32 MB, each extracted entry to 8 MB, and workbooks to 100 worksheets. Crawler responses are capped while streaming. A crash can replay an unfinished page. JSON checkpoint costs on very large collections remain a scaling limitation.

The app is a local trusted-user application. It is not a hardened public service: private literal destinations and credentials in URLs are rejected, but full DNS-rebinding-resistant connection pinning is not implemented. Do not deploy this Mac core as an internet-facing server.
