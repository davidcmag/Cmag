import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

struct WebsiteConfirmation: Codable, Hashable {
    enum Outcome: String, Codable {
        case published = "Published"
        case notFound = "Not found on page"
        case unavailable = "Page unavailable"
        case noSource = "No website source"
        case cancelled = "Cancelled"
    }
    enum Match: String, Codable { case pageText = "Page text", mailto = "Email link" }
    var outcome: Outcome
    var reason: String
    var checkedAt = Date()
    var sourceURL: String
    var finalURL: String?
    var httpStatus: Int?
    var match: Match?
    var excerpt: String?
    var organizationDomain: Bool?
    var checkerVersion = "website-0.12.4"
    var summary: String {
        let date = DateFormatter.localizedString(from: checkedAt, dateStyle: .medium, timeStyle: .short)
        return [reason, "Checked: " + date, "URL: " + (finalURL ?? sourceURL)].joined(separator: "\n")
    }
    var label: String {
        guard outcome == .published else { return outcome.rawValue }
        return organizationDomain == true ? "Published by organization" : "Published on source"
    }
}

struct WebsiteTarget: Hashable {
    var address: String
    var source: String
    var ids: [UUID]
}

enum WebsiteConfirmationPolicy {
    static func targets(_ rows: [FoundEmail], selected: Set<UUID>? = nil,
                        rules: [SmartRule], removed: Set<String>, limit: Int = 100) -> [WebsiteTarget] {
        var result: [WebsiteTarget] = []; var indices: [String: Int] = [:]
        for row in rows {
            guard (selected == nil || selected!.contains(row.id)),
                  VerificationApplication.eligible(row, rules: rules, removed: removed) else { continue }
            let key = row.address.lowercased() + "\n" + row.source
            if let index = indices[key] { result[index].ids.append(row.id) }
            else if result.count < limit {
                indices[key] = result.count
                result.append(WebsiteTarget(address: row.address, source: row.source, ids: [row.id]))
            }
        }
        return result
    }
    static func apply(_ confirmation: WebsiteConfirmation, to row: inout FoundEmail) {
        if let previous = row.websiteConfirmation {
            var history = row.websiteHistory ?? []
            history.append(previous); row.websiteHistory = Array(history.suffix(3))
        }
        row.websiteConfirmation = confirmation
        // Publication is independent evidence. Never change acceptance,
        // exclusions, removals, SMTP verdicts or provider conclusions here.
    }
    static func organization(_ host: String, email: String) -> Bool {
        guard let domain = email.split(separator: "@").last else { return false }
        let host = host.lowercased(), name = domain.lowercased()
        return host == name || host.hasSuffix("." + name)
    }
    static func sourceURL(_ source: String) -> URL? {
        guard source.utf8.count <= 8192, let url = URL(string: source),
              EmailPolicy.httpURL(url), let host = url.host,
              MailAddressSafety.hostname(host), url.port == nil || url.port == 80 || url.port == 443 else { return nil }
        return url
    }
    static func reflects(_ address: String, in url: URL) -> Bool {
        guard let query = URLComponents(url: url, resolvingAgainstBaseURL: false)?.query else { return false }
        return query.lowercased().contains(address.lowercased()) || (query.removingPercentEncoding?.lowercased().contains(address.lowercased()) == true)
    }
    static func permits(_ candidate: URL, from source: URL) -> Bool {
        guard sourceURL(candidate.absoluteString) != nil,
              let a = candidate.host, let b = source.host,
              EmailPolicy.canonicalHost(a) == EmailPolicy.canonicalHost(b),
              source.scheme?.lowercased() != "https" || candidate.scheme?.lowercased() == "https" else { return false }
        return true
    }
}

/// Serial, user-initiated batch. A fresh instance is created for every check.
/// Reuses a page only within that batch, with the actual fetch timestamp.
/// Static page text/mailto only: no JavaScript execution or guessed addresses.
final class WebsiteConfirmer {
    typealias Fetch = (URLRequest, @escaping () -> Bool, @escaping (URL) -> Bool) -> HTTPResult
    private struct Page { var response: HTTPResult; var at: Date }
    private let fetch: Fetch
    private let now: () -> Date
    private var pages: [String: Page] = [:]
    private var pageOrder: [String] = []
    private var requestCount = 0
    static let maximumBytes = 1_000_000
    init(fetch: @escaping Fetch = { request, cancelled, redirect in
        HTTPTransport.perform(request, maxBytes: WebsiteConfirmer.maximumBytes, timeout: 12,
                              shouldCancel: cancelled, redirect: redirect)
    }, now: @escaping () -> Date = Date.init) { self.fetch = fetch; self.now = now }

    func confirm(address: String, source: String, cancelled: @escaping () -> Bool = { false }) -> WebsiteConfirmation {
        var result = WebsiteConfirmation(outcome: .unavailable, reason: "", checkedAt: now(), sourceURL: source)
        guard !cancelled() else { result.outcome = .cancelled; result.reason = "Cancelled before website request"; return result }
        guard EmailPolicy.validSyntax(address) else { result.reason = "Unsupported address syntax"; return result }
        guard let url = WebsiteConfirmationPolicy.sourceURL(source) else {
            result.outcome = .noSource; result.reason = "Source is not a supported public HTTP/HTTPS website URL"; return result
        }
        guard !WebsiteConfirmationPolicy.reflects(address, in: url) else {
            result.reason = "Address is part of the source query; an echoed query is not independent publication evidence"; return result
        }
        guard var components = URLComponents(url: url, resolvingAgainstBaseURL: false) else { result.reason = "Could not normalize source URL"; return result }
        components.fragment = nil
        guard let requestURL = components.url else { result.reason = "Could not normalize source URL"; return result }
        let key = requestURL.absoluteString
        let page: Page
        if let cached = pages[key] { page = cached }
        else {
            guard requestCount < 100 else { result.reason = "Batch page limit reached; check this source in a new batch"; return result }
            requestCount += 1
            var request = URLRequest(url: requestURL, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 10)
            request.httpShouldHandleCookies = false
            request.setValue("no-cache, no-store", forHTTPHeaderField: "Cache-Control")
            request.setValue("no-cache", forHTTPHeaderField: "Pragma")
            request.setValue("text/html, application/xhtml+xml, text/plain;q=0.9", forHTTPHeaderField: "Accept")
            request.setValue("EmailGrabber3/0.12.4 (user-requested source confirmation)", forHTTPHeaderField: "User-Agent")
            let response = fetch(request, cancelled, { WebsiteConfirmationPolicy.permits($0, from: url) })
            page = Page(response: response, at: now())
            if !cancelled() {
                if pageOrder.count >= 8 { pages.removeValue(forKey: pageOrder.removeFirst()) }
                pages[key] = page; pageOrder.append(key)
            }
        }
        result.checkedAt = page.at
        result.finalURL = page.response.finalURL?.absoluteString
        result.httpStatus = page.response.status
        guard !cancelled() else { result.outcome = .cancelled; result.reason = "Cancelled during website request"; return result }
        guard page.response.succeeded else {
            result.reason = page.response.status.map { "Website returned HTTP \($0); publication could not be checked" } ?? "Website request failed or timed out"
            if let error = page.response.error { result.reason += ": " + String(error.prefix(250)) }
            return result
        }
        guard let final = page.response.finalURL, WebsiteConfirmationPolicy.permits(final, from: url) else {
            result.reason = "Page redirected outside the source website or downgraded HTTPS; not confirmed"; return result
        }
        guard !WebsiteConfirmationPolicy.reflects(address, in: final) else {
            result.reason = "Address is part of the redirected query; an echoed query is not independent publication evidence"; return result
        }
        result.organizationDomain = WebsiteConfirmationPolicy.organization(final.host ?? "", email: address)
        guard let data = page.response.data, data.count <= Self.maximumBytes,
              let text = page.response.decodedText else { result.reason = "Page was too large or could not be decoded"; return result }
        let mime = page.response.mimeType?.lowercased() ?? ""
        guard ["text/html", "application/xhtml+xml", "text/plain"].contains(mime) else {
            result.reason = "Unsupported page content type; HTML or plain text is required"; return result
        }
        let lower = text.lowercased()
        if lower.contains("cf-chl-") || lower.contains("<title>just a moment") || lower.contains("<title>access denied") || lower.contains("<title>verify you are human") {
            result.reason = "Website returned an access challenge; publication could not be checked"; return result
        }
        if let found = WebsitePublicationMatcher.find(address, in: text, html: mime != "text/plain") {
            result.outcome = .published; result.match = found.0; result.excerpt = found.1
            result.reason = "Exact address found in " + found.0.rawValue.lowercased() + " on " + (result.organizationDomain == true ? "the email domain's website" : "the recorded source website") + ". Publication does not prove mailbox delivery."
            if final.scheme?.lowercased() == "http" { result.reason += " Source uses unencrypted HTTP." }
        } else {
            result.outcome = .notFound
            result.reason = "Exact address not found in the retrieved page text or email links. This does not mean the mailbox is invalid; the page may have changed, hide contacts, or require JavaScript."
        }
        return result
    }
}

enum WebsitePublicationMatcher {
    private static let hidden = try! NSRegularExpression(pattern: #"<!--.*?(?:-->|$)|<(script|style|head|template|noscript)\b[^>]*>.*?(?:</\1\s*>|$)"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
    private static let anchors = try! NSRegularExpression(pattern: #"<a\b(?:[^>"']|"[^"]*"|'[^']*')*>"#, options: [.caseInsensitive])
    private static let href = try! NSRegularExpression(pattern: #"\s+([A-Z_:][A-Z0-9_:.-]*)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))"#, options: [.caseInsensitive])
    private static let tags = try! NSRegularExpression(pattern: #"<(?:[^>"']|"[^"]*"|'[^']*')*>"#)
    private static let blocks = try! NSRegularExpression(pattern: #"</?(?:p|div|br|li|ul|ol|section|article|header|footer|table|tr|td|th|h[1-6]|hr)\b(?:[^>"']|"[^"]*"|'[^']*')*>"#, options: [.caseInsensitive])
    private static let emails = try! NSRegularExpression(pattern: #"(?<![\p{L}\p{N}.!#$%&'*+/=?^_`{|}~-])[A-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9-]+(?:\.[A-Z0-9-]+)+(?![\p{L}\p{N}_-]|\.[\p{L}\p{N}_-])"#, options: [.caseInsensitive])
    private static let whitespace = try! NSRegularExpression(pattern: #"\s+"#)
    private static func replace(_ regex: NSRegularExpression, _ value: String, _ with: String) -> String {
        regex.stringByReplacingMatches(in: value, range: NSRange(value.startIndex..., in: value), withTemplate: with)
    }
    static func find(_ address: String, in input: String, html: Bool = true) -> (WebsiteConfirmation.Match, String)? {
        guard input.utf8.count <= WebsiteConfirmer.maximumBytes, EmailPolicy.validSyntax(address) else { return nil }
        let expected = address.lowercased()
        var body = input
        if html {
            body = replace(hidden, body, " ")
            for anchor in anchors.matches(in: body, range: NSRange(body.startIndex..., in: body)) {
                guard let range = Range(anchor.range, in: body) else { continue }
                let tag = String(body[range])
                for attribute in href.matches(in: tag, range: NSRange(tag.startIndex..., in: tag)) {
                    guard let name = Range(attribute.range(at: 1), in: tag), tag[name].lowercased() == "href" else { continue }
                    for group in 2...4 where attribute.range(at: group).location != NSNotFound {
                        guard let r = Range(attribute.range(at: group), in: tag) else { continue }
                        let link = EmailPolicy.decodeHTML(String(tag[r])).trimmingCharacters(in: .whitespacesAndNewlines)
                        guard link.lowercased().hasPrefix("mailto:") else { continue }
                        // Header subject/body values are not recipient publication.
                        let to = String(link.dropFirst(7).prefix { $0 != "?" && $0 != "#" })
                        guard let decoded = to.removingPercentEncoding else { continue }
                        for recipient in decoded.components(separatedBy: CharacterSet(charactersIn: ",;")) {
                            if recipient.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() == expected { return (.mailto, "mailto:" + address) }
                        }
                    }
                }
            }
            body = replace(blocks, body, "\n")
            body = replace(tags, body, "")
            body = EmailPolicy.decodeHTML(body)
        }
        for match in emails.matches(in: body, range: NSRange(body.startIndex..., in: body)) {
            guard let range = Range(match.range, in: body), body[range].lowercased() == expected else { continue }
            let start = body.index(range.lowerBound, offsetBy: -80, limitedBy: body.startIndex) ?? body.startIndex
            let end = body.index(range.upperBound, offsetBy: 80, limitedBy: body.endIndex) ?? body.endIndex
            return (.pageText, String(replace(whitespace, String(body[start..<end]), " ").prefix(240)))
        }
        return nil
    }
}
