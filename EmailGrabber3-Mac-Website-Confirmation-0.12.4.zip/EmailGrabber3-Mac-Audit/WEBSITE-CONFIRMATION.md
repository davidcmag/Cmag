# Fresh website confirmation — 0.12.4 source candidate

## Use

Quit the earlier app and retain a saved-data backup before trying this candidate.
In the app, select Dan's row (or other desired rows), then click **Confirm
selected on website**. Right-click → **Confirm on website** checks one row.
The left sidebar's **Confirm next 100 on website** processes unchecked records;
select rows to explicitly recheck already-checked addresses. **Stop verification**
cancels website and SMTP work. Another active crawl/discovery/verification must
finish or stop before starting a new check. No EHLO, sender address, API key or
provider credits are needed for website-only checks.

SMTP verification now also revisits the saved source URLs for the selected
addresses. Its confirmation explains both operations. A Website column displays
the separate publication result. Hover for the reason, date and URL; right-click
→ Show verification evidence to inspect/copy the URL, timestamp, match method,
excerpt and earlier checks. CSV retains its original first five columns and
appends website evidence and history. Each completed check autosaves.

## Meaning

- **Published by organization**: exact address in static page text or a mailto
  recipient link; final website host equals the email domain or a subdomain.
- **Published on source**: exact match on the recorded third-party source page.
- **Not found on page**: the retrieved successful HTML/plain-text page did not
  contain an exact match. This never marks the address invalid. The page may
  have changed, require JavaScript, or hide contacts.
- **Page unavailable**: blocked/rate-limited response, timeout, unsupported or
  oversized content, challenge page, unsafe redirect, or inconclusive fetch.
- **No website source**: Source is pasted/imported text or an unsupported URL.
- **Cancelled**: the request did not complete as a confirmation.

A recent website listing corroborates publication, not mailbox existence or
future delivery. Catch-all SMTP results remain Catch-all/Uncertain. Publication
never overwrites SMTP/provider findings, overall acceptance, exclusions or
recoverable removals. Up to three earlier website checks are retained as history.
A failed recheck shows its actual current outcome rather than presenting an old
positive finding as fresh. Old projects without the new optional fields decode.

## Request and matching behavior

Every user-initiated batch creates a new checker and requests saved Source URLs
with local/remote cache-bypass policy, no-cache/no-store headers, and cookie
handling disabled. It makes no search-provider or verification-provider calls.
Only HTTP/HTTPS domain hosts on standard web ports are accepted. Literal/private
hosts, credentials and local names are rejected by the existing URL policies.
Redirects are restricted to the source host/www equivalent; HTTPS cannot be
silently downgraded. The existing native HTTP transport bounds redirects, bytes,
timeout and cancellation. Up to 100 page requests are allowed per batch, each
capped at 1 MB and twelve seconds. The eight-page in-batch cache avoids repeating
requests when several addresses share one page, retaining the actual fetch time.
It is not reused by a later check.

Matching is case-insensitive but exact; a similar name, longer mailbox or longer
domain is insufficient. The checker decodes HTML entities and percent-encoded
mailto recipient addresses, and supports inline text markup. Mailto subject,
body and cc fields do not count as recipient links. Scripts, styles, comments,
head metadata and template/noscript content are ignored. Attribute contents are
not mistaken for page text, and fake data-href attributes are not mailto links.
A target address reflected in the source/final URL query is not independent
publication evidence. No guessed addresses or [at]/[dot] reconstruction are used.

This is static source inspection, not a browser renderer. It does not execute
JavaScript, expand protected widgets, solve CAPTCHAs, interpret all CSS visibility,
or prove a page's author/end-user identity. A listing may itself be stale or
incorrect. HTTP (rather than HTTPS) sources are explicitly noted as unencrypted.
The HTTP client's existing DNS-rebinding limits documented in README/AUDIT remain;
do not deploy this desktop core as an internet-facing verification service.

## Validation

221 portable XCTest tests pass: all 186 prior regressions plus 35 website tests.
Coverage includes exact/entity/encoded matches, negative substring cases,
misleading attributes, failed/blocked/oversized pages, content types, cancellation,
cache bypass and fresh subsequent checks, request budgets, recipient eligibility,
source/domain labeling, evidence history/merging, old records and CSV preservation.
HTTP integration tests exercise the native streaming transport with URLProtocol
fixtures. No real public mailbox or paid API was contacted.

Xcode project app/core/test membership and source references are validated; source
and shell syntax checks pass. macOS compilation, the Website UI and real CPR
website behavior have NOT been validated in this Linux environment. CPR access
is blocked by this environment's network policy. The Mac app uses the user's
normal website connection. Actual Mac verification remains necessary:

```sh
bash verify-mac.sh
```

The established one-command download/build/launch workflow can use build-mac.sh
and then open dist/EmailGrabber3.app. Keep backups and the previous candidate.
The earlier Mac TLS status and Darwin.bind compiler fixes are retained.
