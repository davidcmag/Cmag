import XCTest
import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
@testable import EmailGrabberCore

private final class WebsiteFixtureProtocol: URLProtocol, @unchecked Sendable {
    override class func canInit(with request: URLRequest) -> Bool { request.url?.host == "fixture.public.org" }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        let path = request.url!.path
        if path == "/hang" { return }
        let status = path == "/blocked" ? 403 : path == "/missing" ? 404 : 200
        let mime = path == "/plain" ? "text/plain" : path == "/binary" ? "application/octet-stream" : "text/html; charset=utf-8"
        let response = HTTPURLResponse(url: request.url!, statusCode: status, httpVersion: "HTTP/1.1", headerFields: ["Content-Type": mime])!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        let text: String
        switch path {
        case "/no-address": text = "<p>This staff page has no published email.</p>"
        case "/large": text = String(repeating: "A", count: WebsiteConfirmer.maximumBytes + 1)
        default: text = "<p>Contact <a href='mailto:dan.boyce@public.org'>Email Dan</a></p>"
        }
        client?.urlProtocol(self, didLoad: Data(text.utf8))
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}

final class WebsiteConfirmationTests: XCTestCase {
    let email = "dan.boyce@cpr.org"
    let source = "https://www.cpr.org/people/dan-boyce/"
    func match(_ html: String, address: String = "dan.boyce@cpr.org") -> (WebsiteConfirmation.Match, String)? {
        WebsitePublicationMatcher.find(address, in: html)
    }
    func page(_ text: String, url: String? = nil, status: Int = 200, mime: String = "text/html") -> HTTPResult {
        HTTPResult(data: Data(text.utf8), status: status, finalURL: URL(string: url ?? source), mimeType: mime)
    }
    func testExactAddressInPageText() {
        XCTAssertEqual(match("<p>Contact Dan at dan.boyce@cpr.org.</p>")?.0, .pageText)
        XCTAssertTrue(match("<p>Email dan.boyce@cpr.org today</p>")!.1.contains(email))
    }
    func testMailtoWithHiddenAddressBehindLabel() {
        XCTAssertEqual(match("<a href='mailto:dan.boyce@cpr.org'>Email Dan</a>")?.0, .mailto)
    }
    func testCaseInsensitivityAndHTMLEntities() {
        XCTAssertNotNil(match("<p>DAN.BOYCE&#64;CPR&#x2e;ORG</p>"))
        XCTAssertNotNil(match("dan.boyce&commat;cpr&period;org"))
        XCTAssertEqual(match("<A HREF=\"MAILTO:DAN.BOYCE@CPR.ORG\">Email</A>")?.0, .mailto)
    }
    func testPercentEncodedMailtoAndPlusAddress() {
        XCTAssertEqual(match("<a href='mailto:dan.boyce%40cpr.org?subject=Hi'>Email</a>")?.0, .mailto)
        XCTAssertEqual(match("<a href='mailto:dan%2Bnews%40cpr.org'>Email</a>", address: "dan+news@cpr.org")?.0, .mailto)
    }
    func testMailtoMultipleRecipientsAndUnquotedAttribute() {
        XCTAssertEqual(match("<a href=mailto:other@cpr.org,dan.boyce@cpr.org>Email</a>")?.0, .mailto)
    }
    func testMailtoSubjectBodyAndCcDoNotCountAsRecipientLink() {
        XCTAssertNil(match("<a href='mailto:other@cpr.org?subject=dan.boyce@cpr.org&amp;body=dan.boyce@cpr.org&amp;cc=dan.boyce@cpr.org'>Email</a>"))
    }
    func testDifferentMailboxAndLongerDomainAreNotExactMatches() {
        for text in ["other.dan.boyce@cpr.org", "dan.boyce@cpr.org.evil.com", "dan.boyce+news@cpr.org", "é dan.boyce@cpr.org.evil", "édan.boyce@cpr.org", "dan.boyce@cpr.orgé"] { XCTAssertNil(match(text), text) }
    }
    func testHiddenScriptCommentsStylesAndTemplateAreNotPublication() {
        for text in ["<!-- dan.boyce@cpr.org -->", "<script>var x='dan.boyce@cpr.org';</script>", "<style>/* dan.boyce@cpr.org */</style>", "<template><a href='mailto:dan.boyce@cpr.org'>Email</a></template>", "<head><meta content='dan.boyce@cpr.org'></head>"] { XCTAssertNil(match(text), text) }
    }
    func testUnclosedScriptDoesNotExposeAddress() { XCTAssertNil(match("<script>let email = 'dan.boyce@cpr.org'")) }
    func testDataHrefAndQuotedFakeHrefAreNotEmailLinks() {
        XCTAssertNil(match("<a data-href='mailto:dan.boyce@cpr.org'>Email</a>"))
        XCTAssertNil(match("<a title=\"href='mailto:dan.boyce@cpr.org'\" href='/contact'>Email</a>"))
    }
    func testRealHrefAfterOtherQuotedAttributes() {
        XCTAssertEqual(match("<a title=\"click > here\" class='mail' href='mailto:dan.boyce@cpr.org'>Email</a>")?.0, .mailto)
    }
    func testInlineMarkupCanJoinButSeparateBlocksCannotInventAddress() {
        XCTAssertNotNil(match("<p>dan.<strong>boyce</strong>@cpr.org</p>"))
        XCTAssertNil(match("<div>dan.boyce</div><div>@cpr.org</div>"))
    }
    func testObfuscationIsNotGuessed() { XCTAssertNil(match("dan.boyce [at] cpr [dot] org")) }
    func testPlainTextDoesNotInterpretHTML() {
        XCTAssertNil(WebsitePublicationMatcher.find(email, in: "dan.<b>boyce</b>@cpr.org", html: false))
        XCTAssertNotNil(WebsitePublicationMatcher.find(email, in: "dan.boyce@cpr.org", html: false))
    }
    func testSourceURLAndRedirectSafety() {
        for value in ["Pasted text", "file:///etc/passwd", "ftp://cpr.org/", "https://u:p@cpr.org/", "http://127.0.0.1/", "http://localhost/", "http://a.local/", "https://cpr.org:8080/"] { XCTAssertNil(WebsiteConfirmationPolicy.sourceURL(value), value) }
        let start = URL(string: source)!
        XCTAssertTrue(WebsiteConfirmationPolicy.permits(URL(string: "https://cpr.org/people/")!, from: start))
        for value in ["https://evil.org/", "https://cpr.org.evil.org/", "http://www.cpr.org/", "http://127.0.0.1/"] { XCTAssertFalse(WebsiteConfirmationPolicy.permits(URL(string: value)!, from: start), value) }
    }
    func testOrganizationDomainRequiresExactDomainOrSubdomain() {
        XCTAssertTrue(WebsiteConfirmationPolicy.organization("www.cpr.org", email: email))
        XCTAssertTrue(WebsiteConfirmationPolicy.organization("staff.cpr.org", email: email))
        XCTAssertFalse(WebsiteConfirmationPolicy.organization("notcpr.org", email: email))
        XCTAssertFalse(WebsiteConfirmationPolicy.organization("cpr.org.directory.com", email: email))
    }
    func testFreshRequestBypassesCachesAndCookiesAndSavesEvidence() {
        let date = Date(timeIntervalSince1970: 1000)
        let checker = WebsiteConfirmer(fetch: { request,cancelled,redirect in
            XCTAssertEqual(request.cachePolicy, .reloadIgnoringLocalAndRemoteCacheData)
            XCTAssertFalse(request.httpShouldHandleCookies)
            XCTAssertEqual(request.value(forHTTPHeaderField: "Cache-Control"), "no-cache, no-store")
            XCTAssertFalse(cancelled())
            XCTAssertFalse(redirect(URL(string: "https://evil.org/")!))
            return self.page("<a href='mailto:dan.boyce@cpr.org'>Email Dan</a>")
        }, now: { date })
        let result = checker.confirm(address: email, source: source)
        XCTAssertEqual(result.outcome, .published); XCTAssertEqual(result.label, "Published by organization")
        XCTAssertEqual(result.checkedAt, date); XCTAssertEqual(result.match, .mailto)
        XCTAssertEqual(result.sourceURL, source); XCTAssertEqual(result.finalURL, source)
        XCTAssertEqual(result.httpStatus, 200); XCTAssertEqual(result.excerpt, "mailto:" + email)
    }
    func testThirdPartyPublicationIsNotLabeledOrganization() {
        let url = "https://directory.org/contact"
        let checker = WebsiteConfirmer(fetch: { _,_,_ in self.page(self.email, url: url) })
        let result = checker.confirm(address: email, source: url)
        XCTAssertEqual(result.outcome, .published); XCTAssertEqual(result.label, "Published on source")
        XCTAssertEqual(result.organizationDomain, false)
    }
    func testSamePageFetchedOnceInBatchButFreshOnNextRun() {
        var requests = 0; var date = Date(timeIntervalSince1970: 1000)
        let fetch: WebsiteConfirmer.Fetch = { _,_,_ in requests += 1; return self.page("dan.boyce@cpr.org other@cpr.org") }
        let first = WebsiteConfirmer(fetch: fetch, now: { date })
        let a = first.confirm(address: email, source: source)
        date = date.addingTimeInterval(10)
        let b = first.confirm(address: "other@cpr.org", source: source + "#contact")
        XCTAssertEqual(requests, 1); XCTAssertEqual(a.checkedAt, b.checkedAt)
        let second = WebsiteConfirmer(fetch: fetch, now: { date })
        XCTAssertGreaterThan(second.confirm(address: email, source: source).checkedAt, a.checkedAt)
        XCTAssertEqual(requests, 2)
    }
    func testNoSourceAndInvalidAddressDoNotFetch() {
        let checker = WebsiteConfirmer(fetch: { _,_,_ in XCTFail("Unexpected fetch"); return HTTPResult() })
        XCTAssertEqual(checker.confirm(address: email, source: "Pasted text").outcome, .noSource)
        XCTAssertEqual(checker.confirm(address: "invalid", source: source).outcome, .unavailable)
        XCTAssertEqual(checker.confirm(address: email, source: source, cancelled: { true }).outcome, .cancelled)
    }
    func testFailedOrBlockedPageNeverMeansAddressInvalidOrPublished() {
        for status in [401,403,404,429,500,503] {
            let checker = WebsiteConfirmer(fetch: { _,_,_ in self.page(self.email, status: status) })
            let result = checker.confirm(address: email, source: source)
            XCTAssertEqual(result.outcome, .unavailable); XCTAssertEqual(result.httpStatus, status)
        }
    }
    func testMissingAddressIsNotAnInvalidMailboxFinding() {
        let checker = WebsiteConfirmer(fetch: { _,_,_ in self.page("<p>Other contact</p>") })
        let result = checker.confirm(address: email, source: source)
        XCTAssertEqual(result.outcome, .notFound); XCTAssertTrue(result.reason.contains("does not mean the mailbox is invalid"))
    }
    func testFailedTransportAndPartialBodyCannotPublish() {
        let checker = WebsiteConfirmer(fetch: { _,_,_ in HTTPResult(data: Data(self.email.utf8), status: 200, finalURL: URL(string: self.source), error: "Response exceeds download limit", mimeType: "text/html") })
        XCTAssertEqual(checker.confirm(address: email, source: source).outcome, .unavailable)
    }
    func testWrongContentTypeChallengeAndUnsafeFinalURLAreUnavailable() {
        for r in [page(email, mime: "application/json"), page("<title>Just a moment</title>" + email), page(email, url: "https://evil.org/")] {
            let checker = WebsiteConfirmer(fetch: { _,_,_ in r })
            XCTAssertEqual(checker.confirm(address: email, source: source).outcome, .unavailable)
        }
    }
    func testCancellationAfterRequestDiscardsEvenPositiveResponse() {
        var cancelled = false
        let checker = WebsiteConfirmer(fetch: { _,_,_ in cancelled = true; return self.page(self.email) })
        XCTAssertEqual(checker.confirm(address: email, source: source, cancelled: { cancelled }).outcome, .cancelled)
    }
    func testSelectedTargetsPreserveDistinctSourcesAndRespectExclusions() {
        var a = makeEmailFixture(email); a.source = source
        var duplicate = a; duplicate.id = UUID(); duplicate.address = email.uppercased()
        var otherSource = a; otherSource.id = UUID(); otherSource.source = "https://directory.org/contact"
        var excluded = makeEmailFixture("excluded@cpr.org"); excluded.status = "Excluded"
        let rows = [a,duplicate,otherSource,excluded]
        let targets = WebsiteConfirmationPolicy.targets(rows, rules: [], removed: [])
        XCTAssertEqual(targets.count, 2); XCTAssertEqual(targets[0].ids.count, 2)
        XCTAssertEqual(WebsiteConfirmationPolicy.targets(rows, selected: [duplicate.id], rules: [], removed: []).first?.ids, [duplicate.id])
        XCTAssertTrue(WebsiteConfirmationPolicy.targets(rows, rules: [], removed: [email]).isEmpty)
        XCTAssertTrue(WebsiteConfirmationPolicy.targets(rows, rules: [.init(kind: "Domain", pattern: "cpr.org")], removed: []).isEmpty)
    }
    func testPublicationNeverOverridesSMTPProviderOrExcludedStatus() throws {
        for status in ["Uncertain", "Rejected", "Excluded", "Accepted"] {
            var row = makeEmailFixture(email); row.status = status
            row.smtpVerification = .init(verdict: .catchAll, reason: "all accepted")
            row.providerVerification = .init(status: "Uncertain", reason: "provider unknown")
            let original = row
            WebsiteConfirmationPolicy.apply(.init(outcome: .published, reason: "exact match", sourceURL: source, organizationDomain: true), to: &row)
            XCTAssertEqual(row.status, original.status); XCTAssertEqual(row.reason, original.reason)
            XCTAssertEqual(row.smtpVerification, original.smtpVerification); XCTAssertEqual(row.providerVerification, original.providerVerification)
            XCTAssertEqual(try JSONDecoder().decode(FoundEmail.self, from: JSONEncoder().encode(row)), row)
        }
    }
    func testUnavailableRecheckDoesNotMasqueradeAsFreshPublication() {
        var row = makeEmailFixture(email)
        WebsiteConfirmationPolicy.apply(.init(outcome: .published, reason: "exact match", sourceURL: source, organizationDomain: true), to: &row)
        WebsiteConfirmationPolicy.apply(.init(outcome: .unavailable, reason: "HTTP 403", sourceURL: source), to: &row)
        XCTAssertEqual(row.websiteConfirmation?.outcome, .unavailable)
        XCTAssertEqual(row.websiteHistory?.last?.outcome, .published)
        XCTAssertTrue(VerificationEvidence.text(row).contains("historical, not fresh confirmation"))
    }
    func testMergeRetainsWebsiteEvidenceAlongsideNewerSMTPAndHistory() {
        var older = makeEmailFixture(email)
        WebsiteConfirmationPolicy.apply(.init(outcome: .published, reason: "old", checkedAt: Date(timeIntervalSince1970: 1), sourceURL: source), to: &older)
        var newer = older; newer.websiteConfirmation = nil
        newer.checkedAt = older.checkedAt.addingTimeInterval(1); newer.smtpVerification = .init(verdict: .catchAll, reason: "catch-all")
        let first = ResultMerge.combine([older], [newer])[0]
        XCTAssertEqual(first.websiteConfirmation, older.websiteConfirmation); XCTAssertEqual(first.smtpVerification, newer.smtpVerification)
        var checked = first
        WebsiteConfirmationPolicy.apply(.init(outcome: .notFound, reason: "changed page", checkedAt: Date(timeIntervalSince1970: 2), sourceURL: source), to: &checked)
        let merged = ResultMerge.combine([older], [checked])[0]
        XCTAssertEqual(merged.websiteConfirmation?.outcome, .notFound); XCTAssertEqual(merged.websiteHistory?.last?.outcome, .published)
    }
    func testOldRowsDecodeAndCSVRetainsOriginalFiveColumns() throws {
        var row = makeEmailFixture(email)
        XCTAssertNil(try JSONDecoder().decode(FoundEmail.self, from: JSONEncoder().encode(row)).websiteConfirmation)
        WebsiteConfirmationPolicy.apply(.init(outcome: .published, reason: "exact match", sourceURL: source, match: .mailto, excerpt: "mailto:" + email, organizationDomain: true), to: &row)
        XCTAssertTrue(VerificationCSV.header.hasPrefix("email,status,reason,source,checked_at,"))
        XCTAssertTrue(VerificationCSV.line(row).contains("Published by organization"))
        XCTAssertTrue(VerificationCSV.line(row).contains(source))
        XCTAssertTrue(VerificationEvidence.text(row).contains("Website checked:"))
    }
    func testNativeHTTPTransportContentTypeAndStreamingIntegration() {
        let checker = WebsiteConfirmer(fetch: { request,cancelled,redirect in
            HTTPTransport.perform(request, maxBytes: WebsiteConfirmer.maximumBytes, timeout: 1, shouldCancel: cancelled, protocolClasses: [WebsiteFixtureProtocol.self], redirect: redirect)
        })
        XCTAssertEqual(checker.confirm(address: "dan.boyce@public.org", source: "https://fixture.public.org/match").outcome, .published)
        XCTAssertEqual(checker.confirm(address: "dan.boyce@public.org", source: "https://fixture.public.org/blocked").outcome, .unavailable)
        XCTAssertEqual(checker.confirm(address: "dan.boyce@public.org", source: "https://fixture.public.org/no-address").outcome, .notFound)
        XCTAssertEqual(checker.confirm(address: "dan.boyce@public.org", source: "https://fixture.public.org/binary").outcome, .unavailable)
        XCTAssertEqual(checker.confirm(address: "dan.boyce@public.org", source: "https://fixture.public.org/large").outcome, .unavailable)
    }
    func testNativeHTTPTransportCanCancelAnUnresponsiveSource() {
        let control = CrawlControl()
        let checker = WebsiteConfirmer(fetch: { request,cancelled,redirect in
            DispatchQueue.global().asyncAfter(deadline: .now() + 0.05) { control.cancel() }
            return HTTPTransport.perform(request, timeout: 2, shouldCancel: cancelled, protocolClasses: [WebsiteFixtureProtocol.self], redirect: redirect)
        })
        let before = Date()
        let result = checker.confirm(address: email, source: "https://fixture.public.org/hang", cancelled: { control.wasCancelled })
        XCTAssertEqual(result.outcome, .cancelled); XCTAssertLessThan(Date().timeIntervalSince(before), 1)
    }
    func testQuotedGreaterThanDoesNotLeakAttributeAddressIntoPageText() {
        XCTAssertNil(match("<span title='>dan.boyce@cpr.org'>No contact</span>"))
        XCTAssertNil(match("<div data-value='>dan.boyce@cpr.org'>No contact</div>"))
    }
    func testAddressReflectedFromQueryIsNotIndependentPublication() {
        let checker = WebsiteConfirmer(fetch: { _,_,_ in XCTFail("Should not request a query containing the target address"); return self.page(self.email) })
        let result = checker.confirm(address: email, source: source + "?q=dan.boyce%40cpr.org")
        XCTAssertEqual(result.outcome, .unavailable); XCTAssertTrue(result.reason.contains("echoed query"))
        let redirect = WebsiteConfirmer(fetch: { _,_,_ in self.page(self.email, url: self.source + "?email=dan.boyce%40cpr.org") })
        XCTAssertEqual(redirect.confirm(address: email, source: source).outcome, .unavailable)
    }
    func testBatchRequestBudgetAndWebsiteHistoryAreBounded() {
        var count = 0
        let checker = WebsiteConfirmer(fetch: { request,_,_ in count += 1; return self.page(self.email, url: request.url!.absoluteString) })
        for i in 0..<100 { XCTAssertEqual(checker.confirm(address: email, source: source + "?page=" + String(i)).outcome, .published) }
        XCTAssertEqual(checker.confirm(address: email, source: source + "?page=100").outcome, .unavailable)
        XCTAssertEqual(count, 100)
        var row = makeEmailFixture(email)
        for i in 0..<10 { WebsiteConfirmationPolicy.apply(.init(outcome: .notFound, reason: String(i), sourceURL: source), to: &row) }
        XCTAssertEqual(row.websiteHistory?.count, 3)
    }

}
