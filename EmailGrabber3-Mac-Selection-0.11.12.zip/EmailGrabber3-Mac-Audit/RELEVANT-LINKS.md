Email Grabber 3 Mac 0.11.10 candidate

Enable Follow relevant links to other websites. Adaptive depth, unlimited total
pages and adaptive pages per website have no fixed traversal cap in this mode.
Contact/staff/team/directory links remain prioritized. External links are chosen
using the search topic, anchor text and directory context. Direct website input
has an optional topic field. Crawling ends when stopped or the eligible frontier
is exhausted; continuous discovery is not guaranteed.

Choose Simultaneous websites from 1 to 8 before a new crawl. Choosing 5 allows
up to five different sites to overlap, with only one worker assigned per site.
Workers fetch one page at a time; one coordinator owns all pending page URLs,
merges emails, deduplicates URLs, inserts relevant links and writes checkpoints.
The right-hand panel shows active page URLs and each waiting page URL, including
contact/deeper pages waiting while their website has an active worker.
A recent-pages display holds 100 entries; the actual frontier has no such cap.
Incomplete in-flight pages remain recoverable. Committed results are retained.

Native page requests lease their destination hosts through redirects. Aliases
cannot issue overlapping page requests to the same canonical host. A busy
redirect destination is deferred to the shared queue, without deadlocking
redirect chains. Host delays and robots policy remain active. Blocked sites
do not stop other sites. Existing saved jobs preserve their previous settings.

99 automated Swift core tests pass, including real thread overlap, per-site
exclusion, page budgets, the contact-page/two-links shared queue example,
pause/resume, stop/restart, redirect reservations, blocked/robots-denied sources,
URL cleanup and older saved formats. These are controlled fixtures, not a claim
of public-site performance. macOS build and live GUI verification remain open.

Run bash verify-mac.sh, then Run the app from Xcode. Keep the prior app/source
and the script's private data backup until the candidate is verified.


0.11.11 adds wildcard filtering/rules/blocked entries, default collection order
with optional alphabetical sorting, explicit live row checkboxes, selectable
email text and copy actions. See README.md and MAC-ACCEPTANCE.md. The current
suite contains 109 passing core tests; native GUI validation remains open.


0.11.12 adds additive plain-row selection, independent explicit checkboxes and
a narrow fix for 32-character hex Sentry keys at bare sentry.io. Existing
technical records become Rejected while preserving evidence. Included view
and accepted CSV enforce the same technical policy. 117 core tests pass;
native Mac GUI validation remains required.
