# Email Grabber 3 — audited Mac source candidate 0.11.12

Audited from the supplied `EmailGrabber3-v0.11.6-filter-scope.zip`. The uploaded original is unchanged. This is repaired source, not a compiled, notarized or fully Mac-validated release. Read AUDIT.md for findings and verification limits.

## With your existing Xcode

1. Quit the previous Email Grabber app; keep its app bundle and source as a fallback.
2. In Terminal, enter this extracted folder and run `bash verify-mac.sh`. It first makes a private backup of existing EmailGrabber3 application data, then asks Xcode to build the application and run the tests. No VPS commands, Python dependencies, API keys or paid services are needed.
3. If that succeeds, open `EmailGrabber3.xcodeproj`, choose the EmailGrabber3 scheme and My Mac, and press Command-R. Complete MAC-ACCEPTANCE.md before treating the candidate as your replacement.

The script stores the complete Xcode log and result bundle under `validation/`. It does not install over your existing app. Xcode uses local ad-hoc signing; no Apple Developer team or notarization is claimed. An alternative local application build remains available with `bash build-mac.sh`.

## What changed

0.11.12 makes plain row clicks additive: click another row to add it, and click
a selected row to deselect it. Checkboxes use the same explicit selection set.
The native table no longer owns that set, so a native single-row selection or
refresh cannot replace earlier explicit selections. Selected cells are tinted.
Select visible, Copy selected, filtering and sorting remain available.
Changing the filter/status intentionally clears selection as before.

The exact reported 32-hex-character key at sentry.io is now rejected before
extraction acceptance or DNS checks. Regional Sentry ingest and Wix telemetry
hosts remain rejected. Ordinary mailboxes such as support@sentry.io and hex
mailboxes at unrelated domains remain eligible. On restoration/resume, existing
technical records are reclassified as Rejected without losing ID, source or
timestamp. Included view and accepted export reject them even if an old status
claimed Accepted or Verified. All/Rejected retain them for inspection.

117 portable core tests pass. The user's clarification narrowed the selection
repair to additive row/checkbox state; the existing SwiftUI grid is retained.
Actual Mac mouse/keyboard interaction still requires the acceptance checks.


0.11.11 defaults to Found order and offers Email A–Z / Email Z–A in the Order
control. Clicking sortable column headers remains available; choose Found order
to return to collection sequence. Incoming rows append rather than moving
existing rows alphabetically by default. Email text is selectable, row
checkboxes and Copy selected stay available during crawling, and the email cell
context menu supports Copy email and recoverable Remove email.

Results search, blocked input entries and a new Wildcard reusable rule support
case-insensitive * (zero or more characters) and ? (one character). Wildcards
match a whole email or selected field; use *word* for contains behavior.
Examples: info@*, *@example.org, *support*, sales?@example.org. Plain search
text and existing literal exclusion entries retain their substring behavior.
Wildcard rules have the same preview, undo, Included view and export behavior
as other rules. They apply to existing and newly collected addresses.
The matcher executes no regex and bounds patterns to 512 characters and field
values to 16,384 characters. Tests include an independent matching reference.

109 portable core tests pass. Native selection, copying and sort controls still
require the macOS build and GUI checks below.


0.11.10 adds a Simultaneous websites setting (1–8) and a right-hand activity panel.
Select 5 before starting a new crawl to permit up to five different sites at once.
New installations default to 5; existing projects and checkpoints retain their
saved setting, or 1 for older formats. The setting cannot change mid-crawl.
One coordinator owns the shared page frontier, deduplication, results and
checkpoints. Workers fetch individual pages, not private site queues. Relevant
links return to the shared queue. The panel lists active page URLs and every
pending page URL, including pages waiting for a busy site. It restores the
saved queue after restart. Recent history is a bounded display, not a crawl cap.
Each site receives at most one worker. Host leases protect native page requests
through redirects; a busy redirect target returns to the shared frontier.
Per-site delays, robots checks, optional page budgets and stop/resume remain
active. Search-provider discovery itself remains sequential.


Adaptive mode now starts from homepages and follows promising contact/staff/sales/profile links. Multiple explicitly supplied URLs on the same host are retained. Removed emails stay recoverable without becoming exclusion rules. All/Included/Excluded/Removed views and scoped search are consistent. Live updates send new rows in batches instead of repeatedly copying the entire result array.

Projects autosave privately; checkpoints preserve rules/removals and are written around every scanned page. Resuming merges newer saved validation results and retains unfinished requests. Native URLSession networking, cookies and shared connection reuse are retained; streamed response limits, cancellation and responsible provider-rate-limit handling are added.

CSV/TSV imports handle CRLF, quotes, multiline fields and BOMs. XLSX rich-text runs remain joined; resource limits and external-entity rejection protect workbook imports. CSV exports neutralize spreadsheet formulas. Syntax checks, null-MX handling, DNS fallback, telemetry rejection and optional ZeroBounce response handling are corrected.

## Existing scope and limits

This remains a native macOS 13+ app. It supports CSV export and text/CSV/TSV/XLSX import; XLSX export is not implemented. It supports ASCII email syntax, not full internationalized mailbox syntax. Disposable-domain detection is a starter list. Local syntax/MX/fallback checks never verify an individual mailbox. ZeroBounce is optional, requires explicit confirmation, and can consume credits. No audit tests contact it.

Discovery retains the existing free Bing RSS, DuckDuckGo and optional single-state OSM strategy. It processes the first five keyword lines, up to 3,000 candidate hosts, and bounded independent-source/directory queries. The original US geographic expansion is retained. Search providers may throttle or change their interfaces. No exhaustive coverage or comparative live-search performance is promised.

Zero page caps mean no numeric total/per-site cap, not unlimited memory or downloads. With relevant external-link following enabled, adaptive traversal has no fixed depth or per-page link-count cap. Legacy closed-site mode retains its 20-level/200-link limits. Text/CSV inputs are limited to 64 MB; workbook extracted text to 32 MB, each extracted entry to 8 MB, and workbooks to 100 worksheets. Crawler responses are capped while streaming. A crash can replay an unfinished page. JSON checkpoint costs on very large collections remain a scaling limitation.

The app is a local trusted-user application. It is not a hardened public service: private literal destinations and credentials in URLs are rejected, but full DNS-rebinding-resistant connection pinning is not implemented. Do not deploy this Mac core as an internet-facing server.
