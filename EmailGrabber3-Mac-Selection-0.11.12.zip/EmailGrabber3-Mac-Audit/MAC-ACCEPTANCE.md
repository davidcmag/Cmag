# Remaining macOS acceptance

The cloud environment cannot run AppKit/SwiftUI or the Mac Keychain. Passing portable Swift tests does not replace these checks.

Run `bash verify-mac.sh` once from this folder. It backs up the existing local application-data directory, builds the native app, and runs the same XCTest suite against the Mac SDK. Keep the original app/source and the printed backup directory. Quit the original app before launching the new build.

After a successful build, open the Xcode project and press Command-R:

For 0.11.12, while extraction runs, click three distinct rows without Command.
The selected count should increase to three. Click one again: only it should
deselect. Mix checkbox clicks with row clicks; earlier choices must remain
selected. New arrivals and switching order must not clear the set. Copy selected
and remove/restore the selected records. Confirm text selection/copy still works.
Open the saved results that contain the reported hex-key@sentry.io record:
it must disappear from Included and accepted CSV, and remain Rejected in All /
Rejected with its source evidence. support@sentry.io must remain eligible.


For 0.11.11, verify the Order control starts at Found order. During a crawl,
select rows with the checkboxes, copy selected addresses, and select/copy an
individual email's text. Selection must remain usable while results append.
Switch to Email A–Z, then Found order; confirm the latter restores collection
sequence. Try *@example.org and *support* in the Email filter, and a Wildcard
reusable rule. Confirm preview counts, Included view and Included CSV agree;
undo the rule and confirm originals restore. These GUI checks are not replaced
by the portable core tests.


For 0.11.10, first set Simultaneous websites to 5 and start a fresh crawl with
at least six accessible sites. Confirm the panel shows up to five active page
URLs, without two workers on one site. Pending contact/deeper page URLs should
appear in the shared queue before assignment, including while another page of
their site is active. With only one eligible site, one worker is expected.
Pause/resume, then stop and relaunch; verify the visible saved page queue and
results restore. Older jobs retain concurrency 1 until you start a new crawl
with a different setting.


1. Crawl the same accessible URLs used by your existing Mac copy with the same limits. Include a homepage whose contact link uses a fragment, plus several pages on one host. Confirm adaptive crawling reaches contact/sales/staff pages and records retain actual source URLs.
2. Select an email, choose Remove selected, and confirm no reusable rule is added. Restore last removal. Check Included, All, Excluded and Removed views, scoped search and column sorting. Excluded/removed records must stay out of accepted CSV exports.
3. Pause an unfinished crawl, stop it, quit normally and relaunch. Resume saved crawl; confirm original results, rules, removals and progress remain. A completed checkpoint must also restore its results without requiring remaining links.
4. Reimport a CSV exported by the original app and the included rich-text XLSX fixture. Export CSV and inspect the dataset against the grid.
5. Run the same keyword phrases/location on the old and new app separately. Record actual relevant sites, pages, genuine addresses, false positives and elapsed time. Provider restrictions must be reported; do not bypass website security. No result-count target substitutes for this comparison.

Keep ZeroBounce off for acceptance unless you intentionally authorize a paid batch. Keychain save/update/unlock behavior requires a separate Mac check if that optional integration is used. Do not send an API key or passwords in chat.

If a build or required check fails, retain the original app. Share the compiler/check output rather than repeatedly testing an incomplete release. Do not call this candidate finished until these checks pass.
