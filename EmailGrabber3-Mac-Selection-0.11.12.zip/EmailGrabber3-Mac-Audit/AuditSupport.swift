import Foundation
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

/// Pure policies shared by the application and its regression tests.
enum EmailPolicy {
    static func validSyntax(_ address: String) -> Bool {
        let fields = address.split(separator: "@", omittingEmptySubsequences: false)
        guard fields.count == 2, address.utf8.count <= 254 else { return false }
        let local = String(fields[0]), domain = String(fields[1])
        guard !local.isEmpty, local.utf8.count <= 64, !local.hasPrefix("."), !local.hasSuffix("."), !address.contains("..") else { return false }
        let labels = domain.split(separator: ".", omittingEmptySubsequences: false)
        guard labels.count >= 2, labels.allSatisfy({ !$0.isEmpty && $0.utf8.count <= 63 && !$0.hasPrefix("-") && !$0.hasSuffix("-") }) else { return false }
        return address.range(of: #"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,63}$"#, options: .regularExpression) != nil
    }
    static func csvField(_ value: String) -> String {
        let safe = value.first.map { "=+-@\t\r\n".contains($0) } == true ? "'" + value : value
        return "\"" + safe.replacingOccurrences(of: "\"", with: "\"\"") + "\""
    }
    static func canonicalHost(_ host: String) -> String {
        let h = host.lowercased(); return h.hasPrefix("www.") ? String(h.dropFirst(4)) : h
    }
    static func httpURL(_ url: URL) -> Bool {
        guard ["https", "http"].contains(url.scheme?.lowercased() ?? ""), let host = url.host, !host.isEmpty, url.user == nil, url.password == nil else { return false }
        let name = host.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: "[]."))
        if name == "localhost" || name.hasSuffix(".localhost") || name.hasSuffix(".local") || name.hasSuffix(".home.arpa") || name.hasSuffix(".internal") { return false }
        var v4 = in_addr(); var v6 = in6_addr()
        if inet_pton(AF_INET, name, &v4) == 1 {
            let bytes = withUnsafeBytes(of: &v4) { Array($0) }
            let a = Int(bytes[0]), b = Int(bytes[1])
            if a == 0 || a == 10 || a == 127 || a >= 224 || (a == 169 && b == 254) || (a == 172 && (16...31).contains(b)) || (a == 192 && b == 168) || (a == 100 && (64...127).contains(b)) { return false }
        } else if inet_pton(AF_INET6, name, &v6) == 1 {
            let bytes = withUnsafeBytes(of: &v6) { Array($0) }
            guard (0x20...0x3f).contains(bytes[0]), !(bytes[0] == 0x20 && bytes[1] == 0x02) else { return false }
            if bytes[0] == 0x20 && bytes[1] == 0x01 && ((bytes[2] == 0x0d && bytes[3] == 0xb8) || bytes[2] < 2) { return false }
        } else if !name.contains(".") || name.range(of: #"^(?:0x[0-9a-f]+|[0-9]+)(?:\.(?:0x[0-9a-f]+|[0-9]+)){0,3}$"#, options: .regularExpression) != nil { return false }
        return true
    }
    static func searchURL(_ query: String) -> URL? {
        var c = URLComponents(string: "https://www.bing.com/search")!
        c.queryItems = [URLQueryItem(name: "format", value: "rss"), URLQueryItem(name: "q", value: query)]
        c.percentEncodedQuery = c.percentEncodedQuery?.replacingOccurrences(of: "+", with: "%2B")
        return c.url
    }
    static func decodeHTML(_ text: String) -> String {
        var out = text
        let entities = ["&lt;":"<", "&gt;":">", "&quot;":"\"", "&apos;":"'", "&nbsp;":" ", "&commat;":"@", "&period;":"."]
        for (key,value) in entities { out = out.replacingOccurrences(of: key, with: value, options: .caseInsensitive) }
        if let regex = try? NSRegularExpression(pattern: #"&#(x[0-9a-f]+|[0-9]+);"#, options: .caseInsensitive) {
            let matches = regex.matches(in: out, range: NSRange(out.startIndex..., in: out))
            for m in matches.reversed() {
                guard let r = Range(m.range(at: 1), in: out), let full = Range(m.range, in: out) else { continue }
                let token = String(out[r]); let hex = token.lowercased().hasPrefix("x")
                if let code = UInt32(hex ? String(token.dropFirst()) : token, radix: hex ? 16 : 10), let scalar = UnicodeScalar(code) { out.replaceSubrange(full, with: String(scalar)) }
            }
        }
        return out.replacingOccurrences(of: "&amp;", with: "&", options: .caseInsensitive)
    }
}

enum DNSAssessment: Equatable {
    case mx, fallback, noMail, unknown
    var reason: String {
        switch self {
        case .mx: return "Syntax and MX passed; individual mailbox unverified"
        case .fallback: return "No MX; address-record fallback available; individual mailbox unverified"
        case .noMail: return "No usable mail-server configuration; individual mailbox unverified"
        case .unknown: return "DNS lookup failed or was inconclusive; individual mailbox unverified"
        }
    }
    static func parseMX(_ text: String) -> DNSAssessment? {
        let answers = text.split(whereSeparator: \.isNewline).map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty && !$0.hasPrefix(";") }
        guard !answers.isEmpty else { return nil }
        var hasNull = false; var hasMail = false
        for line in answers {
            let parts = line.split(whereSeparator: \.isWhitespace)
            guard parts.count == 2, UInt16(parts[0]) != nil else { return .unknown }
            if parts[1] == "." { guard parts[0] == "0" else { return .unknown }; hasNull = true }
            else if parts[1].contains(".") { hasMail = true }
            else { return .unknown }
        }
        if hasNull && hasMail { return .unknown }
        return hasNull ? .noMail : hasMail ? .mx : .unknown
    }
}

enum ProviderClassification {
    static func result(status: String, substatus: String) -> (String, String) {
        let value = status.lowercased()
        let final: String
        switch value {
        case "valid":
            let caution = substatus.lowercased().replacingOccurrences(of: "-", with: "_")
            final = caution.contains("catch_all") || caution.contains("catchall") || caution.contains("unknown") ? "Uncertain" : "Verified"
        case "invalid", "spamtrap", "abuse", "do_not_mail": final = "Rejected"
        default: final = "Uncertain"
        }
        return (final, "ZeroBounce: \(value)\(substatus.isEmpty ? "" : " (\(substatus))")")
    }
}

struct RobotsPolicy {
    struct Rule { let allow: Bool; let pattern: String }
    var rules: [Rule] = []
    var delay: TimeInterval = 0.3
    static let denyAll = RobotsPolicy(rules: [Rule(allow: false, pattern: "/")])
    init(rules: [Rule] = [], delay: TimeInterval = 0.3) { self.rules = rules; self.delay = delay }
    init(_ text: String, agent: String = "EmailGrabber3") {
        struct Group { var agents: [String] = []; var rules: [Rule] = []; var delay: TimeInterval?; var started = false }
        var groups: [Group] = []; var group = Group()
        for line in text.components(separatedBy: .newlines) {
            let raw = line.components(separatedBy: "#")[0].trimmingCharacters(in: .whitespaces)
            let pieces = raw.split(separator: ":", maxSplits: 1, omittingEmptySubsequences: false)
            guard pieces.count == 2 else { continue }
            let key = pieces[0].lowercased(), value = pieces[1].trimmingCharacters(in: .whitespaces)
            if key == "user-agent" {
                if group.started { groups.append(group); group = Group() }
                group.agents.append(value.lowercased())
            } else if !group.agents.isEmpty {
                group.started = true
                if (key == "allow" || key == "disallow") && !value.isEmpty { group.rules.append(Rule(allow: key == "allow", pattern: value)) }
                if key == "crawl-delay", let seconds = Double(value), seconds.isFinite, seconds >= 0 { group.delay = seconds }
            }
        }
        groups.append(group)
        let target = agent.lowercased()
        func specificity(_ g: Group) -> Int { g.agents.map { $0 == "*" ? 0 : (target.contains($0) ? $0.count : -1) }.max() ?? -1 }
        let best = groups.map(specificity).max() ?? -1
        let chosen = groups.filter { best >= 0 && specificity($0) == best }
        rules = chosen.flatMap(\.rules)
        delay = max(0.3, chosen.compactMap(\.delay).max() ?? 0.3)
    }
    private static func normalized(_ value: String) -> [UInt8] {
        let input = Array(value.utf8); var output: [UInt8] = []; var i = 0
        let hex = Array("0123456789ABCDEF".utf8)
        func digit(_ byte: UInt8) -> Int? {
            if (48...57).contains(byte) { return Int(byte - 48) }
            if (65...70).contains(byte) { return Int(byte - 65 + 10) }
            if (97...102).contains(byte) { return Int(byte - 97 + 10) }
            return nil
        }
        func unreserved(_ b: UInt8) -> Bool { (65...90).contains(b) || (97...122).contains(b) || (48...57).contains(b) || [45,46,95,126].contains(b) }
        while i < input.count {
            if input[i] == 37, i + 2 < input.count, let a = digit(input[i+1]), let b = digit(input[i+2]) {
                let byte = UInt8(a*16+b)
                if unreserved(byte) { output.append(byte) } else { output += [37,hex[a],hex[b]] }
                i += 3
            } else {
                let byte = input[i]
                if byte > 127 || byte < 33 { output += [37,hex[Int(byte)/16],hex[Int(byte)%16]] }
                else { output.append(byte) }
                i += 1
            }
        }
        return output
    }
    /// Greedy glob matching with a shared work budget. Website-provided patterns
    /// never become regular expressions with unbounded backtracking.
    private static func matches(_ pattern: [UInt8], _ text: [UInt8], anchored: Bool, budget: inout Int) -> Bool? {
        var i = 0; var j = 0; var star: Int?; var retry = 0
        while i < text.count {
            budget -= 1; if budget < 0 { return nil }
            if j < pattern.count && pattern[j] == 42 { star = j; j += 1; retry = i }
            else if j < pattern.count && pattern[j] == text[i] { i += 1; j += 1 }
            else if j == pattern.count && !anchored { return true }
            else if let previous = star { retry += 1; i = retry; j = previous + 1 }
            else { return false }
        }
        while j < pattern.count && pattern[j] == 42 { j += 1 }
        return j == pattern.count
    }
    func allows(_ url: URL) -> Bool {
        let c = URLComponents(url: url, resolvingAgainstBaseURL: false)
        let path = (c?.percentEncodedPath.isEmpty == false ? c!.percentEncodedPath : "/") + (c?.percentEncodedQuery.map { "?" + $0 } ?? "")
        guard rules.count <= 4096, path.utf8.count <= 16_384 else { return false }
        var best = -1; var allowed = true; var budget = 1_000_000
        let text = Self.normalized(path)
        for rule in rules {
            guard rule.pattern.utf8.count <= 4096 else { return false }
            var pattern = rule.pattern; let anchored = pattern.hasSuffix("$")
            if anchored { pattern.removeLast() }
            let bytes = Self.normalized(pattern)
            guard let match = Self.matches(bytes, text, anchored: anchored, budget: &budget) else { return false }
            if !match { continue }
            let length = bytes.filter { $0 != 42 }.count
            if length > best || (length == best && rule.allow) { best = length; allowed = rule.allow }
        }
        return allowed
    }
}


enum ResultMerge {
    /// Stable identity merge: preserves newer validation and tolerates repeated IDs
    /// in imported files without trapping or discarding newer checkpoint rows.
    static func combine(_ checkpoint: [FoundEmail], _ project: [FoundEmail]) -> [FoundEmail] {
        var values: [UUID: FoundEmail] = [:]; var order: [UUID] = []
        for row in checkpoint + project {
            if values[row.id] == nil { order.append(row.id) }
            if values[row.id] == nil || row.checkedAt >= values[row.id]!.checkedAt { values[row.id] = row }
        }
        return order.compactMap { values[$0] }
    }
}

enum ResultPolicy {
    static func displayedStatus(_ row: FoundEmail, rules: [SmartRule], removed: Set<String>) -> String {
        if removed.contains(row.address.lowercased()) { return "Removed" }
        if TechnicalAddressPolicy.rejectionReason(row.address) != nil { return "Rejected" }
        return rules.contains { $0.matches(row.address) } ? "Excluded by rule" : row.status
    }
    static func displayedReason(_ row: FoundEmail) -> String {
        TechnicalAddressPolicy.rejectionReason(row.address) ?? row.reason
    }
    static func exportRows(_ rows: [FoundEmail], rules: [SmartRule], removed: Set<String>, onlyAccepted: Bool) -> [FoundEmail] {
        rows.compactMap { original in
            guard !removed.contains(original.address.lowercased()), !rules.contains(where: { $0.matches(original.address) }) else { return nil }
            let row = TechnicalAddressPolicy.reclassified(original)
            if onlyAccepted && row.status != "Accepted" && row.status != "Verified" { return nil }
            return row
        }
    }
    static func filtered(_ rows: [FoundEmail], rules: [SmartRule], removed: Set<String>, status: String, search: String, scope: String) -> [FoundEmail] {
        let needle = search.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let wildcard = SafeWildcard.containsWildcard(needle) ? SafeWildcard(needle) : nil
        func matches(_ value: String) -> Bool {
            wildcard?.matches(value) ?? value.lowercased().contains(needle)
        }
        return rows.filter { row in
            let isRemoved = removed.contains(row.address.lowercased())
            let ruleHidden = rules.contains { $0.matches(row.address) }
            let effectiveStatus = TechnicalAddressPolicy.rejectionReason(row.address) == nil ? row.status : "Rejected"
            let eligible: Bool
            switch status {
            case "All": eligible = true
            case "Removed": eligible = isRemoved
            case "Included": eligible = !isRemoved && !ruleHidden && effectiveStatus != "Rejected" && effectiveStatus != "Excluded"
            case "Excluded": eligible = !isRemoved && (ruleHidden || effectiveStatus == "Excluded")
            default: eligible = !isRemoved && !ruleHidden && effectiveStatus == status
            }
            guard eligible, !needle.isEmpty else { return eligible }
            switch scope {
            case "Domain": return matches(row.address.split(separator: "@").last.map(String.init) ?? "")
            case "Source": return matches(row.source)
            case "All fields": return wildcard == nil ? [row.address,row.source,displayedReason(row),displayedStatus(row,rules: rules,removed: removed)].joined(separator: " ").lowercased().contains(needle) : [row.address,row.source,displayedReason(row),displayedStatus(row,rules: rules,removed: removed)].contains(where: matches)
            default: return matches(row.address)
            }
        }
    }
}

/// Whole-field, case-insensitive shell-style wildcards, without regex execution.
/// Repeated stars collapse; bounded inputs prevent pathological work in the UI.
struct SafeWildcard {
    static let maximumPatternLength = 512
    private let pattern: [Character]
    private let valid: Bool
    init(_ value: String) {
        let text = value.lowercased()
        valid = text.count <= Self.maximumPatternLength
        var result: [Character] = []
        if valid {
            for character in text {
                if character == "*" && result.last == "*" { continue }
                result.append(character)
            }
        }
        pattern = result
    }
    static func containsWildcard(_ value: String) -> Bool {
        value.contains("*") || value.contains("?")
    }
    func matches(_ value: String) -> Bool {
        guard valid, value.count <= 16_384 else { return false }
        let text = Array(value.lowercased())
        var input = 0, token = 0, retry = 0
        var star: Int?
        while input < text.count {
            if token < pattern.count && (pattern[token] == "?" || (pattern[token] != "*" && pattern[token] == text[input])) {
                token += 1; input += 1
            } else if token < pattern.count && pattern[token] == "*" {
                star = token; token += 1; retry = input
            } else if let previous = star {
                retry += 1; input = retry; token = previous + 1
            } else { return false }
        }
        while token < pattern.count && pattern[token] == "*" { token += 1 }
        return token == pattern.count
    }
}

enum ResultOrdering {
    static func label(_ order: [KeyPathComparator<FoundEmail>]) -> String {
        guard let first = order.first else { return "Found order" }
        if order.count == 1 && first.keyPath == \FoundEmail.address {
            return first.order == .forward ? "Email A–Z" : "Email Z–A"
        }
        return "Column sort"
    }
    static func comparators(_ choice: String) -> [KeyPathComparator<FoundEmail>]? {
        switch choice {
        case "Found order": return []
        case "Email A–Z": return [KeyPathComparator(\FoundEmail.address, order: .forward)]
        case "Email Z–A": return [KeyPathComparator(\FoundEmail.address, order: .reverse)]
        default: return nil
        }
    }
    static func apply(_ rows: [FoundEmail], order: [KeyPathComparator<FoundEmail>]) -> [FoundEmail] {
        order.isEmpty ? rows : rows.sorted(using: order)
    }
}

enum TechnicalAddressPolicy {
    private static let assetExtensions: Set<String> = [
        "png","jpg","jpeg","gif","webp","svg","avif","ico","bmp","tif","tiff",
        "heic","apng","jfif","woff","woff2","ttf","otf","eot","css","js","map"
    ]
    private static let wixHosts = ["sentry.wixpress.com","sentry-next.wixpress.com"]
    static func reclassified(_ original: FoundEmail) -> FoundEmail {
        guard let reason = rejectionReason(original.address) else { return original }
        var row = original; row.status = "Rejected"; row.reason = reason
        return row
    }
    static func reclassify(_ rows: [FoundEmail]) -> [FoundEmail] { rows.map(reclassified) }
    static func rejectionReason(_ address: String) -> String? {
        let fields = address.lowercased().split(separator: "@", omittingEmptySubsequences: false)
        guard fields.count == 2 else { return nil }
        let local = String(fields[0])
        let host = String(fields[1]).trimmingCharacters(in: CharacterSet(charactersIn: "."))
        let parts = host.split(separator: ".").map(String.init)
        if let ext = parts.last, assetExtensions.contains(ext) {
            return "Technical asset filename; not a contact email address"
        }
        if parts.count == 1 && (host == "2x" || host == "3x") {
            return "Technical asset filename; not a contact email address"
        }
        if wixHosts.contains(where: { host == $0 || host.hasSuffix("." + $0) }) {
            return "Sentry telemetry endpoint; not a contact email address"
        }
        if host == "sentry.io" || host.hasSuffix(".sentry.io") {
            let key = local.utf8
            let hexadecimalKey = key.count == 32 && key.allSatisfy { (48...57).contains($0) || (97...102).contains($0) }
            if hexadecimalKey || parts.dropLast(2).contains("ingest") {
                return "Sentry telemetry identifier; not a contact email address"
            }
        }
        return nil
    }
}

enum ResultSelection {
    /// Shared by row clicks and checkbox actions. It has no native table
    /// selection binding that can replace the explicit selection on refresh.
    static func updated(_ current: Set<UUID>, id: UUID, selected: Bool? = nil) -> Set<UUID> {
        var result = current
        if selected ?? !current.contains(id) { result.insert(id) }
        else { result.remove(id) }
        return result
    }
}
