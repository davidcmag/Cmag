"""Polite crawler with durable page boundaries and safe network destinations."""
import base64
import html
import gzip
import io
import http.client
import ipaddress
import json
import os
import re
import socket
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from html.parser import HTMLParser
from urllib.robotparser import RobotFileParser
from defusedxml import ElementTree as ET
import dns.resolver
import dns.exception
from core import ASSET, extract

AGENT = 'EmailGrabber3/0.3 (+public-page research; robots.txt respected)'

class Links(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.links=[]
        self.feed(text)
    def handle_starttag(self, tag, attrs):
        if tag.lower()=='a':
            self.links.extend(v for k,v in attrs if k.lower()=='href' and v)

def resolve_addresses(host, resolver=None):
    try:
        return [str(ipaddress.ip_address(host))]
    except ValueError:
        pass
    resolver=resolver or dns.resolver.Resolver()
    resolver.timeout=2
    resolver.lifetime=4
    addresses=[]
    for kind in ('A','AAAA'):
        try:
            addresses.extend(str(record) for record in resolver.resolve(host,kind,search=False))
        except dns.resolver.NoAnswer:
            continue
        except dns.resolver.NXDOMAIN as e:
            raise ValueError('Destination domain does not exist') from e
        except dns.exception.DNSException as e:
            raise TimeoutError('Destination DNS lookup failed or timed out') from e
    return list(dict.fromkeys(addresses))

def destination(url):
    u = urllib.parse.urlsplit(url)
    if u.scheme not in ('http','https') or not u.hostname or u.username or u.password:
        raise ValueError('Invalid or credential-bearing URL')
    if u.port not in (None,80,443) or any(ord(x)<33 for x in url) or '\\' in url:
        raise ValueError('Only public HTTP/HTTPS destinations on standard ports are allowed')
    if u.hostname.lower() in ('localhost','localhost.localdomain') or u.hostname.lower().endswith('.local'):
        raise ValueError('Local destination blocked')
    ips=resolve_addresses(u.hostname)
    if not ips or any(not ipaddress.ip_address(x).is_global for x in ips):
        raise ValueError('Private or reserved destination blocked')
    return u, ips

class PinnedHTTP(http.client.HTTPConnection):
    def __init__(self, host, ip, port):
        super().__init__(host,port,timeout=15)
        self.ip=ip
    def connect(self):
        self.sock=socket.create_connection((self.ip,self.port),self.timeout)

class PinnedHTTPS(PinnedHTTP):
    def connect(self):
        super().connect()
        self.sock=ssl.create_default_context().wrap_socket(self.sock,server_hostname=self.host)

class RobotsRestricted(ValueError):
    pass

class UnsupportedContent(ValueError):
    pass

class CrawlStopped(Exception):
    pass

class GuardRedirect(urllib.request.HTTPRedirectHandler):
    def __init__(self, before_request=None):
        super().__init__()
        self.before_request=before_request

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        destination(newurl)
        if self.before_request:
            self.before_request(newurl)
        return super().redirect_request(req,fp,code,msg,headers,newurl)

class Network:
    @staticmethod
    def connection(u,ips):
        deadline=time.monotonic()+15
        last_error=None
        for ip in ips:
            remaining=deadline-time.monotonic()
            if remaining<=0:
                break
            conn=(PinnedHTTPS if u.scheme=='https' else PinnedHTTP)(u.hostname,ip,u.port or (443 if u.scheme=='https' else 80))
            conn.timeout=min(5,remaining)
            try:
                conn.connect()
                return conn
            except OSError as e:
                last_error=e
                conn.close()
        raise last_error or TimeoutError('No reachable public address')

    def crawl_fetch(self, url, before_request):
        return self.fetch(url,before_request=before_request)

    def fetch(self, url, limit=2_000_000, before_request=None):
        # On VPS, pin direct connections to the validated IP to close DNS rebinding.
        # Managed cloud proxy enforces its own destination policy; retain its trust/auth.
        for _ in range(6):
            u, ips = destination(url)
            if before_request:
                before_request(url)
            proxies=urllib.request.getproxies()
            if proxies.get(u.scheme) and not urllib.request.proxy_bypass(u.hostname):
                opener=urllib.request.build_opener(GuardRedirect(before_request))
                req=urllib.request.Request(url,headers={'User-Agent':AGENT})
                with opener.open(req,timeout=15) as r:
                    return self.decode(r.read(limit+1),r.headers,limit), r.url
            conn=self.connection(u,ips)
            try:
                path=urllib.parse.urlunsplit(('','',u.path or '/',u.query,''))
                conn.request('GET',path,headers={'User-Agent':AGENT,'Accept':'text/html,text/plain,application/rss+xml,application/xml'})
                r=conn.getresponse()
                if r.status in (301,302,303,307,308):
                    location=r.getheader('Location')
                    if not location:
                        raise ValueError('Redirect has no destination')
                    url=urllib.parse.urljoin(url,location)
                    continue
                if r.status>=400:
                    raise urllib.error.HTTPError(url,r.status,r.reason,r.headers,None)
                return self.decode(r.read(limit+1),r.headers,limit),url
            finally:
                conn.close()
        raise ValueError('Too many redirects')

    @staticmethod
    def decode(data,headers,limit):
        if len(data)>limit:
            raise ValueError('Page exceeds download limit')
        encoding=headers.get('Content-Encoding','identity').lower()
        if encoding=='gzip':
            with gzip.GzipFile(fileobj=io.BytesIO(data)) as stream:
                data=stream.read(limit+1)
            if len(data)>limit:
                raise ValueError('Expanded page exceeds download limit')
        elif encoding not in ('identity',''):
            raise UnsupportedContent('Unsupported content encoding')
        kind=headers.get('Content-Type','').lower()
        if not any(x in kind for x in ('html','text/plain','xml','rss')):
            raise UnsupportedContent('Unsupported page content type')
        encoding=headers.get_content_charset() if hasattr(headers,'get_content_charset') else None
        try:
            return data.decode(encoding or 'utf-8','replace')
        except LookupError:
            return data.decode('utf-8','replace')

    def robots(self, url):
        u=urllib.parse.urlsplit(url)
        root=urllib.parse.urlunsplit((u.scheme,u.netloc,'/robots.txt','',''))
        rp=RobotFileParser(root)
        try:
            body,_=self.fetch(root,500_000)
            rp.parse(body.splitlines())
        except urllib.error.HTTPError as e:
            if e.code in (404,410):
                rp.parse([])
            else:
                raise
        return rp

    def discover(self, query, control=lambda:True, report=lambda x:None):
        found={}
        # Queries are topic-agnostic. Geography is supplied by the caller.
        for term in (query,query+' contact',query+' directory'):
            for provider,page in [('bing',p) for p in range(5)] + [('duckduckgo',0)]:
                if not control():
                    return list(found.values())
                url=('https://www.bing.com/search?'+urllib.parse.urlencode({'format':'rss','q':term,'first':page*10+1}) if provider=='bing' else
                     'https://html.duckduckgo.com/html/?'+urllib.parse.urlencode({'q':term}))
                try:
                    text,_=self.fetch(url)
                    if provider=='bing':
                        candidates=[x.text for x in ET.fromstring(text).findall('.//item/link') if x.text]
                    else:
                        candidates=[]
                        for raw in Links(text).links:
                            link=urllib.parse.urljoin(url,raw)
                            args=urllib.parse.parse_qs(urllib.parse.urlsplit(link).query)
                            candidates.append(args.get('uddg',[link])[0])
                    for link in candidates:
                        p=urllib.parse.urlsplit(html.unescape(link))
                        host=(p.hostname or '').lower()
                        if p.scheme not in ('http','https') or not host or any(host==x or host.endswith('.'+x) for x in ('bing.com','duckduckgo.com','microsoft.com')):
                            continue
                        found.setdefault(host.removeprefix('www.'),link)
                except Exception as e:
                    report(f'{provider}: {type(e).__name__}: {e}')
                time.sleep(1)
        return list(found.values())

def normalize(url):
    p=urllib.parse.urlsplit(url)
    return urllib.parse.urlunsplit((p.scheme.lower(),p.netloc.lower(),p.path or '/',p.query,''))

def priority(url):
    return (0 if any(x in urllib.parse.urlsplit(url).path.lower() for x in ('contact','staff','directory','about','team','profile','people')) else 1,len(url))

class Crawler:
    def __init__(self,store,network=None,delay=0.5):
        self.store=store; self.network=network or Network(); self.delay=delay
        self.lock=threading.RLock(); self.stop_event=threading.Event(); self.gate=threading.Event(); self.gate.set()
        self.worker=None
        self.active=store.job()
        if self.active and self.active['state'] in ('running','paused','discovering'):
            self.active['state']='interrupted'
            store.save_job(self.active)

    def checkpoint(self):
        self.store.save_job(self.active)

    def status(self):
        with self.lock:
            j=self.active or {}
            sites=j.get('sites',{})
            return {'running':bool(self.worker and self.worker.is_alive()),'paused':not self.gate.is_set(),
                    'pages':j.get('pages',0),'sites':sum(x['pages']>0 for x in sites.values()),
                    'discovered':len(sites),'blocked_sites':sum(x['state']=='blocked' for x in sites.values()),
                    'failed_sites':sum(x['state']=='failed' for x in sites.values()),
                    'skipped_robots':sum(x['state']=='robots' for x in sites.values()),
                    'skipped_sites':sum(x['state']=='skipped' for x in sites.values()),
                    'status':j.get('message','Ready'),'last_error':j.get('error',''),
                    'job_id':j.get('id'),'job_state':j.get('state'),
                    'resumable':bool(j.get('queue') or j.get('inputs')) and j.get('state') not in ('completed',)}

    def start(self, inputs=None, resume=None, **options):
        with self.lock:
            if self.worker and self.worker.is_alive():
                raise RuntimeError('A crawl is already running')
            if resume:
                job=self.store.job(int(resume))
                if not job or job['state']=='completed':
                    raise ValueError('No resumable job')
                self.active=job
                # Each continuation grants another page batch while retaining totals.
                job['batch_end']=job['pages']+job['options'].get('max_pages',0)
            else:
                if not inputs or not any(x.strip() for x in inputs):
                    raise ValueError('Enter URLs or search terms')
                self.active={'inputs':list(inputs),'options':options,'queue':[],'visited':[], 'sites':{},'pages':0,'state':'discovering','message':'Discovering websites','error':''}
            self.stop_event.clear(); self.gate.set(); self.checkpoint()
            self.worker=threading.Thread(target=self.run,daemon=True)
            self.worker.start()

    def control(self):
        while not self.gate.wait(.2):
            if self.stop_event.is_set():
                return False
        return not self.stop_event.is_set()

    def pause(self):
        with self.lock:
            if self.gate.is_set():
                self.gate.clear(); self.active['state']='paused'; self.active['message']='Paused after current request'
            else:
                self.gate.set(); self.active['state']='running'; self.active['message']='Resumed'
            self.checkpoint()

    def stop(self):
        self.stop_event.set(); self.gate.set()

    def run(self):
        j=self.active; opts=j['options']; robots={}; last_request={}
        batch_end=j.get('batch_end',opts.get('max_pages',0))
        def permitted(target):
            p=urllib.parse.urlsplit(target)
            origin=urllib.parse.urlunsplit((p.scheme,p.netloc,'','',''))
            if origin not in robots:
                robots[origin]=self.network.robots(target)
            rp=robots[origin]
            if not rp.can_fetch(AGENT,target):
                raise RobotsRestricted('robots.txt disallows this page')
            key=(p.hostname or '').removeprefix('www.')
            delay=max(self.delay,rp.crawl_delay(AGENT) or 0)
            rate=rp.request_rate(AGENT)
            if rate and rate.requests:
                delay=max(delay,rate.seconds/rate.requests)
            wait=delay-(time.monotonic()-last_request.get(key,0))
            if wait>0 and self.stop_event.wait(wait):
                raise CrawlStopped()
            if not self.control():
                raise CrawlStopped()
            last_request[key]=time.monotonic()

        def error(message):
            j['error']=message
        try:
            while j['inputs'] and self.control():
                item=j['inputs'][0].strip()
                if item.startswith(('https://','http://')):
                    seeds=[item]
                elif re.fullmatch(r'[\w.-]+\.[a-zA-Z]{2,63}(?:/[^\s]*)?',item):
                    seeds=['https://'+item]
                else:
                    seeds=self.network.discover((item+' '+opts.get('geography','')).strip(),self.control,error)
                    if self.stop_event.is_set():
                        break
                for seed in seeds:
                    u=normalize(seed); host=(urllib.parse.urlsplit(u).hostname or '').removeprefix('www.')
                    if not host:
                        j.setdefault('input_errors',[]).append('Invalid URL: '+seed)
                        continue
                    if host not in j['sites']:
                        j['sites'][host]={'pages':0,'state':'pending','error':''}
                    if u not in {x[0] for x in j['queue']} and u not in j['visited']:
                        j['queue'].append([u,0])
                j['inputs'].pop(0); self.checkpoint()
            if self.stop_event.is_set():
                j['state']='stopped'; j['message']='Stopped; checkpoint saved'; return
            j['state']='running'
            while j['queue'] and self.control():
                if opts.get('max_pages',0) and j['pages']>=batch_end:
                    j['state']='limited'; j['message']='Page limit reached; pending links saved'; break
                entry=j['queue'][0]; url,depth=entry[:2]; host=entry[2] if len(entry)>2 else (urllib.parse.urlsplit(url).hostname or '').removeprefix('www.'); site=j['sites'][host]
                if url in j['visited'] or site['state'] in ('blocked',):
                    j['queue'].pop(0); self.checkpoint(); continue
                if opts.get('per_site',0) and site['pages']>=opts['per_site']:
                    site['state']='scanned' if site['pages'] else 'skipped'
                    j['queue'].pop(0); self.checkpoint(); continue
                try:
                    j['message']='Scanning '+host
                    if hasattr(self.network,'crawl_fetch'):
                        body,final=self.network.crawl_fetch(url,permitted)
                    else:
                        permitted(url)
                        body,final=self.network.fetch(url)
                    # Records commit first. Queue checkpoint follows: a crash may repeat
                    # a page, but uniqueness prevents duplicates and no committed row is lost.
                    for address in extract(body):
                        self.store.insert(address,final,opts.get('exclude_roles',False))
                    site['pages']+=1; site['state']='scanned'; j['pages']+=1
                    if depth<opts.get('depth',3) or (opts.get('depth')==0 and depth<20 and (depth==0 or priority(url)[0]==0)):
                        queued={x[0] for x in j['queue']}|set(j['visited'])
                        links=[]
                        for raw in Links(body).links:
                            link=normalize(urllib.parse.urljoin(final,raw)); p=urllib.parse.urlsplit(link)
                            if p.scheme in ('http','https') and (p.hostname or '').removeprefix('www.')==(urllib.parse.urlsplit(final).hostname or '').removeprefix('www.') and not p.path.lower().endswith(tuple('.'+x for x in ASSET)) and link not in queued:
                                links.append(link); queued.add(link)
                        # Prioritized children follow existing seed pages for site coverage.
                        j['queue'].extend([x,depth+1,host] for x in sorted(links,key=priority))
                except CrawlStopped:
                    break
                except RobotsRestricted as e:
                    if not site['pages']:
                        site['state']='robots'
                    site['error']=str(e)
                except UnsupportedContent as e:
                    if not site['pages']:
                        site['state']='skipped'
                    site['error']=str(e)
                except urllib.error.HTTPError as e:
                    site['state']='blocked' if e.code in (401,403,429) else 'failed'
                    site['error']=f'HTTP {e.code}'; error(host+': '+site['error'])
                except Exception as e:
                    site['state']='failed'; site['error']=f'{type(e).__name__}: {e}'; error(host+': '+site['error'])
                j['queue'].pop(0); j['visited'].append(url); self.checkpoint()
            if self.stop_event.is_set():
                j['state']='stopped'; j['message']='Stopped; checkpoint saved'
            elif not j['queue']:
                j['state']='completed'; j['message']=f"Completed: {j['pages']} pages; see blocked and failed counts"
        except Exception as e:
            j['state']='failed'; j['error']=f'{type(e).__name__}: {e}'; j['message']='Job failed; checkpoint retained'
        finally:
            self.checkpoint(); self.gate.set()
