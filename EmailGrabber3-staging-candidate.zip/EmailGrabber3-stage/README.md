# Email Grabber 3 repair candidate

Source: the supplied Mac v0.11.6, VPS deployment, and crawler-fix v0.2 archives. Originals are preserved under `/workspace/emailgrabber-handoff`. The Cmag repository is unrelated and unchanged.

This candidate has **not been deployed or production-approved**. See STATUS.md for acceptance gaps.

## Local development

Python 3.12 is required. From this directory:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-dev.txt
.venv/bin/python -m unittest discover -s tests -v
EMAILGRABBER_DB=/workspace/EmailGrabber3/local-data/results.sqlite3 .venv/bin/python server.py
```

Browser tests use the installed `/usr/bin/chromium`. They start temporary loopback servers, use isolated temporary databases, and do not contact external sites. The crawler network is simulated in these tests; actual browser requests to the application are real. In restricted execution environments, socket operations need the environment's supported execution permissions.

The service binds to 127.0.0.1:8787. Do not expose that port. The UI polls for live results. Checkpoints persist after every page. Interrupted jobs require an explicit Resume saved job action; they do not start crawling automatically after a service restart. A resumed page-limited job gets another batch of the configured size. Zero page limits mean no numeric cap. Depth zero adaptively follows promising contact paths up to 20 levels; positive depth supplies an explicit bound.

DNS checks run only when requested, report MX/address fallback separately, and never verify individual mailboxes. Disposable detection is a small starter list. No ZeroBounce calls are implemented or made.

## Authentication

Retain existing Nginx HTTPS and Basic Authentication for the entire hostname, including all API paths. An optional backend password can be supplied through a protected environment file with `EMAILGRABBER_AUTH_USER` and `EMAILGRABBER_AUTH_PASSWORD`; do not put credentials in source, shell history, or saved cloud scripts. If no backend password is configured, loopback access relies on the reverse proxy for authentication. The backend is not independently safe for public exposure.

CSRF protection uses an unpredictable token delivered in authenticated HTML. Cross-origin POSTs are rejected. Input is treated as data; no subprocess executes crawl inputs. Direct VPS connections resolve and validate every destination and redirect, reject nonpublic addresses and nonstandard ports, and pin connections to the validated IP while retaining TLS hostname verification. In a managed proxy environment, the proxy resolves connections and must enforce private-network restrictions. A production egress audit remains required.

## Persistence and exports

The original database schema is migrated additively. Back up before using a production database. Results, sources, validation timestamps, filtering rules, reversible removals and jobs persist in SQLite WAL mode. Filtering rules apply dynamically to existing and new results. Included exports omit deleted, excluded, and rejected rows and respect current search scope. CSV/XLSX imports preserve source columns; spreadsheet exports neutralize formula prefixes.

Run no deployments until the existing paths and service configuration have been inspected. Follow deploy/DEPLOYMENT.md.

## Staging on the inspected VPS

Upload the staging ZIP outside the public website directory. Extract into a new directory and run `/opt/emailgrabber3/venv/bin/python deploy/stage.py` from its EmailGrabber3-stage directory as root. Before running, verify the ZIP SHA256 against the value provided separately in chat. The stage script verifies the inspected production hash, service user/directory, existing private backups and package manifest; creates an isolated root-owned release and venv under `/opt/emailgrabber3-releases`; and runs backend tests and live network/application checks as emailgrabber. It never updates the production service, production database, Nginx, Apache, or existing venv. It requires working TLS-verified access to PyPI and the public test/search sites. A failed stage leaves the candidate directory for diagnosis and leaves production untouched. No automatic retries or production switch occur. The stage installer and live external checks still require execution on the VPS; their presence in this ZIP is not evidence they passed.
