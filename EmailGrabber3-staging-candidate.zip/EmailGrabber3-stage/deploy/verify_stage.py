"""Run as emailgrabber in staging. Uses temporary databases; never changes the live app."""
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from core import dns_check
from server import Application,handler_for

def backend_tests():
    spec=importlib.util.spec_from_file_location('grabber_tests',ROOT/'tests/test_system.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    suite=unittest.TestSuite()
    for name,cls in vars(module).items():
        if isinstance(cls,type) and issubclass(cls,unittest.TestCase) and name not in ('TempStore','BrowserTests'):
            suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(cls))
    if suite.countTestCases()<25:
        raise RuntimeError('Too few backend tests selected')
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():
        raise RuntimeError('Staging backend tests failed')

def public_authentication():
    base='https://grabber.spymastermagazine.com'
    for path in ('/','/api/state','/api/results','/api/export','/api/jobs'):
        try:
            urllib.request.urlopen(base+path,timeout=20).close()
        except urllib.error.HTTPError as e:
            if e.code==401:
                print('Public authentication required:',path,flush=True)
                continue
            raise RuntimeError(f'Expected public HTTP 401 for {path}; got {e.code}')
        raise RuntimeError('Unauthenticated public access allowed: '+path)
    req=urllib.request.Request(base+'/api/security-probe',data=b'{}',headers={'Content-Type':'application/json'})
    try:
        urllib.request.urlopen(req,timeout=20).close()
    except urllib.error.HTTPError as e:
        if e.code==401:
            return
        raise RuntimeError(f'Expected HTTP 401 on unauthenticated API POST, got {e.code}')
    raise RuntimeError('Public API POST not protected')

def live_application():
    with tempfile.TemporaryDirectory(prefix='emailgrabber-stage-') as tmp:
        app=Application(Path(tmp)/'results.sqlite3')
        http=ThreadingHTTPServer(('127.0.0.1',0),handler_for(app))
        worker=threading.Thread(target=http.serve_forever,daemon=True);worker.start()
        base=f'http://127.0.0.1:{http.server_port}'
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        def request(path,data=None):
            headers={'Content-Type':'application/json','X-Local-Token':app.token}
            req=urllib.request.Request(base+path,data=json.dumps(data).encode() if data is not None else None,headers=headers)
            with opener.open(req,timeout=20) as r:
                return r.read()
        def job(inputs,limit,timeout):
            request('/api/start',{'inputs':inputs,'depth':2,'max_pages':limit,'per_site':3,'exclude_roles':False})
            deadline=time.monotonic()+timeout
            while time.monotonic()<deadline:
                state=json.loads(request('/api/state'))
                if not state['running']:
                    print('Live job:',json.dumps(state),flush=True)
                    if not state['pages']:
                        raise RuntimeError('Live job scanned zero pages; inspect reported errors')
                    return state
                time.sleep(1)
            app.crawler.stop()
            raise RuntimeError('Live job exceeded its staging timeout')
        try:
            print('Checking direct public URL crawling through staged API...',flush=True)
            job('https://www.python.org/about/help/\nhttps://www.iana.org/help/',6,180)
            rows=json.loads(request('/api/results'))['rows']
            if not rows:
                raise RuntimeError('Public pages yielded no Included records; extraction is not validated')
            print('Live publicly sourced Included records:',len(rows),flush=True)
            if not request('/api/export?format=csv').startswith(b'\xef\xbb\xbfemail,'):
                raise RuntimeError('CSV export failed')
            if not request('/api/export?format=xlsx').startswith(b'PK'):
                raise RuntimeError('XLSX export failed')
            print('Checking arbitrary-keyword discovery through staged API (may take several minutes)...',flush=True)
            state=job('astronomy observatory',2,360)
            if not state['discovered']:
                raise RuntimeError('Live keyword discovery returned no websites')
            print('Checking actual DNS MX/fallback...',flush=True)
            state,reason=dns_check('python.org')
            print('DNS:',state,reason,flush=True)
            if state not in ('mx','fallback'):
                raise RuntimeError('Live DNS validation did not pass')
            # Reopen the real temporary DB after worker shutdown to check committed persistence.
            from core import Store
            if not Store(Path(tmp)/'results.sqlite3').records()[0]:
                raise RuntimeError('Committed live results did not persist')
        finally:
            app.crawler.stop()
            if app.crawler.worker:app.crawler.worker.join(35)
            http.shutdown();http.server_close();worker.join()

if __name__=='__main__':
    os.umask(0o077)
    print('Running as UID',os.getuid(),'; production files remain unchanged.',flush=True)
    backend_tests()
    public_authentication()
    live_application()
    print('STAGING CHECKS PASSED. This is not a production deployment or authenticated public acceptance.',flush=True)
