import base64
import csv
import io
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path
from unittest.mock import patch
from urllib.robotparser import RobotFileParser
from http.server import ThreadingHTTPServer
import dns.resolver
import dns.exception
from openpyxl import load_workbook
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from core import Store,extract,reason_for,dns_check
from crawler import Crawler,Network,destination
from server import Application,handler_for

class FixtureNetwork:
    def __init__(self):
        self.calls=[]
    def discover(self,query,control,report):
        return ['https://open.org/','https://blocked.org/','https://other.org/']
    def robots(self,url):
        rp=RobotFileParser();rp.parse(['User-agent: *','Disallow: /private']);return rp
    def fetch(self,url,limit=2_000_000):
        self.calls.append(url)
        if 'blocked.org' in url:
            raise urllib.error.HTTPError(url,403,'Forbidden',{},None)
        if 'other.org' in url:
            return 'jane@other.org',url
        if url.endswith('/contact'):
            return 'jane [at] open [dot] org jane@open.org logo@2x.png',url
        if url.endswith('/staff'):
            return 'person@open.org',url
        return '<a href="/contact">Contact</a><a href="/staff">Staff</a><a href="/private">Private</a><a href="http://127.0.0.1/">unsafe</a>',url

class TempStore(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)/'results.sqlite3';self.store=Store(self.path)
    def tearDown(self):
        self.tmp.cleanup()

class ExtractionTests(TempStore):
    def test_obfuscation_and_json_cleanup(self):
        self.assertEqual(extract(r'\u003eJane [at] public [dot] org mailto:jane%40public.org &#106;ane@public.org'),['jane@public.org'])
    def test_false_positives_excluded_from_default(self):
        false=['logo@2x.png','hash@sentry.wixpress.com','hash@sentry-next.wixpress.com','hash@abc.ingest.sentry.io','info@yoursite.com','x..y@public.org']
        for email in false:
            self.assertTrue(reason_for(email),email);self.store.insert(email,'test')
        self.assertEqual(self.store.records()[0],[])
    def test_role_and_disposable(self):
        for name in ('info','care','support','office','contact'):
            self.store.insert(name+'@public.org','test',True)
        self.store.insert('jane@mailinator.com','test')
        self.assertEqual(len(self.store.records(view='excluded')[0]),6)
    def test_dedupe_preserves_sources(self):
        self.assertTrue(self.store.insert('Jane@public.org','https://public.org/a'))
        self.assertFalse(self.store.insert('jane@public.org','https://public.org/b'))
        with self.store.db() as c:
            self.assertEqual(c.execute('SELECT count(*) FROM sources').fetchone()[0],2)

class FilteringTests(TempStore):
    def test_rule_preview_existing_future_undo(self):
        for i in range(125):self.store.insert(f'person{i}@public.org','https://source.org')
        self.assertEqual(self.store.rule('domain','public.org',True),125)
        self.store.rule('domain','public.org')
        self.store.insert('new@public.org','test')
        self.assertEqual(len(self.store.records()[0]),0)
        with self.store.db() as c:c.execute('DELETE FROM rules')
        self.assertEqual(len(self.store.records()[0]),126)
    def test_scopes_delete_undo_persistence(self):
        self.store.insert('jane@public.org','https://info.org')
        self.assertEqual(self.store.records(q='info')[0],[])
        rows,_=self.store.records(q='info',scope='source')
        self.assertEqual(len(rows),1)
        self.assertEqual(self.store.remove([rows[0]['id'],999]),1)
        restored=Store(self.path)
        self.assertEqual(restored.records()[0],[])
        restored.undo_delete();self.assertEqual(len(restored.records()[0]),1)
    def test_sort(self):
        self.store.insert('z@public.org','test');self.store.insert('a@public.org','test')
        self.assertEqual(self.store.records(sort='email',direction='asc')[0][0]['email'],'a@public.org')
    def test_csv_xlsx_roundtrip_and_sources(self):
        self.store.insert('jane@public.org','https://public.org/contact')
        self.store.insert('info@yoursite.com','test')
        for fmt in ('csv','xlsx'):
            data=self.store.export(fmt)
            other=Store(Path(self.tmp.name)/(fmt+'.sqlite3'))
            self.assertEqual(other.import_file(data,fmt),1)
            rows,_=other.records();self.assertEqual(rows[0]['source'],'https://public.org/contact')
    def test_formula_sanitized(self):
        self.store.insert('jane@public.org','=HYPERLINK("bad")')
        wb=load_workbook(io.BytesIO(self.store.export('xlsx')))
        self.assertEqual(wb.active['D2'].data_type,'s')
        self.assertTrue(wb.active['D2'].value.startswith("'="))
    def test_validation_never_claims_mailbox_verification(self):
        self.store.insert('info@public.org','test',True)
        self.store.insert('jane@public.org','test')
        self.store.validate(lambda domain:('mx','MX configured; individual mailbox unverified'))
        rows,_=self.store.records(view='all')
        self.assertEqual({r['status'] for r in rows},{'Excluded','Unverified'});self.assertEqual(len(self.store.records()[0]),1)
        self.assertTrue(all(r['validated'] and r['dns']=='mx' for r in rows))

class DNSTests(unittest.TestCase):
    def resolver(self,answers):
        class Resolver:
            def resolve(self,domain,kind):
                value=answers[kind]
                if isinstance(value,Exception):raise value
                return value
        return Resolver()
    def test_mx(self):
        class MX:exchange='mail.public.org.'
        self.assertEqual(dns_check('public.org',self.resolver({'MX':[MX()]}))[0],'mx')
    def test_null_mx(self):
        class MX:exchange='.'
        self.assertEqual(dns_check('public.org',self.resolver({'MX':[MX()]}))[0],'no-mail')
    def test_fallback(self):
        self.assertEqual(dns_check('public.org',self.resolver({'MX':dns.resolver.NoAnswer(),'A':['1.1.1.1']}))[0],'fallback')
    def test_missing_and_uncertain(self):
        self.assertEqual(dns_check('public.org',self.resolver({'MX':dns.resolver.NXDOMAIN()}))[0],'no-domain')
        self.assertEqual(dns_check('public.org',self.resolver({'MX':dns.exception.Timeout()}))[0],'unknown')

class CrawlTests(TempStore):
    def wait(self,c):
        c.worker.join(10);self.assertFalse(c.worker.is_alive())
    def test_discovery_crawl_blocked_continue_and_robots(self):
        n=FixtureNetwork(); c=Crawler(self.store,n,0)
        c.start(['arbitrary nonprofit topic'],max_pages=0,per_site=0,depth=3,exclude_roles=False)
        self.wait(c)
        self.assertEqual(c.status()['pages'],4)
        self.assertEqual(c.status()['sites'],2)
        self.assertEqual(c.status()['discovered'],3)
        self.assertEqual(c.status()['blocked_sites'],1)
        self.assertFalse(any('/private' in x for x in n.calls))
        self.assertEqual({x['email'] for x in self.store.records()[0]},{'jane@open.org','person@open.org','jane@other.org'})
    def test_stop_restart_resume(self):
        class Slow(FixtureNetwork):
            def fetch(self,url,limit=0):
                time.sleep(.05);return super().fetch(url)
        c=Crawler(self.store,Slow(),0)
        c.start(['https://open.org/'],depth=3)
        deadline=time.monotonic()+3
        while c.status()['pages']==0 and time.monotonic()<deadline:time.sleep(.005)
        c.stop();self.wait(c)
        ident=c.status()['job_id']
        c2=Crawler(Store(self.path),FixtureNetwork(),0)
        c2.start(resume=ident);self.wait(c2)
        self.assertEqual(c2.status()['job_state'],'completed')
        self.assertEqual(len(self.store.records()[0]),2)
    def test_interrupted_job_detected(self):
        job={'state':'running','inputs':[],'queue':[['https://open.org/',0]],'options':{'depth':3},'visited':[],'sites':{'open.org':{'pages':0,'state':'pending'}},'pages':0}
        self.store.save_job(job)
        c=Crawler(Store(self.path),FixtureNetwork(),0)
        self.assertEqual(c.status()['job_state'],'interrupted')
        c.start(resume=job['id']);self.wait(c)
        self.assertEqual(c.status()['job_state'],'completed')
    def test_pause_stop_does_not_hang(self):
        c=Crawler(self.store,FixtureNetwork(),.3);c.start(['https://open.org/'],depth=3)
        c.pause();c.stop();self.wait(c)
        self.assertEqual(c.status()['job_state'],'stopped')
    def test_failures_are_not_successful_pages(self):
        class Fail(FixtureNetwork):
            def fetch(self,*a):raise TimeoutError('timeout')
        c=Crawler(self.store,Fail(),0);c.start(['https://open.org/'],depth=3);self.wait(c)
        self.assertEqual(c.status()['pages'],0);self.assertEqual(c.status()['failed_sites'],1)

class DiscoveryTests(unittest.TestCase):
    @patch('crawler.time.sleep')
    def test_bing_rss_duck_wrappers_merge_and_arbitrary_topic(self,_):
        n=Network();queries=[]
        def fetch(url,limit=0):
            queries.append(url)
            if 'bing' in url:return '<rss><channel><item><link>https://science.org/contact</link></item></channel></rss>',url
            return '<a href="//duckduckgo.com/l/?uddg=https%3A%2F%2Farchive.org%2F">Result</a>',url
        n.fetch=fetch
        self.assertEqual(n.discover('history of astronomy'),['https://science.org/contact','https://archive.org/'])
        self.assertEqual(len(queries),18)

class SecurityTests(unittest.TestCase):
    def test_ssrf_destinations(self):
        for url in ('http://localhost/','http://127.0.0.1/','http://169.254.169.254/','http://[::1]/','file:///etc/passwd','http://user:pass@public.org/','https://public.org:8787/'):
            with self.subTest(url=url),self.assertRaises((ValueError,OSError)):destination(url)
    def test_mixed_public_private_dns_rejected(self):
        with patch('crawler.resolve_addresses',return_value=['1.1.1.1','10.0.0.1']):
            with self.assertRaises(ValueError):destination('https://public.org/')

class HTTPTests(TempStore):
    def setUp(self):
        TempStore.setUp(self)
        self.app=Application(self.path,FixtureNetwork())
        self.http=ThreadingHTTPServer(('127.0.0.1',0),handler_for(self.app))
        self.thread=threading.Thread(target=self.http.serve_forever,daemon=True);self.thread.start()
        self.base=f'http://127.0.0.1:{self.http.server_port}'
        self.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    def tearDown(self):
        self.app.crawler.stop()
        if self.app.crawler.worker:self.app.crawler.worker.join(5)
        self.http.shutdown();self.http.server_close();self.thread.join();TempStore.tearDown(self)
    def request(self,path,data=None,headers=None):
        h={'Content-Type':'application/json','X-Local-Token':self.app.token,**(headers or {})}
        req=urllib.request.Request(self.base+path,data=json.dumps(data).encode() if data is not None else None,headers=h)
        try:
            with self.opener.open(req,timeout=10) as r:return r.status,r.read()
        except urllib.error.HTTPError as e:return e.code,e.read()
    def test_import_live_results_filter_export_and_undo(self):
        self.assertEqual(self.request('/api/import',{'entries':['jane@public.org','info@yoursite.com']})[0],200)
        code,body=self.request('/api/results');self.assertEqual(code,200);self.assertEqual(json.loads(body)['total'],1)
        self.assertEqual(json.loads(self.request('/api/rule-preview',{'kind':'domain','value':'public.org'})[1])['count'],1)
        self.request('/api/delete-matching',{'filters':{'q':'jane'}})
        self.assertEqual(json.loads(self.request('/api/results')[1])['total'],0)
        self.request('/api/undo-delete',{})
        self.assertEqual(json.loads(self.request('/api/results')[1])['total'],1)
        self.assertIn(b'jane@public.org',self.request('/api/export')[1])
        self.assertNotIn(b'info@yoursite.com',self.request('/api/export')[1])
    def test_csrf_bad_input_and_origin(self):
        self.assertEqual(self.request('/api/import',{}, {'X-Local-Token':'bad'})[0],403)
        self.assertEqual(self.request('/api/import',{}, {'Origin':'https://evil.org'})[0],403)
        self.assertEqual(self.request('/api/start',{'inputs':'https://open.org','depth':'bad'})[0],400)
        self.assertEqual(self.request('/api/results?offset=bad')[0],400)
    def test_basic_auth_all_routes(self):
        with patch.dict(os.environ,{'EMAILGRABBER_AUTH_PASSWORD':'test-only-password'}):
            for path in ('/','/api/state','/api/results','/api/export','/api/jobs'):
                self.assertEqual(self.request(path)[0],401,path)
            self.assertEqual(self.request('/api/stop',{})[0],401)
            h={'Authorization':'Basic '+base64.b64encode(b'emailgrabber:test-only-password').decode()}
            self.assertEqual(self.request('/api/state',headers=h)[0],200)
    def test_real_http_start_and_live_polling(self):
        self.assertEqual(self.request('/api/start',{'inputs':'https://open.org/','depth':3})[0],200)
        deadline=time.monotonic()+8
        seen_live=False
        while time.monotonic()<deadline:
            state=json.loads(self.request('/api/state')[1]);results=json.loads(self.request('/api/results')[1])
            if state['running'] and results['total']>0:seen_live=True
            if not state['running']:break
            time.sleep(.02)
        self.assertFalse(state['running']);self.assertEqual(results['total'],2);self.assertTrue(seen_live)

if __name__=='__main__':unittest.main()

class DurabilityTests(TempStore):
    def test_process_killed_mid_request_and_resume(self):
        marker=Path(self.tmp.name)/'inflight'
        script=r'''
import sys,time
from pathlib import Path
from core import Store
from crawler import Crawler
from urllib.robotparser import RobotFileParser
class Network:
 def robots(self,url):
  rp=RobotFileParser();rp.parse([]);return rp
 def fetch(self,url,limit=0):
  if url.endswith('/contact'):
   Path(sys.argv[2]).write_text('ready')
   time.sleep(60)
  return 'jane@public.org <a href="/contact">Contact</a>',url
Path(sys.argv[2]+'.loaded').write_text('imports loaded')
c=Crawler(Store(sys.argv[1]),Network(),0)
c.start(['https://public.org/'],depth=3)
c.worker.join()
'''
        p=subprocess.Popen([sys.executable,'-c',script,str(self.path),str(marker)],cwd=Path(__file__).resolve().parents[1])
        try:
            startup=Path(str(marker)+'.loaded')
            deadline=time.monotonic()+30
            while not startup.exists() and p.poll() is None and time.monotonic()<deadline:time.sleep(.02)
            self.assertTrue(startup.exists(),'Child did not finish importing test dependencies')
            deadline=time.monotonic()+5
            while not marker.exists() and time.monotonic()<deadline:time.sleep(.02)
            self.assertTrue(marker.exists())
            p.kill();p.wait(5)
            self.assertEqual(len(Store(self.path).records()[0]),1)
            class Recover(FixtureNetwork):
                def fetch(self,url,limit=0):return 'jane@public.org second@public.org',url
            c=Crawler(Store(self.path),Recover(),0)
            self.assertEqual(c.status()['job_state'],'interrupted')
            c.start(resume=c.status()['job_id']);c.worker.join(5)
            self.assertFalse(c.worker.is_alive())
            self.assertEqual(c.status()['job_state'],'completed')
            self.assertEqual(len(self.store.records()[0]),2)
        finally:
            if p.poll() is None:p.kill();p.wait()
    def test_500_page_job_with_checkpoints(self):
        class Chain(FixtureNetwork):
            def fetch(self,url,limit=0):
                i=int(url.rstrip('/').rsplit('/',1)[-1])
                links=''.join(f'<a href="/{n}">Contact</a>' for n in range(1,501)) if i==0 else ''
                return f'person{i}@public.org '+links,url
        c=Crawler(self.store,Chain(),0)
        c.start(['https://public.org/0'],depth=2,max_pages=500)
        c.worker.join(20)
        self.assertFalse(c.worker.is_alive())
        self.assertEqual(c.status()['pages'],500)
        self.assertEqual(len(self.store.records()[0]),500)
        self.assertEqual(Store(self.path).job()['pages'],500)
    def test_resume_extends_page_budget(self):
        c=Crawler(self.store,FixtureNetwork(),0)
        c.start(['https://open.org/'],max_pages=1,depth=3)
        c.worker.join(5);self.assertEqual(c.status()['pages'],1)
        c.start(resume=c.status()['job_id']);c.worker.join(5)
        self.assertEqual(c.status()['pages'],2)

class BrowserTests(TempStore):
    setUp=HTTPTests.setUp
    tearDown=HTTPTests.tearDown
    request=HTTPTests.request
    def test_interface_import_rule_preview_undo_export(self):
        from playwright.sync_api import sync_playwright,expect
        with sync_playwright() as p:
            browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
            try:
                page=browser.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(self.base)
                page.locator('#excludeRoles').uncheck()
                page.once('dialog',lambda d:d.accept())
                page.locator('#file').set_input_files({'name':'addresses.csv','mimeType':'text/csv','buffer':b'Email,Source\njane@public.org,https://public.org/contact\ninfo@public.org,https://public.org/contact\n'})
                expect(page.locator('#body tr')).to_have_count(2)
                page.locator('#filter').fill('info')
                expect(page.locator('#body tr')).to_have_count(1)
                page.locator('#rule').click()
                page.locator('#ruleKind').select_option('prefix')
                page.locator('#ruleValue').fill('info@')
                expect(page.locator('#preview')).to_have_text('1 matching records across the entire database.')
                page.locator('#applyRule').click()
                expect(page.locator('#body tr')).to_have_count(0)
                page.locator('#undo').click()
                expect(page.locator('#body tr')).to_have_count(1)
                with page.expect_download() as download:page.locator('#exportXlsx').click()
                wb=load_workbook(io.BytesIO(Path(download.value.path()).read_bytes()),read_only=True)
                try:
                    values=list(wb.active.values);self.assertEqual(len(values),2);self.assertEqual(values[1][0],'info@public.org')
                finally:wb.close()
                self.assertEqual(errors,[])
            finally:browser.close()

class MigrationTests(TempStore):
    def test_legacy_rule_exclusions_restore_after_undo(self):
        self.store.insert('jane@public.org','legacy')
        self.store.rule('domain','public.org')
        with self.store.db() as c:
            c.execute("UPDATE emails SET status='Excluded',reason='Matches filtering rule'")
        migrated=Store(self.path)
        self.assertEqual(migrated.records()[0],[])
        with migrated.db() as c:c.execute('DELETE FROM rules')
        self.assertEqual(len(migrated.records()[0]),1)
    def test_roles_apply_existing_future_and_can_restore(self):
        self.store.insert('info@public.org','before')
        self.store.set_roles(True)
        self.store.insert('care@public.org','after')
        self.assertEqual(self.store.records()[0],[])
        self.store.set_roles(False)
        self.assertEqual(len(self.store.records()[0]),2)
    def test_legacy_roles_preserved_and_restorable(self):
        self.store.insert('support@public.org','legacy')
        with self.store.db() as c:c.execute("UPDATE emails SET status='Excluded',reason='Generic role account'")
        migrated=Store(self.path)
        self.assertEqual(migrated.records()[0],[])
        migrated.set_roles(False)
        self.assertEqual(len(migrated.records()[0]),1)
    def test_old_schema_migrates_without_losing_rows(self):
        path=Path(self.tmp.name)/'old.sqlite3'
        import sqlite3
        with sqlite3.connect(path) as c:
            c.execute('CREATE TABLE emails(id INTEGER PRIMARY KEY,email TEXT UNIQUE COLLATE NOCASE,source TEXT,status TEXT,reason TEXT,discovered TEXT DEFAULT CURRENT_TIMESTAMP,deleted INTEGER DEFAULT 0)')
            c.execute("INSERT INTO emails(email,source,status,reason) VALUES('jane@public.org','old source','Unverified','Syntax valid')")
        store=Store(path);self.assertEqual(store.records()[0][0]['source'],'old source')

class RedirectTests(unittest.TestCase):
    def test_policy_checked_before_each_redirected_page(self):
        from email.message import Message
        from crawler import RobotsRestricted
        headers=Message();headers['Content-Type']='text/html'
        requests=[];policy=[]
        class Connection:
            def __init__(self,host,ip,port):self.host=host
            def connect(self):pass
            def request(self,method,path,headers):requests.append((self.host,path))
            def getresponse(self):
                class Response:
                    status=302;reason='Found'
                    def getheader(self,k):return 'https://target.org/private'
                return Response()
            def close(self):pass
        def check(url):
            policy.append(url)
            if 'target.org' in url:raise RobotsRestricted('denied')
        with patch('crawler.destination',side_effect=lambda url:(urllib.parse.urlsplit(url),['1.1.1.1'])),patch('crawler.urllib.request.getproxies',return_value={}),patch('crawler.PinnedHTTPS',Connection):
            with self.assertRaises(RobotsRestricted):Network().crawl_fetch('https://start.org/',check)
        self.assertEqual(policy,['https://start.org/','https://target.org/private'])
        self.assertEqual(requests,[('start.org','/')])
    def test_redirect_to_private_ip_rejected_before_connection(self):
        from crawler import GuardRedirect
        with patch('crawler.resolve_addresses',return_value=['10.0.0.1']):
            with self.assertRaises(ValueError):GuardRedirect().redirect_request(None,None,302,'Found',{},'http://10.0.0.1/')
    def test_redirected_site_follows_deeper_links_and_keeps_one_site(self):
        with tempfile.TemporaryDirectory() as tmp:
            class Moved(FixtureNetwork):
                def fetch(self,url,limit=0):
                    if url=='https://old.org/':return '<a href="/contact">Contact</a>','https://new.org/'
                    return 'jane@new.org',url
            store=Store(Path(tmp)/'db.sqlite3');c=Crawler(store,Moved(),0)
            c.start(['https://old.org/'],depth=2);c.worker.join(5)
            self.assertEqual(c.status()['sites'],1);self.assertEqual(c.status()['pages'],2)
            self.assertEqual(store.records()[0][0]['email'],'jane@new.org')

class TransportTests(unittest.TestCase):
    def test_tries_next_validated_address_after_ipv6_failure(self):
        attempted=[]
        class Connection:
            def __init__(self,host,ip,port):self.ip=ip
            def connect(self):
                attempted.append(self.ip)
                if ':' in self.ip:raise OSError('IPv6 unavailable')
            def close(self):pass
        with patch('crawler.PinnedHTTPS',Connection):
            c=Network.connection(urllib.parse.urlsplit('https://public.org'),['2606:4700:4700::1111','1.1.1.1'])
        self.assertEqual(c.ip,'1.1.1.1');self.assertEqual(len(attempted),2)
    def test_gzip_decoding_and_expansion_limit(self):
        from email.message import Message
        import gzip
        headers=Message();headers['Content-Type']='text/html';headers['Content-Encoding']='gzip'
        data=gzip.compress(b'jane@public.org')
        self.assertEqual(Network.decode(data,headers,100),'jane@public.org')
        with self.assertRaises(ValueError):Network.decode(gzip.compress(b'x'*1000),headers,100)

class DestinationDNSTests(unittest.TestCase):
    def test_literal_addresses_do_not_use_dns(self):
        from crawler import resolve_addresses
        self.assertEqual(resolve_addresses('1.1.1.1'),['1.1.1.1'])
    def test_dns_timeout_is_reported(self):
        from crawler import resolve_addresses
        class Resolver:
            def resolve(self,*args,**kwargs):raise dns.exception.Timeout()
        with self.assertRaises(TimeoutError):resolve_addresses('public.org',Resolver())

class PrefixRuleTests(TempStore):
    def test_prefix_with_at_does_not_remove_longer_local_names(self):
        self.store.insert('info@public.org','test');self.store.insert('information@public.org','test')
        self.assertEqual(self.store.rule('prefix','info@',True),1)
        self.assertEqual(self.store.rule('prefix','info',True),2)
        with self.assertRaises(ValueError):self.store.rule('prefix','@')
